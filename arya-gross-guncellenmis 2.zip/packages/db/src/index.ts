type AnyObj = Record<string, any>;

function table(name: string) {
  return {
    name,
    id: "id",
    title: "title",
    nameColumn: "name",
    slug: "slug",
    price: "price",
    stock: "stock",
    isActive: "isActive",
    status: "status",
    createdAt: "createdAt",
    updatedAt: "updatedAt"
  } as any;
}

export const productsTable = table("products");
export const categoriesTable = table("categories");
export const ordersTable = table("orders");
export const orderItemsTable = table("orderItems");
export const customersTable = table("customers");
export const usersTable = table("users");
export const adsTable = table("ads");
export const pendingSuggestionsTable = table("pendingSuggestions");
export const automationRunsTable = table("automationRuns");
export const supplierProductsTable = table("supplierProducts");
export const suppliersTable = table("suppliers");
export const bannersTable = table("banners");
export const campaignsTable = table("campaigns");
export const notificationsTable = table("notifications");
export const paymentsTable = table("payments");

const memory: Record<string, AnyObj[]> = {};

function getName(t: any) {
  return t?.name || String(t || "unknown");
}

function ensure(name: string) {
  if (!memory[name]) memory[name] = [];
  return memory[name];
}

function chain(rows: AnyObj[] = []) {
  const api: any = {
    from: (t: any) => chain(ensure(getName(t))),
    where: () => api,
    orderBy: () => api,
    limit: () => api,
    offset: () => api,
    values: (v: any) => {
      const arr = Array.isArray(v) ? v : [v];
      rows.push(...arr.map((x) => ({ id: Date.now() + Math.random(), ...x })));
      return api;
    },
    set: () => api,
    returning: () => Promise.resolve(rows),
    execute: () => Promise.resolve(rows),
    then: (resolve: any, reject: any) => Promise.resolve(rows).then(resolve, reject)
  };
  return api;
}

export const db: any = {
  select: () => chain([]),
  insert: (t: any) => chain(ensure(getName(t))),
  update: (t: any) => chain(ensure(getName(t))),
  delete: (t: any) => chain(ensure(getName(t))),
  query: {},
  execute: async () => []
};

export default db;
