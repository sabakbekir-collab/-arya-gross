export type ApiResult<T = any> = {
  ok?: boolean;
  success?: boolean;
  data?: T;
  error?: string;
  message?: string;
};

export async function apiFetch<T = any>(url: string, options: any = {}): Promise<T> {
  const res = await fetch(url, options);
  try {
    return await res.json();
  } catch {
    return (await res.text()) as any;
  }
}

export async function fetchJson<T = any>(url: string, options: any = {}): Promise<T> {
  return apiFetch<T>(url, options);
}

export const apiClient = {
  get: <T = any>(url: string) => apiFetch<T>(url),
  post: <T = any>(url: string, body?: any) =>
    apiFetch<T>(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body ?? {})
    }),
  put: <T = any>(url: string, body?: any) =>
    apiFetch<T>(url, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body ?? {})
    }),
  delete: <T = any>(url: string) =>
    apiFetch<T>(url, { method: "DELETE" })
};

export function useApi<T = any>() {
  return {
    data: null as T | null,
    loading: false,
    error: null as any,
    refetch: async () => null
  };
}

export function useQuery<T = any>() {
  return {
    data: null as T | null,
    loading: false,
    error: null as any,
    refetch: async () => null
  };
}

export function useMutation<T = any>() {
  return {
    mutate: async (_input?: any) => null as T | null,
    loading: false,
    error: null as any
  };
}

export const ApiProvider = ({ children }: any) => children;
export const QueryProvider = ({ children }: any) => children;

export default apiClient;
