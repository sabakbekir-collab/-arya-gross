/**
 * @workspace/api-zod — tam export
 * lib/api-zod/src/generated/api.ts içeriği buraya kopyalandı.
 * pnpm-workspace.yaml yalnızca packages/* ve artifacts/* içerdiğinden
 * lib/api-zod doğrudan workspace paketi olarak kullanılamaz.
 */
import * as zod from "zod";

export { zod };

// ── helpers ────────────────────────────────────────────────
export function ok(data: unknown = {}) {
  return { success: true, ok: true, data };
}
export function fail(message = "Hata") {
  return { success: false, ok: false, error: message, message };
}

// ── Health ─────────────────────────────────────────────────
export const HealthCheckResponse = zod.object({ status: zod.string() });

// ── Dashboard ──────────────────────────────────────────────
export const GetDashboardSummaryResponse = zod.object({
  totalRevenue: zod.number(),
  totalOrders: zod.number(),
  totalProducts: zod.number(),
  lowStockCount: zod.number(),
  pendingOrders: zod.number(),
  todayRevenue: zod.number(),
});

export const GetTopProductsResponseItem = zod.object({
  productId: zod.number(),
  name: zod.string(),
  totalSold: zod.number(),
  revenue: zod.number(),
  viralPotential: zod.string(),
});
export const GetTopProductsResponse = zod.array(GetTopProductsResponseItem);

const orderItemShape = zod.object({
  productId: zod.number(),
  name: zod.string(),
  price: zod.number(),
  quantity: zod.number(),
  subtotal: zod.number(),
});

const orderShape = zod.object({
  id: zod.number(),
  customerName: zod.string().nullish(),
  customerEmail: zod.string().nullish(),
  customerPhone: zod.string().nullish(),
  address: zod.string().nullish(),
  notes: zod.string().nullish(),
  status: zod.string(),
  paymentMethod: zod.string().nullish(),
  orderType: zod.string().nullish(),
  adminApprovalStatus: zod.string().nullish(),
  sourcingStatus: zod.string().nullish(),
  supplierPurchaseStatus: zod.string().nullish(),
  profitEstimate: zod.number().nullish(),
  paymentStatus: zod.string().nullish(),
  decontStatus: zod.string().nullish(),
  paymentConfirmedBy: zod.string().nullish(),
  paymentConfirmedAt: zod.string().nullish(),
  total: zod.number(),
  items: zod.array(orderItemShape),
  createdAt: zod.string(),
});

export const GetRecentOrdersResponseItem = orderShape;
export const GetRecentOrdersResponse = zod.array(GetRecentOrdersResponseItem);

// ── Categories ─────────────────────────────────────────────
export const ListCategoriesResponseItem = zod.object({
  id: zod.number(),
  name: zod.string(),
  description: zod.string().nullish(),
  createdAt: zod.string(),
});
export const ListCategoriesResponse = zod.array(ListCategoriesResponseItem);

export const CreateCategoryBody = zod.object({
  name: zod.string(),
  description: zod.string().optional(),
});

export const DeleteCategoryParams = zod.object({ id: zod.coerce.number() });

// ── Products ───────────────────────────────────────────────
export const ListProductsQueryParams = zod.object({
  categoryId: zod.coerce.number().nullish(),
  search: zod.coerce.string().nullish(),
  inStock: zod.coerce.boolean().nullish(),
  productStatus: zod.coerce.string().nullish(),
});

const productResponseShape = zod.object({
  id: zod.number(),
  name: zod.string(),
  description: zod.string().nullish(),
  price: zod.number(),
  costPrice: zod.number().nullish(),
  stock: zod.number(),
  categoryId: zod.number().nullish(),
  categoryName: zod.string().nullish(),
  imageUrl: zod.string().nullish(),
  keywords: zod.string().nullish(),
  isActive: zod.boolean().optional(),
  supplierName: zod.string().nullish(),
  supplierProductUrl: zod.string().nullish(),
  supplierPrice: zod.number().nullish(),
  riskScore: zod.number().nullish(),
  demandScore: zod.number().nullish(),
  opportunityScore: zod.number().nullish(),
  productStatus: zod.string().nullish(),
  estimatedShippingDays: zod.number().nullish(),
  createdAt: zod.string(),
});

export const ListProductsResponseItem = productResponseShape;
export const ListProductsResponse = zod.array(ListProductsResponseItem);

export const CreateProductBody = zod.object({
  name: zod.string(),
  description: zod.string().optional(),
  price: zod.number(),
  costPrice: zod.number().optional(),
  stock: zod.number(),
  categoryId: zod.number().optional(),
  imageUrl: zod.string().optional(),
  keywords: zod.string().optional(),
  supplierName: zod.string().optional(),
  supplierProductUrl: zod.string().optional(),
  supplierPrice: zod.number().optional(),
  riskScore: zod.number().optional(),
  demandScore: zod.number().optional(),
  opportunityScore: zod.number().optional(),
  productStatus: zod.string().optional(),
  estimatedShippingDays: zod.number().optional(),
});

export const GetProductParams = zod.object({ id: zod.coerce.number() });
export const GetProductResponse = productResponseShape;

export const UpdateProductParams = zod.object({ id: zod.coerce.number() });
export const UpdateProductBody = zod.object({
  name: zod.string().optional(),
  description: zod.string().optional(),
  price: zod.number().optional(),
  costPrice: zod.number().optional(),
  stock: zod.number().optional(),
  categoryId: zod.number().optional(),
  imageUrl: zod.string().optional(),
  keywords: zod.string().optional(),
  isActive: zod.boolean().optional(),
  supplierName: zod.string().optional(),
  supplierProductUrl: zod.string().optional(),
  supplierPrice: zod.number().optional(),
  riskScore: zod.number().optional(),
  demandScore: zod.number().optional(),
  opportunityScore: zod.number().optional(),
  productStatus: zod.string().optional(),
  estimatedShippingDays: zod.number().optional(),
});
export const UpdateProductResponse = productResponseShape;

export const DeleteProductParams = zod.object({ id: zod.coerce.number() });

export const UpdateStockParams = zod.object({ id: zod.coerce.number() });
export const UpdateStockBody = zod.object({ stock: zod.number() });
export const UpdateStockResponse = productResponseShape;

// ── Cart ───────────────────────────────────────────────────
const cartItemShape = zod.object({
  productId: zod.number(),
  name: zod.string(),
  price: zod.number(),
  quantity: zod.number(),
  subtotal: zod.number(),
  imageUrl: zod.string().nullish(),
});
const cartResponseShape = zod.object({
  items: zod.array(cartItemShape),
  total: zod.number(),
  itemCount: zod.number(),
});

export const GetCartResponse = cartResponseShape;
export const AddToCartBody = zod.object({ productId: zod.number(), quantity: zod.number() });
export const AddToCartResponse = cartResponseShape;
export const UpdateCartItemParams = zod.object({ productId: zod.coerce.number() });
export const UpdateCartItemBody = zod.object({ quantity: zod.number() });
export const UpdateCartItemResponse = cartResponseShape;
export const RemoveFromCartParams = zod.object({ productId: zod.coerce.number() });
export const RemoveFromCartResponse = cartResponseShape;
export const ClearCartResponse = cartResponseShape;

// ── Orders ─────────────────────────────────────────────────
export const ListOrdersQueryParams = zod.object({ status: zod.coerce.string().nullish() });
export const ListOrdersResponseItem = orderShape;
export const ListOrdersResponse = zod.array(ListOrdersResponseItem);

export const CreateOrderBody = zod.object({
  customerName: zod.string().optional(),
  customerEmail: zod.string().optional(),
  customerPhone: zod.string().optional(),
  address: zod.string().optional(),
  notes: zod.string().optional(),
  paymentMethod: zod.string().optional(),
  orderType: zod.string().optional(),
  items: zod.array(zod.object({ productId: zod.number(), quantity: zod.number() })),
});

export const GetOrderParams = zod.object({ id: zod.coerce.number() });
export const GetOrderResponse = orderShape;

export const UpdateOrderPaymentStatusParams = zod.object({ id: zod.coerce.number() });
export const UpdateOrderPaymentStatusBody = zod.object({
  paymentStatus: zod.string().optional(),
  decontStatus: zod.string().optional(),
  paymentConfirmedBy: zod.string().optional(),
});
export const UpdateOrderPaymentStatusResponse = orderShape;

export const UpdateOrderStatusParams = zod.object({ id: zod.coerce.number() });
export const UpdateOrderStatusBody = zod.object({
  status: zod.string(),
  adminApprovalStatus: zod.string().optional(),
  sourcingStatus: zod.string().optional(),
  supplierPurchaseStatus: zod.string().optional(),
});
export const UpdateOrderStatusResponse = orderShape;

// ── Import ─────────────────────────────────────────────────
export const ImportProductsBody = zod.object({
  products: zod.array(zod.object({
    name: zod.string(),
    brand: zod.string().optional(),
    category: zod.string().optional(),
    supplierName: zod.string().optional(),
    supplierPrice: zod.number().optional(),
    price: zod.number(),
    stock: zod.number(),
    description: zod.string().optional(),
    imageUrl: zod.string().optional(),
  })),
});
export const ImportProductsResponse = zod.object({
  imported: zod.number(),
  skipped: zod.number(),
  errors: zod.array(zod.string()),
});

// ── AI ─────────────────────────────────────────────────────
export const AiGenerateProductBody = zod.object({ idea: zod.string() });
export const AiGenerateProductResponse = zod.object({
  name: zod.string(),
  description: zod.string(),
  suggestedPrice: zod.number(),
  estimatedCost: zod.number(),
  estimatedProfit: zod.number(),
  category: zod.string(),
  keywords: zod.string(),
  imageIdea: zod.string(),
  viralPotential: zod.string(),
});

export const AiOptimizePriceBody = zod.object({
  productId: zod.number(),
  targetMargin: zod.number().optional(),
});
export const AiOptimizePriceResponse = zod.object({
  currentPrice: zod.number(),
  suggestedPrice: zod.number(),
  estimatedRevenueLift: zod.number(),
  reasoning: zod.string(),
});

// ── Ads ────────────────────────────────────────────────────
export const GenerateAdBody = zod.object({
  productId: zod.number(),
  platform: zod.string().optional(),
});
export const GenerateAdResponse = zod.object({
  hook: zod.string(),
  scenario: zod.string(),
  videoIdea: zod.string(),
  adText: zod.string(),
  hashtags: zod.array(zod.string()),
  emotionalTitle: zod.string(),
  cta: zod.string(),
  platform: zod.string(),
});

export const ListAdsResponseItem = zod.object({
  id: zod.number(),
  productId: zod.number(),
  productName: zod.string(),
  platform: zod.string(),
  hook: zod.string(),
  scenario: zod.string().optional(),
  videoIdea: zod.string().optional(),
  adText: zod.string().optional(),
  hashtags: zod.array(zod.string()).optional(),
  emotionalTitle: zod.string().optional(),
  cta: zod.string().optional(),
  createdAt: zod.string(),
});
export const ListAdsResponse = zod.array(ListAdsResponseItem);

// ── Revenue ────────────────────────────────────────────────
export const GetRevenueAnalysisResponse = zod.object({
  topPerformers: zod.array(zod.object({
    productId: zod.number(),
    name: zod.string(),
    revenue: zod.number(),
    margin: zod.number(),
    recommendation: zod.string(),
  })),
  underperformers: zod.array(zod.object({
    productId: zod.number(),
    name: zod.string(),
    revenue: zod.number(),
    margin: zod.number(),
    recommendation: zod.string(),
  })),
  priceOptimizations: zod.array(zod.object({
    productId: zod.number(),
    name: zod.string(),
    currentPrice: zod.number(),
    suggestedPrice: zod.number(),
    reason: zod.string(),
  })),
  conversionTips: zod.array(zod.string()),
  totalPotentialRevenue: zod.number(),
});

export const GetViralScoreParams = zod.object({ productId: zod.coerce.number() });
export const GetViralScoreResponse = zod.object({
  productId: zod.number(),
  score: zod.number(),
  level: zod.string(),
  factors: zod.array(zod.string()),
  tips: zod.array(zod.string()),
});

// ── legacy passthrough aliases (backward compat) ───────────
export const idSchema = zod.union([zod.string(), zod.number()]);
export const emptySchema = zod.object({}).passthrough();
export const productSchema = zod.object({}).passthrough();
export const orderSchema = zod.object({}).passthrough();
export const categorySchema = zod.object({}).passthrough();
export const userSchema = zod.object({}).passthrough();
export const customerSchema = zod.object({}).passthrough();
export const supplierSchema = zod.object({}).passthrough();
export const supplierProductSchema = zod.object({}).passthrough();
export const pendingSuggestionSchema = zod.object({}).passthrough();
export const automationRunSchema = zod.object({}).passthrough();
