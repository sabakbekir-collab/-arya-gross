-- Safe additive migration: no DROP, TRUNCATE, or modification of existing records.
CREATE TABLE IF NOT EXISTS customers (
  id serial PRIMARY KEY, name text NOT NULL, email text, phone text NOT NULL,
  default_address text, created_at timestamp NOT NULL DEFAULT now(), updated_at timestamp NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS customers_phone_unique ON customers (phone);
CREATE TABLE IF NOT EXISTS carts (
  id serial PRIMARY KEY, session_id text NOT NULL, customer_id integer,
  created_at timestamp NOT NULL DEFAULT now(), updated_at timestamp NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS carts_session_unique ON carts (session_id);
CREATE TABLE IF NOT EXISTS cart_items (
  id serial PRIMARY KEY, cart_id integer NOT NULL, product_id integer NOT NULL, quantity integer NOT NULL CHECK (quantity > 0),
  created_at timestamp NOT NULL DEFAULT now(), updated_at timestamp NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS cart_items_cart_product_unique ON cart_items (cart_id, product_id);
CREATE TABLE IF NOT EXISTS favorites (
  id serial PRIMARY KEY, customer_id integer, session_id text NOT NULL, product_id integer NOT NULL,
  created_at timestamp NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS favorites_session_product_unique ON favorites (session_id, product_id);
CREATE TABLE IF NOT EXISTS coupons (
  id serial PRIMARY KEY, code text NOT NULL, type text NOT NULL CHECK (type IN ('percent', 'fixed')),
  value numeric(10,2) NOT NULL CHECK (value > 0), minimum_subtotal numeric(10,2) NOT NULL DEFAULT 0,
  usage_limit integer, used_count integer NOT NULL DEFAULT 0, is_active boolean NOT NULL DEFAULT true,
  starts_at timestamp, expires_at timestamp, created_at timestamp NOT NULL DEFAULT now(), updated_at timestamp NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS coupons_code_unique ON coupons (code);
