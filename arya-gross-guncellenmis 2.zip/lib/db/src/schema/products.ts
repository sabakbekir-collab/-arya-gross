import { pgTable, serial, text, timestamp, integer, numeric, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const productsTable = pgTable("products", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  price: numeric("price", { precision: 10, scale: 2 }).notNull(),
  costPrice: numeric("cost_price", { precision: 10, scale: 2 }),
  stock: integer("stock").notNull().default(0),
  categoryId: integer("category_id"),
  imageUrl: text("image_url"),
  keywords: text("keywords"),
  brand: text("brand"),
  barcode: text("barcode"),
  isActive: boolean("is_active").notNull().default(true),
  supplierName: text("supplier_name"),
  supplierProductUrl: text("supplier_product_url"),
  supplierPrice: numeric("supplier_price", { precision: 10, scale: 2 }),
  riskScore: integer("risk_score").default(0),
  demandScore: integer("demand_score").default(0),
  opportunityScore: integer("opportunity_score").default(0),
  productStatus: text("product_status").default("draft"),
  estimatedShippingDays: integer("estimated_shipping_days").default(2),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertProductSchema = createInsertSchema(productsTable).omit({ id: true, createdAt: true });
export type InsertProduct = z.infer<typeof insertProductSchema>;
export type Product = typeof productsTable.$inferSelect;
