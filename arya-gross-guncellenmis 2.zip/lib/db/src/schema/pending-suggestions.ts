import { pgTable, serial, text, timestamp, integer, numeric, jsonb, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const pendingSuggestionsTable = pgTable("pending_product_suggestions", {
  id: serial("id").primaryKey(),
  // Origin
  source: text("source").notNull().default("automation"),
  runId: integer("run_id"),
  // Product info
  name: text("name").notNull(),
  brand: text("brand"),
  barcode: text("barcode"),
  categoryId: integer("category_id"),
  categoryName: text("category_name"),
  description: text("description"),
  imageUrl: text("image_url"),
  stock: integer("stock").default(0),
  // Pricing
  estimatedSellPrice: numeric("estimated_sell_price", { precision: 10, scale: 2 }).notNull(),
  estimatedCostPrice: numeric("estimated_cost_price", { precision: 10, scale: 2 }),
  profitMargin: integer("profit_margin"),
  // Supplier
  supplierVerified: boolean("supplier_verified").default(false),
  supplierShippingDays: integer("supplier_shipping_days"),
  supplierName: text("supplier_name"),
  supplierProductUrl: text("supplier_product_url"),
  supplierLinks: jsonb("supplier_links").$type<{
    trendyol: string;
    hepsiburada: string;
    n11: string;
    cimri: string;
  }>(),
  // Marketing
  adText: jsonb("ad_text").$type<{
    tiktok: string;
    instagram: string;
    google: string;
    whatsapp: string;
  }>(),
  campaignReason: text("campaign_reason"),
  // Scores
  demandScore: integer("demand_score").default(0),
  riskScore: integer("risk_score").default(0),
  opportunityScore: integer("opportunity_score").default(0),
  isCampaignCandidate: boolean("is_campaign_candidate").default(false),
  suggestedDiscount: integer("suggested_discount"),
  // Multi-supplier offers
  supplierOffers: jsonb("supplier_offers").$type<Array<{
    supplierName: string;
    supplierUrl: string;
    price: number;
    verified: boolean;
    httpStatus: number | string;
  }>>(),
  linkBroken: boolean("link_broken").default(false),
  // Status
  status: text("status").notNull().default("pending"),
  rejectedReason: text("rejected_reason"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertPendingSuggestionSchema = createInsertSchema(pendingSuggestionsTable).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertPendingSuggestion = z.infer<typeof insertPendingSuggestionSchema>;
export type PendingSuggestion = typeof pendingSuggestionsTable.$inferSelect;
