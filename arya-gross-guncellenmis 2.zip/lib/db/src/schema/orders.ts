import { pgTable, serial, text, timestamp, integer, numeric, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const ordersTable = pgTable("orders", {
  id: serial("id").primaryKey(),
  customerName: text("customer_name"),
  customerEmail: text("customer_email"),
  customerPhone: text("customer_phone"),
  address: text("address"),
  notes: text("notes"),
  status: text("status").notNull().default("beklemede"),
  // V5: Ödeme & Tedarik alanları
  paymentMethod: text("payment_method").default("kapida"),
  orderType: text("order_type").default("normal"),
  adminApprovalStatus: text("admin_approval_status").default("bekliyor"),
  sourcingStatus: text("sourcing_status").default("bekliyor"),
  supplierPurchaseStatus: text("supplier_purchase_status"),
  profitEstimate: numeric("profit_estimate", { precision: 10, scale: 2 }),
  paymentStatus: text("payment_status").default("odeme-bekleniyor"),
  decontStatus: text("decont_status").default("bekleniyor"),
  paymentConfirmedBy: text("payment_confirmed_by"),
  paymentConfirmedAt: timestamp("payment_confirmed_at"),
  total: numeric("total", { precision: 10, scale: 2 }).notNull(),
  items: jsonb("items").notNull().$type<Array<{
    productId: number;
    name: string;
    price: number;
    quantity: number;
    subtotal: number;
  }>>(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertOrderSchema = createInsertSchema(ordersTable).omit({ id: true, createdAt: true });
export type InsertOrder = z.infer<typeof insertOrderSchema>;
export type Order = typeof ordersTable.$inferSelect;
