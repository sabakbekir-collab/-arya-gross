import { pgTable, serial, text, timestamp, integer, numeric, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const supplierProductsTable = pgTable("supplier_products", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  brand: text("brand"),
  category: text("category"),
  barcode: text("barcode"),
  supplierName: text("supplier_name"),
  supplierUrl: text("supplier_url"),
  imageUrl: text("image_url"),
  supplierPrice: numeric("supplier_price", { precision: 10, scale: 2 }),
  suggestedSalePrice: numeric("suggested_sale_price", { precision: 10, scale: 2 }),
  stock: integer("stock").default(0),
  source: text("source").default("csv"),
  isActive: boolean("is_active").notNull().default(true),
  estimatedShippingDays: integer("estimated_shipping_days").default(3),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertSupplierProductSchema = createInsertSchema(supplierProductsTable).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertSupplierProduct = z.infer<typeof insertSupplierProductSchema>;
export type SupplierProduct = typeof supplierProductsTable.$inferSelect;
