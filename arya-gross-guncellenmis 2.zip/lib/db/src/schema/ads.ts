import { pgTable, serial, text, timestamp, integer, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const adsTable = pgTable("ads", {
  id: serial("id").primaryKey(),
  productId: integer("product_id").notNull(),
  productName: text("product_name").notNull(),
  platform: text("platform").notNull().default("tiktok"),
  hook: text("hook").notNull(),
  scenario: text("scenario"),
  videoIdea: text("video_idea"),
  adText: text("ad_text"),
  hashtags: jsonb("hashtags").$type<string[]>().default([]),
  emotionalTitle: text("emotional_title"),
  cta: text("cta"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertAdSchema = createInsertSchema(adsTable).omit({ id: true, createdAt: true });
export type InsertAd = z.infer<typeof insertAdSchema>;
export type Ad = typeof adsTable.$inferSelect;
