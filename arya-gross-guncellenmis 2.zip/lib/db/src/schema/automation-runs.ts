import { pgTable, serial, text, timestamp, integer, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const automationRunsTable = pgTable("automation_runs", {
  id: serial("id").primaryKey(),
  status: text("status").notNull().default("running"),
  triggeredBy: text("triggered_by").notNull().default("manual"),
  summary: jsonb("summary").$type<{
    scannedProducts: number;
    suggestionsGenerated: number;
    campaignCandidates: number;
    adsGenerated: number;
    errorsFound: number;
  }>(),
  errorMessage: text("error_message"),
  durationMs: integer("duration_ms"),
  startedAt: timestamp("started_at").defaultNow().notNull(),
  completedAt: timestamp("completed_at"),
});

export const insertAutomationRunSchema = createInsertSchema(automationRunsTable).omit({ id: true, startedAt: true });
export type InsertAutomationRun = z.infer<typeof insertAutomationRunSchema>;
export type AutomationRun = typeof automationRunsTable.$inferSelect;
