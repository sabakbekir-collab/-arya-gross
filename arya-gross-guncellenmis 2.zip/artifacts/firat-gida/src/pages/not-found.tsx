import { Link } from "wouter";
import { Home, ShoppingBag, Search } from "lucide-react";

export default function NotFound() {
  return (
    <div className="min-h-screen w-full flex items-center justify-center bg-gray-50 px-4">
      <div className="text-center max-w-md">
        <div className="text-[120px] font-black text-[#DC2626] leading-none select-none">
          404
        </div>
        <h1 className="text-2xl font-bold text-gray-900 mt-2 mb-3">
          Sayfa Bulunamadı
        </h1>
        <p className="text-gray-500 text-sm leading-relaxed mb-8">
          Aradığınız sayfa taşınmış, silinmiş ya da hiç var olmamış olabilir.
        </p>
        <div className="flex flex-col sm:flex-row gap-3 justify-center">
          <Link href="/magaza">
            <button className="inline-flex items-center gap-2 bg-[#DC2626] text-white font-semibold px-6 py-3 rounded-xl hover:bg-[#b91c1c] transition-colors w-full sm:w-auto justify-center">
              <Home className="h-4 w-4" />
              Ana Sayfaya Dön
            </button>
          </Link>
          <Link href="/magaza/urunler">
            <button className="inline-flex items-center gap-2 bg-white text-gray-700 font-semibold px-6 py-3 rounded-xl border border-gray-200 hover:bg-gray-50 transition-colors w-full sm:w-auto justify-center">
              <ShoppingBag className="h-4 w-4" />
              Ürünlere Göz At
            </button>
          </Link>
        </div>
        <div className="mt-8 pt-6 border-t border-gray-100">
          <p className="text-xs text-gray-400 flex items-center justify-center gap-1">
            <Search className="h-3 w-3" />
            Üst taraftaki arama kutusunu kullanarak ürün arayabilirsiniz.
          </p>
        </div>
      </div>
    </div>
  );
}
