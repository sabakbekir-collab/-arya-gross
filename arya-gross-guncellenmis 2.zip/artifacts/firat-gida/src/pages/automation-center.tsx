import AryaOtomasyon from "./arya-otomasyon";

export default function AutomationCenter() {
  return (
    <div className="min-h-screen bg-[#0b0b0b]">
      <div className="border-b border-neutral-800 px-5 py-4">
        <h1 className="text-2xl font-black text-white">Admin Paneli — Otomasyon Merkezi</h1>
        <p className="text-sm text-neutral-400 mt-1">
          Arya ve tedarikçi otomasyon çalıştırmalarını buradan yönetin.
        </p>
      </div>

      <AryaOtomasyon />
    </div>
  );
}
