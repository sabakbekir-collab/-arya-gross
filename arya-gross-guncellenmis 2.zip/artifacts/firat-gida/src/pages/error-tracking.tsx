import { useListProducts, useListOrders } from "@workspace/api-client-react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { AlertCircle, CheckCircle2, XCircle, AlertTriangle } from "lucide-react";
import { useMemo } from "react";

const WHATSAPP_PHONE = import.meta.env.VITE_WHATSAPP_PHONE || "";

const LEVEL_MAP = {
  error:   { label: "Kritik",   icon: XCircle,       color: "text-red-400",    bg: "bg-red-500/20",    badge: "bg-red-500/20 text-red-400 border-red-500/30" },
  warning: { label: "Uyarı",    icon: AlertTriangle,  color: "text-yellow-400", bg: "bg-yellow-500/20", badge: "bg-yellow-500/20 text-yellow-400 border-yellow-500/30" },
  info:    { label: "Bilgi",     icon: AlertCircle,    color: "text-blue-400",   bg: "bg-blue-500/20",   badge: "bg-blue-500/20 text-blue-400 border-blue-500/30" },
  success: { label: "Başarılı",  icon: CheckCircle2,   color: "text-green-400",  bg: "bg-green-500/20",  badge: "bg-green-500/20 text-green-400 border-green-500/30" },
};

interface SystemCheck {
  id: string;
  level: keyof typeof LEVEL_MAP;
  message: string;
  module: string;
  resolved: boolean;
}

export default function ErrorTracking() {
  const { data: products } = useListProducts();
  const { data: orders } = useListOrders();

  const checks = useMemo<SystemCheck[]>(() => {
    const list: SystemCheck[] = [];

    const criticalStock = (products || []).filter(p => p.stock < 5);
    const lowStock     = (products || []).filter(p => p.stock >= 5 && p.stock < 15);
    const noImage      = (products || []).filter(p => p.productStatus === "active" && !p.imageUrl);

    if (criticalStock.length > 0) {
      list.push({
        id: "stock-critical",
        level: "error",
        message: `${criticalStock.length} ürün kritik stok seviyesinde: ${criticalStock.slice(0, 3).map(p => p.name).join(", ")}`,
        module: "Stok Sistemi",
        resolved: false,
      });
    }

    if (lowStock.length > 0) {
      list.push({
        id: "stock-low",
        level: "warning",
        message: `${lowStock.length} ürün düşük stok seviyesinde`,
        module: "Stok Sistemi",
        resolved: false,
      });
    }

    if (!WHATSAPP_PHONE || WHATSAPP_PHONE === "905352765849") {
      // WhatsApp is configured to default, mark as info
      list.push({
        id: "wa-configured",
        level: "success",
        message: "WhatsApp sipariş hattı aktif",
        module: "WhatsApp Entegrasyonu",
        resolved: true,
      });
    }

    if (noImage.length > 0) {
      list.push({
        id: "no-image",
        level: "warning",
        message: `${noImage.length} yayında ürün görselsiz`,
        module: "Ürün Yönetimi",
        resolved: false,
      });
    }

    const pendingOrders = (orders || []).filter(o => o.status === "beklemede");
    if (pendingOrders.length > 5) {
      list.push({
        id: "pending-overflow",
        level: "warning",
        message: `${pendingOrders.length} sipariş onay bekliyor`,
        module: "Sipariş Yönetimi",
        resolved: false,
      });
    }

    if ((products || []).length > 0) {
      list.push({
        id: "db-ok",
        level: "success",
        message: "Veritabanı bağlantısı aktif",
        module: "Sistem",
        resolved: true,
      });
    }

    list.push({
      id: "api-ok",
      level: "success",
      message: "API sunucusu çalışıyor",
      module: "Sistem",
      resolved: true,
    });

    list.sort((a, b) => (a.resolved ? 1 : 0) - (b.resolved ? 1 : 0));
    return list;
  }, [products, orders]);

  const active   = checks.filter(e => !e.resolved);
  const resolved = checks.filter(e => e.resolved);

  return (
    <div className="space-y-4 animate-in fade-in duration-500">
      <div className="flex items-start gap-3">
        <div className="w-10 h-10 bg-red-500/20 rounded-xl flex items-center justify-center shrink-0 border border-red-500/30">
          <AlertCircle className="h-5 w-5 text-red-400" />
        </div>
        <div>
          <h1 className="text-xl font-black">🚨 Sistem Durumu</h1>
          <p className="text-xs text-muted-foreground mt-0.5">Stok, sipariş ve sistem sağlık kontrolleri</p>
        </div>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {[
          { label: "Kritik",   val: checks.filter(e => e.level === "error").length,   color: "text-red-400" },
          { label: "Uyarı",    val: checks.filter(e => e.level === "warning").length,  color: "text-yellow-400" },
          { label: "Bilgi",    val: checks.filter(e => e.level === "info").length,     color: "text-blue-400" },
          { label: "Başarılı", val: checks.filter(e => e.level === "success").length,  color: "text-green-400" },
        ].map(s => (
          <Card key={s.label} className="border-border bg-card/60">
            <CardContent className="p-3">
              <div className="text-[10px] text-muted-foreground uppercase tracking-wider mb-1">{s.label}</div>
              <div className={`text-2xl font-black ${s.color}`}>{s.val}</div>
            </CardContent>
          </Card>
        ))}
      </div>

      {active.length > 0 && (
        <div className="space-y-2">
          <h2 className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Aktif Uyarılar</h2>
          {active.map(e => {
            const lvl = LEVEL_MAP[e.level];
            const Icon = lvl.icon;
            return (
              <Card key={e.id} className={`border bg-card/60`} style={{ borderColor: "rgba(var(--border), 0.5)" }}>
                <CardContent className="p-3 flex items-center gap-3">
                  <div className={`w-8 h-8 ${lvl.bg} rounded-lg flex items-center justify-center shrink-0`}>
                    <Icon className={`h-4 w-4 ${lvl.color}`} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">{e.message}</p>
                    <p className="text-[11px] text-muted-foreground">{e.module}</p>
                  </div>
                  <Badge className={`text-[9px] shrink-0 ${lvl.badge}`}>{lvl.label}</Badge>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      {resolved.length > 0 && (
        <div className="space-y-2">
          <h2 className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Başarılı Kontroller</h2>
          {resolved.map(e => {
            const lvl = LEVEL_MAP[e.level];
            const Icon = lvl.icon;
            return (
              <Card key={e.id} className="border-border bg-card/40 opacity-70">
                <CardContent className="p-3 flex items-center gap-3">
                  <div className={`w-8 h-8 ${lvl.bg} rounded-lg flex items-center justify-center shrink-0`}>
                    <Icon className={`h-4 w-4 ${lvl.color}`} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">{e.message}</p>
                    <p className="text-[11px] text-muted-foreground">{e.module}</p>
                  </div>
                  <Badge className={`text-[9px] shrink-0 ${lvl.badge}`}>{lvl.label}</Badge>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}
