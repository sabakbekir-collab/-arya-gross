import { useListCategories, useCreateCategory, useDeleteCategory, getListCategoriesQueryKey } from "@workspace/api-client-react";
import { formatCurrency, formatDate } from "@/lib/format";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Trash2, Plus } from "lucide-react";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";

const formSchema = z.object({
  name: z.string().min(2, "Kategori adı en az 2 karakter olmalıdır"),
  description: z.string().optional()
});

export default function Categories() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const { data: categories, isLoading } = useListCategories();

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      description: ""
    }
  });

  const createCategory = useCreateCategory({
    mutation: {
      onSuccess: () => {
        toast({ title: "Başarılı", description: "Kategori oluşturuldu." });
        form.reset();
        queryClient.invalidateQueries({ queryKey: getListCategoriesQueryKey() });
      }
    }
  });

  const deleteCategory = useDeleteCategory({
    mutation: {
      onSuccess: () => {
        toast({ title: "Başarılı", description: "Kategori silindi." });
        queryClient.invalidateQueries({ queryKey: getListCategoriesQueryKey() });
      }
    }
  });

  const onSubmit = (values: z.infer<typeof formSchema>) => {
    createCategory.mutate({ data: values });
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <div>
        <h1 className="text-3xl font-bold tracking-tighter uppercase text-foreground">Kategoriler</h1>
        <p className="text-muted-foreground">Ürün kategorilerini yönetin.</p>
      </div>

      <div className="grid gap-6 md:grid-cols-3">
        <Card className="md:col-span-1 border-border bg-card/50 backdrop-blur h-fit">
          <CardHeader>
            <CardTitle>Yeni Kategori</CardTitle>
            <CardDescription>Katalog için yeni bir kategori ekle.</CardDescription>
          </CardHeader>
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Kategori Adı</FormLabel>
                      <FormControl>
                        <Input placeholder="Örn: Elektronik" {...field} className="bg-secondary/50" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Açıklama (Opsiyonel)</FormLabel>
                      <FormControl>
                        <Input placeholder="Kategori açıklaması..." {...field} className="bg-secondary/50" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <Button type="submit" className="w-full" disabled={createCategory.isPending}>
                  {createCategory.isPending ? "Ekleniyor..." : "Ekle"}
                </Button>
              </form>
            </Form>
          </CardContent>
        </Card>

        <Card className="md:col-span-2 border-border bg-card/50 backdrop-blur">
          <CardHeader>
            <CardTitle>Kategori Listesi</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="rounded-md border border-border overflow-hidden">
              <Table>
                <TableHeader className="bg-secondary/30">
                  <TableRow className="border-border hover:bg-transparent">
                    <TableHead>Ad</TableHead>
                    <TableHead>Açıklama</TableHead>
                    <TableHead>Oluşturulma</TableHead>
                    <TableHead className="text-right w-[80px]"></TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {isLoading ? (
                    <TableRow>
                      <TableCell colSpan={4} className="text-center py-8 text-muted-foreground">Yükleniyor...</TableCell>
                    </TableRow>
                  ) : categories?.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={4} className="text-center py-8 text-muted-foreground">Kategori bulunamadı.</TableCell>
                    </TableRow>
                  ) : categories?.map((cat) => (
                    <TableRow key={cat.id} className="border-border hover:bg-secondary/20 transition-colors">
                      <TableCell className="font-medium text-primary">{cat.name}</TableCell>
                      <TableCell className="text-muted-foreground">{cat.description || "-"}</TableCell>
                      <TableCell className="text-xs text-muted-foreground">{formatDate(cat.createdAt)}</TableCell>
                      <TableCell className="text-right">
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          className="h-8 w-8 text-muted-foreground hover:text-destructive"
                          onClick={() => {
                            if(confirm("Silmek istediğinize emin misiniz?")) {
                              deleteCategory.mutate({ id: cat.id });
                            }
                          }}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
