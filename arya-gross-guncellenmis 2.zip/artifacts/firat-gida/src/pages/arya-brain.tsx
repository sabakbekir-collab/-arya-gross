import { useState, useCallback } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { formatCurrency } from "@/lib/format";
import {
  BrainCircuit, AlertTriangle, CheckCircle2, XCircle, Package,
  TrendingUp, ShoppingCart, Users, Store, ListChecks, ChevronDown,
  ChevronUp, RefreshCw, Link2, ImageOff, Tag, BarChart3,
  ShieldAlert, Loader2, Clock, Zap, Eye, EyeOff,
} from "lucide-react";
import { cn } from "@/lib/utils";

interface AffectedProduct { id: number; name: string; }

interface Issue {
  id: string;
  title: string;
  description: string;
  severity: "critical" | "warning" | "info";
  count: number;
  affectedProducts: AffectedProduct[];
  suggestedAction: string;
  actionType: string | null;
  actionData: { ids: number[] } | null;
}

interface DailyTask {
  id: string;
  title: string;
  description: string;
  priority: "high" | "medium" | "low";
}

interface OrderStats {
  pending: number;
  inProgress: number;
  delivered: number;
  cancelled: number;
  total: number;
  totalRevenue: number;
  pendingRevenue: number;
}

interface CustomerStats {
  total: number;
  repeat: number;
  topCustomer: { name: string; total: number; orders: number } | null;
}

interface Analysis {
  healthScore: number;
  criticalCount: number;
  warningCount: number;
  productsToFixCount: number;
  todaySuggestionsCount: number;
  totalProducts: number;
  activeProductCount: number;
  criticalErrors: Issue[];
  productIssues: Issue[];
  stockWarnings: Issue[];
  profitOpportunities: Issue[];
  orderStats: OrderStats;
  customerStats: CustomerStats;
  storeAppearance: Issue[];
  dailyTasks: DailyTask[];
}

async function fetchAnalysis(): Promise<Analysis> {
  const res = await fetch("/api/ai-brain/analysis");
  if (!res.ok) throw new Error("Analiz yüklenemedi");
  return res.json();
}

async function applyAction(actionType: string, ids: number[]): Promise<{ applied: number; message: string }> {
  const res = await fetch("/api/ai-brain/apply", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ actionType, ids }),
  });
  if (!res.ok) throw new Error("İşlem uygulanamadı");
  return res.json();
}

function HealthScoreRing({ score }: { score: number }) {
  const color = score >= 80 ? "text-green-400" : score >= 60 ? "text-yellow-400" : "text-red-400";
  const bg = score >= 80 ? "bg-green-500/20 border-green-500/30" : score >= 60 ? "bg-yellow-500/20 border-yellow-500/30" : "bg-red-500/20 border-red-500/30";
  const label = score >= 80 ? "Sağlıklı" : score >= 60 ? "Orta" : "Kritik";
  return (
    <div className={cn("flex flex-col items-center justify-center w-28 h-28 rounded-full border-4 shrink-0", bg)}>
      <span className={cn("text-3xl font-black", color)}>{score}</span>
      <span className="text-[10px] text-muted-foreground font-semibold uppercase tracking-wide">{label}</span>
    </div>
  );
}

function SeverityBadge({ severity }: { severity: Issue["severity"] }) {
  const map = {
    critical: "bg-red-500/20 text-red-400 border-red-500/30",
    warning: "bg-yellow-500/20 text-yellow-400 border-yellow-500/30",
    info: "bg-blue-500/20 text-blue-400 border-blue-500/30",
  };
  const labels = { critical: "Kritik", warning: "Uyarı", info: "Bilgi" };
  return <Badge className={cn("text-[9px] border shrink-0", map[severity])}>{labels[severity]}</Badge>;
}

function IssueCard({
  issue, onApply, onDismiss, applying,
}: {
  issue: Issue;
  onApply: (issue: Issue) => void;
  onDismiss: (id: string) => void;
  applying: boolean;
}) {
  const [expanded, setExpanded] = useState(false);
  const [dismissed, setDismissed] = useState(false);

  if (dismissed) return null;

  const iconMap: Record<Issue["severity"], React.ElementType> = {
    critical: ShieldAlert,
    warning: AlertTriangle,
    info: Eye,
  };
  const Icon = iconMap[issue.severity];

  return (
    <div className={cn(
      "rounded-xl border p-3 space-y-2 transition-all",
      issue.severity === "critical" ? "border-red-500/30 bg-red-500/5" :
      issue.severity === "warning" ? "border-yellow-500/30 bg-yellow-500/5" :
      "border-blue-500/20 bg-blue-500/5"
    )}>
      <div className="flex items-start gap-2.5">
        <Icon className={cn("h-4 w-4 mt-0.5 shrink-0",
          issue.severity === "critical" ? "text-red-400" :
          issue.severity === "warning" ? "text-yellow-400" : "text-blue-400"
        )} />
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-1.5 flex-wrap">
            <span className="text-xs font-bold leading-tight">{issue.title}</span>
            <SeverityBadge severity={issue.severity} />
            <Badge className="bg-secondary text-muted-foreground border-border text-[9px]">{issue.count} adet</Badge>
          </div>
          <p className="text-[11px] text-muted-foreground mt-0.5 leading-relaxed">{issue.description}</p>
        </div>
      </div>

      {issue.affectedProducts.length > 0 && (
        <div>
          <button
            onClick={() => setExpanded(!expanded)}
            className="flex items-center gap-1 text-[10px] text-muted-foreground hover:text-foreground transition-colors"
          >
            {expanded ? <ChevronUp className="h-3 w-3" /> : <ChevronDown className="h-3 w-3" />}
            Etkilenen ürünleri gör ({Math.min(issue.affectedProducts.length, 10)})
          </button>
          {expanded && (
            <div className="mt-1.5 space-y-0.5 max-h-32 overflow-y-auto">
              {issue.affectedProducts.slice(0, 10).map(p => (
                <div key={p.id} className="text-[10px] text-muted-foreground bg-secondary/50 rounded px-2 py-0.5 truncate">
                  #{p.id} — {p.name}
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      <div className="bg-secondary/30 rounded-lg px-2.5 py-1.5 text-[10px] text-muted-foreground">
        💡 <span className="text-foreground font-medium">Öneri:</span> {issue.suggestedAction}
      </div>

      <div className="flex gap-1.5 flex-wrap">
        {issue.actionType && issue.actionData && (
          <Button
            size="sm"
            onClick={() => onApply(issue)}
            disabled={applying}
            className="h-7 text-[11px] font-bold bg-primary hover:bg-primary/90 text-white gap-1 px-2.5"
          >
            {applying ? <Loader2 className="h-3 w-3 animate-spin" /> : <CheckCircle2 className="h-3 w-3" />}
            Onayla ve Uygula
          </Button>
        )}
        <Button
          size="sm"
          variant="ghost"
          onClick={() => setDismissed(true)}
          className="h-7 text-[11px] text-muted-foreground hover:text-foreground gap-1 px-2"
        >
          <EyeOff className="h-3 w-3" /> Yok Say
        </Button>
      </div>
    </div>
  );
}

function SectionCard({
  title, icon: Icon, iconColor, issues, onApply, applying, emptyText, children,
}: {
  title: string;
  icon: React.ElementType;
  iconColor: string;
  issues?: Issue[];
  onApply?: (issue: Issue) => void;
  applying?: boolean;
  emptyText?: string;
  children?: React.ReactNode;
}) {
  const [collapsed, setCollapsed] = useState(false);

  return (
    <Card className="border-border bg-card/60">
      <CardContent className="p-0">
        <button
          onClick={() => setCollapsed(!collapsed)}
          className="w-full flex items-center gap-2.5 p-3 text-left hover:bg-secondary/20 transition-colors rounded-t-lg"
        >
          <div className={cn("w-7 h-7 rounded-lg flex items-center justify-center shrink-0 border", iconColor)}>
            <Icon className="h-3.5 w-3.5" />
          </div>
          <span className="text-sm font-bold flex-1">{title}</span>
          {issues && issues.length > 0 && (
            <Badge className="bg-secondary text-muted-foreground border-border text-[10px]">{issues.length} sorun</Badge>
          )}
          {collapsed ? <ChevronDown className="h-4 w-4 text-muted-foreground" /> : <ChevronUp className="h-4 w-4 text-muted-foreground" />}
        </button>

        {!collapsed && (
          <div className="px-3 pb-3 space-y-2 border-t border-border/50 pt-2.5">
            {issues && issues.length === 0 && emptyText && (
              <div className="flex items-center gap-2 text-[11px] text-green-400 bg-green-500/10 border border-green-500/20 rounded-lg px-3 py-2">
                <CheckCircle2 className="h-3.5 w-3.5 shrink-0" />
                {emptyText}
              </div>
            )}
            {issues?.map(issue => (
              <IssueCard
                key={issue.id}
                issue={issue}
                onApply={onApply ?? (() => {})}
                onDismiss={() => {}}
                applying={applying ?? false}
              />
            ))}
            {children}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

export default function AryaBrain() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [applyingId, setApplyingId] = useState<string | null>(null);

  const { data, isLoading, isError, refetch, isFetching } = useQuery<Analysis>({
    queryKey: ["ai-brain-analysis"],
    queryFn: fetchAnalysis,
    staleTime: 60_000,
    retry: 1,
  });

  const handleApply = useCallback(async (issue: Issue) => {
    if (!issue.actionType || !issue.actionData) return;
    setApplyingId(issue.id);
    try {
      const result = await applyAction(issue.actionType, issue.actionData.ids);
      toast({ title: "✅ İşlem Uygulandı", description: result.message });
      queryClient.invalidateQueries({ queryKey: ["ai-brain-analysis"] });
      queryClient.invalidateQueries({ queryKey: ["/api/products"] });
    } catch {
      toast({ title: "Hata", description: "İşlem uygulanamadı. Tekrar deneyin.", variant: "destructive" });
    } finally {
      setApplyingId(null);
    }
  }, [toast, queryClient]);

  if (isLoading) {
    return (
      <div className="space-y-4 animate-in fade-in duration-500">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 bg-primary/20 rounded-xl flex items-center justify-center border border-primary/30">
            <BrainCircuit className="h-4.5 w-4.5 text-primary" style={{ width: 18, height: 18 }} />
          </div>
          <div>
            <h1 className="text-base font-black">🧠 Arya AI Beyin</h1>
            <p className="text-[11px] text-muted-foreground">Mağaza analiz ediliyor...</p>
          </div>
        </div>
        <Card className="border-border bg-card/60">
          <CardContent className="p-8 flex flex-col items-center gap-3">
            <Loader2 className="h-8 w-8 text-primary animate-spin" />
            <p className="text-sm text-muted-foreground">Veritabanı taranıyor, analiz hazırlanıyor...</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (isError || !data) {
    return (
      <div className="space-y-4 animate-in fade-in duration-500">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 bg-primary/20 rounded-xl flex items-center justify-center border border-primary/30">
            <BrainCircuit className="h-4.5 w-4.5 text-primary" style={{ width: 18, height: 18 }} />
          </div>
          <h1 className="text-base font-black">🧠 Arya AI Beyin</h1>
        </div>
        <Card className="border-red-500/20 bg-red-500/5">
          <CardContent className="p-6 flex flex-col items-center gap-3 text-center">
            <XCircle className="h-8 w-8 text-red-400" />
            <div>
              <p className="text-sm font-bold text-red-400">Analiz yüklenemedi</p>
              <p className="text-[11px] text-muted-foreground mt-1">AI bağlı değil ama analiz motoru temel kontrolleri yapıyor. API sunucusuna bağlanılamadı.</p>
            </div>
            <Button size="sm" onClick={() => refetch()} className="gap-2 bg-primary hover:bg-primary/90 text-white">
              <RefreshCw className="h-3.5 w-3.5" /> Tekrar Dene
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const { healthScore, criticalCount, warningCount, productsToFixCount, todaySuggestionsCount,
    totalProducts, activeProductCount, criticalErrors, productIssues, stockWarnings,
    profitOpportunities, orderStats, customerStats, storeAppearance, dailyTasks } = data;

  const scoreColor = healthScore >= 80 ? "text-green-400" : healthScore >= 60 ? "text-yellow-400" : "text-red-400";

  return (
    <div className="space-y-3 animate-in fade-in duration-500">
      {/* Header */}
      <div className="flex items-center gap-2.5">
        <div className="w-9 h-9 bg-primary/20 rounded-xl flex items-center justify-center shrink-0 border border-primary/30">
          <BrainCircuit className="h-4.5 w-4.5 text-primary" style={{ width: 18, height: 18 }} />
        </div>
        <div className="flex-1 min-w-0">
          <h1 className="text-base font-black">🧠 Arya AI Beyin</h1>
          <p className="text-[11px] text-muted-foreground">Mağaza analiz motoru — gerçek verilerden otomatik kontrol</p>
        </div>
        <Button
          size="sm"
          variant="outline"
          onClick={() => refetch()}
          disabled={isFetching}
          className="gap-1.5 text-xs shrink-0"
        >
          <RefreshCw className={cn("h-3.5 w-3.5", isFetching && "animate-spin")} />
          {isFetching ? "Taranıyor..." : "Yenile"}
        </Button>
      </div>

      {/* Notice */}
      <div className="flex items-start gap-2 bg-blue-500/10 border border-blue-500/20 rounded-xl px-3 py-2">
        <Zap className="h-3.5 w-3.5 text-blue-400 shrink-0 mt-0.5" />
        <p className="text-[10px] text-blue-300 leading-relaxed">
          AI API anahtarı olmasa da analiz motoru temel kontrolleri yapıyor. Her işlem için <strong>"Onayla ve Uygula"</strong> butonu tıklanmadan hiçbir değişiklik yapılmaz.
        </p>
      </div>

      {/* Health Score + Stats */}
      <Card className="border-primary/20 bg-gradient-to-br from-primary/5 via-card to-card">
        <CardContent className="p-4">
          <div className="flex gap-4 items-center">
            <HealthScoreRing score={healthScore} />
            <div className="flex-1 space-y-1.5">
              <p className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Mağaza Sağlık Skoru</p>
              <div className="h-2 bg-secondary rounded-full overflow-hidden">
                <div
                  className={cn("h-full rounded-full transition-all duration-700",
                    healthScore >= 80 ? "bg-green-500" : healthScore >= 60 ? "bg-yellow-500" : "bg-red-500"
                  )}
                  style={{ width: `${healthScore}%` }}
                />
              </div>
              <p className={cn("text-[11px] font-medium", scoreColor)}>
                {healthScore >= 80 ? "Mağaza iyi durumda! Küçük iyileştirmeler yapılabilir." :
                 healthScore >= 60 ? "Birkaç önemli sorun var. Düzeltmeler ciroyu artırır." :
                 "Kritik sorunlar var. Acil müdahale gerekiyor!"}
              </p>
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mt-4">
            {[
              { label: "Kritik Hata", val: criticalCount, color: criticalCount > 0 ? "text-red-400" : "text-green-400", icon: ShieldAlert },
              { label: "Uyarı", val: warningCount, color: warningCount > 0 ? "text-yellow-400" : "text-green-400", icon: AlertTriangle },
              { label: "Düzeltilecek Ürün", val: productsToFixCount, color: productsToFixCount > 0 ? "text-orange-400" : "text-green-400", icon: Package },
              { label: "Bugünkü Görev", val: todaySuggestionsCount, color: "text-blue-400", icon: ListChecks },
            ].map(s => (
              <div key={s.label} className="bg-secondary/50 rounded-xl p-2.5 text-center">
                <s.icon className={cn("h-4 w-4 mx-auto mb-1", s.color)} />
                <div className={cn("text-xl font-black", s.color)}>{s.val}</div>
                <div className="text-[9px] text-muted-foreground mt-0.5 leading-tight">{s.label}</div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* 1. Kritik Hatalar */}
      <SectionCard
        title="🚨 Kritik Hatalar"
        icon={ShieldAlert}
        iconColor="bg-red-500/20 text-red-400 border-red-500/30"
        issues={criticalErrors}
        onApply={handleApply}
        applying={!!applyingId}
        emptyText="Kritik hata bulunamadı — mağaza bu alanda sağlıklı!"
      />

      {/* 2. Ürün Eksikleri */}
      <SectionCard
        title="📦 Ürün Eksikleri"
        icon={Package}
        iconColor="bg-orange-500/20 text-orange-400 border-orange-500/30"
        issues={productIssues}
        onApply={handleApply}
        applying={!!applyingId}
        emptyText="Tüm ürünlerde açıklama ve fiyat bilgisi eksiksiz!"
      />

      {/* 3. Stok Uyarıları */}
      <SectionCard
        title="📊 Stok Uyarıları"
        icon={BarChart3}
        iconColor="bg-yellow-500/20 text-yellow-400 border-yellow-500/30"
        issues={stockWarnings}
        onApply={handleApply}
        applying={!!applyingId}
        emptyText="Tüm ürünlerde stok yeterli!"
      />

      {/* 4. Kâr Fırsatları */}
      <SectionCard
        title="💰 Kâr Fırsatları"
        icon={TrendingUp}
        iconColor="bg-green-500/20 text-green-400 border-green-500/30"
        issues={profitOpportunities}
        onApply={handleApply}
        applying={!!applyingId}
        emptyText="Kâr optimize edilmiş görünüyor!"
      />

      {/* 5. Sipariş Analizi */}
      <SectionCard
        title="🛒 Sipariş Analizi"
        icon={ShoppingCart}
        iconColor="bg-blue-500/20 text-blue-400 border-blue-500/30"
      >
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
          {[
            { label: "Bekleyen", val: orderStats.pending, color: orderStats.pending > 0 ? "text-yellow-400" : "text-muted-foreground" },
            { label: "Hazırlanıyor/Kargoda", val: orderStats.inProgress, color: "text-blue-400" },
            { label: "Teslim Edildi", val: orderStats.delivered, color: "text-green-400" },
            { label: "İptal Edildi", val: orderStats.cancelled, color: "text-red-400" },
            { label: "Toplam Sipariş", val: orderStats.total, color: "text-foreground" },
          ].map(s => (
            <div key={s.label} className="bg-secondary/50 rounded-xl p-2.5 text-center">
              <div className={cn("text-xl font-black", s.color)}>{s.val}</div>
              <div className="text-[9px] text-muted-foreground mt-0.5">{s.label}</div>
            </div>
          ))}
          <div className="bg-primary/10 border border-primary/20 rounded-xl p-2.5 text-center">
            <div className="text-sm font-black text-primary">{formatCurrency(orderStats.totalRevenue)}</div>
            <div className="text-[9px] text-muted-foreground mt-0.5">Teslim Edilen Ciro</div>
          </div>
        </div>
        {orderStats.pendingRevenue > 0 && (
          <div className="flex items-center gap-2 bg-yellow-500/10 border border-yellow-500/20 rounded-lg px-3 py-2 text-[11px]">
            <Clock className="h-3.5 w-3.5 text-yellow-400 shrink-0" />
            <span><strong className="text-yellow-400">{formatCurrency(orderStats.pendingRevenue)}</strong> bekleyen ciro onay bekliyor</span>
          </div>
        )}
        {orderStats.pending > 0 && (
          <div className="flex items-center gap-2 bg-red-500/10 border border-red-500/20 rounded-lg px-3 py-2 text-[11px]">
            <ShieldAlert className="h-3.5 w-3.5 text-red-400 shrink-0" />
            <span className="text-red-400 font-semibold">{orderStats.pending} sipariş onay bekliyor — Siparişler sayfasına gidin!</span>
          </div>
        )}
      </SectionCard>

      {/* 6. Müşteri Analizi */}
      <SectionCard
        title="👥 Müşteri Analizi"
        icon={Users}
        iconColor="bg-purple-500/20 text-purple-400 border-purple-500/30"
      >
        {customerStats.total === 0 ? (
          <div className="text-[11px] text-muted-foreground text-center py-2">Henüz sipariş verilmemiş. Müşteriler sipariş verdikçe burada görünecek.</div>
        ) : (
          <div className="space-y-2">
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {[
                { label: "Toplam Müşteri", val: customerStats.total, color: "text-purple-400" },
                { label: "Tekrar Eden", val: customerStats.repeat, color: "text-blue-400" },
                { label: "Sadakat Oranı", val: customerStats.total > 0 ? `%${Math.round((customerStats.repeat / customerStats.total) * 100)}` : "%0", color: "text-green-400" },
              ].map(s => (
                <div key={s.label} className="bg-secondary/50 rounded-xl p-2.5 text-center">
                  <div className={cn("text-xl font-black", s.color)}>{s.val}</div>
                  <div className="text-[9px] text-muted-foreground mt-0.5">{s.label}</div>
                </div>
              ))}
            </div>
            {customerStats.topCustomer && (
              <div className="flex items-center gap-2 bg-secondary/30 rounded-xl px-3 py-2 text-[11px]">
                <span className="text-lg">🏆</span>
                <div>
                  <span className="font-bold text-foreground">{customerStats.topCustomer.name}</span>
                  <span className="text-muted-foreground ml-1">— {customerStats.topCustomer.orders} sipariş — {formatCurrency(customerStats.topCustomer.total)}</span>
                </div>
              </div>
            )}
          </div>
        )}
      </SectionCard>

      {/* 7. Mağaza Görünüm Önerileri */}
      <SectionCard
        title="🏪 Mağaza Görünüm Önerileri"
        icon={Store}
        iconColor="bg-cyan-500/20 text-cyan-400 border-cyan-500/30"
        issues={storeAppearance}
        onApply={handleApply}
        applying={!!applyingId}
        emptyText="Mağaza görünümü yeterli!"
      >
        <div className="grid grid-cols-2 gap-2 mt-1">
          {[
            { label: "Toplam Ürün", val: totalProducts, icon: Package, color: "text-foreground" },
            { label: "Aktif / Yayında", val: activeProductCount, icon: CheckCircle2, color: "text-green-400" },
          ].map(s => (
            <div key={s.label} className="bg-secondary/50 rounded-xl p-2.5 flex items-center gap-2">
              <s.icon className={cn("h-4 w-4 shrink-0", s.color)} />
              <div>
                <div className={cn("text-base font-black", s.color)}>{s.val}</div>
                <div className="text-[9px] text-muted-foreground">{s.label}</div>
              </div>
            </div>
          ))}
        </div>
      </SectionCard>

      {/* 8. Günlük Yapılacaklar */}
      <SectionCard
        title="📋 Günlük Yapılacaklar"
        icon={ListChecks}
        iconColor="bg-indigo-500/20 text-indigo-400 border-indigo-500/30"
      >
        {dailyTasks.length === 0 ? (
          <div className="flex items-center gap-2 text-[11px] text-green-400 bg-green-500/10 border border-green-500/20 rounded-lg px-3 py-2">
            <CheckCircle2 className="h-3.5 w-3.5 shrink-0" /> Bugün için bekleyen görev yok — harika iş!
          </div>
        ) : (
          <div className="space-y-1.5">
            {dailyTasks.map(task => {
              const priorityMap = {
                high: { cls: "border-red-500/30 bg-red-500/5", dot: "bg-red-400", label: "Acil" },
                medium: { cls: "border-yellow-500/30 bg-yellow-500/5", dot: "bg-yellow-400", label: "Önemli" },
                low: { cls: "border-border bg-card/50", dot: "bg-muted-foreground", label: "Normal" },
              };
              const { cls, dot, label } = priorityMap[task.priority];
              return (
                <div key={task.id} className={cn("flex items-start gap-2.5 rounded-xl border px-3 py-2", cls)}>
                  <div className={cn("w-2 h-2 rounded-full mt-1.5 shrink-0", dot)} />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-1.5">
                      <span className="text-[11px] font-semibold leading-tight">{task.title}</span>
                      <span className={cn("text-[9px] font-bold px-1.5 py-0.5 rounded",
                        task.priority === "high" ? "text-red-400 bg-red-500/10" :
                        task.priority === "medium" ? "text-yellow-400 bg-yellow-500/10" :
                        "text-muted-foreground bg-secondary"
                      )}>{label}</span>
                    </div>
                    <p className="text-[10px] text-muted-foreground mt-0.5">{task.description}</p>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </SectionCard>

      {/* Eksik görseller + hatalı linkler özeti */}
      {(criticalErrors.some(i => i.id === "active-no-image") || criticalErrors.some(i => i.id === "bad-trendyol-url")) && (
        <Card className="border-primary/20 bg-primary/5">
          <CardContent className="p-3 space-y-2">
            <p className="text-xs font-bold text-primary uppercase tracking-wider">⚡ Hızlı Aksiyonlar</p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {criticalErrors.find(i => i.id === "bad-trendyol-url") && (
                <div className="flex items-start gap-2 bg-secondary/50 rounded-xl p-2.5">
                  <Link2 className="h-4 w-4 text-blue-400 shrink-0 mt-0.5" />
                  <div className="flex-1 min-w-0">
                    <p className="text-[11px] font-semibold">Hatalı Trendyol Linklerini Düzelt</p>
                    <p className="text-[10px] text-muted-foreground">{criticalErrors.find(i => i.id === "bad-trendyol-url")?.count} ürün → arama linkine çevrilecek</p>
                  </div>
                  <Button
                    size="sm"
                    className="h-7 text-[10px] bg-blue-600 hover:bg-blue-700 text-white px-2 shrink-0"
                    disabled={!!applyingId}
                    onClick={() => {
                      const issue = criticalErrors.find(i => i.id === "bad-trendyol-url");
                      if (issue) handleApply(issue);
                    }}
                  >
                    {applyingId === "bad-trendyol-url" ? <Loader2 className="h-3 w-3 animate-spin" /> : "Uygula"}
                  </Button>
                </div>
              )}
              {criticalErrors.find(i => i.id === "active-no-image") && (
                <div className="flex items-start gap-2 bg-secondary/50 rounded-xl p-2.5">
                  <ImageOff className="h-4 w-4 text-orange-400 shrink-0 mt-0.5" />
                  <div className="flex-1 min-w-0">
                    <p className="text-[11px] font-semibold">Görselsiz Ürünleri Taslağa Al</p>
                    <p className="text-[10px] text-muted-foreground">{criticalErrors.find(i => i.id === "active-no-image")?.count} ürün → draft durumuna alınacak</p>
                  </div>
                  <Button
                    size="sm"
                    className="h-7 text-[10px] bg-orange-600 hover:bg-orange-700 text-white px-2 shrink-0"
                    disabled={!!applyingId}
                    onClick={() => {
                      const issue = criticalErrors.find(i => i.id === "active-no-image");
                      if (issue) handleApply(issue);
                    }}
                  >
                    {applyingId === "active-no-image" ? <Loader2 className="h-3 w-3 animate-spin" /> : "Uygula"}
                  </Button>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
