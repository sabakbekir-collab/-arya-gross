import { useListOrders, useListProducts } from "@workspace/api-client-react";
import { formatCurrency } from "@/lib/format";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { TrendingUp, TrendingDown, DollarSign, Package, BarChart3, AlertTriangle } from "lucide-react";
import { useMemo } from "react";

export default function Accounting() {
  const { data: orders } = useListOrders();
  const { data: products } = useListProducts();

  const stats = useMemo(() => {
    const delivered = (orders || []).filter(o => o.status === "teslim edildi");
    const totalRevenue = delivered.reduce((s, o) => s + Number(o.total), 0);
    const pending = (orders || []).filter(o => !["teslim edildi", "iptal"].includes(o.status));
    const pendingRevenue = pending.reduce((s, o) => s + Number(o.total), 0);
    const cancelled = (orders || []).filter(o => o.status === "iptal").length;

    // Estimate cost from items
    let estimatedCost = 0;
    for (const order of delivered) {
      for (const item of (order.items || [])) {
        const product = (products || []).find(p => p.id === item.productId);
        if (product?.costPrice) {
          estimatedCost += Number(product.costPrice) * item.quantity;
        } else {
          estimatedCost += (Number(item.price) * 0.45) * item.quantity;
        }
      }
    }
    const netProfit = totalRevenue - estimatedCost;
    const margin = totalRevenue > 0 ? Math.round((netProfit / totalRevenue) * 100) : 0;

    // Product profitability
    const productStats: Record<number, { name: string; revenue: number; cost: number; units: number }> = {};
    for (const order of delivered) {
      for (const item of (order.items || [])) {
        if (!productStats[item.productId]) {
          const p = (products || []).find(pr => pr.id === item.productId);
          productStats[item.productId] = { name: item.name, revenue: 0, cost: 0, units: 0 };
        }
        const p = (products || []).find(pr => pr.id === item.productId);
        productStats[item.productId].revenue += Number(item.price) * item.quantity;
        productStats[item.productId].cost += (Number(p?.costPrice) || Number(item.price) * 0.45) * item.quantity;
        productStats[item.productId].units += item.quantity;
      }
    }

    const productList = Object.values(productStats).map(p => ({
      ...p, profit: p.revenue - p.cost,
      margin: p.revenue > 0 ? Math.round(((p.revenue - p.cost) / p.revenue) * 100) : 0,
    })).sort((a, b) => b.profit - a.profit);

    return { totalRevenue, estimatedCost, netProfit, margin, pendingRevenue, cancelled, productList, orderCount: delivered.length };
  }, [orders, products]);

  return (
    <div className="space-y-4 animate-in fade-in duration-500">
      <div className="flex items-start gap-3">
        <div className="w-10 h-10 bg-green-500/20 rounded-xl flex items-center justify-center shrink-0 border border-green-500/30">
          <TrendingUp className="h-5 w-5 text-green-400" />
        </div>
        <div>
          <h1 className="text-xl font-black">💰 Muhasebe & Kâr Takibi</h1>
          <p className="text-xs text-muted-foreground mt-0.5">Gelir, maliyet ve kâr analizi</p>
        </div>
      </div>

      {/* Main metrics */}
      <div className="grid grid-cols-2 gap-3">
        <Card className="border-primary/25 bg-primary/5 col-span-2 sm:col-span-1">
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-1">
              <span className="text-[10px] text-muted-foreground uppercase tracking-wider">Toplam Ciro</span>
              <DollarSign className="h-4 w-4 text-primary" />
            </div>
            <div className="text-3xl font-black text-primary">{formatCurrency(stats.totalRevenue)}</div>
            <div className="text-[11px] text-muted-foreground mt-1">{stats.orderCount} tamamlanan sipariş</div>
          </CardContent>
        </Card>
        <Card className="border-green-500/25 bg-green-500/5">
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-1">
              <span className="text-[10px] text-muted-foreground uppercase tracking-wider">Net Kâr</span>
              <TrendingUp className="h-4 w-4 text-green-400" />
            </div>
            <div className="text-3xl font-black text-green-400">{formatCurrency(stats.netProfit)}</div>
            <div className="text-[11px] text-muted-foreground mt-1">Kâr marjı: %{stats.margin}</div>
          </CardContent>
        </Card>
        <Card className="border-border bg-card/60">
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-1">
              <span className="text-[10px] text-muted-foreground uppercase tracking-wider">Tahmini Maliyet</span>
              <TrendingDown className="h-4 w-4 text-muted-foreground" />
            </div>
            <div className="text-3xl font-black text-foreground">{formatCurrency(stats.estimatedCost)}</div>
            <div className="text-[11px] text-muted-foreground mt-1">Ürün maliyeti tahmini</div>
          </CardContent>
        </Card>
        <Card className="border-yellow-500/20 bg-yellow-500/5">
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-1">
              <span className="text-[10px] text-muted-foreground uppercase tracking-wider">Bekleyen Ciro</span>
              <AlertTriangle className="h-4 w-4 text-yellow-400" />
            </div>
            <div className="text-3xl font-black text-yellow-400">{formatCurrency(stats.pendingRevenue)}</div>
            <div className="text-[11px] text-muted-foreground mt-1">İşleme alınan siparişler</div>
          </CardContent>
        </Card>
      </div>

      {/* Profit margin bar */}
      <Card className="border-border bg-card/60">
        <CardContent className="p-4">
          <div className="flex justify-between items-center mb-2">
            <span className="text-xs font-semibold">Kâr Marjı</span>
            <span className="text-sm font-black text-green-400">%{stats.margin}</span>
          </div>
          <div className="h-3 bg-secondary rounded-full overflow-hidden">
            <div className="h-full bg-gradient-to-r from-primary to-green-500 rounded-full transition-all duration-700" style={{ width: `${Math.min(stats.margin, 100)}%` }} />
          </div>
          <div className="flex justify-between text-[10px] text-muted-foreground mt-1">
            <span>Maliyet {formatCurrency(stats.estimatedCost)}</span>
            <span>Kâr {formatCurrency(stats.netProfit)}</span>
          </div>
        </CardContent>
      </Card>

      {/* Product profitability */}
      {stats.productList.length > 0 && (
        <Card className="border-border bg-card/60">
          <CardHeader className="py-3 px-4 pb-2">
            <CardTitle className="text-sm flex items-center gap-2">
              <BarChart3 className="h-4 w-4 text-accent" /> Ürün Bazlı Kâr Analizi
            </CardTitle>
          </CardHeader>
          <CardContent className="px-4 pb-4">
            <div className="space-y-3">
              {stats.productList.map((p, i) => (
                <div key={i}>
                  <div className="flex items-center justify-between mb-1">
                    <div className="flex items-center gap-2 min-w-0">
                      <span className="text-[10px] text-primary font-bold w-4">#{i + 1}</span>
                      <span className="text-xs font-medium truncate">{p.name}</span>
                    </div>
                    <div className="flex items-center gap-3 shrink-0">
                      <span className="text-[10px] text-muted-foreground">{p.units} adet</span>
                      <span className="text-xs font-black text-green-400">{formatCurrency(p.profit)}</span>
                      <span className="text-[10px] text-muted-foreground w-8 text-right">%{p.margin}</span>
                    </div>
                  </div>
                  <div className="h-1.5 bg-secondary rounded-full overflow-hidden">
                    <div
                      className="h-full rounded-full bg-gradient-to-r from-primary to-accent"
                      style={{ width: `${Math.min(p.margin, 100)}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {stats.totalRevenue === 0 && (
        <Card className="border-dashed border-border bg-card/30">
          <div className="py-10 text-center space-y-2">
            <Package className="h-8 w-8 text-muted-foreground mx-auto" />
            <p className="text-sm text-muted-foreground">Henüz tamamlanan sipariş yok</p>
            <p className="text-xs text-muted-foreground">Siparişler "Teslim Edildi" olarak işaretlendiğinde muhasebe verileri burada görünecek</p>
          </div>
        </Card>
      )}
    </div>
  );
}
