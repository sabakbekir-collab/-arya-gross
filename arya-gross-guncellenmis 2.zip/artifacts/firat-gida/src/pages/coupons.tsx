import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Ticket, Plus, Copy, Trash2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface Coupon { id: string; code: string; discount: number; type: "percent" | "fixed"; usageLimit: number; usedCount: number; active: boolean; expires: string; }

const INITIAL: Coupon[] = [];

export default function Coupons() {
  const { toast } = useToast();
  const [coupons, setCoupons] = useState<Coupon[]>(INITIAL);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ code: "", discount: "", type: "percent", usageLimit: "100", expires: "2026-12-31" });

  const generate = () => {
    const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
    const code = Array.from({ length: 8 }, () => chars[Math.floor(Math.random() * chars.length)]).join("");
    setForm(f => ({ ...f, code }));
  };

  const add = () => {
    if (!form.code || !form.discount) { toast({ title: "Kod ve indirim zorunludur", variant: "destructive" }); return; }
    setCoupons(prev => [...prev, { id: Date.now().toString(), code: form.code.toUpperCase(), discount: Number(form.discount), type: form.type as any, usageLimit: Number(form.usageLimit), usedCount: 0, active: true, expires: form.expires }]);
    setShowForm(false);
    setForm({ code: "", discount: "", type: "percent", usageLimit: "100", expires: "2026-12-31" });
    toast({ title: "Kupon oluşturuldu" });
  };

  return (
    <div className="space-y-4 animate-in fade-in duration-500">
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-start gap-3">
          <div className="w-10 h-10 bg-yellow-500/20 rounded-xl flex items-center justify-center shrink-0 border border-yellow-500/30">
            <Ticket className="h-5 w-5 text-yellow-400" />
          </div>
          <div>
            <h1 className="text-xl font-black">🎟️ Kupon Yönetimi</h1>
            <p className="text-xs text-muted-foreground mt-0.5">İndirim kuponları oluştur ve yönet</p>
          </div>
        </div>
        <Button size="sm" className="bg-primary hover:bg-primary/90 text-white gap-1.5 shrink-0" onClick={() => setShowForm(!showForm)}>
          <Plus className="h-4 w-4" /> Yeni
        </Button>
      </div>

      {showForm && (
        <Card className="border-primary/30 bg-primary/5">
          <CardContent className="p-4 space-y-3">
            <div className="flex gap-2">
              <Input placeholder="Kupon kodu" value={form.code} onChange={e => setForm(f => ({ ...f, code: e.target.value.toUpperCase() }))} className="bg-secondary/50 h-9 text-sm font-mono uppercase" />
              <Button variant="outline" size="sm" className="h-9 shrink-0" onClick={generate}>Üret</Button>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <Input type="number" placeholder={form.type === "percent" ? "% indirim" : "TL indirim"} value={form.discount} onChange={e => setForm(f => ({ ...f, discount: e.target.value }))} className="bg-secondary/50 h-9 text-sm" />
              <Input type="number" placeholder="Kullanım limiti" value={form.usageLimit} onChange={e => setForm(f => ({ ...f, usageLimit: e.target.value }))} className="bg-secondary/50 h-9 text-sm" />
            </div>
            <div className="flex gap-2">
              <Button size="sm" onClick={add} className="bg-primary hover:bg-primary/90 text-white">Oluştur</Button>
              <Button size="sm" variant="outline" onClick={() => setShowForm(false)}>İptal</Button>
            </div>
          </CardContent>
        </Card>
      )}

      <div className="space-y-2">
        {coupons.map(c => {
          const usagePct = c.usageLimit > 0 ? Math.round((c.usedCount / c.usageLimit) * 100) : 0;
          const expired = new Date(c.expires) < new Date();
          return (
            <Card key={c.id} className={`border ${c.active && !expired ? "border-border bg-card/60" : "border-border bg-card/30 opacity-60"}`}>
              <CardContent className="p-3">
                <div className="flex items-center justify-between gap-3 mb-2">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-mono text-sm font-black tracking-wider">{c.code}</span>
                    <Badge className={c.active && !expired ? "bg-green-500/20 text-green-400 border-green-500/30 text-[9px]" : "bg-secondary text-muted-foreground text-[9px]"}>
                      {expired ? "Süresi Doldu" : c.active ? "Aktif" : "Pasif"}
                    </Badge>
                    <Badge className="bg-yellow-500/20 text-yellow-400 border-yellow-500/30 text-[9px]">
                      {c.type === "percent" ? `%${c.discount}` : `₺${c.discount}`}
                    </Badge>
                  </div>
                  <div className="flex gap-1 shrink-0">
                    <Button variant="ghost" size="icon" className="h-7 w-7 text-muted-foreground hover:text-foreground" onClick={() => { navigator.clipboard.writeText(c.code); toast({ title: "Kopyalandı" }); }}><Copy className="h-3 w-3" /></Button>
                    <Button variant="ghost" size="icon" className="h-7 w-7 text-muted-foreground hover:text-destructive" onClick={() => { setCoupons(prev => prev.filter(x => x.id !== c.id)); toast({ title: "Kupon silindi" }); }}><Trash2 className="h-3 w-3" /></Button>
                  </div>
                </div>
                <div className="flex justify-between text-[10px] text-muted-foreground mb-1">
                  <span>{c.usedCount}/{c.usageLimit} kullanım</span>
                  <span>{c.expires}'e kadar</span>
                </div>
                <div className="h-1.5 bg-secondary rounded-full overflow-hidden">
                  <div className={`h-full rounded-full ${usagePct >= 100 ? "bg-red-500" : "bg-primary"}`} style={{ width: `${usagePct}%` }} />
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
}
