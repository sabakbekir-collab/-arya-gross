import { useEffect, useState } from "react";

export default function ProductSuggestions() {
  const [items, setItems] = useState<any[]>([]);
  const [message, setMessage] = useState("");

  async function load() {
    const res = await fetch("/api/supplier-automation/suggestions");
    const data = await res.json();
    setItems(data.items ?? []);
  }

  async function approve(id: number) {
    const res = await fetch(`/api/supplier-automation/approve/${id}`, { method: "POST" });
    const data = await res.json();
    setMessage(data.message || "İşlem tamamlandı");
    await load();
  }

  async function reject(id: number) {
    const res = await fetch(`/api/supplier-automation/reject/${id}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ reason: "Admin reddetti" }),
    });
    const data = await res.json();
    setMessage(data.message || "Reddedildi");
    await load();
  }

  useEffect(() => {
    load();
  }, []);

  return (
    <div style={{ padding: 20, color: "white" }}>
      <h1 style={{ fontSize: 30, fontWeight: 900 }}>Onay Listesi</h1>
      <p style={{ color: "#aaa" }}>Bekleyen ürünleri onayla veya reddet.</p>

      {message && <div style={{ marginTop: 15, padding: 12, background: "#064e3b", borderRadius: 10 }}>{message}</div>}

      <div style={{ display: "grid", gap: 14, marginTop: 20 }}>
        {items.map((p) => (
          <div key={p.id} style={{ background: "#151515", border: "1px solid #333", borderRadius: 14, padding: 16 }}>
            <b style={{ fontSize: 20 }}>{p.name}</b>
            <p>{p.categoryName || "Genel"} — Maliyet: {p.estimatedCostPrice} TL — Satış: {p.estimatedSellPrice} TL</p>
            <p style={{ color: "#aaa" }}>{p.supplierName}</p>

            <div style={{ display: "flex", gap: 10 }}>
              <button onClick={() => approve(p.id)} style={{ padding: 12, borderRadius: 10, background: "#16a34a", color: "white", border: "none", fontWeight: 900 }}>
                Onayla ve Siteye Ekle
              </button>
              <button onClick={() => reject(p.id)} style={{ padding: 12, borderRadius: 10, background: "#991b1b", color: "white", border: "none", fontWeight: 900 }}>
                Reddet
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
