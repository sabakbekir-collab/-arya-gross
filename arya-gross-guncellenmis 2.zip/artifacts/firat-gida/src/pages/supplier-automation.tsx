import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import {
  Search, CheckCircle, XCircle, Trash2, ExternalLink,
  Loader2, AlertTriangle, ShoppingBag, TrendingUp, Package,
} from "lucide-react";

interface Suggestion {
  id: number;
  name: string;
  brand: string | null;
  categoryName: string | null;
  description: string | null;
  supplierName: string | null;
  supplierProductUrl: string | null;
  imageUrl: string | null;
  estimatedCostPrice: string | null;
  estimatedSellPrice: string | null;
  profitMargin: number | null;
  opportunityScore: number | null;
  linkBroken: boolean | null;
  status: string;
  createdAt: string;
}

interface RunResult {
  success: boolean;
  inserted?: number;
  errors?: number;
  openaiUsed?: boolean;
  message?: string;
  error?: string;
}

async function safeFetch<T>(url: string, options?: RequestInit): Promise<T> {
  const res = await fetch(url, options);
  const text = await res.text();
  if (text.trim().startsWith("<")) {
    throw new Error("Backend JSON yerine HTML döndürdü. API route veya server çalışmıyor.");
  }
  const data: unknown = JSON.parse(text);
  return data as T;
}

export default function SupplierAutomation() {
  const { toast } = useToast();
  const [query, setQuery] = useState("çay, pirinç, mercimek, şeker, zeytinyağı");
  const [limit, setLimit] = useState(20);
  const [profitRate, setProfitRate] = useState(0.20);
  const [running, setRunning] = useState(false);
  const [loading, setLoading] = useState(false);
  const [suggestions, setSuggestions] = useState<Suggestion[]>([]);
  const [rejectReason, setRejectReason] = useState<Record<number, string>>({});

  async function loadSuggestions() {
    setLoading(true);
    try {
      const data = await safeFetch<{ success: boolean; items: Suggestion[] }>(
        "/api/supplier-automation/suggestions"
      );
      if (data.success) setSuggestions(data.items);
    } catch (err) {
      toast({ title: "Hata", description: String(err), variant: "destructive" });
    } finally {
      setLoading(false);
    }
  }

  async function handleRun() {
    if (!query.trim()) {
      toast({ title: "Uyarı", description: "Ürün sorgusu boş olamaz.", variant: "destructive" });
      return;
    }
    setRunning(true);
    try {
      const data = await safeFetch<RunResult>("/api/supplier-automation/run", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ query, limit, profitRate }),
      });
      if (data.success) {
        toast({
          title: "Tamamlandı",
          description: `${data.inserted ?? 0} ürün öneri kuyruğuna eklendi.${data.openaiUsed ? " (OpenAI analizi kullanıldı)" : ""}`,
        });
        await loadSuggestions();
      } else {
        toast({ title: "Hata", description: data.error ?? "Bilinmeyen hata", variant: "destructive" });
      }
    } catch (err) {
      toast({ title: "Bağlantı Hatası", description: String(err), variant: "destructive" });
    } finally {
      setRunning(false);
    }
  }

  async function handleApprove(id: number) {
    try {
      const data = await safeFetch<{ success: boolean; error?: string }>(
        `/api/supplier-automation/approve/${id}`,
        { method: "POST" }
      );
      if (data.success) {
        toast({ title: "Onaylandı", description: "Ürün siteye eklendi." });
        setSuggestions(prev => prev.filter(s => s.id !== id));
      } else {
        toast({ title: "Hata", description: data.error ?? "Onay başarısız", variant: "destructive" });
      }
    } catch (err) {
      toast({ title: "Hata", description: String(err), variant: "destructive" });
    }
  }

  async function handleReject(id: number) {
    try {
      const data = await safeFetch<{ success: boolean; error?: string }>(
        `/api/supplier-automation/reject/${id}`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ reason: rejectReason[id] || "Admin reddetti" }),
        }
      );
      if (data.success) {
        toast({ title: "Reddedildi", description: "Öneri reddedildi." });
        setSuggestions(prev => prev.filter(s => s.id !== id));
      } else {
        toast({ title: "Hata", description: data.error ?? "Red başarısız", variant: "destructive" });
      }
    } catch (err) {
      toast({ title: "Hata", description: String(err), variant: "destructive" });
    }
  }

  async function handleDelete(id: number) {
    try {
      const data = await safeFetch<{ success: boolean; error?: string }>(
        `/api/supplier-automation/suggestions/${id}`,
        { method: "DELETE" }
      );
      if ((data as { success: boolean }).success) {
        toast({ title: "Silindi", description: "Öneri silindi." });
        setSuggestions(prev => prev.filter(s => s.id !== id));
      }
    } catch (err) {
      toast({ title: "Hata", description: String(err), variant: "destructive" });
    }
  }

  function statusBadge(s: Suggestion) {
    if (s.status === "approved") return <Badge className="bg-green-600 text-white">Onaylı</Badge>;
    if (s.status === "rejected") return <Badge variant="destructive">Reddedildi</Badge>;
    if (s.status === "unverified") return <Badge variant="outline" className="border-yellow-500 text-yellow-700">Doğrulanamadı</Badge>;
    return <Badge variant="secondary">Bekliyor</Badge>;
  }

  function scoreColor(score: number | null) {
    if (!score) return "text-gray-400";
    if (score >= 75) return "text-green-600";
    if (score >= 50) return "text-yellow-600";
    return "text-red-500";
  }

  const pending = suggestions.filter(s => s.status === "pending" || s.status === "unverified");

  return (
    <div className="p-6 space-y-6 max-w-6xl">
      <div className="flex items-center gap-3">
        <ShoppingBag className="w-7 h-7 text-red-600" />
        <div>
          <h1 className="text-2xl font-bold">Tedarikçi Otomasyonu</h1>
          <p className="text-sm text-gray-500">
            Gerçek tedarikçi katalog verisiyle ürün araştır — OpenAI yalnızca analiz için kullanılır, sahte URL/fiyat üretmez.
          </p>
        </div>
      </div>

      {/* Arama Formu */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Search className="w-5 h-5" /> Ürün Araştır
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label>Ürün Sorgusu</Label>
            <Textarea
              value={query}
              onChange={e => setQuery(e.target.value)}
              placeholder="çay, pirinç, mercimek, şeker, zeytinyağı"
              rows={3}
            />
            <p className="text-xs text-gray-400">Virgülle ayırın. Katalogdaki ürünler eşleştirilir.</p>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Limit (max ürün)</Label>
              <Input
                type="number"
                value={limit}
                onChange={e => setLimit(parseInt(e.target.value) || 20)}
                min={1}
                max={50}
              />
            </div>
            <div className="space-y-2">
              <Label>Kâr Oranı (%)</Label>
              <Input
                type="number"
                value={Math.round(profitRate * 100)}
                onChange={e => setProfitRate((parseInt(e.target.value) || 20) / 100)}
                min={5}
                max={100}
              />
            </div>
          </div>
          <div className="flex gap-3">
            <Button
              onClick={handleRun}
              disabled={running}
              className="bg-red-600 hover:bg-red-700 text-white"
            >
              {running ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Search className="w-4 h-4 mr-2" />}
              {running ? "Araştırılıyor..." : "Ürün Araştır"}
            </Button>
            <Button variant="outline" onClick={loadSuggestions} disabled={loading}>
              {loading ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : null}
              Önerileri Yükle
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Özet */}
      {suggestions.length > 0 && (
        <div className="grid grid-cols-3 gap-4">
          <Card>
            <CardContent className="pt-4 flex items-center gap-3">
              <Package className="w-8 h-8 text-blue-600" />
              <div>
                <div className="text-2xl font-bold">{pending.length}</div>
                <div className="text-sm text-gray-500">Bekleyen Öneri</div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-4 flex items-center gap-3">
              <CheckCircle className="w-8 h-8 text-green-600" />
              <div>
                <div className="text-2xl font-bold">{suggestions.filter(s => s.status === "approved").length}</div>
                <div className="text-sm text-gray-500">Onaylanan</div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-4 flex items-center gap-3">
              <TrendingUp className="w-8 h-8 text-red-600" />
              <div>
                <div className="text-2xl font-bold">
                  {pending.length > 0
                    ? `%${Math.round(pending.reduce((a, s) => a + (s.profitMargin ?? 0), 0) / pending.length)}`
                    : "—"}
                </div>
                <div className="text-sm text-gray-500">Ort. Kâr Oranı</div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Öneri Kartları */}
      {pending.length === 0 && suggestions.length === 0 && (
        <div className="text-center py-12 text-gray-400">
          <Search className="w-12 h-12 mx-auto mb-3 opacity-30" />
          <p>Henüz öneri yok. Yukarıdan ürün araştır.</p>
        </div>
      )}

      <div className="space-y-4">
        {pending.map(s => (
          <Card key={s.id} className={s.status === "unverified" ? "border-yellow-300" : ""}>
            <CardContent className="pt-4">
              <div className="flex gap-4">
                {/* Fotoğraf */}
                <div className="w-20 h-20 flex-shrink-0 rounded overflow-hidden bg-gray-100 flex items-center justify-center">
                  {s.imageUrl ? (
                    <img src={s.imageUrl} alt={s.name} className="w-full h-full object-cover" />
                  ) : (
                    <Package className="w-8 h-8 text-gray-300" />
                  )}
                </div>

                {/* Bilgiler */}
                <div className="flex-1 space-y-1">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <h3 className="font-semibold">{s.name}</h3>
                      <p className="text-sm text-gray-500">{s.brand} · {s.categoryName}</p>
                    </div>
                    {statusBadge(s)}
                  </div>

                  {s.description && (
                    <p className="text-xs text-gray-500">{s.description}</p>
                  )}

                  <div className="flex flex-wrap gap-4 text-sm">
                    <div>
                      <span className="text-gray-400">Tedarikçi:</span>{" "}
                      <span className="font-medium">{s.supplierName}</span>
                    </div>
                    <div>
                      <span className="text-gray-400">Maliyet:</span>{" "}
                      <span className="font-medium text-blue-700">₺{parseFloat(s.estimatedCostPrice ?? "0").toFixed(2)}</span>
                    </div>
                    <div>
                      <span className="text-gray-400">Satış Fiyatı:</span>{" "}
                      <span className="font-bold text-green-700">₺{parseFloat(s.estimatedSellPrice ?? "0").toFixed(2)}</span>
                    </div>
                    <div>
                      <span className="text-gray-400">Tahmini Kâr:</span>{" "}
                      <span className="font-medium text-red-700">
                        ₺{(parseFloat(s.estimatedSellPrice ?? "0") - parseFloat(s.estimatedCostPrice ?? "0")).toFixed(2)}
                      </span>
                    </div>
                    <div>
                      <span className="text-gray-400">Güven:</span>{" "}
                      <span className={`font-bold ${scoreColor(s.opportunityScore)}`}>
                        {s.opportunityScore ?? "—"}/100
                      </span>
                    </div>
                  </div>

                  {s.linkBroken && (
                    <div className="flex items-center gap-1 text-xs text-yellow-600">
                      <AlertTriangle className="w-3 h-3" />
                      Ürün URL'si doğrulanamadı — onaylamadan önce manuel kontrol edin
                    </div>
                  )}

                  {s.supplierProductUrl && !s.linkBroken && (
                    <a
                      href={s.supplierProductUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1 text-xs text-blue-600 hover:underline"
                    >
                      <ExternalLink className="w-3 h-3" /> Ürün linkini aç
                    </a>
                  )}
                </div>

                {/* Aksiyon Butonları */}
                <div className="flex flex-col gap-2 flex-shrink-0">
                  <Button
                    size="sm"
                    className="bg-green-600 hover:bg-green-700 text-white"
                    onClick={() => handleApprove(s.id)}
                  >
                    <CheckCircle className="w-4 h-4 mr-1" /> Onayla
                  </Button>
                  <div className="flex gap-1">
                    <Input
                      placeholder="Red sebebi"
                      className="text-xs h-8 w-24"
                      value={rejectReason[s.id] ?? ""}
                      onChange={e => setRejectReason(prev => ({ ...prev, [s.id]: e.target.value }))}
                    />
                    <Button
                      size="sm"
                      variant="destructive"
                      onClick={() => handleReject(s.id)}
                    >
                      <XCircle className="w-4 h-4" />
                    </Button>
                  </div>
                  <Button
                    size="sm"
                    variant="ghost"
                    className="text-gray-400 hover:text-red-500"
                    onClick={() => handleDelete(s.id)}
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
