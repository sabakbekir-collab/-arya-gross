import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { CreditCard, CheckCircle2, XCircle, ExternalLink } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const PAYMENT_METHODS = [
  { name: "Kapıda Ödeme", icon: "💵", status: "active", desc: "Nakit veya kart ile kapıda tahsilat" },
  { name: "WhatsApp Sipariş", icon: "💬", status: "active", desc: "WhatsApp üzerinden sipariş ve ödeme" },
  { name: "Havale / EFT", icon: "🏦", status: "active", desc: "Banka havalesi ile ödeme" },
  { name: "PayTR", icon: "💳", status: "missing", desc: "Online kredi kartı ödemesi (PayTR entegrasyonu gerekli)" },
  { name: "iyzico", icon: "💳", status: "missing", desc: "Online ödeme (iyzico API key gerekli)" },
];

export default function Payments() {
  const { toast } = useToast();
  return (
    <div className="space-y-4 animate-in fade-in duration-500">
      <div className="flex items-start gap-3">
        <div className="w-10 h-10 bg-green-500/20 rounded-xl flex items-center justify-center shrink-0 border border-green-500/30">
          <CreditCard className="h-5 w-5 text-green-400" />
        </div>
        <div>
          <h1 className="text-xl font-black">💳 Ödeme Yönetimi</h1>
          <p className="text-xs text-muted-foreground mt-0.5">Ödeme yöntemleri ve entegrasyonları</p>
        </div>
      </div>

      <div className="space-y-3">
        {PAYMENT_METHODS.map(p => (
          <Card key={p.name} className={`border ${p.status === "active" ? "border-green-500/20 bg-green-500/5" : "border-border bg-card/60"}`}>
            <CardContent className="p-4 flex items-center gap-4">
              <span className="text-2xl">{p.icon}</span>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="font-semibold text-sm">{p.name}</span>
                  <Badge className={p.status === "active" ? "bg-green-500/20 text-green-400 border-green-500/30 text-[9px]" : "bg-red-500/20 text-red-400 border-red-500/30 text-[9px]"}>
                    {p.status === "active" ? <><CheckCircle2 className="h-2.5 w-2.5 mr-0.5 inline" />Aktif</> : <><XCircle className="h-2.5 w-2.5 mr-0.5 inline" />Kurulmadı</>}
                  </Badge>
                </div>
                <p className="text-xs text-muted-foreground mt-0.5">{p.desc}</p>
              </div>
              {p.status === "missing" && (
                <Button variant="outline" size="sm" className="h-7 text-xs gap-1 shrink-0" onClick={() => toast({ title: "Sistem Ayarlarına git", description: "API anahtarını Sistem Ayarları'ndan girin." })}>
                  <ExternalLink className="h-3 w-3" /> Kur
                </Button>
              )}
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
