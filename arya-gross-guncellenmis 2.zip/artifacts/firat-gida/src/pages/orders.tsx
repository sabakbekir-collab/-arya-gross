import { useState } from "react";
import { useListOrders, getListOrdersQueryKey, useUpdateOrderStatus } from "@workspace/api-client-react";
import { formatCurrency, formatDate } from "@/lib/format";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { ClipboardList, ChevronRight, CheckCircle2, XCircle, ShoppingBag, Truck, Package, MessageCircle, Banknote, ExternalLink, Clock, AlertTriangle } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

const WHATSAPP_PHONE = import.meta.env.VITE_WHATSAPP_PHONE || "905352765849";
const IBAN = "TR66 0001 0000 9587 1394 3350 01";

const ORDER_STATUSES = [
  { value: "beklemede",        label: "Yeni Sipariş",      color: "bg-yellow-500/20 text-yellow-400 border-yellow-500/30" },
  { value: "kabul-edildi",     label: "Kabul Edildi",      color: "bg-cyan-500/20 text-cyan-400 border-cyan-500/30" },
  { value: "odeme-bekleniyor", label: "Ödeme Bekleniyor",  color: "bg-orange-500/20 text-orange-400 border-orange-500/30" },
  { value: "hazirlaniyor",     label: "Hazırlanıyor",      color: "bg-indigo-500/20 text-indigo-400 border-indigo-500/30" },
  { value: "kargoda",          label: "Kargoya Verildi",   color: "bg-purple-500/20 text-purple-400 border-purple-500/30" },
  { value: "teslim edildi",    label: "Teslim Edildi",     color: "bg-green-500/20 text-green-400 border-green-500/30" },
  { value: "iptal",            label: "İptal Edildi",      color: "bg-red-500/20 text-red-400 border-red-500/30" },
];

const PAYMENT_METHOD_LABELS: Record<string, { label: string; icon: React.ElementType; color: string }> = {
  kapida: { label: "Kapıda Ödeme", icon: Truck, color: "text-blue-400" },
  whatsapp: { label: "WhatsApp", icon: MessageCircle, color: "text-green-400" },
  havale: { label: "Havale/EFT", icon: Banknote, color: "text-yellow-400" },
};

function StatusBadge({ status }: { status: string }) {
  const info = ORDER_STATUSES.find(s => s.value === status) || ORDER_STATUSES[0];
  return <Badge className={cn("text-[10px] border shrink-0", info.color)}>{info.label}</Badge>;
}

function PaymentBadge({ method }: { method?: string | null }) {
  if (!method) return null;
  const info = PAYMENT_METHOD_LABELS[method];
  if (!info) return null;
  const Icon = info.icon;
  return (
    <span className={cn("flex items-center gap-1 text-[10px] font-medium", info.color)}>
      <Icon className="h-3 w-3" />{info.label}
    </span>
  );
}

function ScoreBar({ value, max = 100, color = "bg-primary" }: { value: number; max?: number; color?: string }) {
  const pct = Math.round((value / max) * 100);
  return (
    <div className="flex items-center gap-2">
      <div className="flex-1 h-1.5 bg-secondary rounded-full overflow-hidden">
        <div className={cn("h-full rounded-full transition-all", color)} style={{ width: `${pct}%` }} />
      </div>
      <span className="text-[10px] font-mono w-6 text-right">{value}</span>
    </div>
  );
}

interface AdminAction {
  label: string;
  icon: React.ElementType;
  status?: string;
  adminApprovalStatus?: string;
  sourcingStatus?: string;
  supplierPurchaseStatus?: string;
  color: string;
  variant?: "default" | "outline" | "ghost" | "destructive";
}

const FINAL_STATUSES = ["teslim edildi", "iptal"];

function getAdminActions(order: any): AdminAction[] {
  const status = order.status;
  const payMethod = order.paymentMethod;
  const actions: AdminAction[] = [];

  if (status === "beklemede") {
    actions.push({ label: "✅ Kabul Et", icon: CheckCircle2, status: "kabul-edildi", adminApprovalStatus: "onaylandi", color: "text-green-400 border-green-500/30 hover:bg-green-500/10" });
    actions.push({ label: "❌ Reddet", icon: XCircle, status: "iptal", adminApprovalStatus: "reddedildi", color: "text-red-400 border-red-500/30 hover:bg-red-500/10" });
  }
  if (status === "kabul-edildi") {
    if (payMethod === "havale") {
      actions.push({ label: "💰 Ödeme Alındı", icon: CheckCircle2, status: "hazirlaniyor", adminApprovalStatus: "onaylandi", color: "text-blue-400 border-blue-500/30 hover:bg-blue-500/10" });
    } else {
      actions.push({ label: "📦 Hazırlamaya Başla", icon: Package, status: "hazirlaniyor", color: "text-indigo-400 border-indigo-500/30 hover:bg-indigo-500/10" });
    }
  }
  if (status === "odeme-bekleniyor") {
    actions.push({ label: "💰 Ödeme Alındı", icon: CheckCircle2, status: "hazirlaniyor", adminApprovalStatus: "onaylandi", color: "text-blue-400 border-blue-500/30 hover:bg-blue-500/10" });
  }
  if (status === "hazirlaniyor") {
    actions.push({ label: "🚚 Kargoya Verildi", icon: Truck, status: "kargoda", color: "text-purple-400 border-purple-500/30 hover:bg-purple-500/10" });
    actions.push({ label: "🛍️ Satıcıdan Aldım", icon: ShoppingBag, supplierPurchaseStatus: "alindi", color: "text-yellow-400 border-yellow-500/30 hover:bg-yellow-500/10" });
  }
  if (status === "kargoda") {
    actions.push({ label: "✅ Teslim Edildi", icon: Package, status: "teslim edildi", color: "text-green-400 border-green-500/30 hover:bg-green-500/10" });
  }
  if (!FINAL_STATUSES.includes(status) && status !== "beklemede") {
    actions.push({ label: "🚫 İptal Et", icon: XCircle, status: "iptal", color: "text-red-400 border-red-500/30 hover:bg-red-500/10", variant: "outline" });
  }

  return actions;
}

function OrderDetailDialog({ order }: { order: any }) {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const updateStatus = useUpdateOrderStatus({
    mutation: {
      onSuccess: () => {
        toast({ title: "Güncellendi", description: "Sipariş durumu değiştirildi." });
        queryClient.invalidateQueries({ queryKey: getListOrdersQueryKey() });
      }
    }
  });

  const statusInfo = ORDER_STATUSES.find(s => s.value === order.status) || ORDER_STATUSES[0];
  const adminActions = getAdminActions(order);
  const supplierUrl = order.supplierLinks?.[0];

  const payLabel = PAYMENT_METHOD_LABELS[order.paymentMethod]?.label || order.paymentMethod || "—";
  const itemsText = (order.items || []).map((i: any) => `• ${i.quantity}x ${i.name} — ${formatCurrency(i.subtotal || 0)}`).join("\n");
  const waMsg = encodeURIComponent(
    `🛒 YENİ SİPARİŞ\n\n` +
    `Sipariş No: #${order.id}\n\n` +
    `Müşteri: ${order.customerName || "—"}\n` +
    `Telefon: ${order.customerPhone || "—"}\n` +
    `Adres: ${order.address || "—"}\n\n` +
    `Ürünler:\n${itemsText}\n\n` +
    `Toplam: ${formatCurrency(order.total)}\n` +
    `Ödeme: ${payLabel}\n` +
    (order.notes ? `Not: ${order.notes}` : "")
  );

  return (
    <DialogContent className="sm:max-w-[680px] border-primary/20 bg-card max-h-[90vh] overflow-y-auto">
      <DialogHeader>
        <DialogTitle className="flex items-center gap-2 text-lg">
          <span className="text-primary font-black">#{order.id}</span>
          <StatusBadge status={order.status} />
          {order.paymentMethod && <PaymentBadge method={order.paymentMethod} />}
        </DialogTitle>
      </DialogHeader>

      <div className="space-y-4">
        {/* Admin Actions */}
        {adminActions.length > 0 && (
          <div>
            <p className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground mb-2">⚡ Hızlı İşlemler</p>
            <div className="flex flex-wrap gap-2">
              {adminActions.map(action => {
                const Icon = action.icon;
                return (
                  <Button key={action.label} variant="outline" size="sm"
                    className={cn("gap-1.5 text-xs h-8 border", action.color)}
                    disabled={updateStatus.isPending}
                    onClick={() => updateStatus.mutate({ id: order.id, data: {
                      status: action.status || order.status,
                      ...(action.adminApprovalStatus && { adminApprovalStatus: action.adminApprovalStatus }),
                      ...(action.sourcingStatus && { sourcingStatus: action.sourcingStatus }),
                      ...(action.supplierPurchaseStatus && { supplierPurchaseStatus: action.supplierPurchaseStatus }),
                    }})}>
                    <Icon className="h-3.5 w-3.5" /> {action.label}
                  </Button>
                );
              })}
              {supplierUrl && (
                <a href={supplierUrl} target="_blank" rel="noopener noreferrer">
                  <Button variant="outline" size="sm" className="gap-1.5 text-xs h-8 border border-indigo-500/30 text-indigo-400 hover:bg-indigo-500/10">
                    <ExternalLink className="h-3.5 w-3.5" /> Satıcı Linkini Aç
                  </Button>
                </a>
              )}
              <a href={`https://wa.me/${WHATSAPP_PHONE}?text=${waMsg}`} target="_blank" rel="noopener noreferrer">
                <Button variant="outline" size="sm" className="gap-1.5 text-xs h-8 border border-green-500/30 text-green-400 hover:bg-green-500/10">
                  <MessageCircle className="h-3.5 w-3.5" /> WhatsApp
                </Button>
              </a>
            </div>
          </div>
        )}

        {/* Havale bilgileri */}
        {order.paymentMethod === "havale" && (order.status === "beklemede" || order.status === "odeme-bekleniyor") && (
          <div className="bg-yellow-500/10 border border-yellow-500/20 rounded-xl p-3 space-y-1">
            <p className="text-xs font-bold text-yellow-400 flex items-center gap-1"><Banknote className="h-3.5 w-3.5" /> Havale Bilgileri</p>
            <div className="text-xs text-muted-foreground">Banka: <span className="text-foreground font-semibold">Ziraat Bankası</span></div>
            <div className="text-xs text-muted-foreground">IBAN: <span className="text-foreground font-mono font-bold">{IBAN}</span></div>
            <div className="text-xs text-muted-foreground">Tutar: <span className="text-primary font-black">{formatCurrency(order.total)}</span></div>
          </div>
        )}

        {/* Müşteri & Sipariş Bilgileri */}
        <div className="grid grid-cols-2 gap-3">
          <div className="bg-secondary/30 rounded-xl p-3 space-y-1">
            <p className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">Müşteri</p>
            <p className="font-semibold text-sm">{order.customerName || "—"}</p>
            <p className="text-xs text-muted-foreground">{order.customerPhone}</p>
            <p className="text-xs text-muted-foreground">{order.customerEmail}</p>
            {order.address && <p className="text-xs text-muted-foreground">{order.address}</p>}
          </div>
          <div className="bg-secondary/30 rounded-xl p-3 space-y-1">
            <p className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">Sipariş</p>
            <p className="text-xs text-muted-foreground">{formatDate(order.createdAt)}</p>
            {order.notes && <p className="text-xs text-muted-foreground">Not: {order.notes}</p>}
            {order.adminApprovalStatus && (
              <p className="text-xs"><span className="text-muted-foreground">Onay: </span><span className="font-semibold">{order.adminApprovalStatus}</span></p>
            )}
            {order.orderType && order.orderType !== "normal" && (
              <Badge className="text-[9px] bg-indigo-500/20 text-indigo-400 border-indigo-500/30">{order.orderType}</Badge>
            )}
          </div>
        </div>

        {/* Durum Değiştir */}
        <div>
          <p className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground mb-2">Durum Güncelle</p>
          <Select value={order.status} onValueChange={(val) => updateStatus.mutate({ id: order.id, data: { status: val } })}>
            <SelectTrigger className="bg-secondary/50 border-border h-9 text-sm">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {ORDER_STATUSES.map(s => <SelectItem key={s.value} value={s.value} className="text-xs">{s.label}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>

        {/* Ürünler */}
        <div>
          <p className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground mb-2">Sipariş İçeriği</p>
          <div className="space-y-2">
            {order.items.map((item: any) => (
              <div key={item.productId} className="flex justify-between items-center py-2 px-3 bg-secondary/20 rounded-lg">
                <div>
                  <div className="font-semibold text-sm">{item.name}</div>
                  <div className="text-xs text-muted-foreground">{item.quantity} × {formatCurrency(item.price)}</div>
                </div>
                <div className="font-bold text-primary">{formatCurrency(item.subtotal)}</div>
              </div>
            ))}
          </div>
          <div className="flex justify-between items-center mt-3 pt-3 border-t border-border">
            <span className="font-bold text-sm">Genel Toplam</span>
            <span className="text-xl font-black text-primary">{formatCurrency(order.total)}</span>
          </div>
        </div>
      </div>
    </DialogContent>
  );
}

export default function Orders() {
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const { data: orders, isLoading } = useListOrders({
    status: statusFilter !== "all" ? statusFilter : undefined
  });

  const pending = orders?.filter(o => o.status === "beklemede").length || 0;
  const odeme = orders?.filter(o => o.status === "odeme-bekleniyor").length || 0;

  return (
    <div className="space-y-4 animate-in fade-in duration-500">
      <div className="flex items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-black tracking-tight flex items-center gap-2">
            📦 Sipariş Yönetimi
            {pending > 0 && <Badge className="bg-yellow-500/20 text-yellow-400 border-yellow-500/30 text-xs">{pending} yeni</Badge>}
            {odeme > 0 && <Badge className="bg-orange-500/20 text-orange-400 border-orange-500/30 text-xs">{odeme} ödeme bekliyor</Badge>}
          </h1>
          <p className="text-xs text-muted-foreground mt-0.5">Siparişleri takip edin ve operasyonu yönetin.</p>
        </div>
      </div>

      {/* Status Summary */}
      <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
        {ORDER_STATUSES.slice(0, 6).map(s => {
          const count = orders?.filter(o => o.status === s.value).length || 0;
          return (
            <button key={s.value} onClick={() => setStatusFilter(statusFilter === s.value ? "all" : s.value)}
              className={cn("bg-secondary/30 rounded-xl p-2.5 text-center border-2 transition-all hover:border-border",
                statusFilter === s.value ? "border-primary bg-primary/10" : "border-transparent")}>
              <div className="text-lg font-black">{count}</div>
              <div className="text-[9px] text-muted-foreground leading-tight mt-0.5">{s.label}</div>
            </button>
          );
        })}
      </div>

      <Card className="border-border bg-card/50">
        <CardHeader className="pb-3 pt-4 px-4">
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2 text-base">
              <ClipboardList className="h-4 w-4 text-primary" />
              {orders?.length || 0} Sipariş
            </CardTitle>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-[160px] bg-secondary/50 border-border h-8 text-xs">
                <SelectValue placeholder="Tüm Siparişler" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all" className="text-xs">Tüm Siparişler</SelectItem>
                {ORDER_STATUSES.map(s => <SelectItem key={s.value} value={s.value} className="text-xs">{s.label}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
        </CardHeader>
        <CardContent className="px-4 pb-4">
          {isLoading ? (
            <div className="space-y-2">
              {[1,2,3].map(i => <div key={i} className="h-16 bg-secondary/30 rounded-xl animate-pulse" />)}
            </div>
          ) : !orders || orders.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground border-2 border-dashed border-border rounded-xl">
              <ClipboardList className="h-10 w-10 mx-auto mb-3 opacity-20" />
              <p className="text-sm font-semibold">Henüz gerçek sipariş yok.</p>
              <p className="text-xs text-muted-foreground mt-1">Müşteriler mağazadan sipariş verince burada listelenecek.</p>
            </div>
          ) : (
            <div className="space-y-2">
              {orders.map(order => {
                const isUrgent = order.status === "beklemede" || order.status === "odeme-bekleniyor";
                return (
                  <Dialog key={order.id}>
                    <DialogTrigger asChild>
                      <div className={cn(
                        "flex items-center gap-3 p-3 rounded-xl border cursor-pointer hover:border-primary/30 transition-all group",
                        isUrgent ? "border-yellow-500/30 bg-yellow-500/5" : "border-border bg-secondary/20"
                      )}>
                        {/* ID + Status */}
                        <div className="shrink-0 text-center w-12">
                          <div className="font-black text-sm text-primary">#{order.id}</div>
                          {isUrgent && <AlertTriangle className="h-3 w-3 text-yellow-400 mx-auto mt-0.5" />}
                        </div>

                        {/* Customer */}
                        <div className="flex-1 min-w-0">
                          <div className="font-semibold text-sm truncate">{order.customerName || "Bilinmiyor"}</div>
                          <div className="flex items-center gap-2 mt-0.5">
                            <StatusBadge status={order.status} />
                            <PaymentBadge method={order.paymentMethod} />
                          </div>
                        </div>

                        {/* Date + Amount */}
                        <div className="text-right shrink-0">
                          <div className="font-black text-primary">{formatCurrency(order.total)}</div>
                          <div className="text-[10px] text-muted-foreground mt-0.5 flex items-center gap-1 justify-end">
                            <Clock className="h-3 w-3" />
                            {formatDate(order.createdAt)}
                          </div>
                        </div>

                        <ChevronRight className="h-4 w-4 text-muted-foreground shrink-0 group-hover:text-primary transition-colors" />
                      </div>
                    </DialogTrigger>
                    <OrderDetailDialog order={order} />
                  </Dialog>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
