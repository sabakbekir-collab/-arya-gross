import {
  useGetDashboardSummary,
  useGetTopProducts,
  useGetRecentOrders,
} from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { formatCurrency } from "@/lib/format";
import {
  TrendingUp,
  AlertTriangle,
  ShoppingCart,
  DollarSign,
  Activity,
  BrainCircuit,
  Zap,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Link } from "wouter";

const statusColors: Record<string, string> = {
  beklemede: "bg-yellow-500/20 text-yellow-400 border-yellow-500/30",
  hazirlaniyor: "bg-blue-500/20 text-blue-400 border-blue-500/30",
  kargoda: "bg-purple-500/20 text-purple-400 border-purple-500/30",
  "teslim edildi": "bg-green-500/20 text-green-400 border-green-500/30",
  iptal: "bg-red-500/20 text-red-400 border-red-500/30",
};

function toArray(data: any): any[] {
  if (Array.isArray(data)) return data;
  if (Array.isArray(data?.data)) return data.data;
  if (Array.isArray(data?.products)) return data.products;
  if (Array.isArray(data?.orders)) return data.orders;
  if (Array.isArray(data?.items)) return data.items;
  return [];
}

export default function Dashboard() {
  const { data: summary, isLoading: isLoadingSummary } = useGetDashboardSummary();
  const { data: topProductsRaw, isLoading: isLoadingTop } = useGetTopProducts();
  const { data: recentOrdersRaw, isLoading: isLoadingOrders } = useGetRecentOrders();

  const topProducts = toArray(topProductsRaw);
  const recentOrders = toArray(recentOrdersRaw);

  return (
    <div className="space-y-4 animate-in fade-in duration-500">
      <div>
        <h1 className="text-2xl font-black tracking-tight text-foreground">
          📊 Kontrol Paneli
        </h1>
        <p className="text-xs text-muted-foreground mt-1">
          Arya Gross — gerçek zamanlı performans özeti
        </p>
      </div>

      <Link href="/arya">
        <div className="flex items-center gap-3 p-3 rounded-xl border border-primary/30 bg-primary/10 hover:bg-primary/15 transition-colors cursor-pointer">
          <div className="w-9 h-9 bg-primary/20 rounded-lg flex items-center justify-center shrink-0">
            <BrainCircuit className="h-5 w-5 text-primary" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="text-sm font-bold text-primary leading-none">
              🧠 Arya AI Beyin
            </div>
            <div className="text-[11px] text-muted-foreground mt-0.5">
              Tek tıkla tüm otomasyonları başlat
            </div>
          </div>
          <Zap className="h-4 w-4 text-primary shrink-0" />
        </div>
      </Link>

      {isLoadingSummary ? (
        <div className="grid grid-cols-2 gap-3">
          {[1, 2, 3, 4].map((i) => (
            <Card key={i} className="h-24 animate-pulse bg-secondary/40 border-border" />
          ))}
        </div>
      ) : summary ? (
        <div className="grid grid-cols-2 gap-3">
          <MetricCard
            title="Bugünkü Gelir"
            value={formatCurrency((summary as any).todayRevenue || 0)}
            sub="Son 24 saat"
            icon={<DollarSign className="h-3.5 w-3.5 text-primary" />}
            color="text-primary"
            cardClass="border-primary/25 bg-primary/5"
          />

          <MetricCard
            title="Toplam Gelir"
            value={formatCurrency((summary as any).totalRevenue || 0)}
            sub="Tüm zamanlar"
            icon={<TrendingUp className="h-3.5 w-3.5 text-accent" />}
            color="text-accent"
          />

          <MetricCard
            title="Bekleyen"
            value={(summary as any).pendingOrders || 0}
            sub="Sipariş"
            icon={<ShoppingCart className="h-3.5 w-3.5 text-muted-foreground" />}
          />

          <MetricCard
            title="Düşük Stok"
            value={(summary as any).lowStockCount || 0}
            sub="Kritik ürün"
            icon={
              <AlertTriangle
                className={`h-3.5 w-3.5 ${
                  (summary as any).lowStockCount > 0
                    ? "text-red-400"
                    : "text-muted-foreground"
                }`}
              />
            }
            color={(summary as any).lowStockCount > 0 ? "text-red-400" : ""}
            cardClass={
              (summary as any).lowStockCount > 0
                ? "border-red-500/30 bg-red-500/5"
                : "border-border bg-card/60"
            }
          />
        </div>
      ) : null}

      <Card className="border-border bg-card/60">
        <CardHeader className="py-3 px-4 pb-2">
          <CardTitle className="text-sm flex items-center gap-2">
            <Activity className="h-4 w-4 text-primary" />
            Son Siparişler
          </CardTitle>
        </CardHeader>

        <CardContent className="px-4 pb-3">
          {isLoadingOrders ? (
            <SkeletonRows count={3} height="h-12" />
          ) : recentOrders.length > 0 ? (
            <div className="space-y-2">
              {recentOrders.map((order: any) => {
                const status = String(order.status || "beklemede").toLowerCase();

                return (
                  <div
                    key={order.id}
                    className="flex items-center justify-between gap-2 p-2.5 rounded-lg bg-secondary/30 border border-border/50"
                  >
                    <div className="min-w-0">
                      <div className="flex items-center gap-1.5 min-w-0">
                        <span className="text-[10px] font-mono text-muted-foreground shrink-0">
                          #{order.id}
                        </span>
                        <span className="text-sm font-semibold truncate">
                          {order.customerName || order.customer_name || "Müşteri"}
                        </span>
                      </div>

                      <Badge
                        className={`text-[9px] mt-0.5 px-1.5 py-0 h-4 ${
                          statusColors[status] ?? "bg-secondary text-muted-foreground"
                        }`}
                      >
                        {status.toUpperCase()}
                      </Badge>
                    </div>

                    <span className="font-black font-mono text-sm text-foreground shrink-0">
                      {formatCurrency(order.total || 0)}
                    </span>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="py-6 text-center text-sm text-muted-foreground">
              Henüz sipariş yok
            </div>
          )}
        </CardContent>
      </Card>

      <Card className="border-border bg-card/60">
        <CardHeader className="py-3 px-4 pb-2">
          <CardTitle className="text-sm flex items-center gap-2">
            <TrendingUp className="h-4 w-4 text-accent" />
            🏆 En Çok Satanlar
          </CardTitle>
        </CardHeader>

        <CardContent className="px-4 pb-3">
          {isLoadingTop ? (
            <SkeletonRows count={3} height="h-10" />
          ) : topProducts.length > 0 ? (
            <div className="space-y-2">
              {topProducts.map((product: any, i: number) => (
                <div
                  key={product.productId || product.id || i}
                  className="flex items-center justify-between p-2.5 rounded-lg border border-border/50 hover:bg-secondary/20 transition-colors"
                >
                  <div className="flex items-center gap-2 min-w-0">
                    <span className="text-xs font-black text-primary w-5 shrink-0">
                      #{i + 1}
                    </span>
                    <div className="min-w-0">
                      <div className="text-sm font-medium truncate">
                        {product.name || product.productName || "Ürün"}
                      </div>
                      <div className="text-[10px] text-muted-foreground">
                        {product.totalSold || product.soldQty || 0} adet
                      </div>
                    </div>
                  </div>

                  <span className="font-black text-sm text-accent shrink-0 ml-2">
                    {formatCurrency(product.revenue || product.totalRevenue || 0)}
                  </span>
                </div>
              ))}
            </div>
          ) : (
            <div className="py-6 text-center text-sm text-muted-foreground">
              Veri bulunamadı
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

function MetricCard({
  title,
  value,
  sub,
  icon,
  color = "",
  cardClass = "border-border bg-card/60",
}: {
  title: string;
  value: string | number;
  sub: string;
  icon: React.ReactNode;
  color?: string;
  cardClass?: string;
}) {
  return (
    <Card className={cardClass}>
      <CardContent className="p-3">
        <div className="flex items-center justify-between mb-1">
          <span className="text-[10px] text-muted-foreground uppercase tracking-wider">
            {title}
          </span>
          {icon}
        </div>
        <div className={`text-xl font-black ${color}`}>{value}</div>
        <div className="text-[10px] text-muted-foreground">{sub}</div>
      </CardContent>
    </Card>
  );
}

function SkeletonRows({ count, height }: { count: number; height: string }) {
  return (
    <div className="space-y-2">
      {Array.from({ length: count }).map((_, i) => (
        <div key={i} className={`${height} bg-secondary/40 animate-pulse rounded-lg`} />
      ))}
    </div>
  );
}