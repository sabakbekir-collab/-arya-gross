import { useState, useMemo, useEffect } from "react";
import { useLocation } from "wouter";
import { useListProducts, useListCategories, useAddToCart, getGetCartQueryKey } from "@workspace/api-client-react";
import { formatCurrency } from "@/lib/format";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { ShoppingCart, Heart, SlidersHorizontal, Search, X, ChevronDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Link } from "wouter";

const PLACEHOLDER = "/placeholder-product.svg";

function resolveImg(p: any): string {
  const raw = p?.imageUrl || p?.image_url || p?.image || p?.photoUrl || p?.fotograf_url || p?.productImage || "";
  return typeof raw === "string" && raw.startsWith("http") ? raw : PLACEHOLDER;
}

function ProductImage({ product, className = "" }: { product: any; className?: string }) {
  const [src, setSrc] = useState(() => resolveImg(product));
  const [errored, setErrored] = useState(false);
  useEffect(() => { setSrc(resolveImg(product)); setErrored(false); }, [product?.imageUrl, product?.image_url, product?.image]);
  return <img src={src} alt={product?.name ?? ""} onError={() => { if (!errored) { setErrored(true); setSrc(PLACEHOLDER); } }} className={className} />;
}

function StoreProductCard({ product }: { product: any }) {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [liked, setLiked] = useState(false);
  const addToCart = useAddToCart({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetCartQueryKey() });
        toast({ title: "Sepete eklendi ✓", description: product.name, duration: 2000 });
      }
    }
  });

  return (
    <div className="group bg-white rounded-2xl shadow-sm hover:shadow-lg transition-all duration-300 overflow-hidden border border-gray-100 hover:border-[#DC2626]/20 flex flex-col">
      <div className="relative overflow-hidden bg-gray-50 aspect-square">
        <Link href={`/magaza/urun/${product.id}`}>
          <ProductImage product={product} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 cursor-pointer" />
        </Link>
        <div className="absolute top-2 left-2 flex flex-col gap-1">
          {product.stock > 0 && product.stock <= 5 && (
            <Badge className="bg-orange-500 text-white text-[10px] px-1.5 py-0.5 font-bold">Son {product.stock} adet</Badge>
          )}
          {product.stock === 0 && (
            <Badge className="bg-gray-400 text-white text-[10px] px-1.5 py-0.5">Tükendi</Badge>
          )}
        </div>
        <button
          onClick={() => setLiked(!liked)}
          className="absolute top-2 right-2 w-8 h-8 bg-white rounded-full shadow flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
          <Heart className={`h-4 w-4 ${liked ? "fill-[#DC2626] text-[#DC2626]" : "text-gray-400"}`} />
        </button>
        <div className="absolute bottom-0 left-0 right-0 translate-y-full group-hover:translate-y-0 transition-transform duration-300">
          <Button
            onClick={() => addToCart.mutate({ data: { productId: product.id, quantity: 1 } })}
            disabled={addToCart.isPending || product.stock === 0}
            className="w-full rounded-none bg-[#DC2626] hover:bg-[#b91c1c] text-white font-bold py-2.5 text-sm gap-2">
            <ShoppingCart className="h-4 w-4" />
            {product.stock === 0 ? "Stokta Yok" : "Sepete Ekle"}
          </Button>
        </div>
      </div>
      <div className="p-3 flex flex-col flex-1">
        <Link href={`/magaza/urun/${product.id}`}>
          <p className="text-[10px] text-gray-400 uppercase tracking-wide truncate mb-0.5">{product.categoryName || "Genel"}</p>
          <h3 className="font-semibold text-gray-900 text-sm leading-tight line-clamp-2 hover:text-[#DC2626] cursor-pointer mb-2">{product.name}</h3>
        </Link>
        <div className="mt-auto flex items-end justify-between">
          <div>
            <div className="text-base font-black text-[#DC2626]">{formatCurrency(product.price)}</div>
          </div>
          <Button size="sm"
            onClick={() => addToCart.mutate({ data: { productId: product.id, quantity: 1 } })}
            disabled={addToCart.isPending || product.stock === 0}
            className="bg-[#DC2626] hover:bg-[#b91c1c] text-white h-8 w-8 p-0 rounded-full">
            <ShoppingCart className="h-3.5 w-3.5" />
          </Button>
        </div>
      </div>
    </div>
  );
}

const SORT_OPTIONS = [
  { label: "Önerilen", value: "default" },
  { label: "Fiyat: Düşükten Yükseğe", value: "price_asc" },
  { label: "Fiyat: Yüksekten Düşüğe", value: "price_desc" },
  { label: "En Yeni", value: "newest" },
  { label: "İsim A-Z", value: "name_asc" },
];

export default function ProductList() {
  const [location] = useLocation();
  const params = new URLSearchParams(typeof window !== "undefined" ? window.location.search : "");
  const initialQ = params.get("q") || "";
  const initialKat = params.get("kat") || "";

  const [search, setSearch] = useState(initialQ);
  const [selectedCat, setSelectedCat] = useState<string>("all");
  const [sort, setSort] = useState("default");
  const [priceMin, setPriceMin] = useState("");
  const [priceMax, setPriceMax] = useState("");
  const [showFilters, setShowFilters] = useState(false);
  const [inStockOnly, setInStockOnly] = useState(false);

  const { data: products } = useListProducts();
  const { data: categories } = useListCategories();

  const filtered = useMemo(() => {
    let list = (products || []).filter((p: any) =>
      p.isActive === true && (p.productStatus === "active" || !p.productStatus)
    );
    if (search) list = list.filter((p: any) => p.name.toLowerCase().includes(search.toLowerCase()));
    if (selectedCat !== "all") list = list.filter((p: any) => String(p.categoryId) === selectedCat);
    if (inStockOnly) list = list.filter((p: any) => p.stock > 0);
    if (priceMin) list = list.filter((p: any) => p.price >= Number(priceMin));
    if (priceMax) list = list.filter((p: any) => p.price <= Number(priceMax));
    if (sort === "price_asc") list = [...list].sort((a: any, b: any) => a.price - b.price);
    else if (sort === "price_desc") list = [...list].sort((a: any, b: any) => b.price - a.price);
    else if (sort === "name_asc") list = [...list].sort((a: any, b: any) => a.name.localeCompare(b.name));
    else if (sort === "newest") list = [...list].reverse();
    return list;
  }, [products, search, selectedCat, sort, priceMin, priceMax, inStockOnly]);

  const clearFilters = () => {
    setSearch("");
    setSelectedCat("all");
    setPriceMin("");
    setPriceMax("");
    setInStockOnly(false);
  };
  const hasFilters = search || selectedCat !== "all" || priceMin || priceMax || inStockOnly;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6">
      {/* Breadcrumb */}
      <div className="text-xs text-gray-400 mb-4 flex items-center gap-1">
        <Link href="/magaza" className="hover:text-[#DC2626]">Ana Sayfa</Link>
        <span>/</span>
        <span className="text-gray-700 font-medium">Tüm Ürünler</span>
      </div>

      <div className="flex gap-6">
        {/* Sidebar Filters */}
        <aside className={`${showFilters ? "fixed inset-0 z-50 sm:relative sm:inset-auto" : "hidden sm:block"} w-64 shrink-0`}>
          {showFilters && <div className="sm:hidden fixed inset-0 bg-black/50 z-40" onClick={() => setShowFilters(false)} />}
          <div className={`${showFilters ? "fixed left-0 top-0 h-full z-50 overflow-y-auto sm:relative sm:h-auto sm:z-auto" : ""} bg-white rounded-2xl shadow-sm border border-gray-100 p-4 space-y-5 w-64`}>
            <div className="flex items-center justify-between">
              <h3 className="font-black text-gray-900">Filtreler</h3>
              {hasFilters && (
                <button onClick={clearFilters} className="text-[#DC2626] text-xs font-semibold hover:underline flex items-center gap-1">
                  <X className="h-3 w-3" /> Temizle
                </button>
              )}
            </div>

            {/* Category Filter */}
            <div>
              <h4 className="font-bold text-gray-800 text-sm mb-2">Kategori</h4>
              <div className="space-y-1">
                <button onClick={() => setSelectedCat("all")}
                  className={`w-full text-left px-2 py-1.5 rounded text-sm ${selectedCat === "all" ? "bg-[#DC2626] text-white font-semibold" : "text-gray-600 hover:bg-gray-50"}`}>
                  Tüm Kategoriler
                </button>
                {(categories || []).map((cat: any) => (
                  <button key={cat.id} onClick={() => setSelectedCat(String(cat.id))}
                    className={`w-full text-left px-2 py-1.5 rounded text-sm ${selectedCat === String(cat.id) ? "bg-[#DC2626] text-white font-semibold" : "text-gray-600 hover:bg-gray-50"}`}>
                    {cat.name}
                  </button>
                ))}
              </div>
            </div>

            {/* Price Filter */}
            <div>
              <h4 className="font-bold text-gray-800 text-sm mb-2">Fiyat Aralığı</h4>
              <div className="flex gap-2">
                <Input placeholder="Min ₺" value={priceMin} onChange={e => setPriceMin(e.target.value)}
                  className="h-8 text-xs border-gray-200" type="number" />
                <Input placeholder="Max ₺" value={priceMax} onChange={e => setPriceMax(e.target.value)}
                  className="h-8 text-xs border-gray-200" type="number" />
              </div>
            </div>

            {/* Stock Filter */}
            <div>
              <label className="flex items-center gap-2 cursor-pointer">
                <input type="checkbox" checked={inStockOnly} onChange={e => setInStockOnly(e.target.checked)}
                  className="accent-[#DC2626] w-4 h-4" />
                <span className="text-sm text-gray-700 font-medium">Sadece Stokta Olanlar</span>
              </label>
            </div>

            {showFilters && (
              <Button onClick={() => setShowFilters(false)} className="w-full bg-[#DC2626] hover:bg-[#b91c1c] text-white font-bold sm:hidden">
                Uygula ({filtered.length} ürün)
              </Button>
            )}
          </div>
        </aside>

        {/* Main Content */}
        <div className="flex-1 min-w-0">
          {/* Toolbar */}
          <div className="flex flex-wrap items-center gap-3 mb-5">
            <div className="relative flex-1 max-w-sm">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
              <Input value={search} onChange={e => setSearch(e.target.value)} placeholder="Ürün ara..."
                className="pl-9 h-10 border-gray-200 focus-visible:border-[#DC2626] focus-visible:ring-0" />
            </div>
            <Button variant="outline" size="sm" onClick={() => setShowFilters(true)}
              className="sm:hidden border-gray-200 gap-2 h-10">
              <SlidersHorizontal className="h-4 w-4" /> Filtrele
            </Button>
            <div className="flex items-center gap-2 ml-auto">
              <span className="text-sm text-gray-500 hidden sm:block">{filtered.length} ürün</span>
              <div className="relative">
                <select value={sort} onChange={e => setSort(e.target.value)}
                  className="appearance-none bg-white border-2 border-gray-200 rounded-lg text-sm px-3 py-2 pr-8 focus:outline-none focus:border-[#DC2626] cursor-pointer">
                  {SORT_OPTIONS.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
                </select>
                <ChevronDown className="absolute right-2 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400 pointer-events-none" />
              </div>
            </div>
          </div>

          {/* Active Filters */}
          {hasFilters && (
            <div className="flex flex-wrap gap-2 mb-4">
              {search && (
                <Badge className="bg-gray-100 text-gray-700 pr-1 pl-2 gap-1">
                  Arama: {search}
                  <button onClick={() => setSearch("")}><X className="h-3 w-3" /></button>
                </Badge>
              )}
              {priceMin && (
                <Badge className="bg-gray-100 text-gray-700 pr-1 pl-2 gap-1">
                  Min: {priceMin}₺ <button onClick={() => setPriceMin("")}><X className="h-3 w-3" /></button>
                </Badge>
              )}
              {priceMax && (
                <Badge className="bg-gray-100 text-gray-700 pr-1 pl-2 gap-1">
                  Max: {priceMax}₺ <button onClick={() => setPriceMax("")}><X className="h-3 w-3" /></button>
                </Badge>
              )}
            </div>
          )}

          {/* Products Grid */}
          {filtered.length === 0 ? (
            <div className="text-center py-20 text-gray-400">
              <div className="text-5xl mb-4">🔍</div>
              <p className="font-semibold text-gray-600 mb-2">Ürün bulunamadı</p>
              <p className="text-sm">Farklı arama terimleri veya filtreler deneyin</p>
              {hasFilters && <button onClick={clearFilters} className="mt-4 text-[#DC2626] font-semibold underline text-sm">Filtreleri Temizle</button>}
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-4">
              {filtered.map((p: any) => <StoreProductCard key={p.id} product={p} />)}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
