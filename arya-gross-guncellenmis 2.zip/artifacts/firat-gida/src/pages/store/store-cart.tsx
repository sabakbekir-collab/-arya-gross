import { useState } from "react";
import { Link, useLocation } from "wouter";
import {
  useGetCart, getGetCartQueryKey, useUpdateCartItem, useRemoveFromCart,
  useClearCart, useCreateOrder, getListOrdersQueryKey,
} from "@workspace/api-client-react";
import { formatCurrency } from "@/lib/format";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { Trash2, ShoppingBag, Plus, Minus, ChevronLeft, Banknote, Copy, CheckCheck, MessageCircle, Truck } from "lucide-react";
import { cn } from "@/lib/utils";

const IBAN = "TR66 0001 0000 9587 1394 3350 01";
const BANK = "Ziraat Bankası";
const WHATSAPP = import.meta.env.VITE_WHATSAPP_PHONE || "905352765849";
type PaymentMethod = "kapida" | "havale" | "whatsapp";

const PLACEHOLDER = "/placeholder-product.svg";

function IBANCard({ amount }: { amount: number }) {
  const [copied, setCopied] = useState(false);
  const { toast } = useToast();
  const copy = () => {
    navigator.clipboard.writeText(IBAN.replace(/\s/g, ""));
    setCopied(true);
    toast({ title: "IBAN kopyalandı!", duration: 2000 });
    setTimeout(() => setCopied(false), 3000);
  };
  return (
    <div className="bg-green-50 border border-green-200 rounded-xl p-4 space-y-3">
      <div className="flex items-center gap-2">
        <Banknote className="h-4 w-4 text-green-600" />
        <span className="font-bold text-sm text-green-700">Havale / EFT Bilgileri</span>
      </div>
      <div className="space-y-2 text-sm">
        <div className="flex justify-between"><span className="text-gray-500">Banka</span><span className="font-semibold">{BANK}</span></div>
        <div className="flex justify-between"><span className="text-gray-500">Alıcı Adı</span><span className="font-semibold">Arya Gross</span></div>
        <div className="flex items-center justify-between gap-2">
          <span className="text-gray-500">IBAN</span>
          <div className="flex items-center gap-2">
            <code className="font-mono text-xs font-bold text-gray-800">{IBAN}</code>
            <button onClick={copy} className="p-1 rounded hover:bg-green-100 transition-colors">
              {copied ? <CheckCheck className="h-4 w-4 text-green-600" /> : <Copy className="h-4 w-4 text-gray-400" />}
            </button>
          </div>
        </div>
        <div className="flex justify-between">
          <span className="text-gray-500">Tutar</span>
          <span className="font-black text-[#DC2626] text-base">{formatCurrency(amount)}</span>
        </div>
      </div>
      <p className="text-[11px] text-gray-400 leading-relaxed">
        Havale/EFT yaptıktan sonra WhatsApp'tan dekont gönderin. Ödeme onaylandıktan sonra siparişiniz hazırlanır.
      </p>
    </div>
  );
}

export default function StoreCart() {
  const [, navigate] = useLocation();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [address, setAddress] = useState("");
  const [note, setNote] = useState("");
  const [payment, setPayment] = useState<PaymentMethod>("kapida");
  const [ordered, setOrdered] = useState(false);
  const [orderNo, setOrderNo] = useState("");

  const { data: cart, isLoading } = useGetCart();
  const updateItem = useUpdateCartItem({ mutation: { onSuccess: () => queryClient.invalidateQueries({ queryKey: getGetCartQueryKey() }) } });
  const removeItem = useRemoveFromCart({ mutation: { onSuccess: () => queryClient.invalidateQueries({ queryKey: getGetCartQueryKey() }) } });
  const clearCart = useClearCart({ mutation: { onSuccess: () => queryClient.invalidateQueries({ queryKey: getGetCartQueryKey() }) } });
  const createOrder = useCreateOrder();

  const items = (cart?.items || []) as Array<{ productId: number; name: string; price: number | null; quantity: number; subtotal: number; imageUrl?: string | null }>;
  const subtotal = items.reduce((s, i) => s + (i.price ?? 0) * i.quantity, 0);
  const shipping = subtotal >= 500 ? 0 : 49.90;
  const total = subtotal + shipping;

  const handleOrder = async () => {
    if (!name.trim() || !phone.trim() || !address.trim()) {
      toast({ title: "Lütfen tüm zorunlu alanları doldurun.", variant: "destructive" });
      return;
    }
    if (items.length === 0) {
      toast({ title: "Sepetiniz boş.", variant: "destructive" });
      return;
    }
    try {
      const order = await createOrder.mutateAsync({
        data: {
          customerName: name,
          customerPhone: phone,
          address: address,
          paymentMethod: payment,
          notes: note || undefined,
          items: items.map(i => ({ productId: i.productId, quantity: i.quantity })),
        },
      });
      queryClient.invalidateQueries({ queryKey: getListOrdersQueryKey() });
      queryClient.invalidateQueries({ queryKey: getGetCartQueryKey() });

      if (payment === "whatsapp") {
        const cartText = items.map(i => `• ${i.quantity}x ${i.name} — ${formatCurrency((i.price ?? 0) * i.quantity)}`).join("\n");
        const msg = encodeURIComponent(
          `Merhaba, sipariş vermek istiyorum! 🛒\n\n${cartText}\n\n📦 Toplam: ${formatCurrency(total)}\n💳 Ödeme: Kapıda Ödeme\n📍 Adres: ${address}`
        );
        window.open(`https://wa.me/${WHATSAPP}?text=${msg}`, "_blank");
      }
      setOrderNo(`#${order.id}`);
      setOrdered(true);
    } catch {
      toast({ title: "Sipariş oluşturulamadı.", description: "Lütfen tekrar deneyin veya WhatsApp'tan sipariş verin.", variant: "destructive" });
    }
  };

  if (isLoading) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-20 text-center">
        <div className="w-10 h-10 border-4 border-[#DC2626] border-t-transparent rounded-full animate-spin mx-auto" />
      </div>
    );
  }

  if (ordered) {
    return (
      <div className="max-w-lg mx-auto px-4 py-16 text-center">
        <div className="text-6xl mb-5">🎉</div>
        <h2 className="text-2xl font-black text-gray-900 mb-2">Siparişiniz Alındı!</h2>
        <p className="text-gray-500 mb-2">Sipariş No: <strong className="text-gray-800">{orderNo}</strong></p>
        {payment === "havale" && (
          <div className="mt-4 mb-4"><IBANCard amount={total} /></div>
        )}
        <p className="text-gray-500 text-sm mb-6">Siparişiniz en kısa sürede hazırlanacak. Sizi bilgilendireceğiz!</p>
        <div className="flex gap-3 justify-center flex-wrap">
          <Link href="/magaza">
            <Button className="bg-[#DC2626] hover:bg-[#b91c1c] text-white font-bold rounded-full px-6">
              Alışverişe Devam Et
            </Button>
          </Link>
          <a href={`https://wa.me/${WHATSAPP}?text=Sipariş No: ${orderNo} hakkında bilgi almak istiyorum.`} target="_blank" rel="noopener noreferrer">
            <Button variant="outline" className="border-green-300 text-green-600 hover:bg-green-50 font-bold rounded-full px-6 gap-2">
              <MessageCircle className="h-4 w-4" /> WhatsApp Destek
            </Button>
          </a>
        </div>
      </div>
    );
  }

  if (items.length === 0) {
    return (
      <div className="max-w-lg mx-auto px-4 py-20 text-center">
        <ShoppingBag className="h-16 w-16 text-gray-200 mx-auto mb-5" />
        <h2 className="text-xl font-black text-gray-900 mb-2">Sepetiniz Boş</h2>
        <p className="text-gray-500 text-sm mb-6">Alışverişe başlamak için ürünleri inceleyin.</p>
        <Link href="/magaza/urunler">
          <Button className="bg-[#DC2626] hover:bg-[#b91c1c] text-white font-bold rounded-full px-6">
            Ürünleri Gör
          </Button>
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-5xl mx-auto px-4 py-6 sm:py-10">
      {/* Header */}
      <div className="flex items-center gap-3 mb-6">
        <Link href="/magaza/urunler">
          <button className="p-2 text-gray-400 hover:text-gray-700 transition-colors">
            <ChevronLeft className="h-5 w-5" />
          </button>
        </Link>
        <h1 className="text-xl font-black text-gray-900">Sepetim</h1>
        <Badge className="bg-[#DC2626] text-white">{items.length} ürün</Badge>
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Cart Items */}
        <div className="lg:col-span-2 space-y-3">
          {items.map(item => (
            <div key={item.productId} className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4 flex gap-3">
              <div className="w-20 h-20 rounded-xl overflow-hidden bg-gray-50 shrink-0">
                <img
                  src={item.imageUrl || PLACEHOLDER}
                  alt={item.name || "Ürün"}
                  onError={e => { (e.target as HTMLImageElement).src = PLACEHOLDER; }}
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="flex-1 min-w-0">
                <h3 className="font-semibold text-gray-900 text-sm leading-tight line-clamp-2">{item.name || "Ürün"}</h3>
                <div className="text-base font-black text-[#DC2626] mt-1">{formatCurrency((item.price ?? 0) * item.quantity)}</div>
                <div className="text-xs text-gray-400">{formatCurrency(item.price ?? 0)} / adet</div>
              </div>
              <div className="flex flex-col items-end gap-2 shrink-0">
                <button
                  onClick={() => removeItem.mutate({ productId: item.productId })}
                  className="text-gray-300 hover:text-red-400 transition-colors">
                  <Trash2 className="h-4 w-4" />
                </button>
                <div className="flex items-center border border-gray-200 rounded-xl overflow-hidden">
                  <button
                    onClick={() => item.quantity > 1
                      ? updateItem.mutate({ productId: item.productId, data: { quantity: item.quantity - 1 } })
                      : removeItem.mutate({ productId: item.productId })}
                    className="w-8 h-8 flex items-center justify-center text-gray-500 hover:bg-gray-50">
                    <Minus className="h-3 w-3" />
                  </button>
                  <span className="w-8 text-center font-bold text-sm text-gray-900">{item.quantity}</span>
                  <button
                    onClick={() => updateItem.mutate({ productId: item.productId, data: { quantity: item.quantity + 1 } })}
                    className="w-8 h-8 flex items-center justify-center text-gray-500 hover:bg-gray-50">
                    <Plus className="h-3 w-3" />
                  </button>
                </div>
              </div>
            </div>
          ))}

          {/* Shipping info */}
          <div className="bg-gray-50 rounded-xl p-3 flex items-center gap-2 text-sm text-gray-600">
            <Truck className="h-4 w-4 text-[#DC2626] shrink-0" />
            {subtotal >= 500
              ? <span><strong className="text-green-600">Ücretsiz kargo</strong> kazandınız! 🎉</span>
              : <span>500₺ üzeri ücretsiz kargo — <strong className="text-[#DC2626]">{formatCurrency(500 - subtotal)}</strong> daha ekleyin!</span>
            }
          </div>
        </div>

        {/* Order Summary + Checkout */}
        <div className="space-y-4">
          {/* Summary */}
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5 space-y-3">
            <h3 className="font-black text-gray-900">Sipariş Özeti</h3>
            <div className="flex justify-between text-sm text-gray-600"><span>Ara Toplam</span><span>{formatCurrency(subtotal)}</span></div>
            <div className="flex justify-between text-sm text-gray-600">
              <span>Kargo</span>
              <span className={shipping === 0 ? "text-green-600 font-semibold" : ""}>{shipping === 0 ? "ÜCRETSİZ" : formatCurrency(shipping)}</span>
            </div>
            <div className="border-t border-gray-100 pt-3 flex justify-between font-black text-lg">
              <span>Toplam</span>
              <span className="text-[#DC2626]">{formatCurrency(total)}</span>
            </div>
          </div>

          {/* Customer Info */}
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5 space-y-3">
            <h3 className="font-black text-gray-900">Teslimat Bilgileri</h3>
            <div>
              <label className="text-xs text-gray-500 font-semibold">Ad Soyad *</label>
              <Input value={name} onChange={e => setName(e.target.value)} placeholder="Adınız Soyadınız"
                className="mt-1 border-gray-200 focus-visible:ring-[#DC2626] text-sm" />
            </div>
            <div>
              <label className="text-xs text-gray-500 font-semibold">Telefon *</label>
              <Input value={phone} onChange={e => setPhone(e.target.value)} placeholder="05xx xxx xx xx"
                className="mt-1 border-gray-200 focus-visible:ring-[#DC2626] text-sm" />
            </div>
            <div>
              <label className="text-xs text-gray-500 font-semibold">Teslimat Adresi *</label>
              <Textarea value={address} onChange={e => setAddress(e.target.value)} placeholder="Mahalle, sokak, bina no, daire..."
                className="mt-1 border-gray-200 focus-visible:ring-[#DC2626] text-sm resize-none" rows={3} />
            </div>
            <div>
              <label className="text-xs text-gray-500 font-semibold">Not (isteğe bağlı)</label>
              <Input value={note} onChange={e => setNote(e.target.value)} placeholder="Sipariş notu..."
                className="mt-1 border-gray-200 focus-visible:ring-[#DC2626] text-sm" />
            </div>
          </div>

          {/* Payment Method */}
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5 space-y-3">
            <h3 className="font-black text-gray-900">Ödeme Yöntemi</h3>
            {([
              { id: "kapida", label: "💵 Kapıda Ödeme", sub: "Teslimat sırasında nakit ödeme" },
              { id: "havale", label: "🏦 Havale / EFT", sub: `${BANK} — ${IBAN}` },
              { id: "whatsapp", label: "💬 WhatsApp Sipariş", sub: "Sipariş detayları WhatsApp'tan gönderilir" },
            ] as { id: PaymentMethod; label: string; sub: string }[]).map(p => (
              <label key={p.id} className={cn(
                "flex items-start gap-3 p-3 rounded-xl border-2 cursor-pointer transition-all",
                payment === p.id ? "border-[#DC2626] bg-red-50" : "border-gray-100 hover:border-gray-200"
              )}>
                <input type="radio" name="payment" value={p.id} checked={payment === p.id} onChange={() => setPayment(p.id)}
                  className="mt-0.5 accent-[#DC2626]" />
                <div>
                  <div className="font-semibold text-sm text-gray-900">{p.label}</div>
                  <div className="text-xs text-gray-400">{p.sub}</div>
                </div>
              </label>
            ))}
            {payment === "havale" && <IBANCard amount={total} />}
          </div>

          {/* Place Order */}
          <Button
            onClick={handleOrder}
            disabled={createOrder.isPending}
            className="w-full bg-[#DC2626] hover:bg-[#b91c1c] text-white font-black h-14 text-base rounded-2xl shadow-lg hover:shadow-xl transition-all gap-2">
            <ShoppingBag className="h-5 w-5" />
            {createOrder.isPending ? "Sipariş oluşturuluyor..." : `Sipariş Ver — ${formatCurrency(total)}`}
          </Button>

          <button onClick={() => clearCart.mutate()} className="w-full text-xs text-gray-400 hover:text-red-400 transition-colors py-1">
            Sepeti Temizle
          </button>
        </div>
      </div>
    </div>
  );
}
