import { Link } from "wouter";
import { useQueryClient } from "@tanstack/react-query";
import { useAddToCart, useGetCart, useListProducts, getGetCartQueryKey } from "@workspace/api-client-react";
import { formatCurrency } from "@/lib/format";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { ShoppingCart, ArrowRight, PackageOpen } from "lucide-react";

const PLACEHOLDER = "/placeholder-product.svg";

export default function StoreHome() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const { data: products, isLoading, isError } = useListProducts({ inStock: true });
  const { data: cart } = useGetCart();
  const addToCart = useAddToCart({ mutation: { onSuccess: () => queryClient.invalidateQueries({ queryKey: getGetCartQueryKey() }) } });
  const activeProducts = (products ?? []).filter((product) => product.isActive && product.productStatus === "active" && product.stock > 0);

  const add = (product: (typeof activeProducts)[number]) => {
    addToCart.mutate({ data: { productId: product.id, quantity: 1 } }, {
      onSuccess: () => toast({ title: "Sepete eklendi", description: product.name }),
      onError: () => toast({ title: "Ürün sepete eklenemedi", variant: "destructive" }),
    });
  };

  return <main className="max-w-7xl mx-auto px-4 sm:px-6 py-6 sm:py-10">
    <section className="rounded-3xl bg-gradient-to-br from-[#7f1d1d] to-[#dc2626] text-white p-7 sm:p-12 mb-8">
      <p className="text-red-100 font-semibold text-sm">ARYA GROSS</p>
      <h1 className="text-3xl sm:text-5xl font-black mt-2 max-w-xl">Gerçek stok, güvenli sipariş, net fiyat.</h1>
      <p className="text-red-100 mt-4 max-w-lg">Yalnızca satışa açık ve stokta bulunan ürünler gösterilir.</p>
      <div className="flex flex-wrap gap-3 mt-6">
        <Link href="/magaza/urunler"><Button className="bg-white text-[#b91c1c] hover:bg-red-50 font-bold">Tüm Ürünleri Gör <ArrowRight className="ml-2 h-4 w-4" /></Button></Link>
        <Link href="/magaza/sepet"><Button variant="outline" className="border-white/70 text-white bg-transparent hover:bg-white/10">Sepetim ({cart?.itemCount ?? 0})</Button></Link>
      </div>
    </section>

    <div className="flex items-center justify-between gap-4 mb-5">
      <div><h2 className="text-2xl font-black text-gray-900">Öne Çıkan Ürünler</h2><p className="text-sm text-gray-500">Güncel fiyatlar sepet ve siparişte sunucudan yeniden hesaplanır.</p></div>
      <Link href="/magaza/urunler" className="text-sm font-bold text-[#dc2626] whitespace-nowrap">Tümünü gör</Link>
    </div>

    {isLoading && <div className="py-16 text-center text-gray-500">Ürünler yükleniyor…</div>}
    {isError && <div className="py-16 text-center text-red-600">Ürünler yüklenemedi. Lütfen tekrar deneyin.</div>}
    {!isLoading && !isError && activeProducts.length === 0 && <div className="py-16 text-center text-gray-500"><PackageOpen className="h-10 w-10 mx-auto mb-3" />Şu an satışta ürün bulunmuyor.</div>}
    <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-5">
      {activeProducts.slice(0, 8).map((product) => <article key={product.id} className="bg-white rounded-2xl border border-gray-100 overflow-hidden shadow-sm">
        <Link href={`/magaza/urun/${product.id}`}><img src={product.imageUrl || PLACEHOLDER} alt={product.name} onError={(event) => { event.currentTarget.src = PLACEHOLDER; }} className="aspect-square w-full object-cover bg-gray-50" /></Link>
        <div className="p-3"><p className="text-xs text-gray-400 truncate">{product.categoryName || "Genel"}</p><Link href={`/magaza/urun/${product.id}`}><h3 className="font-bold text-sm text-gray-900 min-h-10 mt-1 line-clamp-2">{product.name}</h3></Link><div className="flex items-center justify-between gap-2 mt-3"><strong className="text-[#dc2626]">{formatCurrency(product.price)}</strong><Button size="icon" disabled={addToCart.isPending} onClick={() => add(product)} className="bg-[#dc2626] hover:bg-[#b91c1c]"><ShoppingCart className="h-4 w-4" /></Button></div></div>
      </article>)}
    </div>
  </main>;
}
