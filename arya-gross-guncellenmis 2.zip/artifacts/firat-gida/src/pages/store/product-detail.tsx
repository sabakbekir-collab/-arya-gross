import { useState, useEffect } from "react";
import { useRoute, Link } from "wouter";
import { useGetProduct, useListProducts, useAddToCart, getGetCartQueryKey } from "@workspace/api-client-react";
import { formatCurrency } from "@/lib/format";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { ShoppingCart, Heart, Truck, Shield, RotateCcw, MessageCircle, ChevronLeft, Plus, Minus, Package, CheckCircle, XCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

const PLACEHOLDER = "/placeholder-product.svg";

function resolveImg(p: any): string {
  const raw = p?.imageUrl || p?.image_url || p?.image || p?.photoUrl || p?.fotograf_url || p?.productImage || "";
  return typeof raw === "string" && raw.startsWith("http") ? raw : PLACEHOLDER;
}

function ProductImage({ product, className = "" }: { product: any; className?: string }) {
  const [src, setSrc] = useState(() => resolveImg(product));
  const [errored, setErrored] = useState(false);
  useEffect(() => { setSrc(resolveImg(product)); setErrored(false); }, [product?.imageUrl, product?.image_url, product?.image]);
  return <img src={src} alt={product?.name ?? ""} onError={() => { if (!errored) { setErrored(true); setSrc(PLACEHOLDER); } }} className={className} />;
}

function SimilarProductCard({ product: p }: { product: any }) {
  const [imgSrc, setImgSrc] = useState(() => resolveImg(p));
  return (
    <Link href={`/magaza/urun/${p.id}`}>
      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden hover:shadow-md hover:border-[#DC2626]/20 transition-all group cursor-pointer">
        <div className="aspect-square overflow-hidden bg-gray-50">
          <img src={imgSrc} alt={p.name} onError={() => setImgSrc(PLACEHOLDER)}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" />
        </div>
        <div className="p-3">
          <h3 className="text-sm font-semibold text-gray-900 line-clamp-2 mb-1 group-hover:text-[#DC2626]">{p.name}</h3>
          <div className="text-sm font-black text-[#DC2626]">{formatCurrency(p.price)}</div>
        </div>
      </div>
    </Link>
  );
}

export default function ProductDetail() {
  const [, params] = useRoute("/magaza/urun/:id");
  const id = Number(params?.id);
  const [qty, setQty] = useState(1);
  const [liked, setLiked] = useState(false);
  const [activeTab, setActiveTab] = useState<"desc" | "info" | "reviews">("desc");

  const queryClient = useQueryClient();
  const { toast } = useToast();
  const { data: product, isLoading } = useGetProduct(id);
  const { data: allProducts } = useListProducts();

  const addToCart = useAddToCart({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetCartQueryKey() });
        toast({ title: `${qty} adet sepete eklendi ✓`, description: product?.name, duration: 2000 });
      }
    }
  });

  if (isLoading) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-20 flex items-center justify-center">
        <div className="text-center space-y-4">
          <div className="w-12 h-12 border-4 border-[#DC2626] border-t-transparent rounded-full animate-spin mx-auto" />
          <p className="text-gray-500">Ürün yükleniyor...</p>
        </div>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-20 text-center">
        <div className="text-6xl mb-4">😕</div>
        <h2 className="text-xl font-bold text-gray-900 mb-2">Ürün Bulunamadı</h2>
        <Link href="/magaza/urunler">
          <Button className="bg-[#DC2626] hover:bg-[#b91c1c] text-white mt-4">Ürünlere Dön</Button>
        </Link>
      </div>
    );
  }

  const inStock = product.stock > 0;
  const similarProducts = (allProducts || [])
    .filter((p: any) => p.id !== product.id && p.categoryId === product.categoryId && p.stock > 0)
    .slice(0, 4);

  const whatsappMsg = encodeURIComponent(
    `Merhaba, "${product.name}" ürününü sipariş etmek istiyorum.\n\nFiyat: ${formatCurrency(product.price)}\nMiktar: ${qty} adet\nToplam: ${formatCurrency(product.price * qty)}`
  );

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6">
      {/* Breadcrumb */}
      <div className="text-xs text-gray-400 mb-6 flex items-center gap-1">
        <Link href="/magaza" className="hover:text-[#DC2626]">Ana Sayfa</Link>
        <span>/</span>
        <Link href="/magaza/urunler" className="hover:text-[#DC2626]">Ürünler</Link>
        <span>/</span>
        <span className="text-gray-700 font-medium line-clamp-1">{product.name}</span>
      </div>

      <div className="grid lg:grid-cols-2 gap-8 lg:gap-12 mb-12">
        {/* Image Gallery */}
        <div className="space-y-3">
          <div className="bg-white rounded-2xl overflow-hidden shadow-sm border border-gray-100 aspect-square relative group">
            <ProductImage product={product} className="w-full h-full object-contain p-4" />
            {/* Badges */}
            <div className="absolute top-4 left-4 flex flex-col gap-2">
              {!inStock && <Badge className="bg-gray-500 text-white">Stokta Yok</Badge>}
              {inStock && product.stock <= 5 && <Badge className="bg-orange-500 text-white">Son {product.stock} adet!</Badge>}
            </div>
            <button
              onClick={() => setLiked(!liked)}
              className="absolute top-4 right-4 w-10 h-10 bg-white rounded-full shadow-md flex items-center justify-center hover:scale-110 transition-transform">
              <Heart className={`h-5 w-5 ${liked ? "fill-[#DC2626] text-[#DC2626]" : "text-gray-400"}`} />
            </button>
          </div>
          {/* Thumbnail placeholders */}
          <div className="grid grid-cols-4 gap-2">
            {[1,2,3,4].map(i => (
              <div key={i} className={`bg-white rounded-xl overflow-hidden border-2 aspect-square cursor-pointer ${i === 1 ? "border-[#DC2626]" : "border-gray-100 hover:border-gray-300"}`}>
                <ProductImage product={product} className="w-full h-full object-contain p-2 opacity-80 hover:opacity-100" />
              </div>
            ))}
          </div>
        </div>

        {/* Product Info */}
        <div className="space-y-5">
          {/* Category & Title */}
          <div>
            {product.categoryId && (
              <span className="text-xs text-[#DC2626] font-semibold uppercase tracking-widest">{(product as any).categoryName || "Ürün"}</span>
            )}
            <h1 className="text-2xl sm:text-3xl font-black text-gray-900 mt-1 leading-tight">{product.name}</h1>
          </div>

          {/* Price */}
          <div className="flex items-end gap-3">
            <span className="text-3xl sm:text-4xl font-black text-[#DC2626]">{formatCurrency(product.price)}</span>
          </div>

          {/* Tedarik Güvencesi */}
          <div className="bg-blue-50 border border-blue-100 rounded-xl p-3 flex gap-2.5">
            <Shield className="h-4 w-4 text-blue-500 shrink-0 mt-0.5" />
            <div className="text-xs text-blue-700 leading-relaxed">
              <strong>Bu ürün Arya Gross güvencesiyle tedarik edilir.</strong> Siparişiniz onaylandıktan sonra hazırlanır.
            </div>
          </div>

          {/* Stock Status */}
          <div className="flex items-center gap-2">
            <Package className="h-4 w-4 text-gray-400" />
            <span className="text-sm font-medium text-gray-600">Stok durumu sipariş onayında kontrol edilir.</span>
          </div>

          {/* Quantity + Add to Cart */}
          <div className="space-y-3">
            <div className="flex items-center gap-3">
              <span className="text-sm font-semibold text-gray-700">Adet:</span>
              <div className="flex items-center border-2 border-gray-200 rounded-xl overflow-hidden">
                <button
                  onClick={() => setQty(q => Math.max(1, q - 1))}
                  className="w-10 h-10 flex items-center justify-center text-gray-600 hover:bg-gray-50 transition-colors">
                  <Minus className="h-4 w-4" />
                </button>
                <span className="w-12 text-center font-bold text-gray-900">{qty}</span>
                <button
                  onClick={() => setQty(q => Math.min(product.stock, q + 1))}
                  disabled={qty >= product.stock}
                  className="w-10 h-10 flex items-center justify-center text-gray-600 hover:bg-gray-50 disabled:opacity-30 transition-colors">
                  <Plus className="h-4 w-4" />
                </button>
              </div>
              <span className="text-sm text-gray-400">Toplam: <strong className="text-gray-700">{formatCurrency(product.price * qty)}</strong></span>
            </div>

            <div className="flex gap-3">
              <Button
                className="flex-1 bg-[#DC2626] hover:bg-[#b91c1c] text-white font-bold h-12 text-base rounded-xl gap-2 shadow-md hover:shadow-lg transition-all"
                disabled={!inStock || addToCart.isPending}
                onClick={() => addToCart.mutate({ data: { productId: product.id, quantity: qty } })}>
                <ShoppingCart className="h-5 w-5" />
                {inStock ? "Sepete Ekle" : "Stokta Yok"}
              </Button>
              <Button
                variant="outline"
                className="border-2 border-gray-200 hover:border-[#DC2626] h-12 w-12 p-0 rounded-xl"
                onClick={() => setLiked(!liked)}>
                <Heart className={`h-5 w-5 ${liked ? "fill-[#DC2626] text-[#DC2626]" : "text-gray-400"}`} />
              </Button>
            </div>

            {/* WhatsApp Order */}
            <a href={`https://wa.me/${import.meta.env.VITE_WHATSAPP_PHONE || "905352765849"}?text=${whatsappMsg}`} target="_blank" rel="noopener noreferrer">
              <Button className="w-full bg-green-500 hover:bg-green-600 text-white font-bold h-12 text-base rounded-xl gap-2">
                <MessageCircle className="h-5 w-5" /> WhatsApp ile Sipariş Ver
              </Button>
            </a>
          </div>

          {/* Trust Badges */}
          <div className="grid grid-cols-3 gap-2 py-3 border-y border-gray-100">
            {[
              { icon: <Truck className="h-4 w-4 text-[#DC2626]" />, text: "2-5 İş Günü" },
              { icon: <Shield className="h-4 w-4 text-[#DC2626]" />, text: "Güvenli Ödeme" },
              { icon: <RotateCcw className="h-4 w-4 text-[#DC2626]" />, text: "Kolay İade" },
            ].map((t, i) => (
              <div key={i} className="flex flex-col items-center gap-1 text-center">
                <div className="bg-red-50 rounded-full p-2">{t.icon}</div>
                <span className="text-xs text-gray-600 font-medium">{t.text}</span>
              </div>
            ))}
          </div>

          {/* Keywords */}
          {product.keywords && (
            <div className="flex flex-wrap gap-1.5">
              {product.keywords.split(",").map((k: string, i: number) => (
                <Badge key={i} className="bg-gray-100 text-gray-600 text-xs px-2 py-0.5 font-normal hover:bg-gray-200 cursor-default">
                  #{k.trim()}
                </Badge>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Tabs: Description / Info / Reviews */}
      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 mb-10">
        <div className="flex border-b border-gray-100">
          {[
            { key: "desc", label: "Ürün Açıklaması" },
            { key: "info", label: "Teknik Bilgiler" },
            { key: "reviews", label: "Yorumlar" },
          ].map(tab => (
            <button key={tab.key}
              onClick={() => setActiveTab(tab.key as any)}
              className={`px-5 py-4 text-sm font-semibold border-b-2 transition-colors ${activeTab === tab.key ? "border-[#DC2626] text-[#DC2626]" : "border-transparent text-gray-500 hover:text-gray-700"}`}>
              {tab.label}
            </button>
          ))}
        </div>
        <div className="p-6">
          {activeTab === "desc" && (
            <div className="text-gray-600 leading-relaxed">
              {product.description || (
                <div className="text-gray-400 space-y-2">
                  <p>Bu ürün hakkında detaylı açıklama yakında eklenecektir.</p>
                  <p className="text-sm">Ürün kalitesi, içeriği ve kullanım talimatları için WhatsApp hattımızdan bilgi alabilirsiniz.</p>
                </div>
              )}
            </div>
          )}
          {activeTab === "info" && (
            <div className="grid sm:grid-cols-2 gap-4">
              {[
                ["Ürün Adı", product.name],
                ["Stok", `${product.stock} adet`],
                ["Fiyat", formatCurrency(product.price)],
                ["Durum", product.stock > 0 ? "Stokta" : "Tükendi"],
                ["Kategori", (product as any).categoryName || "-"],
                ["SKU", `AG-${String(product.id).padStart(6, "0")}`],
              ].map(([k, v]) => (
                <div key={k} className="flex justify-between items-center py-2 border-b border-gray-50 text-sm">
                  <span className="text-gray-500 font-medium">{k}</span>
                  <span className="text-gray-900 font-semibold">{v}</span>
                </div>
              ))}
            </div>
          )}
          {activeTab === "reviews" && (
            <div className="py-8 text-center">
              <div className="text-4xl mb-3">💬</div>
              <p className="text-gray-500 font-medium">Henüz yorum eklenmedi.</p>
              <p className="text-gray-400 text-sm mt-1">Bu ürünü satın alan ilk yorumcu siz olun!</p>
              <a href={`https://wa.me/${import.meta.env.VITE_WHATSAPP_PHONE || "905352765849"}?text=Merhaba, "${product?.name}" ürünü hakkında yorum yapmak istiyorum.`} target="_blank" rel="noopener noreferrer">
                <button className="mt-4 bg-green-500 hover:bg-green-600 text-white font-bold px-5 py-2 rounded-full text-sm transition-colors">
                  📱 WhatsApp ile Yorum Bırak
                </button>
              </a>
            </div>
          )}
        </div>
      </div>

      {/* Similar Products */}
      {similarProducts.length > 0 && (
        <div>
          <h2 className="text-xl font-black text-gray-900 mb-5">Benzer Ürünler</h2>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            {similarProducts.map((p: any) => (
              <SimilarProductCard key={p.id} product={p} />
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
