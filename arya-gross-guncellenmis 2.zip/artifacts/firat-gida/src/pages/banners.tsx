import { ModulePage } from "@/components/module-page";

export default function Banners() {
  return (
    <ModulePage
      emoji="🖼️"
      title="Banner / Slider Yönetimi"
      description="Ana sayfa slider ve banner görselleri yönetimi"
      badge="Yakında"
      stats={[
        { label: "Aktif Banner", value: "3", color: "text-primary" },
        { label: "Slider", value: "1", color: "text-blue-400" },
        { label: "Popup", value: "0", color: "text-muted-foreground" },
      ]}
    />
  );
}
