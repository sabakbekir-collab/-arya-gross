import { useRef, useState } from "react";
import { useMutation } from "@tanstack/react-query";
import {
  Upload, FileSpreadsheet, CheckCircle2, XCircle, AlertTriangle,
  Download, ArrowRight, RefreshCw, Info, Store,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

// ── Types ──────────────────────────────────────────────────────────
interface ImportResult {
  total: number;
  inserted: number;
  skipped: number;
  errors: number;
  insertedNames: string[];
  skippedItems: Array<{ name: string; reason: string }>;
  errorDetails: Array<{ row: number; reason: string }>;
  message: string;
}

const ACCEPTED_TYPES = ".csv,.xlsx,.xls";

const COLUMNS = [
  { key: "name",          required: true,  desc: "Ürün adı" },
  { key: "brand",         required: false, desc: "Marka" },
  { key: "category",      required: false, desc: "Kategori adı" },
  { key: "supplierName",  required: false, desc: "Tedarikçi firma adı" },
  { key: "supplierPrice", required: false, desc: "Alış / maliyet fiyatı (sayı)" },
  { key: "supplierUrl",   required: false, desc: "Tedarikçi ürün sayfası URL" },
  { key: "stock",         required: false, desc: "Stok adedi" },
  { key: "barcode",       required: false, desc: "Barkod / EAN" },
  { key: "imageUrl",      required: false, desc: "Ürün görseli URL'si" },
  { key: "shippingDays",  required: false, desc: "Tahmini kargo süresi (gün, varsayılan 3)" },
];

export default function SupplierImport() {
  const inputRef = useRef<HTMLInputElement>(null);
  const [dragging, setDragging] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [result, setResult] = useState<ImportResult | null>(null);
  const [showDetails, setShowDetails] = useState(false);

  const mutation = useMutation({
    mutationFn: async (file: File) => {
      const form = new FormData();
      form.append("file", file);
      const res = await fetch("/api/arya/automation/import-csv", { method: "POST", body: form });
      if (!res.ok) {
        const err = await res.json().catch(() => ({})) as { error?: string };
        throw new Error(err.error ?? "Yükleme hatası");
      }
      return res.json() as Promise<ImportResult>;
    },
    onSuccess: (data) => {
      setResult(data);
      setSelectedFile(null);
    },
  });

  function handleFile(file: File) {
    setResult(null);
    setSelectedFile(file);
  }

  function handleDrop(e: React.DragEvent) {
    e.preventDefault();
    setDragging(false);
    const file = e.dataTransfer.files[0];
    if (file) handleFile(file);
  }

  function handleInputChange(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (file) handleFile(file);
    e.target.value = "";
  }

  async function downloadTemplate() {
    const res = await fetch("/api/arya/automation/import-template");
    const blob = await res.blob();
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "tedarikci_katalog_sablon.xlsx";
    a.click();
    URL.revokeObjectURL(url);
  }

  return (
    <div className="space-y-5 max-w-3xl mx-auto">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-black tracking-tight flex items-center gap-2">
          <Store className="h-6 w-6 text-primary" />
          Tedarikçi Kataloğu Yükle
        </h1>
        <p className="text-sm text-muted-foreground mt-0.5">
          CSV veya Excel yükleyin — ürünler tedarikçi kataloğuna kaydedilir.
          Arya bir sonraki çalışmada gerçek fiyat ve tedarikçi bilgisiyle öneri yapar.
        </p>
      </div>

      {/* Nasıl Çalışır */}
      <Card className="border-blue-200 bg-blue-50/30">
        <CardContent className="p-4 flex items-start gap-3">
          <Info className="h-4 w-4 text-blue-500 mt-0.5 shrink-0" />
          <div className="text-xs text-blue-700 space-y-1">
            <p className="font-semibold">Tedarikçi Motoru V2 nasıl çalışır?</p>
            <p>1. Tedarikçi ürünlerini buraya yükleyin → <strong>supplier_products</strong> tablosuna kaydolur</p>
            <p>2. Arya Otomasyon çalışınca katalogdaki ürünleri eşleştirir ve <strong>gerçek fiyat + kâr analizi</strong> yapar</p>
            <p>3. Eşleşen önerilerde <strong className="text-green-700">✓ Tedarikçi Doğrulandı</strong> rozetini görürsünüz</p>
            <p>4. <strong>Onayla</strong> butonuna basana kadar hiçbir ürün yayına alınmaz</p>
          </div>
        </CardContent>
      </Card>

      {/* Template download */}
      <Card className="border-dashed">
        <CardContent className="p-4 flex items-center justify-between gap-4">
          <div>
            <p className="text-sm font-semibold">Şablon dosyası</p>
            <p className="text-xs text-muted-foreground mt-0.5">
              Doğru kolon yapısı için örnek şablonu indirin. Kolon adları Türkçe veya İngilizce olabilir.
            </p>
          </div>
          <Button variant="outline" size="sm" className="shrink-0 gap-1.5" onClick={downloadTemplate}>
            <Download className="h-3.5 w-3.5" />
            Şablon İndir
          </Button>
        </CardContent>
      </Card>

      {/* Column reference */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-bold">Kolon Referansı</CardTitle>
        </CardHeader>
        <CardContent className="p-4 pt-0">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
            {COLUMNS.map(col => (
              <div key={col.key} className="flex items-center gap-2 text-xs">
                <code className={cn(
                  "px-1.5 py-0.5 rounded font-mono text-[11px]",
                  col.required ? "bg-primary/10 text-primary font-bold" : "bg-secondary text-muted-foreground"
                )}>
                  {col.key}
                </code>
                {col.required && <Badge variant="destructive" className="text-[9px] py-0 px-1">zorunlu</Badge>}
                <span className="text-muted-foreground">{col.desc}</span>
              </div>
            ))}
          </div>
          <p className="text-[11px] text-muted-foreground mt-3 bg-secondary/50 rounded p-2">
            <strong>Tekrar kontrolü:</strong> Aynı isim veya barkod katalogda varsa o satır atlanır.
            <br />
            <strong>supplierUrl eksikse:</strong> Arya, öneri kartında otomatik arama linkleri oluşturur.
          </p>
        </CardContent>
      </Card>

      {/* Drop zone */}
      <div
        onDragOver={(e) => { e.preventDefault(); setDragging(true); }}
        onDragLeave={() => setDragging(false)}
        onDrop={handleDrop}
        onClick={() => inputRef.current?.click()}
        className={cn(
          "border-2 border-dashed rounded-xl p-10 flex flex-col items-center justify-center gap-3 cursor-pointer transition-all",
          dragging ? "border-primary bg-primary/5 scale-[1.01]" : "border-border hover:border-primary/50 hover:bg-secondary/30"
        )}
      >
        <input
          ref={inputRef}
          type="file"
          accept={ACCEPTED_TYPES}
          className="hidden"
          onChange={handleInputChange}
        />
        <div className={cn(
          "w-14 h-14 rounded-2xl flex items-center justify-center transition-colors",
          selectedFile ? "bg-green-100" : "bg-secondary"
        )}>
          {selectedFile
            ? <CheckCircle2 className="h-7 w-7 text-green-600" />
            : <Upload className="h-7 w-7 text-muted-foreground" />
          }
        </div>
        {selectedFile ? (
          <div className="text-center">
            <p className="font-bold text-sm">{selectedFile.name}</p>
            <p className="text-xs text-muted-foreground mt-0.5">
              {(selectedFile.size / 1024).toFixed(1)} KB · Yüklemek için butona tıklayın
            </p>
          </div>
        ) : (
          <div className="text-center">
            <p className="font-semibold text-sm">Dosyayı buraya sürükleyin veya tıklayın</p>
            <p className="text-xs text-muted-foreground mt-1">CSV, XLSX veya XLS · Maks 10 MB</p>
          </div>
        )}
      </div>

      {/* Upload button */}
      {selectedFile && (
        <Button
          size="lg"
          className="w-full h-12 font-bold gap-2"
          onClick={() => mutation.mutate(selectedFile)}
          disabled={mutation.isPending}
        >
          {mutation.isPending ? (
            <><RefreshCw className="h-4 w-4 animate-spin" /> Yükleniyor…</>
          ) : (
            <><Upload className="h-4 w-4" /> {selectedFile.name} Kataloğa Yükle</>
          )}
        </Button>
      )}

      {/* Error */}
      {mutation.isError && (
        <div className="bg-red-50 border border-red-200 rounded-xl p-4 flex items-start gap-3">
          <AlertTriangle className="h-4 w-4 text-red-500 mt-0.5 shrink-0" />
          <div>
            <p className="font-semibold text-sm text-red-700">Yükleme başarısız</p>
            <p className="text-xs text-red-600 mt-0.5">{mutation.error?.message}</p>
          </div>
        </div>
      )}

      {/* Result */}
      {result && (
        <Card className="border-green-200 bg-green-50/50">
          <CardContent className="p-5 space-y-4">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="h-5 w-5 text-green-600" />
              <p className="font-bold text-sm text-green-700">{result.message}</p>
            </div>

            <div className="grid grid-cols-3 gap-3">
              <div className="bg-white rounded-xl p-3 text-center border border-green-100">
                <div className="text-2xl font-black text-green-600">{result.inserted}</div>
                <div className="text-[10px] text-muted-foreground">Kataloğa Eklendi</div>
              </div>
              <div className="bg-white rounded-xl p-3 text-center border border-green-100">
                <div className="text-2xl font-black text-yellow-500">{result.skipped}</div>
                <div className="text-[10px] text-muted-foreground">Tekrar / Atlandı</div>
              </div>
              <div className="bg-white rounded-xl p-3 text-center border border-green-100">
                <div className="text-2xl font-black text-red-500">{result.errors}</div>
                <div className="text-[10px] text-muted-foreground">Hatalı Satır</div>
              </div>
            </div>

            {(result.skipped > 0 || result.errors > 0) && (
              <button
                type="button"
                className="text-xs text-primary underline underline-offset-2"
                onClick={() => setShowDetails(!showDetails)}
              >
                {showDetails ? "Detayları Gizle" : "Detayları Göster"}
              </button>
            )}
            {showDetails && (
              <div className="space-y-2 text-xs">
                {result.skippedItems.length > 0 && (
                  <div>
                    <p className="font-bold text-yellow-700 mb-1">Atlananlar</p>
                    {result.skippedItems.map((s, i) => (
                      <div key={i} className="flex gap-2 text-muted-foreground">
                        <XCircle className="h-3 w-3 text-yellow-500 shrink-0 mt-0.5" />
                        <span><strong>{s.name}</strong> — {s.reason}</span>
                      </div>
                    ))}
                  </div>
                )}
                {result.errorDetails.length > 0 && (
                  <div>
                    <p className="font-bold text-red-700 mb-1">Hatalar</p>
                    {result.errorDetails.map((e, i) => (
                      <div key={i} className="flex gap-2 text-muted-foreground">
                        <AlertTriangle className="h-3 w-3 text-red-400 shrink-0 mt-0.5" />
                        <span>Satır {e.row}: {e.reason}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {result.inserted > 0 && (
              <div className="bg-white border border-green-200 rounded-xl p-3 text-xs text-green-700 space-y-1">
                <p className="font-semibold">Sonraki adım:</p>
                <p>Arya Otomasyon'u çalıştırın — yüklediğiniz {result.inserted} tedarikçi ürünü gerçek fiyat ve kâr analiziyle önerilecek.</p>
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}
