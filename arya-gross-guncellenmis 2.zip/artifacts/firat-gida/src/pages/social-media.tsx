import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Share2, Copy, Camera as Instagram, Zap } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useListProducts } from "@workspace/api-client-react";

const WHATSAPP_PHONE = import.meta.env.VITE_WHATSAPP_PHONE || "905352765849";

const TEMPLATES = [
  {
    platform: "Instagram",
    emoji: "📸",
    color: "text-pink-400",
    bg: "bg-pink-500/10",
    border: "border-pink-500/20",
    generate: (name: string, price: number) =>
      `✨ ${name}\n\n💰 Sadece ${price}₺!\n\nArya Gross kalitesi ile sofranıza özel. 🌿\n\n#aryagross #doğal #organik #toptan #gaziantep #sağlıklıbeslenme #kuruyemiş`,
  },
  {
    platform: "TikTok",
    emoji: "🎵",
    color: "text-red-400",
    bg: "bg-red-500/10",
    border: "border-red-500/20",
    generate: (name: string, price: number) =>
      `[HOOK] Bunu bilmiyorsan büyük fırsat kaçırıyorsun! 😱\n\n${name} — sadece ${price}₺!\n\n[ORTA] Arya Gross'ta toptan kalite, perakende fiyatından ucuz.\n\n[KAPANIŞ] Hemen sipariş için biyodaki linke tıkla! ⬇️\n\n#aryagross #keşfet #fırsat`,
  },
  {
    platform: "WhatsApp",
    emoji: "💬",
    color: "text-green-400",
    bg: "bg-green-500/10",
    border: "border-green-500/20",
    generate: (name: string, price: number) =>
      `🎉 *ARYA GROSS KAMPANYA*\n\n${name} şimdi *${price}₺*!\n\nSınırlı stok — kaçırmayın!\n\nSipariş için: wa.me/${WHATSAPP_PHONE}`,
  },
];

export default function SocialMedia() {
  const { toast } = useToast();
  const { data: products } = useListProducts();
  const [selectedProduct, setSelectedProduct] = useState<any>(null);
  const [texts, setTexts] = useState<Record<string, string>>({});

  const generateAll = () => {
    if (!selectedProduct) { toast({ title: "Ürün seçin", variant: "destructive" }); return; }
    const newTexts: Record<string, string> = {};
    TEMPLATES.forEach(t => { newTexts[t.platform] = t.generate(selectedProduct.name, selectedProduct.price); });
    setTexts(newTexts);
    toast({ title: "İçerikler oluşturuldu", description: `${selectedProduct.name} için 3 platform metni hazır.` });
  };

  return (
    <div className="space-y-4 animate-in fade-in duration-500">
      <div className="flex items-start gap-3">
        <div className="w-10 h-10 bg-pink-500/20 rounded-xl flex items-center justify-center shrink-0 border border-pink-500/30">
          <Share2 className="h-5 w-5 text-pink-400" />
        </div>
        <div>
          <h1 className="text-xl font-black">📱 Sosyal Medya Planlayıcı</h1>
          <p className="text-xs text-muted-foreground mt-0.5">Instagram, TikTok ve WhatsApp için içerik üret</p>
        </div>
      </div>

      <Card className="border-border bg-card/60">
        <CardContent className="p-4 space-y-3">
          <p className="text-xs text-muted-foreground font-semibold uppercase tracking-wider">Ürün Seç</p>
          <div className="flex flex-wrap gap-2">
            {(products || []).slice(0, 8).map(p => (
              <button key={p.id} onClick={() => setSelectedProduct(p)}
                className={`text-xs px-3 py-1.5 rounded-full border transition-all ${selectedProduct?.id === p.id ? "bg-primary text-white border-primary" : "border-border text-muted-foreground hover:border-primary/50"}`}>
                {p.name}
              </button>
            ))}
          </div>
          <Button onClick={generateAll} className="w-full gap-2 bg-primary hover:bg-primary/90 text-white" size="sm">
            <Zap className="h-4 w-4" /> İçerikleri Üret
          </Button>
        </CardContent>
      </Card>

      {TEMPLATES.map(t => (
        <Card key={t.platform} className={`border ${t.border} ${t.bg}`}>
          <CardContent className="p-4 space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="text-lg">{t.emoji}</span>
                <span className={`font-bold text-sm ${t.color}`}>{t.platform}</span>
              </div>
              {texts[t.platform] && (
                <Button variant="ghost" size="sm" className="h-7 gap-1 text-xs text-muted-foreground" onClick={() => { navigator.clipboard.writeText(texts[t.platform]); toast({ title: "Kopyalandı" }); }}>
                  <Copy className="h-3 w-3" /> Kopyala
                </Button>
              )}
            </div>
            <Textarea
              value={texts[t.platform] || ""}
              onChange={e => setTexts(prev => ({ ...prev, [t.platform]: e.target.value }))}
              placeholder={`${t.platform} için içerik buraya gelecek...`}
              className="bg-secondary/40 resize-none h-28 text-xs font-mono"
            />
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
