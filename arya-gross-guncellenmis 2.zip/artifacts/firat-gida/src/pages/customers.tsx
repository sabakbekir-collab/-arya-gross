import { useListOrders } from "@workspace/api-client-react";
import { formatCurrency, formatDate } from "@/lib/format";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Users, Search, Phone, Mail, ShoppingBag, Star } from "lucide-react";
import { useMemo, useState } from "react";

interface Customer {
  name: string; email: string; phone: string;
  orderCount: number; totalSpent: number; lastOrder: string;
  status: "vip" | "aktif" | "pasif";
}

export default function Customers() {
  const { data: orders, isLoading } = useListOrders();
  const [search, setSearch] = useState("");

  const customers = useMemo<Customer[]>(() => {
    if (!orders) return [];
    const map: Record<string, Customer> = {};
    for (const o of orders) {
      const key = o.customerEmail || o.customerName || "bilinmiyor";
      if (!map[key]) {
        map[key] = { name: o.customerName || "Bilinmiyor", email: o.customerEmail || "", phone: o.customerPhone || "", orderCount: 0, totalSpent: 0, lastOrder: o.createdAt, status: "aktif" };
      }
      map[key].orderCount++;
      map[key].totalSpent += Number(o.total);
      if (o.createdAt > map[key].lastOrder) map[key].lastOrder = o.createdAt;
    }
    return Object.values(map).map(c => ({
      ...c,
      status: (c.totalSpent > 500 ? "vip" : c.orderCount > 1 ? "aktif" : "pasif") as "vip" | "aktif" | "pasif",
    })).sort((a, b) => b.totalSpent - a.totalSpent);
  }, [orders]);

  const filtered = customers.filter(c =>
    c.name.toLowerCase().includes(search.toLowerCase()) ||
    c.email.toLowerCase().includes(search.toLowerCase()) ||
    c.phone.includes(search)
  );

  const totalRevenue = customers.reduce((s, c) => s + c.totalSpent, 0);
  const vipCount = customers.filter(c => c.status === "vip").length;

  return (
    <div className="space-y-4 animate-in fade-in duration-500">
      <div className="flex items-start gap-3">
        <div className="w-10 h-10 bg-blue-500/20 rounded-xl flex items-center justify-center shrink-0 border border-blue-500/30">
          <Users className="h-5 w-5 text-blue-400" />
        </div>
        <div>
          <h1 className="text-xl font-black">👥 Müşteri Yönetimi</h1>
          <p className="text-xs text-muted-foreground mt-0.5">Tüm müşteri verilerini görüntüle ve analiz et</p>
        </div>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {[
          { label: "Toplam Müşteri", val: customers.length, color: "text-foreground" },
          { label: "VIP Müşteri", val: vipCount, color: "text-yellow-400" },
          { label: "Toplam Ciro", val: formatCurrency(totalRevenue), color: "text-primary" },
          { label: "Ort. Sipariş", val: customers.length > 0 ? formatCurrency(totalRevenue / customers.length) : "—", color: "text-accent" },
        ].map(s => (
          <Card key={s.label} className="border-border bg-card/60">
            <CardContent className="p-3">
              <div className="text-[10px] text-muted-foreground uppercase tracking-wider mb-1">{s.label}</div>
              <div className={`text-xl font-black ${s.color}`}>{s.val}</div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="relative">
        <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
        <Input placeholder="Müşteri ara..." className="pl-9 bg-secondary/50 border-border h-9 text-sm" value={search} onChange={e => setSearch(e.target.value)} />
      </div>

      {isLoading ? (
        <div className="space-y-2">{[1,2,3].map(i => <div key={i} className="h-20 bg-secondary/30 animate-pulse rounded-xl" />)}</div>
      ) : filtered.length === 0 ? (
        <Card className="border-dashed border-border bg-card/30">
          <div className="py-10 text-center"><Users className="h-8 w-8 text-muted-foreground mx-auto mb-2" /><p className="text-sm font-semibold">Henüz müşteri kaydı yok.</p><p className="text-xs text-muted-foreground mt-1">Müşteriler sipariş verdikçe otomatik listelenecek.</p></div>
        </Card>
      ) : (
        <div className="space-y-2">
          {filtered.map((c, i) => (
            <Card key={i} className="border-border bg-card/60 hover:border-primary/20 transition-all">
              <CardContent className="p-4">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-semibold">{c.name}</span>
                      {c.status === "vip" && (
                        <Badge className="bg-yellow-500/20 text-yellow-400 border-yellow-500/30 text-[9px] gap-1">
                          <Star className="h-2.5 w-2.5" /> VIP
                        </Badge>
                      )}
                      {c.status === "aktif" && <Badge className="bg-green-500/20 text-green-400 border-green-500/30 text-[9px]">Aktif</Badge>}
                    </div>
                    <div className="flex items-center gap-3 mt-1 flex-wrap">
                      {c.email && <div className="flex items-center gap-1 text-[11px] text-muted-foreground"><Mail className="h-3 w-3" />{c.email}</div>}
                      {c.phone && <div className="flex items-center gap-1 text-[11px] text-muted-foreground"><Phone className="h-3 w-3" />{c.phone}</div>}
                    </div>
                    <div className="flex items-center gap-3 mt-1.5">
                      <div className="flex items-center gap-1 text-[11px] text-muted-foreground">
                        <ShoppingBag className="h-3 w-3" />{c.orderCount} sipariş
                      </div>
                      <div className="text-[11px] text-muted-foreground">Son: {formatDate(c.lastOrder)}</div>
                    </div>
                  </div>
                  <div className="text-right shrink-0">
                    <div className="font-black text-primary text-lg">{formatCurrency(c.totalSpent)}</div>
                    <div className="text-[10px] text-muted-foreground">toplam harcama</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
