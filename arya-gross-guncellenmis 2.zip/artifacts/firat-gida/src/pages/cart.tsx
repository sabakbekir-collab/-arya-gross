import { useGetCart, getGetCartQueryKey, useUpdateCartItem, useRemoveFromCart, useClearCart, useCreateOrder, getListOrdersQueryKey } from "@workspace/api-client-react";
import { formatCurrency } from "@/lib/format";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Trash2, ShoppingBag, Plus, Minus, Truck, MessageCircle, Banknote, Copy, CheckCheck, ExternalLink, X } from "lucide-react";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { useState } from "react";
import { useLocation } from "wouter";
import { cn } from "@/lib/utils";

const IBAN = "TR66 0001 0000 9587 1394 3350 01";
const WHATSAPP_PHONE = import.meta.env.VITE_WHATSAPP_PHONE || "905352765849";
const BANK = "Ziraat Bankası";

type PaymentMethod = string;

interface OrderSuccessInfo {
  orderNumber: string;
  total: number;
  paymentMethod: PaymentMethod;
  customerPhone: string;
  customerName: string;
}

function IBANCard({ amount, orderNumber }: { amount: number; orderNumber?: string }) {
  const [copied, setCopied] = useState(false);
  const { toast } = useToast();

  const copy = () => {
    navigator.clipboard.writeText(IBAN.replace(/\s/g, ""));
    setCopied(true);
    toast({ title: "IBAN kopyalandı!", duration: 2000 });
    setTimeout(() => setCopied(false), 3000);
  };

  return (
    <div className="bg-green-500/5 border border-green-500/20 rounded-xl p-4 space-y-3">
      <div className="flex items-center gap-2">
        <Banknote className="h-4 w-4 text-green-400 shrink-0" />
        <span className="font-bold text-sm text-green-400">Havale / EFT Bilgileri</span>
      </div>
      <div className="space-y-2 text-sm">
        <div className="flex justify-between items-center">
          <span className="text-muted-foreground text-xs">Banka</span>
          <span className="font-semibold">{BANK}</span>
        </div>
        <div className="flex justify-between items-center gap-2">
          <span className="text-muted-foreground text-xs shrink-0">IBAN</span>
          <div className="flex items-center gap-1.5 min-w-0">
            <span className="font-mono font-bold text-xs truncate">{IBAN}</span>
            <Button variant="ghost" size="icon" className="h-7 w-7 shrink-0 hover:bg-green-500/10" onClick={copy}>
              {copied ? <CheckCheck className="h-3.5 w-3.5 text-green-400" /> : <Copy className="h-3.5 w-3.5 text-muted-foreground" />}
            </Button>
          </div>
        </div>
        {amount > 0 && (
          <div className="flex justify-between items-center">
            <span className="text-muted-foreground text-xs">Tutar</span>
            <span className="font-black text-primary">{formatCurrency(amount)}</span>
          </div>
        )}
        {orderNumber && (
          <div className="flex justify-between items-center">
            <span className="text-muted-foreground text-xs">Açıklama</span>
            <span className="font-mono font-semibold text-xs">{orderNumber}</span>
          </div>
        )}
      </div>
      <div className="bg-yellow-500/10 border border-yellow-500/20 rounded-lg p-2.5 text-xs text-yellow-300 leading-relaxed">
        ⚠️ Havale yaptıktan sonra dekontu WhatsApp üzerinden gönderiniz.
      </div>
    </div>
  );
}

function OrderSuccessModal({ info, onClose }: { info: OrderSuccessInfo; onClose: () => void }) {
  const waMsg = encodeURIComponent(
    `Merhaba! ${info.orderNumber} numaralı siparişimi ${info.paymentMethod === "havale" ? "havale/EFT" : info.paymentMethod === "kapida" ? "kapıda ödeme" : "WhatsApp"} ile tamamladım.\n\nTutar: ${formatCurrency(info.total)}\nAd: ${info.customerName}`
  );

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70">
      <Card className="w-full max-w-sm border-green-500/30 bg-card shadow-2xl">
        <div className="p-5 space-y-4">
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-10 h-10 bg-green-500/20 rounded-xl flex items-center justify-center">
                <CheckCheck className="h-5 w-5 text-green-400" />
              </div>
              <div>
                <h2 className="font-black text-sm text-green-400">Sipariş Alındı!</h2>
                <p className="text-[11px] text-muted-foreground font-mono">{info.orderNumber}</p>
              </div>
            </div>
            <Button variant="ghost" size="icon" className="h-7 w-7 -mt-1 -mr-1" onClick={onClose}>
              <X className="h-4 w-4" />
            </Button>
          </div>

          {info.paymentMethod === "havale" && (
            <div className="space-y-3">
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">Sipariş Durumu</span>
                <Badge className="bg-yellow-500/20 text-yellow-400 border-yellow-500/30 text-[10px]">⏳ Ödeme Bekleniyor</Badge>
              </div>
              <IBANCard amount={info.total} orderNumber={info.orderNumber} />
            </div>
          )}

          {info.paymentMethod === "kapida" && (
            <div className="bg-blue-500/10 border border-blue-500/20 rounded-xl p-3 text-sm">
              <div className="flex items-center gap-2 text-blue-400 font-semibold mb-1">
                <Truck className="h-4 w-4" /> Kapıda Ödeme
              </div>
              <p className="text-xs text-muted-foreground">Sipariş hazırlandıkça bilgilendirileceksiniz. Ödemeyi kuryeye yapınız.</p>
            </div>
          )}

          <div className="space-y-2 pt-1">
            <a href={`https://wa.me/${WHATSAPP_PHONE}?text=${waMsg}`} target="_blank" rel="noopener noreferrer" className="block">
              <Button className="w-full bg-green-600 hover:bg-green-700 text-white font-bold gap-2 h-10">
                <MessageCircle className="h-4 w-4" />
                {info.paymentMethod === "havale" ? "Dekontu WhatsApp'tan Gönder" : "WhatsApp'ta Takip Et"}
              </Button>
            </a>
            <Button variant="outline" className="w-full h-9 text-xs gap-2" onClick={onClose}>
              <ExternalLink className="h-3.5 w-3.5" /> Siparişlerimi Gör
            </Button>
          </div>
        </div>
      </Card>
    </div>
  );
}

const PAYMENT_OPTIONS: { key: PaymentMethod; label: string; icon: React.ElementType; desc: string; color: string }[] = [
  { key: "kapida", label: "Kapıda Ödeme", icon: Truck, desc: "Nakit veya kart", color: "border-blue-500/40 bg-blue-500/5 text-blue-400" },
  { key: "whatsapp", label: "WhatsApp Sipariş", icon: MessageCircle, desc: "WhatsApp üzerinden", color: "border-green-500/40 bg-green-500/5 text-green-400" },
  { key: "havale", label: "Havale / EFT", icon: Banknote, desc: "Banka transferi", color: "border-yellow-500/40 bg-yellow-500/5 text-yellow-400" },
];

export default function Cart() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const { data: cart, isLoading } = useGetCart();

  const [customerInfo, setCustomerInfo] = useState({ name: "", email: "", phone: "", address: "", note: "" });
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>("cash_on_delivery");
  const [orderSuccess, setOrderSuccess] = useState<OrderSuccessInfo | null>(null);

  const updateItem = useUpdateCartItem({ mutation: { onSuccess: () => queryClient.invalidateQueries({ queryKey: getGetCartQueryKey() }) } });
  const removeItem = useRemoveFromCart({ mutation: { onSuccess: () => queryClient.invalidateQueries({ queryKey: getGetCartQueryKey() }) } });
  const clearCart = useClearCart({ mutation: { onSuccess: () => queryClient.invalidateQueries({ queryKey: getGetCartQueryKey() }) } });

  const createOrder = useCreateOrder({
    mutation: {
      onError: (error: any) => {
        const msg = error?.response?.data?.error || error?.message || "Bilinmeyen hata";
        toast({ title: "Sipariş oluşturulamadı", description: msg, variant: "destructive" });
      },
    },
  });

  const handleCheckout = async () => {
    if (!cart || cart.items.length === 0) return;
    if (!customerInfo.name.trim()) {
      toast({ title: "Ad Soyad gerekli", variant: "destructive", duration: 2000 });
      return;
    }

    const snapshotTotal = cart.total;
    const snapshotItems = cart.items;

    try {
      const order = await createOrder.mutateAsync({
        data: {
          customerName: customerInfo.name,
          customerEmail: customerInfo.email || undefined,
          customerPhone: customerInfo.phone || undefined,
          address: customerInfo.address || undefined,
          notes: customerInfo.note || undefined,
          paymentMethod,
          items: snapshotItems.map(i => ({ productId: i.productId, quantity: i.quantity })),
        },
      });

      queryClient.invalidateQueries({ queryKey: getGetCartQueryKey() });
      queryClient.invalidateQueries({ queryKey: getListOrdersQueryKey() });

      const orderNumber = `#${order.id}`;

      if (paymentMethod === "whatsapp") {
        const itemsText = snapshotItems.map(i => `${i.quantity}x ${i.name} — ${formatCurrency(i.subtotal)}`).join("\n");
        const msg = encodeURIComponent(
          `Merhaba! Sipariş vermek istiyorum.\n\n${itemsText}\n\nToplam: ${formatCurrency(snapshotTotal)}\nAd: ${customerInfo.name}\nTelefon: ${customerInfo.phone}\nAdres: ${customerInfo.address}`
        );
        window.open(`https://wa.me/${WHATSAPP_PHONE}?text=${msg}`, "_blank");
        toast({ title: `Sipariş oluşturuldu ${orderNumber}`, description: "WhatsApp açılıyor..." });
        setLocation("/orders");
      } else {
        setOrderSuccess({
          orderNumber,
          total: snapshotTotal,
          paymentMethod,
          customerPhone: customerInfo.phone,
          customerName: customerInfo.name,
        });
      }
    } catch {
      // onError handler zaten toast gösteriyor
    }
  };

  const total = cart?.total || 0;

  return (
    <div className="space-y-5 animate-in fade-in duration-500 pb-4">
      {orderSuccess && (
        <OrderSuccessModal info={orderSuccess} onClose={() => { setOrderSuccess(null); setLocation("/orders"); }} />
      )}

      <div>
        <h1 className="text-2xl font-bold tracking-tight text-foreground">Sepet & Ödeme</h1>
        <p className="text-sm text-muted-foreground">Siparişinizi tamamlayın ve ödeme yöntemini seçin.</p>
      </div>

      <div className="grid gap-5 lg:grid-cols-3">
        {/* Cart Items */}
        <div className="lg:col-span-2 space-y-4">
          <Card className="border-border bg-card/50">
            <CardHeader className="flex flex-row items-center justify-between pb-3 pt-4 px-4">
              <CardTitle className="flex items-center gap-2 text-base">
                <ShoppingBag className="h-4 w-4 text-primary" />
                <span>Sepet İçeriği</span>
                {cart && cart.items.length > 0 && (
                  <Badge className="bg-primary/20 text-primary border-primary/30 text-xs">{cart.items.length} ürün</Badge>
                )}
              </CardTitle>
              {cart && cart.items.length > 0 && (
                <Button variant="ghost" size="sm" onClick={() => clearCart.mutate()} className="text-destructive hover:text-destructive/80 hover:bg-destructive/10 h-8 text-xs">
                  <Trash2 className="h-3.5 w-3.5 mr-1" /> Boşalt
                </Button>
              )}
            </CardHeader>
            <CardContent className="px-4 pb-4">
              {isLoading ? (
                <div className="text-center py-10 text-muted-foreground text-sm">Yükleniyor...</div>
              ) : !cart || cart.items.length === 0 ? (
                <div className="text-center py-12 text-muted-foreground border-2 border-dashed border-border rounded-xl">
                  <ShoppingBag className="h-10 w-10 mx-auto mb-3 opacity-20" />
                  <p className="text-sm">Sepetiniz şu an boş.</p>
                </div>
              ) : (
                <div className="space-y-2">
                  {cart.items.map((item) => (
                    <div key={item.productId} className="flex items-center gap-3 p-3 bg-secondary/30 rounded-xl">
                      <div className="flex-1 min-w-0">
                        <p className="font-semibold text-sm truncate">{item.name}</p>
                        <p className="text-xs text-muted-foreground font-mono">{formatCurrency(item.price)} / adet</p>
                      </div>
                      <div className="flex items-center gap-1.5 shrink-0">
                        <Button variant="outline" size="icon" className="h-7 w-7 border-border"
                          onClick={() => updateItem.mutate({ productId: item.productId, data: { quantity: Math.max(1, item.quantity - 1) } })}>
                          <Minus className="h-3 w-3" />
                        </Button>
                        <span className="w-6 text-center font-bold text-sm">{item.quantity}</span>
                        <Button variant="outline" size="icon" className="h-7 w-7 border-border"
                          onClick={() => updateItem.mutate({ productId: item.productId, data: { quantity: item.quantity + 1 } })}>
                          <Plus className="h-3 w-3" />
                        </Button>
                      </div>
                      <div className="w-20 text-right shrink-0">
                        <span className="font-bold text-sm text-primary">{formatCurrency(item.subtotal)}</span>
                      </div>
                      <Button variant="ghost" size="icon" className="h-7 w-7 text-muted-foreground hover:text-destructive shrink-0"
                        onClick={() => removeItem.mutate({ productId: item.productId })}>
                        <Trash2 className="h-3.5 w-3.5" />
                      </Button>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Payment Method */}
          <Card className="border-border bg-card/50">
            <CardHeader className="pb-3 pt-4 px-4">
              <CardTitle className="text-sm font-bold uppercase tracking-wider text-muted-foreground">Ödeme Yöntemi</CardTitle>
            </CardHeader>
            <CardContent className="px-4 pb-4 space-y-3">
              <div className="grid gap-2">
                {PAYMENT_OPTIONS.map(opt => {
                  const Icon = opt.icon;
                  const selected = paymentMethod === opt.key;
                  return (
                    <button key={opt.key} onClick={() => setPaymentMethod(opt.key)}
                      className={cn(
                        "flex items-center gap-3 p-3 rounded-xl border-2 text-left transition-all w-full",
                        selected ? opt.color : "border-border bg-card/30 hover:bg-secondary/50 text-foreground"
                      )}>
                      <div className={cn("w-8 h-8 rounded-lg flex items-center justify-center shrink-0",
                        selected ? "bg-current/10" : "bg-secondary")}>
                        <Icon className={cn("h-4 w-4", selected ? "inherit" : "text-muted-foreground")} />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className={cn("font-semibold text-sm", !selected && "text-foreground")}>{opt.label}</p>
                        <p className={cn("text-xs", selected ? "opacity-70" : "text-muted-foreground")}>{opt.desc}</p>
                      </div>
                      <div className={cn("w-4 h-4 rounded-full border-2 shrink-0 flex items-center justify-center",
                        selected ? "border-current bg-current" : "border-muted-foreground")}>
                        {selected && <div className="w-2 h-2 rounded-full bg-card" />}
                      </div>
                    </button>
                  );
                })}
              </div>

              {/* Havale bilgileri göster */}
              {paymentMethod === "havale" && <IBANCard amount={total} />}
            </CardContent>
          </Card>
        </div>

        {/* Order Summary + Customer Info */}
        <div className="space-y-4">
          {/* Summary */}
          <Card className="border-primary/20 bg-card/50">
            <CardHeader className="pb-3 pt-4 px-4">
              <CardTitle className="text-base">Sipariş Özeti</CardTitle>
            </CardHeader>
            <CardContent className="px-4 pb-4 space-y-3">
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Ara Toplam</span>
                  <span className="font-mono">{cart ? formatCurrency(cart.total) : "₺0,00"}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Kargo</span>
                  <span className="text-green-400 font-semibold">Ücretsiz</span>
                </div>
                {total > 0 && total < 500 && (
                  <div className="bg-yellow-500/10 text-yellow-400 text-xs rounded-lg p-2">
                    🚚 {formatCurrency(500 - total)} daha alışveriş yapın, kargo ücretsiz olsun!
                  </div>
                )}
                <div className="pt-2 border-t border-border flex justify-between items-center">
                  <span className="font-bold">Toplam</span>
                  <span className="text-xl font-black text-primary">{cart ? formatCurrency(cart.total) : "₺0,00"}</span>
                </div>
              </div>

              {/* Customer Info */}
              <div className="space-y-2 pt-2 border-t border-border">
                <h4 className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Müşteri Bilgileri</h4>
                <Input placeholder="Ad Soyad *" value={customerInfo.name}
                  onChange={e => setCustomerInfo({...customerInfo, name: e.target.value})}
                  className="bg-secondary/50 h-9 text-sm" />
                <Input placeholder="Telefon" value={customerInfo.phone} type="tel"
                  onChange={e => setCustomerInfo({...customerInfo, phone: e.target.value})}
                  className="bg-secondary/50 h-9 text-sm" />
                <Input placeholder="E-posta" value={customerInfo.email} type="email"
                  onChange={e => setCustomerInfo({...customerInfo, email: e.target.value})}
                  className="bg-secondary/50 h-9 text-sm" />
                <Textarea placeholder="Teslimat adresi *" value={customerInfo.address}
                  onChange={e => setCustomerInfo({...customerInfo, address: e.target.value})}
                  className="bg-secondary/50 text-sm resize-none" rows={2} />
                <Input placeholder="Sipariş notu (opsiyonel)" value={customerInfo.note}
                  onChange={e => setCustomerInfo({...customerInfo, note: e.target.value})}
                  className="bg-secondary/50 h-9 text-sm" />
              </div>

              {/* Checkout Button */}
              <Button
                className={cn(
                  "w-full font-bold h-12 text-sm rounded-xl gap-2",
                  paymentMethod === "whatsapp" ? "bg-green-600 hover:bg-green-700 text-white" :
                  paymentMethod === "havale" ? "bg-yellow-500 hover:bg-yellow-600 text-gray-900" :
                  "bg-primary hover:bg-primary/90 text-white"
                )}
                disabled={!cart || cart.items.length === 0 || createOrder.isPending}
                onClick={handleCheckout}>
                {createOrder.isPending ? (
                  <span className="flex items-center gap-2"><span className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin" /> İşleniyor...</span>
                ) : paymentMethod === "kapida" ? (
                  <><Truck className="h-4 w-4" /> Kapıda Ödeme ile Tamamla</>
                ) : paymentMethod === "whatsapp" ? (
                  <><MessageCircle className="h-4 w-4" /> WhatsApp ile Sipariş Ver</>
                ) : (
                  <><Banknote className="h-4 w-4" /> Havale / EFT ile Siparişi Oluştur</>
                )}
              </Button>

              {paymentMethod === "havale" && (
                <p className="text-center text-[10px] text-muted-foreground leading-relaxed">
                  Sipariş oluşturulduktan sonra IBAN bilgileri gösterilecek. Havale sonrası dekontu WhatsApp'tan gönderin.
                </p>
              )}
            </CardContent>
          </Card>

          {/* Trust */}
          <div className="grid grid-cols-2 gap-2">
            {[
              { icon: "🔒", text: "Güvenli Ödeme" },
              { icon: "🚚", text: "Hızlı Teslimat" },
              { icon: "📱", text: "WhatsApp Destek" },
              { icon: "↩️", text: "14 Gün İade" },
            ].map(t => (
              <div key={t.text} className="bg-secondary/30 rounded-lg p-2 text-center text-xs text-muted-foreground">
                <div className="text-base mb-0.5">{t.icon}</div>
                {t.text}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
