import { useState, useEffect } from "react";
import {
  useListProducts,
  useListCategories,
  useDeleteProduct,
  useCreateProduct,
  useUpdateProduct,
  getListProductsQueryKey,
} from "@workspace/api-client-react";
import { formatCurrency } from "@/lib/format";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Plus,
  Search,
  Trash2,
  Edit,
  AlertCircle,
  Package,
  Globe,
  CheckCircle2,
  Link2,
  ImageOff,
  Wrench,
  BrainCircuit,
} from "lucide-react";
import { Link } from "wouter";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { cn } from "@/lib/utils";

const PLACEHOLDER = "/placeholder-product.svg";

function cleanText(v: unknown): string {
  return typeof v === "string" ? v.trim() : "";
}

function resolveProductImage(p: any): string {
  const raw =
    p?.imageUrl ||
    p?.image_url ||
    p?.image ||
    p?.photoUrl ||
    p?.fotograf_url ||
    p?.productImage ||
    "";

  const value = cleanText(raw);
  const lower = value.toLowerCase();

  const bad = [
    "placeholder",
    "no-image",
    "no_image",
    "default",
    "missing",
    "empty",
    "arya",
    "gross",
    "logo",
  ];

  if (!value.startsWith("http")) return PLACEHOLDER;
  if (bad.some((x) => lower.includes(x))) return PLACEHOLDER;

  return value;
}

function cleanProductUrl(url: string | null | undefined): string {
  const trimmed = String(url || "").trim();
  if (!trimmed) return "";

  const fixed = trimmed.startsWith("http") ? trimmed : `https://${trimmed}`;
  const lower = fixed.toLowerCase();

  const badPatterns = [
    "/sr?q=",
    "/ara?q=",
    "/arama?q=",
    "/arama?",
    "/search?",
    "google.com/search",
    "product-not-found",
    "product not found",
    "urun-bulunamadi",
    "sayfa-bulunamadi",
    "404",
  ];

  const bareDomains = [
    "https://www.trendyol.com",
    "http://www.trendyol.com",
    "https://trendyol.com",
    "https://www.hepsiburada.com",
    "https://www.n11.com",
    "https://www.amazon.com.tr",
    "https://www.migros.com.tr",
  ];

  if (bareDomains.includes(lower.replace(/\/$/, ""))) return "";
  if (badPatterns.some((p) => lower.includes(p))) return "";

  return fixed;
}

function ProductImage({ product, className = "" }: { product: any; className?: string }) {
  const [src, setSrc] = useState(() => resolveProductImage(product));
  const [errored, setErrored] = useState(false);

  useEffect(() => {
    const next = resolveProductImage(product);
    setSrc(next);
    setErrored(false);
  }, [product?.imageUrl, product?.image_url, product?.image, product?.photoUrl]);

  return (
    <img
      src={src}
      alt={product?.name ?? "Ürün"}
      onError={() => {
        if (!errored) {
          setErrored(true);
          setSrc(PLACEHOLDER);
        }
      }}
      className={className}
    />
  );
}

function ScoreRing({ value, label, color }: { value: number; label: string; color: string }) {
  if (!value && value !== 0) return null;

  return (
    <div className="text-center">
      <div className={cn("text-base font-black", color)}>{value}</div>
      <div className="text-[8px] text-muted-foreground">{label}</div>
    </div>
  );
}

const PRODUCT_STATUSES = [
  { value: "active", label: "Yayında" },
  { value: "draft", label: "Taslak" },
  { value: "reviewing", label: "İnceleniyor" },
  { value: "pending", label: "Onay Bekliyor" },
  { value: "passive", label: "Pasif" },
  { value: "rejected", label: "Reddedildi" },
];

const productSchema = z.object({
  name: z.string().min(2, "Ürün adı en az 2 karakter olmalıdır"),
  description: z.string().optional(),
  price: z.coerce.number().min(0),
  costPrice: z.coerce.number().min(0).optional(),
  stock: z.coerce.number().min(0),
  categoryId: z.coerce.number().optional(),
  keywords: z.string().optional(),
  imageUrl: z.string().optional(),
  supplierName: z.string().optional(),
  supplierProductUrl: z.string().optional(),
  supplierPrice: z.coerce.number().min(0).optional(),
  riskScore: z.coerce.number().min(0).max(100).optional(),
  demandScore: z.coerce.number().min(0).max(100).optional(),
  opportunityScore: z.coerce.number().min(0).max(100).optional(),
  productStatus: z.string().optional(),
  estimatedShippingDays: z.coerce.number().min(0).optional(),
});

export default function Products() {
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState<string>("all");
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<any>(null);
  const [activeTab, setActiveTab] = useState<"basic" | "supplier">("basic");
  const [statusFilter, setStatusFilter] = useState<"all" | "active" | "inactive">("all");
  const [cleanupRunning, setCleanupRunning] = useState(false);
  const [refreshRunning, setRefreshRunning] = useState(false);
  const [loadTimedOut, setLoadTimedOut] = useState(false);

  const queryClient = useQueryClient();
  const { toast } = useToast();

  const { data: products, isLoading, isError, error } = useListProducts({
    search: search || undefined,
    categoryId: category !== "all" ? Number(category) : undefined,
  });

  const { data: categories } = useListCategories();

  useEffect(() => {
    if (!isLoading) {
      setLoadTimedOut(false);
      return;
    }

    const t = setTimeout(() => setLoadTimedOut(true), 6000);
    return () => clearTimeout(t);
  }, [isLoading]);

  useEffect(() => {
    if (isError) console.error("PRODUCTS_LOAD_ERROR", error);
  }, [isError, error]);

  const form = useForm<z.infer<typeof productSchema>>({
    resolver: zodResolver(productSchema),
    defaultValues: {
      name: "",
      description: "",
      price: 0,
      costPrice: 0,
      stock: 0,
      categoryId: undefined,
      keywords: "",
      imageUrl: "",
      supplierName: "",
      supplierProductUrl: "",
      supplierPrice: 0,
      riskScore: 0,
      demandScore: 0,
      opportunityScore: 0,
      productStatus: "draft",
      estimatedShippingDays: 2,
    },
  });

  const deleteProduct = useDeleteProduct({
    mutation: {
      onSuccess: () => {
        toast({ title: "Silindi" });
        queryClient.invalidateQueries({ queryKey: getListProductsQueryKey() });
      },
    },
  });

  const createProduct = useCreateProduct({
    mutation: {
      onSuccess: () => {
        toast({ title: "Ürün oluşturuldu" });
        queryClient.invalidateQueries({ queryKey: getListProductsQueryKey() });
        setIsDialogOpen(false);
        form.reset();
      },
    },
  });

  const updateProduct = useUpdateProduct({
    mutation: {
      onSuccess: () => {
        toast({ title: "Ürün güncellendi" });
        queryClient.invalidateQueries({ queryKey: getListProductsQueryKey() });
        setIsDialogOpen(false);
        setEditingProduct(null);
        form.reset();
      },
    },
  });

  const publishProduct = useUpdateProduct({
    mutation: {
      onSuccess: () => {
        toast({ title: "✅ İşlem Tamam", description: "Ürün durumu güncellendi." });
        queryClient.invalidateQueries({ queryKey: getListProductsQueryKey() });
      },
      onError: (err: any) => {
        toast({
          title: "Yayınlanamadı",
          description: err?.message || "Ürün linki veya resmi eksik olabilir.",
          variant: "destructive",
        });
      },
    },
  });

  const handleRefreshSupplierData = async () => {
    setRefreshRunning(true);

    try {
      const res = await fetch("/api/products/refresh-supplier-data", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
      });

      const data = await res.json();

      toast({
        title: "Fiyat ve görseller yenilendi",
        description: data?.message || `${data?.updated ?? 0} ürün güncellendi.`,
        duration: 7000,
      });

      queryClient.invalidateQueries({ queryKey: getListProductsQueryKey() });
    } catch {
      toast({ title: "Yenileme başarısız", variant: "destructive" });
    } finally {
      setRefreshRunning(false);
    }
  };

  const handleCleanup = async () => {
    if (!confirm("Linki, görseli veya tedarikçi bilgisi eksik olan ürünler taslağa alınacak. Devam edilsin mi?")) return;

    setCleanupRunning(true);

    try {
      const res = await fetch("/api/products/cleanup", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
      });

      const data = await res.json();

      toast({
        title: "Temizleme tamamlandı",
        description: data?.message || "Hatalı ürünler kontrol edildi.",
        duration: 7000,
      });

      queryClient.invalidateQueries({ queryKey: getListProductsQueryKey() });
    } catch {
      toast({ title: "Temizleme başarısız", variant: "destructive" });
    } finally {
      setCleanupRunning(false);
    }
  };

  const onSubmit = (values: z.infer<typeof productSchema>) => {
    const imageOk = resolveProductImage(values) !== PLACEHOLDER;
    const supplierOk = cleanProductUrl(values.supplierProductUrl);

    if (values.productStatus === "active" && !imageOk) {
      toast({
        title: "Görsel zorunlu",
        description: "Ürünü yayına almak için gerçek görsel URL'si girilmelidir.",
        variant: "destructive",
      });
      return;
    }

    if (values.productStatus === "active" && !supplierOk) {
      toast({
        title: "Tedarikçi linki zorunlu",
        description: "Ürünü yayına almak için gerçek ürün linki girilmelidir.",
        variant: "destructive",
      });
      return;
    }

    if (editingProduct) updateProduct.mutate({ id: editingProduct.id, data: values });
    else createProduct.mutate({ data: values });
  };

  const handleEdit = (product: any) => {
    setEditingProduct(product);

    form.reset({
      name: product.name,
      description: product.description || "",
      price: product.price,
      costPrice: product.costPrice || 0,
      stock: product.stock,
      categoryId: product.categoryId || undefined,
      keywords: product.keywords || "",
      imageUrl: product.imageUrl || "",
      supplierName: product.supplierName || "",
      supplierProductUrl: product.supplierProductUrl || "",
      supplierPrice: product.supplierPrice || 0,
      riskScore: product.riskScore || 0,
      demandScore: product.demandScore || 0,
      opportunityScore: product.opportunityScore || 0,
      productStatus: product.productStatus || "draft",
      estimatedShippingDays: product.estimatedShippingDays || 2,
    });

    setIsDialogOpen(true);
  };

  const getRiskColor = (score: number) => {
    if (score >= 70) return "text-red-400";
    if (score >= 50) return "text-yellow-400";
    return "text-green-400";
  };

  const safeProducts = Array.isArray(products) ? products : [];

  const displayProducts = safeProducts
    .slice()
    .sort((a: any, b: any) => {
      const dateA = new Date(a.createdAt || 0).getTime();
      const dateB = new Date(b.createdAt || 0).getTime();
      if (dateB !== dateA) return dateB - dateA;
      return Number(b.id || 0) - Number(a.id || 0);
    })
    .filter((p: any) => {
      if (statusFilter === "active") return p.productStatus === "active" && p.isActive !== false;
      if (statusFilter === "inactive") return p.productStatus !== "active" || p.isActive === false;
      return true;
    });

  return (
    <div className="space-y-4 animate-in fade-in duration-500">
      <div className="flex items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-black tracking-tight">📦 Ürün Yönetimi</h1>
          <p className="text-xs text-muted-foreground mt-0.5">Tüm envanteri görüntüle ve yönet</p>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <Link href="/arya">
            <Button size="sm" variant="outline" className="gap-1.5 text-xs border-primary/30 text-primary hover:bg-primary/10">
              <BrainCircuit className="h-3.5 w-3.5" />
              Tedarikçi Bul
            </Button>
          </Link>

          <Dialog
            open={isDialogOpen}
            onOpenChange={(open) => {
              setIsDialogOpen(open);
              if (!open) {
                setEditingProduct(null);
                form.reset();
                setActiveTab("basic");
              }
            }}
          >
            <DialogTrigger asChild>
              <Button size="sm" className="bg-primary hover:bg-primary/90 text-white font-bold gap-1.5 shrink-0">
                <Plus className="h-4 w-4" /> Yeni Ürün
              </Button>
            </DialogTrigger>

            <DialogContent className="sm:max-w-[580px] border-border bg-card max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle className="text-lg font-black text-primary">
                  {editingProduct ? "Ürünü Düzenle" : "Yeni Ürün Ekle"}
                </DialogTitle>
              </DialogHeader>

              <div className="flex gap-1 bg-secondary/30 p-1 rounded-lg">
                {[
                  { key: "basic", label: "Temel Bilgiler" },
                  { key: "supplier", label: "Tedarik & Puanlama" },
                ].map((tab) => (
                  <button
                    key={tab.key}
                    onClick={() => setActiveTab(tab.key as any)}
                    className={cn(
                      "flex-1 py-1.5 px-3 rounded-md text-xs font-semibold transition-all",
                      activeTab === tab.key ? "bg-card text-foreground shadow-sm" : "text-muted-foreground hover:text-foreground",
                    )}
                  >
                    {tab.label}
                  </button>
                ))}
              </div>

              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-3">
                  {activeTab === "basic" ? (
                    <>
                      <FormField
                        control={form.control}
                        name="imageUrl"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-xs uppercase tracking-wider text-muted-foreground">Görsel URL</FormLabel>
                            <div className="space-y-2">
                              <div className="relative h-32 rounded-lg overflow-hidden border border-border bg-secondary/30">
                                {field.value ? (
                                  <img
                                    src={field.value}
                                    alt="Önizleme"
                                    onError={(e) => {
                                      (e.currentTarget as HTMLImageElement).src = PLACEHOLDER;
                                    }}
                                    className="w-full h-full object-contain"
                                  />
                                ) : (
                                  <div className="flex flex-col items-center justify-center h-full text-muted-foreground gap-2">
                                    <ImageOff className="h-6 w-6" />
                                    <span className="text-xs">Görsel URL girin</span>
                                  </div>
                                )}
                              </div>
                              <FormControl>
                                <Input placeholder="https://example.com/urun.jpg" {...field} className="bg-secondary/50 text-xs" />
                              </FormControl>
                            </div>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="name"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-xs uppercase tracking-wider text-muted-foreground">Ürün Adı *</FormLabel>
                            <FormControl>
                              <Input placeholder="Örn: Antep Fıstığı 500g" {...field} className="bg-secondary/50" />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="description"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-xs uppercase tracking-wider text-muted-foreground">Açıklama</FormLabel>
                            <FormControl>
                              <Textarea placeholder="Ürün açıklaması..." {...field} className="bg-secondary/50 resize-none h-16" />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <div className="grid grid-cols-2 gap-3">
                        <FormField control={form.control} name="price" render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-xs uppercase tracking-wider text-muted-foreground">Satış Fiyatı (₺)</FormLabel>
                            <FormControl><Input type="number" step="0.01" {...field} className="bg-secondary/50" /></FormControl>
                            <FormMessage />
                          </FormItem>
                        )} />

                        <FormField control={form.control} name="costPrice" render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-xs uppercase tracking-wider text-muted-foreground">Maliyet (₺)</FormLabel>
                            <FormControl><Input type="number" step="0.01" {...field} className="bg-secondary/50" /></FormControl>
                            <FormMessage />
                          </FormItem>
                        )} />
                      </div>

                      <div className="grid grid-cols-2 gap-3">
                        <FormField control={form.control} name="stock" render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-xs uppercase tracking-wider text-muted-foreground">Stok</FormLabel>
                            <FormControl><Input type="number" {...field} className="bg-secondary/50" /></FormControl>
                            <FormMessage />
                          </FormItem>
                        )} />

                        <FormField control={form.control} name="categoryId" render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-xs uppercase tracking-wider text-muted-foreground">Kategori</FormLabel>
                            <Select onValueChange={(val) => field.onChange(Number(val))} value={field.value ? String(field.value) : undefined}>
                              <FormControl><SelectTrigger className="bg-secondary/50"><SelectValue placeholder="Seçin" /></SelectTrigger></FormControl>
                              <SelectContent>
                                {categories?.map((c) => <SelectItem key={c.id} value={String(c.id)}>{c.name}</SelectItem>)}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )} />
                      </div>

                      <div className="grid grid-cols-2 gap-3">
                        <FormField control={form.control} name="productStatus" render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-xs uppercase tracking-wider text-muted-foreground">Durum</FormLabel>
                            <Select onValueChange={field.onChange} value={field.value}>
                              <FormControl><SelectTrigger className="bg-secondary/50"><SelectValue placeholder="Seçin" /></SelectTrigger></FormControl>
                              <SelectContent>
                                {PRODUCT_STATUSES.map((s) => <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>)}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )} />

                        <FormField control={form.control} name="keywords" render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-xs uppercase tracking-wider text-muted-foreground">Anahtar Kelimeler</FormLabel>
                            <FormControl><Input placeholder="virgül ile ayırın" {...field} className="bg-secondary/50" /></FormControl>
                            <FormMessage />
                          </FormItem>
                        )} />
                      </div>
                    </>
                  ) : (
                    <>
                      <div className="bg-secondary/20 border border-border rounded-xl p-3 space-y-3">
                        <p className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Tedarikçi Bilgileri</p>

                        <FormField control={form.control} name="supplierName" render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-xs text-muted-foreground">Tedarikçi Adı</FormLabel>
                            <FormControl><Input placeholder="Örn: Trendyol, N11, Yurt içi" {...field} className="bg-secondary/50 text-xs" /></FormControl>
                          </FormItem>
                        )} />

                        <FormField control={form.control} name="supplierProductUrl" render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-xs text-muted-foreground">Tedarikçi Ürün Linki</FormLabel>
                            <FormControl><Input placeholder="https://..." {...field} className="bg-secondary/50 text-xs" /></FormControl>
                          </FormItem>
                        )} />

                        <div className="grid grid-cols-2 gap-3">
                          <FormField control={form.control} name="supplierPrice" render={({ field }) => (
                            <FormItem>
                              <FormLabel className="text-xs text-muted-foreground">Tedarik Fiyatı (₺)</FormLabel>
                              <FormControl><Input type="number" step="0.01" {...field} className="bg-secondary/50 text-xs" /></FormControl>
                            </FormItem>
                          )} />

                          <FormField control={form.control} name="estimatedShippingDays" render={({ field }) => (
                            <FormItem>
                              <FormLabel className="text-xs text-muted-foreground">Kargo Günü</FormLabel>
                              <FormControl><Input type="number" min="1" max="30" {...field} className="bg-secondary/50 text-xs" /></FormControl>
                            </FormItem>
                          )} />
                        </div>
                      </div>

                      <div className="bg-secondary/20 border border-border rounded-xl p-3 space-y-3">
                        <p className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Puanlama (0-100)</p>

                        <div className="grid grid-cols-3 gap-3">
                          <FormField control={form.control} name="demandScore" render={({ field }) => (
                            <FormItem><FormLabel className="text-xs text-muted-foreground">Talep Puanı</FormLabel><FormControl><Input type="number" min="0" max="100" {...field} className="bg-secondary/50 text-xs" /></FormControl></FormItem>
                          )} />
                          <FormField control={form.control} name="opportunityScore" render={({ field }) => (
                            <FormItem><FormLabel className="text-xs text-muted-foreground">Fırsat Puanı</FormLabel><FormControl><Input type="number" min="0" max="100" {...field} className="bg-secondary/50 text-xs" /></FormControl></FormItem>
                          )} />
                          <FormField control={form.control} name="riskScore" render={({ field }) => (
                            <FormItem><FormLabel className="text-xs text-muted-foreground">Risk Puanı</FormLabel><FormControl><Input type="number" min="0" max="100" {...field} className="bg-secondary/50 text-xs" /></FormControl></FormItem>
                          )} />
                        </div>
                      </div>
                    </>
                  )}

                  <div className="flex justify-end gap-2 pt-2 border-t border-border">
                    <Button variant="outline" type="button" size="sm" onClick={() => setIsDialogOpen(false)}>İptal</Button>
                    <Button type="submit" size="sm" disabled={createProduct.isPending || updateProduct.isPending} className="bg-primary hover:bg-primary/90 text-white">
                      {editingProduct ? "Güncelle" : "Oluştur"}
                    </Button>
                  </div>
                </form>
              </Form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <div className="flex gap-2">
        <div className="relative flex-1">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input placeholder="Ürün ara..." className="pl-9 bg-secondary/50 border-border h-9 text-sm" value={search} onChange={(e) => setSearch(e.target.value)} />
        </div>

        <Select value={category} onValueChange={setCategory}>
          <SelectTrigger className="w-[140px] bg-secondary/50 border-border h-9 text-sm shrink-0">
            <SelectValue placeholder="Kategori" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Tümü</SelectItem>
            {categories?.map((c) => <SelectItem key={c.id} value={c.id.toString()}>{c.name}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>

      <div className="flex flex-wrap items-center gap-2">
        {(["all", "active", "inactive"] as const).map((tab) => (
          <button
            key={tab}
            onClick={() => setStatusFilter(tab)}
            className={cn(
              "px-3 py-1 text-xs rounded-full border transition-all font-medium",
              statusFilter === tab ? "bg-primary text-white border-primary" : "border-border text-muted-foreground hover:border-primary/40 hover:text-foreground",
            )}
          >
            {tab === "all" ? "🗂 Tümü" : tab === "active" ? "✅ Yayında" : "⛔ Pasif / Taslak"}
          </button>
        ))}

        <Button size="sm" variant="outline" onClick={handleRefreshSupplierData} disabled={refreshRunning} className="ml-auto text-xs gap-1.5 border-blue-500/30 text-blue-400 hover:bg-blue-500/10 hover:text-blue-300">
          <Wrench className="h-3.5 w-3.5" />
          {refreshRunning ? "Yenileniyor..." : "Fiyat ve Görselleri Yenile"}
        </Button>

        <Button size="sm" variant="outline" onClick={handleCleanup} disabled={cleanupRunning} className="text-xs gap-1.5 border-orange-500/30 text-orange-400 hover:bg-orange-500/10 hover:text-orange-300">
          <Wrench className="h-3.5 w-3.5" />
          {cleanupRunning ? "Temizleniyor..." : "Hatalı Ürünleri Pasife Al"}
        </Button>
      </div>

      {!isLoading && (
        <p className="text-xs text-muted-foreground">
          {displayProducts.length} ürün listeleniyor{statusFilter !== "all" ? " (filtre aktif)" : ""}
        </p>
      )}

      {isLoading && !loadTimedOut ? (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
          {[1, 2, 3, 4, 5, 6].map((i) => (
            <Card key={i} className="border-border bg-card/60 animate-pulse">
              <div className="h-40 bg-secondary/50 rounded-t-lg" />
              <div className="p-3 space-y-2">
                <div className="h-3 bg-secondary/50 rounded w-3/4" />
                <div className="h-3 bg-secondary/50 rounded w-1/2" />
              </div>
            </Card>
          ))}
        </div>
      ) : isError || loadTimedOut ? (
        <Card className="border-red-500/20 bg-red-500/5">
          <div className="py-10 text-center space-y-2">
            <AlertCircle className="h-8 w-8 text-red-400 mx-auto" />
            <p className="text-sm font-semibold text-red-400">Ürünler yüklenemedi.</p>
            <p className="text-xs text-muted-foreground">{(error as any)?.message || "API sunucusuna bağlanılamadı."}</p>
            <button
              onClick={() => {
                setLoadTimedOut(false);
                queryClient.invalidateQueries({ queryKey: getListProductsQueryKey() });
              }}
              className="mt-2 text-xs text-primary underline"
            >
              Tekrar dene
            </button>
          </div>
        </Card>
      ) : safeProducts.length === 0 ? (
        <Card className="border-dashed border-border bg-card/30">
          <div className="py-12 text-center space-y-2">
            <Package className="h-8 w-8 text-muted-foreground mx-auto" />
            <p className="text-sm font-semibold">Henüz ürün eklenmedi.</p>
          </div>
        </Card>
      ) : displayProducts.length === 0 ? (
        <Card className="border-dashed border-border bg-card/30">
          <div className="py-12 text-center space-y-2">
            <Package className="h-8 w-8 text-muted-foreground mx-auto" />
            <p className="text-sm font-semibold">Filtreye uygun ürün yok.</p>
          </div>
        </Card>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
          {displayProducts.map((product: any) => {
            const margin =
              product.costPrice && product.costPrice > 0
                ? Math.round(((product.price - product.costPrice) / product.price) * 100)
                : null;

            const hasScoring = product.opportunityScore || product.demandScore || product.riskScore;
            const isHighPotential = product.opportunityScore >= 85;
            const isRecommended = product.opportunityScore >= 70 && product.opportunityScore < 85;
            const isHighRisk = product.riskScore >= 70;
            const supplierUrl = cleanProductUrl(product.supplierProductUrl);
            const imageOk = resolveProductImage(product) !== PLACEHOLDER;

            return (
              <Card key={product.id} className={cn("border bg-card/60 hover:border-primary/30 transition-all group overflow-hidden", isHighPotential ? "border-yellow-500/30" : isHighRisk ? "border-red-500/20" : "border-border")}>
                <div className="relative h-40 bg-secondary/30 overflow-hidden">
                  <ProductImage product={product} className="w-full h-full object-contain p-2 group-hover:scale-105 transition-transform duration-300" />

                  <div className="absolute top-2 left-2 flex flex-col gap-1">
                    {product.stock < 10 && <Badge className="bg-red-500/90 text-white text-[9px] px-1.5 py-0 h-4 gap-0.5 border-0"><AlertCircle className="h-2.5 w-2.5" /> Az Stok</Badge>}
                    {!imageOk && <Badge className="bg-orange-500/90 text-white text-[9px] px-1.5 py-0 h-4 border-0">Resim Yok</Badge>}
                    {!supplierUrl && <Badge className="bg-red-500/90 text-white text-[9px] px-1.5 py-0 h-4 border-0">Link Yok</Badge>}
                    {isHighPotential && <Badge className="bg-yellow-500/90 text-black text-[9px] px-1.5 py-0 h-4 border-0">⭐ Yüksek Potansiyel</Badge>}
                    {isRecommended && !isHighPotential && <Badge className="bg-green-500/90 text-white text-[9px] px-1.5 py-0 h-4 border-0">✓ Önerilen</Badge>}
                    {isHighRisk && <Badge className="bg-red-500/80 text-white text-[9px] px-1.5 py-0 h-4 border-0">⚠ Riskli</Badge>}
                  </div>

                  {product.productStatus !== "active" && (
                    <div className="absolute top-1 right-1">
                      <span className="text-[9px] font-bold bg-black/70 text-yellow-400 px-1.5 py-0.5 rounded">
                        {product.productStatus === "draft" ? "Taslak" : product.productStatus === "rejected" ? "Red" : "Pasif"}
                      </span>
                    </div>
                  )}
                </div>

                <CardContent className="p-3 space-y-2">
                  <div className="flex items-start justify-between gap-1">
                    <div className="min-w-0">
                      {product.categoryName && <span className="text-[10px] text-muted-foreground uppercase tracking-wider">{product.categoryName}</span>}
                      <p className="text-sm font-semibold leading-tight line-clamp-2 min-h-[2.5rem]">{product.name}</p>
                    </div>

                    {product.productStatus === "active" && (
                      <span className="shrink-0 flex items-center gap-0.5 text-[9px] font-bold text-green-400 bg-green-500/10 rounded px-1 py-0.5 border border-green-500/20">
                        <CheckCircle2 className="h-2.5 w-2.5" /> Yayında
                      </span>
                    )}
                  </div>

                  <div className="flex items-baseline justify-between">
                    <span className="text-base font-black text-primary">{formatCurrency(product.price)}</span>
                    {margin !== null && <span className="text-[10px] text-green-400 font-mono">%{margin} kâr</span>}
                  </div>

                  <div className="text-[10px] text-muted-foreground space-y-0.5">
                    <div className={product.stock < 10 ? "text-red-400 font-bold" : ""}>Stok: {product.stock}</div>
                    {product.supplierName && <div className="flex items-center gap-1"><span className="truncate">📦 Tedarikçi: {product.supplierName}</span></div>}
                    {product.estimatedShippingDays && product.estimatedShippingDays > 0 && <div>🚚 {product.estimatedShippingDays} iş günü</div>}
                  </div>

                  {hasScoring && (
                    <div className="flex justify-around pt-1 border-t border-border/50">
                      <ScoreRing value={product.demandScore} label="Talep" color="text-blue-400" />
                      <ScoreRing value={product.opportunityScore} label="Fırsat" color="text-green-400" />
                      <ScoreRing value={product.riskScore} label="Risk" color={getRiskColor(product.riskScore)} />
                    </div>
                  )}

                  <div className="pt-1 border-t border-border/50 space-y-1.5">
                    {product.productStatus !== "active" ? (
                      <Button
                        className="w-full h-8 text-xs font-bold bg-green-600 hover:bg-green-700 text-white gap-1.5 disabled:opacity-50"
                        onClick={() => {
                          if (!imageOk) {
                            toast({ title: "Görsel zorunlu", description: "Yayına almak için önce gerçek görsel URL'si ekleyin.", variant: "destructive" });
                            return;
                          }

                          if (!supplierUrl) {
                            toast({ title: "Tedarikçi linki zorunlu", description: "Yayına almak için önce gerçek ürün linki ekleyin.", variant: "destructive" });
                            return;
                          }

                          publishProduct.mutate({ id: product.id, data: { productStatus: "active", isActive: true } as any });
                        }}
                        disabled={publishProduct.isPending || !imageOk || !supplierUrl}
                      >
                        <Globe className="h-3.5 w-3.5" />
                        Siteye Yayınla
                      </Button>
                    ) : (
                      <Button
                        variant="outline"
                        className="w-full h-8 text-xs font-bold text-green-400 border-green-500/30 hover:bg-green-500/10 gap-1.5"
                        onClick={() => publishProduct.mutate({ id: product.id, data: { productStatus: "draft", isActive: false } as any })}
                        disabled={publishProduct.isPending}
                      >
                        <CheckCircle2 className="h-3.5 w-3.5" /> Yayında — Kaldır
                      </Button>
                    )}

                    <div className="flex gap-1">
                      {supplierUrl ? (
                        <a href={supplierUrl} target="_blank" rel="noopener noreferrer" className="flex-1">
                          <Button variant="ghost" size="sm" className="w-full h-7 text-[10px] text-blue-400 hover:text-blue-300 hover:bg-blue-500/10 gap-0.5 px-1">
                            <Link2 className="h-3 w-3" />
                            Ürün Linki
                          </Button>
                        </a>
                      ) : (
                        <Button variant="ghost" size="sm" disabled className="flex-1 h-7 text-[10px] text-muted-foreground gap-0.5 px-1 opacity-60">
                          <Link2 className="h-3 w-3" />
                          Link Yok
                        </Button>
                      )}

                      <Button variant="ghost" size="icon" className="h-7 w-7 text-muted-foreground hover:text-foreground" title="Düzenle" onClick={() => handleEdit(product)}>
                        <Edit className="h-3.5 w-3.5" />
                      </Button>

                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-7 w-7 text-muted-foreground hover:text-destructive"
                        title="Sil"
                        onClick={() => {
                          if (confirm("Silmek istediğinize emin misiniz?")) deleteProduct.mutate({ id: product.id });
                        }}
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}