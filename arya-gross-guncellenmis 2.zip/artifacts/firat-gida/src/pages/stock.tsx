import { useListProducts, useUpdateStock, getListProductsQueryKey } from "@workspace/api-client-react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { BarChart2, AlertTriangle, TrendingDown, CheckCircle2, Search, Edit2 } from "lucide-react";
import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { formatCurrency } from "@/lib/format";

export default function Stock() {
  const { data: products, isLoading } = useListProducts();
  const [search, setSearch] = useState("");
  const [editingId, setEditingId] = useState<number | null>(null);
  const [newStock, setNewStock] = useState("");
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const updateStock = useUpdateStock({
    mutation: {
      onSuccess: () => {
        toast({ title: "Stok güncellendi" });
        queryClient.invalidateQueries({ queryKey: getListProductsQueryKey() });
        setEditingId(null);
        setNewStock("");
      }
    }
  });

  const filtered = (products || []).filter(p =>
    p.name.toLowerCase().includes(search.toLowerCase())
  );

  const critical = filtered.filter(p => p.stock < 10);
  const low = filtered.filter(p => p.stock >= 10 && p.stock < 30);
  const ok = filtered.filter(p => p.stock >= 30);

  const totalValue = (products || []).reduce((s, p) => s + (p.costPrice || p.price) * p.stock, 0);

  return (
    <div className="space-y-4 animate-in fade-in duration-500">
      <div className="flex items-start gap-3">
        <div className="w-10 h-10 bg-cyan-500/20 rounded-xl flex items-center justify-center shrink-0 border border-cyan-500/30">
          <BarChart2 className="h-5 w-5 text-cyan-400" />
        </div>
        <div>
          <h1 className="text-xl font-black">📦 Stok Yönetimi</h1>
          <p className="text-xs text-muted-foreground mt-0.5">Ürün stoklarını takip et, güncelle ve uyarıları gör</p>
        </div>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {[
          { label: "Toplam Ürün", val: products?.length || 0, color: "text-foreground" },
          { label: "Kritik Stok", val: critical.length, color: "text-red-400" },
          { label: "Düşük Stok", val: low.length, color: "text-yellow-400" },
          { label: "Stok Değeri", val: formatCurrency(totalValue), color: "text-accent" },
        ].map(s => (
          <Card key={s.label} className={`border-border bg-card/60 ${s.label === "Kritik Stok" && critical.length > 0 ? "border-red-500/30" : ""}`}>
            <CardContent className="p-3">
              <div className="text-[10px] text-muted-foreground uppercase tracking-wider mb-1">{s.label}</div>
              <div className={`text-xl font-black ${s.color}`}>{s.val}</div>
            </CardContent>
          </Card>
        ))}
      </div>

      {critical.length > 0 && (
        <Card className="border-red-500/30 bg-red-500/5">
          <CardContent className="p-3">
            <div className="flex items-center gap-2 mb-2">
              <AlertTriangle className="h-4 w-4 text-red-400" />
              <span className="text-sm font-bold text-red-400">Kritik Stok Uyarısı — {critical.length} ürün</span>
            </div>
            <div className="space-y-1">
              {critical.map(p => (
                <div key={p.id} className="flex items-center justify-between text-xs">
                  <span className="text-foreground">{p.name}</span>
                  <span className="font-mono text-red-400 font-bold">{p.stock} adet kaldı</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      <div className="relative">
        <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
        <Input placeholder="Ürün ara..." className="pl-9 bg-secondary/50 border-border h-9 text-sm" value={search} onChange={e => setSearch(e.target.value)} />
      </div>

      {isLoading ? (
        <div className="space-y-2">{[1,2,3,4].map(i => <div key={i} className="h-16 bg-secondary/30 animate-pulse rounded-xl" />)}</div>
      ) : (
        <div className="space-y-2">
          {filtered.sort((a, b) => a.stock - b.stock).map(product => {
            const isEditing = editingId === product.id;
            const level = product.stock < 10 ? "critical" : product.stock < 30 ? "low" : "ok";
            return (
              <Card key={product.id} className={`border transition-all ${level === "critical" ? "border-red-500/30 bg-red-500/5" : level === "low" ? "border-yellow-500/20 bg-yellow-500/5" : "border-border bg-card/60"}`}>
                <CardContent className="p-3">
                  <div className="flex items-center gap-3">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-sm font-semibold truncate">{product.name}</span>
                        {level === "critical" && <Badge className="bg-red-500/20 text-red-400 border-red-500/30 text-[9px] gap-1"><AlertTriangle className="h-2.5 w-2.5" />Kritik</Badge>}
                        {level === "low" && <Badge className="bg-yellow-500/20 text-yellow-400 border-yellow-500/30 text-[9px] gap-1"><TrendingDown className="h-2.5 w-2.5" />Düşük</Badge>}
                        {level === "ok" && <Badge className="bg-green-500/20 text-green-400 border-green-500/30 text-[9px] gap-1"><CheckCircle2 className="h-2.5 w-2.5" />Normal</Badge>}
                      </div>
                      <div className="text-[11px] text-muted-foreground mt-0.5">{product.categoryName || "Kategori yok"} · {formatCurrency(product.price)}</div>
                    </div>

                    {isEditing ? (
                      <div className="flex items-center gap-2 shrink-0">
                        <Input
                          type="number"
                          value={newStock}
                          onChange={e => setNewStock(e.target.value)}
                          className="w-20 h-8 text-sm bg-secondary/50"
                          autoFocus
                        />
                        <Button size="sm" className="h-8 bg-primary hover:bg-primary/90 text-white px-3 text-xs"
                          onClick={() => updateStock.mutate({ id: product.id, data: { stock: Number(newStock) } })}
                          disabled={updateStock.isPending}
                        >Kaydet</Button>
                        <Button variant="ghost" size="sm" className="h-8 px-2 text-xs" onClick={() => setEditingId(null)}>İptal</Button>
                      </div>
                    ) : (
                      <div className="flex items-center gap-3 shrink-0">
                        <div className="text-right">
                          <div className={`text-xl font-black ${level === "critical" ? "text-red-400" : level === "low" ? "text-yellow-400" : "text-foreground"}`}>{product.stock}</div>
                          <div className="text-[10px] text-muted-foreground">adet</div>
                        </div>
                        <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-foreground"
                          onClick={() => { setEditingId(product.id); setNewStock(String(product.stock)); }}
                        ><Edit2 className="h-3.5 w-3.5" /></Button>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}
