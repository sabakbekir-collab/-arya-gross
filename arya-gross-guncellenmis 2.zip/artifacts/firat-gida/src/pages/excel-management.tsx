import { useState, useRef } from "react";
import * as XLSX from "xlsx";
import { useImportProducts, getListProductsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Upload, Download, FileSpreadsheet, CheckCircle2, XCircle, AlertTriangle, Trash2, FileDown } from "lucide-react";
import { cn } from "@/lib/utils";

const REQUIRED_COLS = ["Ürün Adı", "Satış Fiyatı", "Stok"];
const OPTIONAL_COLS = ["Marka", "Kategori", "Tedarikçi", "Tedarik Fiyatı", "Açıklama", "Görsel URL"];
const ALL_COLS = [...REQUIRED_COLS, ...OPTIONAL_COLS];

interface ParsedRow {
  name: string;
  brand?: string;
  category?: string;
  supplierName?: string;
  supplierPrice?: number;
  price: number;
  stock: number;
  description?: string;
  imageUrl?: string;
  _valid: boolean;
  _errors: string[];
  _rowNum: number;
}

function parseRow(row: Record<string, any>, rowNum: number): ParsedRow {
  const errors: string[] = [];
  const name = String(row["Ürün Adı"] || "").trim();
  const price = parseFloat(String(row["Satış Fiyatı"] || "").replace(",", "."));
  const stock = parseInt(String(row["Stok"] || "0"), 10);

  if (!name) errors.push("Ürün adı boş");
  if (isNaN(price) || price < 0) errors.push("Geçersiz fiyat");
  if (isNaN(stock) || stock < 0) errors.push("Geçersiz stok");

  return {
    name,
    brand: row["Marka"] ? String(row["Marka"]).trim() : undefined,
    category: row["Kategori"] ? String(row["Kategori"]).trim() : undefined,
    supplierName: row["Tedarikçi"] ? String(row["Tedarikçi"]).trim() : undefined,
    supplierPrice: row["Tedarik Fiyatı"] ? parseFloat(String(row["Tedarik Fiyatı"]).replace(",", ".")) : undefined,
    price: isNaN(price) ? 0 : price,
    stock: isNaN(stock) ? 0 : stock,
    description: row["Açıklama"] ? String(row["Açıklama"]).trim() : undefined,
    imageUrl: row["Görsel URL"] ? String(row["Görsel URL"]).trim() : undefined,
    _valid: errors.length === 0,
    _errors: errors,
    _rowNum: rowNum,
  };
}

function downloadTemplate() {
  const wb = XLSX.utils.book_new();
  const sample = [
    {
      "Ürün Adı": "Antep Fıstığı 500g",
      "Marka": "Doğadan",
      "Kategori": "Kuruyemiş",
      "Tedarikçi": "Trendyol",
      "Tedarik Fiyatı": 80,
      "Satış Fiyatı": 189.9,
      "Stok": 50,
      "Açıklama": "Doğal Antep fıstığı",
      "Görsel URL": "https://example.com/img.jpg",
    }
  ];
  XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(sample), "Şablon");
  XLSX.writeFile(wb, "arya-gross-urun-sablonu.xlsx");
}

export default function ExcelManagement() {
  const [rows, setRows] = useState<ParsedRow[]>([]);
  const [fileName, setFileName] = useState<string | null>(null);
  const [importing, setImporting] = useState(false);
  const [importResult, setImportResult] = useState<{ imported: number; skipped: number; errors: string[] } | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const importProducts = useImportProducts();

  const handleFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setFileName(file.name);
    setImportResult(null);

    const reader = new FileReader();
    reader.onload = (evt) => {
      try {
        const data = new Uint8Array(evt.target!.result as ArrayBuffer);
        const wb = XLSX.read(data, { type: "array" });
        const sheet = wb.Sheets[wb.SheetNames[0]];
        const json = XLSX.utils.sheet_to_json(sheet, { defval: "" }) as Record<string, any>[];
        const parsed = json.map((row, i) => parseRow(row, i + 2));
        setRows(parsed);
      } catch {
        toast({ title: "Hata", description: "Dosya okunamadı. .xlsx veya .csv yükleyin.", variant: "destructive" });
      }
    };
    reader.readAsArrayBuffer(file);
  };

  const handleImport = async () => {
    const validRows = rows.filter(r => r._valid);
    if (validRows.length === 0) {
      toast({ title: "Hata", description: "İçe aktarılacak geçerli satır yok.", variant: "destructive" });
      return;
    }

    setImporting(true);
    try {
      const result = await importProducts.mutateAsync({
        data: {
          products: validRows.map(r => ({
            name: r.name,
            brand: r.brand,
            category: r.category,
            supplierName: r.supplierName,
            supplierPrice: r.supplierPrice,
            price: r.price,
            stock: r.stock,
            description: r.description,
            imageUrl: r.imageUrl,
          }))
        }
      });
      setImportResult(result);
      queryClient.invalidateQueries({ queryKey: getListProductsQueryKey() });
      toast({ title: `${result.imported} ürün içe aktarıldı!` });
    } catch (err: any) {
      toast({ title: "Hata", description: err?.message || "İçe aktarma başarısız.", variant: "destructive" });
    } finally {
      setImporting(false);
    }
  };

  const handleExcelExport = () => {
    window.open("/api/reports/export-excel", "_blank");
  };

  const clearAll = () => {
    setRows([]);
    setFileName(null);
    setImportResult(null);
    if (fileRef.current) fileRef.current.value = "";
  };

  const validCount = rows.filter(r => r._valid).length;
  const invalidCount = rows.filter(r => !r._valid).length;

  return (
    <div className="space-y-4 animate-in fade-in duration-500">
      {/* Header */}
      <div className="flex items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-black tracking-tight">📊 Excel Yönetimi</h1>
          <p className="text-xs text-muted-foreground mt-0.5">Ürünleri içe aktarın, tüm raporları dışa aktarın</p>
        </div>
        <Button size="sm" variant="outline" onClick={handleExcelExport}
          className="gap-1.5 text-xs border-green-500/30 text-green-400 hover:bg-green-500/10">
          <Download className="h-3.5 w-3.5" /> Tüm Raporları İndir
        </Button>
      </div>

      {/* Export Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <Card className="border-border bg-card/60 hover:border-green-500/30 transition-all cursor-pointer" onClick={handleExcelExport}>
          <CardContent className="p-4">
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 bg-green-500/20 rounded-xl flex items-center justify-center shrink-0">
                <FileDown className="h-5 w-5 text-green-400" />
              </div>
              <div className="flex-1">
                <p className="font-bold text-sm">Tüm Raporları Excel'e Aktar</p>
                <p className="text-xs text-muted-foreground mt-0.5">8 sayfalık kapsamlı rapor: Siparişler, Ödemeler, Ürünler, Müşteriler, Stoklar, Kâr, Tedarikçiler, İptaller</p>
                <p className="text-[10px] text-muted-foreground mt-1 font-mono">arya-gross-tum-raporlar-YYYY-MM-DD.xlsx</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-border bg-card/60 hover:border-blue-500/30 transition-all cursor-pointer" onClick={downloadTemplate}>
          <CardContent className="p-4">
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 bg-blue-500/20 rounded-xl flex items-center justify-center shrink-0">
                <FileSpreadsheet className="h-5 w-5 text-blue-400" />
              </div>
              <div className="flex-1">
                <p className="font-bold text-sm">Ürün İçe Aktarma Şablonu İndir</p>
                <p className="text-xs text-muted-foreground mt-0.5">Doldurulacak Excel şablonu — tüm kolonlar dahil</p>
                <div className="flex flex-wrap gap-1 mt-1.5">
                  {REQUIRED_COLS.map(c => <Badge key={c} className="text-[9px] bg-red-500/20 text-red-400 border-red-500/30">{c}*</Badge>)}
                  {OPTIONAL_COLS.slice(0, 3).map(c => <Badge key={c} className="text-[9px] bg-secondary text-muted-foreground border-border">{c}</Badge>)}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Import Section */}
      <Card className="border-border bg-card/50">
        <CardHeader className="pb-3 pt-4 px-4">
          <CardTitle className="text-sm font-bold flex items-center gap-2">
            <Upload className="h-4 w-4 text-primary" />
            Ürün İçe Aktar
          </CardTitle>
        </CardHeader>
        <CardContent className="px-4 pb-4 space-y-3">
          {/* Upload Area */}
          <div
            className="border-2 border-dashed border-border rounded-xl p-6 text-center cursor-pointer hover:border-primary/50 hover:bg-primary/5 transition-all"
            onClick={() => fileRef.current?.click()}
            onDragOver={e => e.preventDefault()}
            onDrop={e => {
              e.preventDefault();
              const file = e.dataTransfer.files[0];
              if (file && fileRef.current) {
                const dt = new DataTransfer();
                dt.items.add(file);
                fileRef.current.files = dt.files;
                fileRef.current.dispatchEvent(new Event("change", { bubbles: true }));
              }
            }}
          >
            <FileSpreadsheet className="h-8 w-8 text-primary/50 mx-auto mb-2" />
            {fileName ? (
              <p className="font-semibold text-sm text-primary">{fileName}</p>
            ) : (
              <>
                <p className="font-semibold text-sm">Excel veya CSV dosyası seçin</p>
                <p className="text-xs text-muted-foreground mt-1">Sürükleyip bırakın veya tıklayın — .xlsx, .csv</p>
              </>
            )}
          </div>
          <input ref={fileRef} type="file" accept=".xlsx,.csv,.xls" className="hidden" onChange={handleFile} />

          {/* Sütun Rehberi */}
          <div className="bg-secondary/20 rounded-xl p-3">
            <p className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground mb-2">Desteklenen Sütunlar</p>
            <div className="flex flex-wrap gap-1">
              {REQUIRED_COLS.map(c => <Badge key={c} className="text-[9px] bg-red-500/20 text-red-400 border-red-500/30">{c} *zorunlu</Badge>)}
              {OPTIONAL_COLS.map(c => <Badge key={c} className="text-[9px] bg-secondary text-muted-foreground border-border">{c}</Badge>)}
            </div>
          </div>

          {/* İçe Aktarma Sonucu */}
          {importResult && (
            <div className="bg-secondary/30 rounded-xl p-3 space-y-1">
              <p className="text-xs font-bold text-green-400">✓ İçe aktarma tamamlandı</p>
              <p className="text-xs text-muted-foreground">{importResult.imported} ürün eklendi, {importResult.skipped} atlandı</p>
              {importResult.errors.length > 0 && (
                <div className="mt-2 space-y-0.5">
                  {importResult.errors.map((e, i) => (
                    <p key={i} className="text-[10px] text-red-400">• {e}</p>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Önizleme Tablosu */}
          {rows.length > 0 && (
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <p className="text-xs font-bold">{rows.length} satır önizlemesi</p>
                  {validCount > 0 && <Badge className="text-[9px] bg-green-500/20 text-green-400 border-green-500/30">{validCount} geçerli</Badge>}
                  {invalidCount > 0 && <Badge className="text-[9px] bg-red-500/20 text-red-400 border-red-500/30">{invalidCount} hatalı</Badge>}
                </div>
                <Button variant="ghost" size="sm" className="text-xs gap-1 text-muted-foreground h-7" onClick={clearAll}>
                  <Trash2 className="h-3 w-3" /> Temizle
                </Button>
              </div>

              <div className="overflow-x-auto rounded-xl border border-border">
                <table className="w-full text-xs">
                  <thead className="bg-secondary/40">
                    <tr>
                      <th className="px-2 py-2 text-left text-muted-foreground font-semibold w-8">#</th>
                      <th className="px-2 py-2 text-left text-muted-foreground font-semibold">Ürün Adı</th>
                      <th className="px-2 py-2 text-right text-muted-foreground font-semibold">Fiyat</th>
                      <th className="px-2 py-2 text-right text-muted-foreground font-semibold">Stok</th>
                      <th className="px-2 py-2 text-left text-muted-foreground font-semibold">Tedarikçi</th>
                      <th className="px-2 py-2 text-center text-muted-foreground font-semibold w-16">Durum</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-border/50">
                    {rows.slice(0, 50).map(row => (
                      <tr key={row._rowNum} className={cn("hover:bg-secondary/20", !row._valid && "bg-red-500/5")}>
                        <td className="px-2 py-1.5 text-muted-foreground">{row._rowNum}</td>
                        <td className="px-2 py-1.5 font-medium max-w-[200px] truncate">{row.name || <span className="text-red-400 italic">boş</span>}</td>
                        <td className="px-2 py-1.5 text-right font-mono">₺{row.price}</td>
                        <td className="px-2 py-1.5 text-right font-mono">{row.stock}</td>
                        <td className="px-2 py-1.5 text-muted-foreground">{row.supplierName || "—"}</td>
                        <td className="px-2 py-1.5 text-center">
                          {row._valid
                            ? <CheckCircle2 className="h-3.5 w-3.5 text-green-400 mx-auto" />
                            : <div title={row._errors.join(", ")}><XCircle className="h-3.5 w-3.5 text-red-400 mx-auto" /></div>
                          }
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
                {rows.length > 50 && (
                  <p className="text-[10px] text-muted-foreground text-center py-2">+{rows.length - 50} satır daha (ilk 50 gösteriliyor)</p>
                )}
              </div>

              {/* Hatalı satırlar */}
              {invalidCount > 0 && (
                <div className="bg-red-500/10 border border-red-500/20 rounded-xl p-3">
                  <p className="text-xs font-bold text-red-400 mb-1.5">
                    <AlertTriangle className="inline h-3.5 w-3.5 mr-1" />
                    {invalidCount} hatalı satır (içe aktarılmayacak)
                  </p>
                  <div className="space-y-0.5">
                    {rows.filter(r => !r._valid).slice(0, 5).map(r => (
                      <p key={r._rowNum} className="text-[10px] text-red-300">
                        Satır {r._rowNum}: {r._errors.join(", ")}
                      </p>
                    ))}
                  </div>
                </div>
              )}

              {/* Import Button */}
              <Button
                className="w-full bg-primary hover:bg-primary/90 text-white font-bold"
                disabled={validCount === 0 || importing}
                onClick={handleImport}
              >
                {importing ? "İçe Aktarılıyor..." : `${validCount} Ürünü Sisteme Aktar`}
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Rapor Açıklaması */}
      <Card className="border-border bg-card/50">
        <CardHeader className="pb-2 pt-4 px-4">
          <CardTitle className="text-sm font-bold">📄 Dışa Aktarılan Rapor İçeriği</CardTitle>
        </CardHeader>
        <CardContent className="px-4 pb-4">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            {[
              { icon: "📦", label: "Siparişler", desc: "Tüm siparişler" },
              { icon: "💳", label: "Ödemeler", desc: "Havale/EFT takibi" },
              { icon: "🛒", label: "Ürünler", desc: "Kâr analiziyle" },
              { icon: "👥", label: "Müşteriler", desc: "Harcama özeti" },
              { icon: "📊", label: "Stoklar", desc: "Stok durumu" },
              { icon: "💰", label: "Kâr", desc: "Tamamlanan sipariş" },
              { icon: "🏭", label: "Tedarikçiler", desc: "Tedarikçi listesi" },
              { icon: "🚫", label: "İptaller", desc: "İptal edilen" },
            ].map(r => (
              <div key={r.label} className="bg-secondary/20 rounded-xl p-2.5 space-y-0.5">
                <div className="font-bold text-sm">{r.icon} {r.label}</div>
                <div className="text-[10px] text-muted-foreground">{r.desc}</div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
