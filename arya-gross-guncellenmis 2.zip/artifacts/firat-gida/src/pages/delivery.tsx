import { ModulePage } from "@/components/module-page";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Truck, Save, MapPin } from "lucide-react";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";

const DISTRICTS = [
  { name: "Şahinbey", fee: 0 }, { name: "Şehitkamil", fee: 0 }, { name: "Nizip", fee: 25 },
  { name: "İslahiye", fee: 30 }, { name: "Nurdağı", fee: 35 }, { name: "Oğuzeli", fee: 20 },
  { name: "Karkamış", fee: 40 }, { name: "Araban", fee: 35 }, { name: "Yavuzeli", fee: 30 },
];

export default function Delivery() {
  const { toast } = useToast();
  const [fees, setFees] = useState(Object.fromEntries(DISTRICTS.map(d => [d.name, d.fee])));
  const [freeOver, setFreeOver] = useState("500");
  const [minOrder, setMinOrder] = useState("100");

  return (
    <div className="space-y-4 animate-in fade-in duration-500">
      <div className="flex items-start gap-3">
        <div className="w-10 h-10 bg-blue-500/20 rounded-xl flex items-center justify-center shrink-0 border border-blue-500/30">
          <Truck className="h-5 w-5 text-blue-400" />
        </div>
        <div>
          <h1 className="text-xl font-black">🚚 Kargo & Teslimat</h1>
          <p className="text-xs text-muted-foreground mt-0.5">Gaziantep ilçe bazlı teslimat ücretleri ve ayarlar</p>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3">
        <Card className="border-border bg-card/60">
          <CardContent className="p-3">
            <label className="text-xs text-muted-foreground mb-1 block">Ücretsiz Teslimat (₺ üzeri)</label>
            <Input type="number" value={freeOver} onChange={e => setFreeOver(e.target.value)} className="bg-secondary/50 h-9 text-sm" />
          </CardContent>
        </Card>
        <Card className="border-border bg-card/60">
          <CardContent className="p-3">
            <label className="text-xs text-muted-foreground mb-1 block">Minimum Sipariş (₺)</label>
            <Input type="number" value={minOrder} onChange={e => setMinOrder(e.target.value)} className="bg-secondary/50 h-9 text-sm" />
          </CardContent>
        </Card>
      </div>

      <Card className="border-border bg-card/60">
        <CardContent className="p-4">
          <div className="flex items-center gap-2 mb-3">
            <MapPin className="h-4 w-4 text-primary" />
            <span className="text-sm font-bold">Gaziantep İlçe Teslimat Ücretleri</span>
          </div>
          <div className="space-y-2">
            {DISTRICTS.map(d => (
              <div key={d.name} className="flex items-center gap-3">
                <span className="text-sm flex-1">{d.name}</span>
                <div className="flex items-center gap-1">
                  <Input
                    type="number"
                    value={fees[d.name]}
                    onChange={e => setFees(f => ({ ...f, [d.name]: Number(e.target.value) }))}
                    className="w-20 h-7 text-xs bg-secondary/50"
                  />
                  <span className="text-xs text-muted-foreground">₺</span>
                </div>
                {fees[d.name] === 0 && <Badge className="bg-green-500/20 text-green-400 border-green-500/30 text-[9px]">Ücretsiz</Badge>}
              </div>
            ))}
          </div>
          <Button onClick={() => toast({ title: "Teslimat ayarları kaydedildi" })} size="sm" className="w-full mt-4 gap-2 bg-primary hover:bg-primary/90 text-white">
            <Save className="h-3.5 w-3.5" /> Kaydet
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
