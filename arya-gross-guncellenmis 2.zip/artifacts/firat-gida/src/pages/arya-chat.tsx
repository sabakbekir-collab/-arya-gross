import { useState, useRef, useEffect } from "react";
import { Send, Bot, User, Zap, RefreshCw, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { cn } from "@/lib/utils";

interface Message {
  id: number;
  role: "user" | "arya";
  text: string;
  mode?: "lite" | "pro";
  ts: Date;
}

const QUICK_PROMPTS = [
  { label: "Ürün bul", text: "Mağazam için hangi ürünleri eklemeliyim? En çok satan kategorileri söyle." },
  { label: "Tedarikçi bul", text: "Hangi ürünlerin tedarikçi linki eksik? Liste ver." },
  { label: "Fiyat analiz et", text: "Kâr marjı düşük olan ürünleri analiz et ve fiyat önerisi yap." },
  { label: "Kampanya öner", text: "Stok fazlası veya düşük satışlı ürünler için kampanya önerisi ver." },
];

export default function AryaChat() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 0,
      role: "arya",
      text: "Merhaba! Ben Arya. Mağaza verilerine erişimim var — ürün, stok, kâr ve tedarikçi konularında yardımcı olabilirim. Ne öğrenmek istersin?",
      ts: new Date(),
    },
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const nextId = useRef(1);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  async function send(text: string) {
    const trimmed = text.trim();
    if (!trimmed || loading) return;

    const userMsg: Message = {
      id: nextId.current++,
      role: "user",
      text: trimmed,
      ts: new Date(),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInput("");
    setLoading(true);

    try {
      const res = await fetch("/api/ai/arya-chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: trimmed }),
      });

      let replyText: string;
      let mode: "lite" | "pro" | undefined;

      if (!res.ok) {
        let errMsg = `HTTP ${res.status}`;
        try {
          const body = (await res.json()) as { error?: string };
          if (body.error) errMsg = body.error;
        } catch { /* ignore */ }
        replyText = `⚠️ Hata: ${errMsg}`;
      } else {
        const data = (await res.json()) as { mode?: "lite" | "pro"; message: string };
        replyText = data.message;
        mode = data.mode;
      }

      const aryaMsg: Message = {
        id: nextId.current++,
        role: "arya",
        text: replyText,
        mode,
        ts: new Date(),
      };
      setMessages((prev) => [...prev, aryaMsg]);
    } catch (err) {
      const aryaMsg: Message = {
        id: nextId.current++,
        role: "arya",
        text: `⚠️ Sunucuya bağlanılamadı: ${err instanceof Error ? err.message : String(err)}`,
        ts: new Date(),
      };
      setMessages((prev) => [...prev, aryaMsg]);
    } finally {
      setLoading(false);
      setTimeout(() => textareaRef.current?.focus(), 50);
    }
  }

  function handleKeyDown(e: React.KeyboardEvent<HTMLTextAreaElement>) {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      void send(input);
    }
  }

  function formatTime(d: Date) {
    return d.toLocaleTimeString("tr-TR", { hour: "2-digit", minute: "2-digit" });
  }

  return (
    <div className="flex flex-col h-[calc(100vh-7rem)] max-h-[820px]">
      {/* Header */}
      <div className="flex items-center gap-3 pb-4 border-b border-border shrink-0">
        <div className="w-9 h-9 rounded-xl bg-primary flex items-center justify-center shadow-md shadow-primary/30">
          <Bot className="h-5 w-5 text-white" />
        </div>
        <div>
          <h1 className="text-lg font-black tracking-tight flex items-center gap-2">
            Arya Chat
            <span className="text-[9px] font-black bg-primary/15 text-primary px-1.5 py-0.5 rounded-full">AI</span>
          </h1>
          <p className="text-xs text-muted-foreground">Mağaza verilerinize erişimi olan yapay zeka asistanı</p>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto py-4 space-y-4 min-h-0">
        {messages.map((msg) => (
          <div
            key={msg.id}
            className={cn(
              "flex gap-2.5 max-w-[88%]",
              msg.role === "user" ? "ml-auto flex-row-reverse" : "mr-auto"
            )}
          >
            {/* Avatar */}
            <div
              className={cn(
                "w-7 h-7 rounded-lg flex items-center justify-center shrink-0 mt-0.5",
                msg.role === "arya"
                  ? "bg-primary text-white shadow-sm shadow-primary/30"
                  : "bg-secondary text-muted-foreground"
              )}
            >
              {msg.role === "arya" ? (
                <Bot className="h-3.5 w-3.5" />
              ) : (
                <User className="h-3.5 w-3.5" />
              )}
            </div>

            {/* Bubble */}
            <div className="flex flex-col gap-1">
              <div
                className={cn(
                  "rounded-2xl px-3.5 py-2.5 text-sm leading-relaxed whitespace-pre-wrap",
                  msg.role === "arya"
                    ? "bg-card border border-border text-foreground rounded-tl-sm"
                    : "bg-primary text-white rounded-tr-sm"
                )}
              >
                {msg.text}
              </div>
              <div
                className={cn(
                  "text-[10px] text-muted-foreground/60 flex items-center gap-1",
                  msg.role === "user" ? "justify-end" : "justify-start"
                )}
              >
                {formatTime(msg.ts)}
                {msg.mode === "lite" && (
                  <span className="text-[9px] bg-yellow-100 text-yellow-700 px-1 py-0.5 rounded font-bold">LITE</span>
                )}
                {msg.mode === "pro" && (
                  <span className="text-[9px] bg-green-100 text-green-700 px-1 py-0.5 rounded font-bold flex items-center gap-0.5">
                    <Zap className="h-2.5 w-2.5" />PRO
                  </span>
                )}
              </div>
            </div>
          </div>
        ))}

        {loading && (
          <div className="flex gap-2.5 max-w-[88%] mr-auto">
            <div className="w-7 h-7 rounded-lg bg-primary flex items-center justify-center shrink-0 mt-0.5">
              <Bot className="h-3.5 w-3.5 text-white" />
            </div>
            <div className="bg-card border border-border rounded-2xl rounded-tl-sm px-3.5 py-3 flex items-center gap-1.5">
              <RefreshCw className="h-3.5 w-3.5 text-muted-foreground animate-spin" />
              <span className="text-sm text-muted-foreground">Düşünüyor…</span>
            </div>
          </div>
        )}

        <div ref={bottomRef} />
      </div>

      {/* Quick prompts */}
      <div className="flex gap-1.5 flex-wrap py-2 shrink-0">
        {QUICK_PROMPTS.map((p) => (
          <button
            key={p.label}
            type="button"
            onClick={() => void send(p.text)}
            disabled={loading}
            className="flex items-center gap-1 text-[11px] font-semibold px-2.5 py-1 rounded-full border border-border bg-secondary hover:bg-primary/10 hover:border-primary/30 hover:text-primary transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
          >
            <Sparkles className="h-2.5 w-2.5" />
            {p.label}
          </button>
        ))}
      </div>

      {/* Input */}
      <div className="flex gap-2 shrink-0 pt-1">
        <Textarea
          ref={textareaRef}
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder="Arya'ya sor… (Enter ile gönder, Shift+Enter yeni satır)"
          rows={2}
          disabled={loading}
          className="flex-1 resize-none text-sm min-h-[52px] max-h-32"
        />
        <Button
          onClick={() => void send(input)}
          disabled={loading || !input.trim()}
          size="icon"
          className="h-auto w-10 self-stretch bg-primary hover:bg-primary/90 shadow-md shadow-primary/20"
        >
          {loading ? (
            <RefreshCw className="h-4 w-4 animate-spin" />
          ) : (
            <Send className="h-4 w-4" />
          )}
        </Button>
      </div>
    </div>
  );
}
