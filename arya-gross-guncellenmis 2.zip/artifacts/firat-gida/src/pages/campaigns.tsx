import { useState } from "react";
import { useListProducts } from "@workspace/api-client-react";
import { formatCurrency } from "@/lib/format";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Megaphone, Plus, Percent, Tag, Calendar, Zap, Star } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface Campaign {
  id: string; name: string; type: "percent" | "fixed" | "cart";
  value: number; productId?: number; productName?: string;
  startDate: string; endDate: string; active: boolean; usageCount: number;
}

const INITIAL_CAMPAIGNS: Campaign[] = [];

export default function Campaigns() {
  const { toast } = useToast();
  const { data: products } = useListProducts();
  const [campaigns, setCampaigns] = useState<Campaign[]>(INITIAL_CAMPAIGNS);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ name: "", type: "percent", value: "", productId: "" });

  const addCampaign = () => {
    if (!form.name || !form.value) { toast({ title: "Hata", description: "Kampanya adı ve değer zorunludur.", variant: "destructive" }); return; }
    const product = products?.find(p => String(p.id) === form.productId);
    setCampaigns(prev => [...prev, {
      id: Date.now().toString(), name: form.name, type: form.type as any,
      value: Number(form.value), productId: product?.id, productName: product?.name,
      startDate: new Date().toISOString().split("T")[0], endDate: "2026-12-31",
      active: true, usageCount: 0,
    }]);
    setForm({ name: "", type: "percent", value: "", productId: "" });
    setShowForm(false);
    toast({ title: "Kampanya oluşturuldu" });
  };

  const toggle = (id: string) => setCampaigns(prev => prev.map(c => c.id === id ? { ...c, active: !c.active } : c));

  return (
    <div className="space-y-4 animate-in fade-in duration-500">
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-start gap-3">
          <div className="w-10 h-10 bg-orange-500/20 rounded-xl flex items-center justify-center shrink-0 border border-orange-500/30">
            <Megaphone className="h-5 w-5 text-orange-400" />
          </div>
          <div>
            <h1 className="text-xl font-black">🎯 Kampanya Yönetimi</h1>
            <p className="text-xs text-muted-foreground mt-0.5">İndirim ve kampanyaları oluştur ve yönet</p>
          </div>
        </div>
        <Button size="sm" className="bg-primary hover:bg-primary/90 text-white gap-1.5 shrink-0" onClick={() => setShowForm(!showForm)}>
          <Plus className="h-4 w-4" /> Yeni
        </Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-3">
        {[
          { label: "Toplam", val: campaigns.length, color: "text-foreground" },
          { label: "Aktif", val: campaigns.filter(c => c.active).length, color: "text-green-400" },
          { label: "Pasif", val: campaigns.filter(c => !c.active).length, color: "text-muted-foreground" },
        ].map(s => (
          <Card key={s.label} className="border-border bg-card/60">
            <CardContent className="p-3 text-center">
              <div className={`text-2xl font-black ${s.color}`}>{s.val}</div>
              <div className="text-[10px] text-muted-foreground">{s.label}</div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Form */}
      {showForm && (
        <Card className="border-primary/30 bg-primary/5">
          <CardContent className="p-4 space-y-3">
            <h3 className="text-sm font-bold">Yeni Kampanya</h3>
            <Input placeholder="Kampanya adı" value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} className="bg-secondary/50 h-9 text-sm" />
            <div className="grid grid-cols-2 gap-2">
              <Select value={form.type} onValueChange={v => setForm(f => ({ ...f, type: v }))}>
                <SelectTrigger className="bg-secondary/50 h-9 text-sm"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="percent">Yüzde İndirim</SelectItem>
                  <SelectItem value="fixed">Sabit TL İndirim</SelectItem>
                  <SelectItem value="cart">Sepet İndirimi</SelectItem>
                </SelectContent>
              </Select>
              <Input type="number" placeholder={form.type === "percent" ? "% değer" : "TL değer"} value={form.value} onChange={e => setForm(f => ({ ...f, value: e.target.value }))} className="bg-secondary/50 h-9 text-sm" />
            </div>
            {form.type !== "cart" && (
              <Select value={form.productId} onValueChange={v => setForm(f => ({ ...f, productId: v }))}>
                <SelectTrigger className="bg-secondary/50 h-9 text-sm"><SelectValue placeholder="Ürün seçin (opsiyonel)" /></SelectTrigger>
                <SelectContent>
                  {products?.map(p => <SelectItem key={p.id} value={String(p.id)}>{p.name}</SelectItem>)}
                </SelectContent>
              </Select>
            )}
            <div className="flex gap-2">
              <Button size="sm" onClick={addCampaign} className="bg-primary hover:bg-primary/90 text-white">Oluştur</Button>
              <Button size="sm" variant="outline" onClick={() => setShowForm(false)}>İptal</Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Campaign list */}
      <div className="space-y-2">
        {campaigns.map(c => (
          <Card key={c.id} className={`border transition-all ${c.active ? "border-border bg-card/60" : "border-border bg-card/30 opacity-60"}`}>
            <CardContent className="p-3">
              <div className="flex items-start justify-between gap-3">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-sm font-semibold">{c.name}</span>
                    <Badge className={c.active ? "bg-green-500/20 text-green-400 border-green-500/30 text-[9px]" : "bg-secondary text-muted-foreground text-[9px]"}>
                      {c.active ? "Aktif" : "Pasif"}
                    </Badge>
                  </div>
                  <div className="flex items-center gap-3 mt-1 flex-wrap">
                    <div className="flex items-center gap-1 text-[11px] text-muted-foreground">
                      {c.type === "percent" ? <Percent className="h-3 w-3" /> : c.type === "fixed" ? <Tag className="h-3 w-3" /> : <Zap className="h-3 w-3" />}
                      {c.type === "percent" ? `%${c.value} indirim` : c.type === "fixed" ? `${c.value}₺ indirim` : `Sepette %${c.value}`}
                    </div>
                    {c.productName && <div className="flex items-center gap-1 text-[11px] text-muted-foreground"><Star className="h-3 w-3" />{c.productName}</div>}
                    <div className="flex items-center gap-1 text-[11px] text-muted-foreground"><Calendar className="h-3 w-3" />{c.endDate}'e kadar</div>
                  </div>
                  <div className="text-[10px] text-muted-foreground mt-1">{c.usageCount} kez kullanıldı</div>
                </div>
                <Button variant="outline" size="sm" className={`h-7 px-2 text-xs shrink-0 ${c.active ? "text-muted-foreground" : "text-green-400 border-green-500/30"}`} onClick={() => toggle(c.id)}>
                  {c.active ? "Durdur" : "Aktifleştir"}
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
