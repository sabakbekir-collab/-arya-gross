import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import {
  Loader2,
  Sparkles,
  CalendarClock,
  ShoppingBag,
  History,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Clock,
} from "lucide-react";

interface AutomationRunSummary {
  scannedProducts: number;
  suggestionsGenerated: number;
  campaignCandidates: number;
  adsGenerated: number;
  errorsFound: number;
}

interface AutomationRun {
  id: number;
  status: string;
  triggeredBy: string;
  summary: AutomationRunSummary | null;
  errorMessage: string | null;
  durationMs: number | null;
  startedAt: string;
  completedAt: string | null;
}

async function safeFetch<T>(url: string, options?: RequestInit): Promise<T> {
  const res = await fetch(url, options);
  const text = await res.text();
  if (text.trim().startsWith("<")) {
    throw new Error("Backend JSON yerine HTML döndürdü. API route veya server çalışmıyor.");
  }
  const data: unknown = text ? JSON.parse(text) : {};
  if (!res.ok) {
    const message =
      (data as { error?: string; message?: string })?.error ??
      (data as { error?: string; message?: string })?.message ??
      `İstek başarısız (${res.status})`;
    throw new Error(message);
  }
  return data as T;
}

function formatDateTime(value: string | null): string {
  if (!value) return "—";
  return new Date(value).toLocaleString("tr-TR");
}

function formatDuration(ms: number | null): string {
  if (ms === null || !Number.isFinite(ms)) return "—";
  if (ms < 1000) return `${ms} ms`;
  return `${(ms / 1000).toFixed(1)} sn`;
}

function StatusBadge({ status }: { status: string }) {
  if (status === "success") {
    return (
      <Badge className="bg-green-600 text-white gap-1">
        <CheckCircle2 className="h-3.5 w-3.5" /> Başarılı
      </Badge>
    );
  }
  if (status === "completed_with_errors") {
    return (
      <Badge className="bg-yellow-600 text-white gap-1">
        <AlertTriangle className="h-3.5 w-3.5" /> Hatalarla Tamamlandı
      </Badge>
    );
  }
  if (status === "failed") {
    return (
      <Badge variant="destructive" className="gap-1">
        <XCircle className="h-3.5 w-3.5" /> Başarısız
      </Badge>
    );
  }
  return (
    <Badge variant="secondary" className="gap-1">
      <Clock className="h-3.5 w-3.5" /> {status}
    </Badge>
  );
}

export default function AryaOtomasyon() {
  const { toast } = useToast();
  const [runningProduct, setRunningProduct] = useState(false);
  const [runningArya, setRunningArya] = useState(false);
  const [runningDaily, setRunningDaily] = useState(false);
  const [historyLoading, setHistoryLoading] = useState(false);
  const [history, setHistory] = useState<AutomationRun[]>([]);

  async function loadHistory() {
    setHistoryLoading(true);
    try {
      const data = await safeFetch<{ success: boolean; runs: AutomationRun[] }>(
        "/api/arya-automation/history?limit=15"
      );
      setHistory(data.runs ?? []);
    } catch (err) {
      toast({
        title: "Geçmiş yüklenemedi",
        description: err instanceof Error ? err.message : String(err),
        variant: "destructive",
      });
    } finally {
      setHistoryLoading(false);
    }
  }

  useEffect(() => {
    loadHistory();
  }, []);

  async function runRealProductFinder() {
    setRunningProduct(true);
    try {
      const data = await safeFetch<{
        success: boolean;
        insertedCount?: number;
        notFoundCount?: number;
        errorCount?: number;
        message?: string;
      }>("/api/supplier-automation/run", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ limit: 10, profitRate: 0.2 }),
      });
      toast({
        title: "Gerçek Ürün Bul tamamlandı",
        description:
          data.message ??
          `Eklenen: ${data.insertedCount ?? 0}, bulunamayan: ${data.notFoundCount ?? 0}, hata: ${data.errorCount ?? 0}`,
      });
    } catch (err) {
      toast({
        title: "Hata",
        description: err instanceof Error ? err.message : String(err),
        variant: "destructive",
      });
    } finally {
      setRunningProduct(false);
    }
  }

  async function runAryaAutomation(kind: "run" | "daily") {
    const setLoading = kind === "run" ? setRunningArya : setRunningDaily;
    setLoading(true);
    try {
      const data = await safeFetch<{
        success: boolean;
        scannedProducts: number;
        suggestionsGenerated: number;
        errorsFound: number;
        message?: string;
      }>(`/api/arya-automation/${kind}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ triggeredBy: kind === "daily" ? "daily" : "manual" }),
      });
      toast({
        title: kind === "daily" ? "Günlük Otomasyon tamamlandı" : "Arya Otomasyon tamamlandı",
        description:
          data.message ??
          `Taranan: ${data.scannedProducts}, öneri: ${data.suggestionsGenerated}, hata: ${data.errorsFound}`,
      });
      await loadHistory();
    } catch (err) {
      toast({
        title: "Hata",
        description: err instanceof Error ? err.message : String(err),
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="p-5 text-white space-y-6">
      <div>
        <h1 className="text-2xl font-black">Arya Otomasyon</h1>
        <p className="text-sm text-neutral-400 mt-1">
          Tedarikçi havuzundan gerçek ürün bulma ve Arya otomasyon çalıştırmaları.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="bg-neutral-900 border-neutral-800">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <ShoppingBag className="h-4 w-4" /> Gerçek Ürün Bul
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <p className="text-sm text-neutral-400">
              Tedarikçi havuzundan gerçek görsel ve direkt linki olan ürünleri onay listesine ekler.
            </p>
            <Button
              onClick={runRealProductFinder}
              disabled={runningProduct}
              className="w-full bg-red-600 hover:bg-red-700"
            >
              {runningProduct ? (
                <Loader2 className="h-4 w-4 animate-spin mr-2" />
              ) : null}
              {runningProduct ? "TARANIYOR..." : "GERÇEK ÜRÜN BUL"}
            </Button>
          </CardContent>
        </Card>

        <Card className="bg-neutral-900 border-neutral-800">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <Sparkles className="h-4 w-4" /> Arya Otomasyon Çalıştır
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <p className="text-sm text-neutral-400">
              Mevcut ürünleri tarar, geçerli tedarikçi ve görsel linki olanları öneri kuyruğuna ekler.
            </p>
            <Button
              onClick={() => runAryaAutomation("run")}
              disabled={runningArya}
              className="w-full"
            >
              {runningArya ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null}
              {runningArya ? "ÇALIŞIYOR..." : "OTOMASYONU ÇALIŞTIR"}
            </Button>
          </CardContent>
        </Card>

        <Card className="bg-neutral-900 border-neutral-800">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <CalendarClock className="h-4 w-4" /> Günlük Otomasyon
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <p className="text-sm text-neutral-400">
              Günlük taramayı manuel olarak tetikler (triggeredBy: daily).
            </p>
            <Button
              onClick={() => runAryaAutomation("daily")}
              disabled={runningDaily}
              variant="secondary"
              className="w-full"
            >
              {runningDaily ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null}
              {runningDaily ? "ÇALIŞIYOR..." : "GÜNLÜK ÇALIŞTIR"}
            </Button>
          </CardContent>
        </Card>
      </div>

      <Separator className="bg-neutral-800" />

      <Card className="bg-neutral-900 border-neutral-800">
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="flex items-center gap-2 text-base">
            <History className="h-4 w-4" /> Son Çalışmalar
          </CardTitle>
          <Button size="sm" variant="ghost" onClick={loadHistory} disabled={historyLoading}>
            {historyLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : "Yenile"}
          </Button>
        </CardHeader>
        <CardContent>
          {historyLoading && history.length === 0 ? (
            <p className="text-sm text-neutral-400">Yükleniyor...</p>
          ) : history.length === 0 ? (
            <p className="text-sm text-neutral-400">Henüz otomasyon çalıştırılmadı.</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="text-left text-neutral-400 border-b border-neutral-800">
                    <th className="py-2 pr-4">Durum</th>
                    <th className="py-2 pr-4">Tetikleyen</th>
                    <th className="py-2 pr-4">Taranan</th>
                    <th className="py-2 pr-4">Öneri</th>
                    <th className="py-2 pr-4">Hata</th>
                    <th className="py-2 pr-4">Süre</th>
                    <th className="py-2 pr-4">Başlatıldı</th>
                    <th className="py-2 pr-4">Tamamlandı</th>
                  </tr>
                </thead>
                <tbody>
                  {history.map((run) => (
                    <tr key={run.id} className="border-b border-neutral-900">
                      <td className="py-2 pr-4"><StatusBadge status={run.status} /></td>
                      <td className="py-2 pr-4 text-neutral-300">{run.triggeredBy}</td>
                      <td className="py-2 pr-4">{run.summary?.scannedProducts ?? "—"}</td>
                      <td className="py-2 pr-4">{run.summary?.suggestionsGenerated ?? "—"}</td>
                      <td className="py-2 pr-4">{run.summary?.errorsFound ?? "—"}</td>
                      <td className="py-2 pr-4 text-neutral-300">{formatDuration(run.durationMs)}</td>
                      <td className="py-2 pr-4 text-neutral-400">{formatDateTime(run.startedAt)}</td>
                      <td className="py-2 pr-4 text-neutral-400">{formatDateTime(run.completedAt)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
