export default function AiBrain() {
  return (
    <div className="p-6 text-white">
      <h1 className="text-3xl font-bold">🧠 Arya AI Beyin</h1>
      <p className="text-gray-400 mt-2">Mağaza analiz sistemi aktif.</p>
    </div>
  );
}
