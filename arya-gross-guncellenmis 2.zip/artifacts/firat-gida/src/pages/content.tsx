import { ModulePage } from "@/components/module-page";

export default function Content() {
  return (
    <ModulePage
      emoji="📝"
      title="İçerik Yönetimi"
      description="Blog yazıları, sayfa içerikleri ve duyurular"
      badge="Yakında"
      stats={[
        { label: "Yayındaki Yazı", value: "0", color: "text-primary" },
        { label: "Taslak", value: "0", color: "text-muted-foreground" },
        { label: "Sayfa", value: "3", color: "text-blue-400" },
      ]}
    />
  );
}
