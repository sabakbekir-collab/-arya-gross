import { useState, useCallback } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { formatCurrency } from "@/lib/format";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import {
  BrainCircuit,
  Loader2,
  RefreshCw,
  Scan,
  Package,
  Megaphone,
  TrendingUp,
  Warehouse,
  CheckCircle2,
  XCircle,
  Link2,
  Zap,
  ShieldCheck,
  ShieldX,
  ExternalLink,
  Truck,
  Trash2,
  Search,
  AlertCircle,
  Info,
} from "lucide-react";

type TabId = "komuta" | "urunler" | "kampanya" | "kar" | "stok";

interface Suggestion {
  id: number;
  name: string;
  brand?: string | null;
  categoryName?: string | null;
  estimatedSellPrice?: string | null;
  estimatedCostPrice?: string | null;
  profitMargin?: number | null;
  supplierName?: string | null;
  supplierProductUrl?: string | null;
  supplierVerified?: boolean | null;
  supplierShippingDays?: number | null;
  demandScore?: number | null;
  riskScore?: number | null;
  opportunityScore?: number | null;
  description?: string | null;
  stock?: number | null;
  imageUrl?: string | null;
  status: string;
  createdAt: string;
}

interface CampaignIdea {
  id?: string;
  title: string;
  description?: string;
  estimatedImpact?: string;
}

interface ProfitProduct {
  id: number;
  name: string;
  price: number;
  costPrice?: number | null;
  margin?: number | null;
}

interface StockProduct {
  id: number;
  name: string;
  stock: number;
  reorderSuggestion?: string | null;
}

interface FinderLog {
  productId?: number;
  supplierProductId?: number;
  name: string;
  status: "accepted" | "rejected" | "updated" | "skipped";
  supplier?: string;
  url?: string;
  imageUrl?: string;
  reason: string;
}

async function fetchJson<T>(url: string, options?: RequestInit): Promise<T> {
  const res = await fetch(url, options);
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error((body as { error?: string }).error ?? `${url} hata verdi`);
  }
  return res.json();
}

export default function Arya() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [tab, setTab] = useState<TabId>("komuta");
  const [actionLoading, setActionLoading] = useState<string | null>(null);
  const [campaigns, setCampaigns] = useState<CampaignIdea[]>([]);
  const [profitProducts, setProfitProducts] = useState<ProfitProduct[]>([]);
  const [stockProducts, setStockProducts] = useState<StockProduct[]>([]);
  const [finderLogs, setFinderLogs] = useState<FinderLog[]>([]);

  // ── Pending suggestions from DB ──────────────────────────────────
  const { data: suggestionsData, isLoading: suggestionsLoading } = useQuery<{
    suggestions: Suggestion[];
    count: number;
  }>({
    queryKey: ["arya-suggestions-pending"],
    queryFn: () => fetchJson("/api/arya/suggestions?status=pending"),
    enabled: tab === "urunler",
    refetchOnWindowFocus: true,
  });

  const pendingSuggestions = suggestionsData?.suggestions ?? [];

  // ── Approve mutation ──────────────────────────────────────────────
  const approveMutation = useMutation({
    mutationFn: (id: number) =>
      fetchJson<{ success: boolean; message: string; duplicate?: boolean; productId?: number }>(
        `/api/arya/suggestions/${id}/approve`,
        { method: "POST", headers: { "Content-Type": "application/json" }, body: "{}" },
      ),
    onSuccess: (data) => {
      toast({
        title: data.duplicate ? "Zaten Mevcut" : "✓ Ürün Eklendi",
        description: data.message,
        duration: 4000,
      });
      queryClient.invalidateQueries({ queryKey: ["arya-suggestions-pending"] });
    },
    onError: (err: Error) => {
      toast({ title: "Hata", description: err.message, variant: "destructive" });
    },
  });

  // ── Reject mutation ───────────────────────────────────────────────
  const rejectMutation = useMutation({
    mutationFn: (id: number) =>
      fetchJson<{ success: boolean; message: string }>(
        `/api/arya/suggestions/${id}/reject`,
        { method: "POST", headers: { "Content-Type": "application/json" }, body: "{}" },
      ),
    onSuccess: (data) => {
      toast({ title: "Reddedildi", description: data.message, duration: 3000 });
      queryClient.invalidateQueries({ queryKey: ["arya-suggestions-pending"] });
    },
    onError: (err: Error) => {
      toast({ title: "Hata", description: err.message, variant: "destructive" });
    },
  });

  // ── Generic action runner ─────────────────────────────────────────
  const runAction = useCallback(
    async <T,>(key: string, fn: () => Promise<T>): Promise<T | null> => {
      setActionLoading(key);
      try {
        return await fn();
      } catch (err) {
        toast({
          title: "Hata",
          description: err instanceof Error ? err.message : "Bilinmeyen hata",
          variant: "destructive",
        });
        return null;
      } finally {
        setActionLoading(null);
      }
    },
    [toast],
  );

  // ── Scan (run automation) ─────────────────────────────────────────
  const scanProducts = useCallback(async () => {
    const data = await runAction("scan", () =>
      fetchJson<{ summary: { suggestionsGenerated: number } }>(
        "/api/arya/automation/run",
        { method: "POST", headers: { "Content-Type": "application/json" }, body: "{}" },
      ),
    );
    if (!data) return;
    const count = data.summary?.suggestionsGenerated ?? 0;
    toast({
      title: count > 0 ? `${count} yeni ürün önerildi` : "Yeni öneri yok",
      description: count > 0
        ? "Ürünler sekmesinde onayla veya reddet."
        : "Önce Tedarikçi Yükle sayfasından katalog ekleyin.",
      duration: 4000,
    });
    queryClient.invalidateQueries({ queryKey: ["arya-suggestions-pending"] });
    setTab("urunler");
  }, [runAction, toast, queryClient]);

  // ── Cleanup fake products ─────────────────────────────────────────
  const cleanupFake = useCallback(async () => {
    const data = await runAction(
      "cleanup",
      () =>
        fetchJson<{ deactivatedCount: number; deactivated: Array<{ id: number; name: string; reason: string }>; message: string }>(
          "/api/arya/cleanup-fake",
          { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ mode: "conservative" }) },
        ),
    );
    if (!data) return;
    toast({
      title: data.deactivatedCount > 0 ? `${data.deactivatedCount} sahte ürün temizlendi` : "Temizlenecek ürün yok",
      description: data.message,
      duration: 5000,
    });
    queryClient.invalidateQueries({ queryKey: ["arya-suggestions-pending"] });
  }, [runAction, toast, queryClient]);

  // ── Find real suppliers ───────────────────────────────────────────
  const findRealSuppliers = useCallback(async () => {
    setFinderLogs([]);
    const data = await runAction(
      "finder",
      () =>
        fetchJson<{ found: number; notFound: number; total: number; logs: FinderLog[]; message: string }>(
          "/api/arya/find-real-suppliers",
          { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ target: "products", limit: 10 }) },
        ),
    );
    if (!data) return;
    setFinderLogs(data.logs ?? []);
    toast({
      title: `Tedarikçi Bulucu: ${data.found}/${data.total} bulundu`,
      description: data.message,
      duration: 5000,
    });
  }, [runAction, toast]);

  const loadCampaigns = useCallback(async () => {
    const data = await runAction("campaigns", () =>
      fetchJson<{ candidates?: Array<{ id: number; name: string; reason: string; estimatedImpact?: string }> }>(
        "/api/arya/campaign-ideas",
      ),
    );
    if (!data) return;
    setCampaigns(
      (data.candidates ?? []).map((c) => ({
        id: String(c.id),
        title: c.name,
        description: c.reason,
        estimatedImpact: c.estimatedImpact,
      })),
    );
    setTab("kampanya");
  }, [runAction]);

  const loadProfit = useCallback(async () => {
    const data = await runAction("profit", () =>
      fetchJson<{ products: ProfitProduct[] }>("/api/arya/profit-analysis"),
    );
    if (!data) return;
    setProfitProducts(data.products ?? []);
    setTab("kar");
  }, [runAction]);

  const loadStock = useCallback(async () => {
    const data = await runAction("stock", () =>
      fetchJson<{ products?: StockProduct[]; critical?: StockProduct[]; outOfStock?: StockProduct[] }>(
        "/api/arya/stock-center",
      ),
    );
    if (!data) return;
    const combined = [
      ...(data.products ?? []),
      ...(data.critical ?? []),
      ...(data.outOfStock ?? []),
    ];
    const unique = combined.filter((p, i, arr) => arr.findIndex((x) => x.id === p.id) === i);
    setStockProducts(unique);
    setTab("stok");
  }, [runAction]);

  const tabs = [
    { id: "komuta" as const, label: "Komuta", icon: Zap },
    { id: "urunler" as const, label: "Ürünler", icon: Package, count: suggestionsData?.count },
    { id: "kampanya" as const, label: "Kampanya", icon: Megaphone },
    { id: "kar" as const, label: "Kâr", icon: TrendingUp },
    { id: "stok" as const, label: "Stok", icon: Warehouse },
  ];

  return (
    <div className="space-y-4 animate-in fade-in duration-300">
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 bg-primary/20 border border-primary/30 rounded-xl flex items-center justify-center">
          <BrainCircuit className="h-5 w-5 text-primary" />
        </div>
        <div className="flex-1">
          <h1 className="text-xl font-black">🧠 Arya</h1>
          <p className="text-[11px] text-muted-foreground">
            Tedarikçi bulucu, kampanya ve stok yönetim asistanı.
          </p>
        </div>
      </div>

      {/* ── Tab bar ── */}
      <div className="flex gap-1 overflow-x-auto pb-1">
        {tabs.map((t) => {
          const Icon = t.icon;
          return (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className={cn(
                "relative flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-[11px] font-semibold whitespace-nowrap",
                tab === t.id ? "bg-primary text-white" : "bg-secondary/60 text-muted-foreground",
              )}
            >
              <Icon className="h-3.5 w-3.5" />
              {t.label}
              {(t.count ?? 0) > 0 && (
                <span className="ml-0.5 bg-white/30 text-white text-[9px] font-black px-1.5 py-0.5 rounded-full">
                  {t.count}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* ── Komuta ── */}
      {tab === "komuta" && (
        <div className="space-y-3">
          <Card className="border-primary/20 bg-primary/5">
            <CardContent className="p-4 space-y-3 text-center">
              <BrainCircuit className="h-8 w-8 text-primary mx-auto" />
              <div>
                <p className="text-sm font-bold">Arya Kontrol Merkezi</p>
                <p className="text-[11px] text-muted-foreground mt-1">
                  Gerçek tedarikçi bul, sahteleri temizle, ürünleri onayla ve mağazana ekle.
                </p>
              </div>
            </CardContent>
          </Card>

          <div className="grid grid-cols-2 gap-2">
            <ActionButton
              title="Ürün Bul"
              subtitle="Katalogdan tara"
              icon={Scan}
              loading={actionLoading === "scan"}
              onClick={scanProducts}
            />
            <ActionButton
              title="Gerçek Tedarikçi Bul"
              subtitle="URL + HTTP doğrula"
              icon={Search}
              loading={actionLoading === "finder"}
              onClick={findRealSuppliers}
              highlight
            />
            <ActionButton
              title="Sahteleri Temizle"
              subtitle="Test/demo pasife al"
              icon={Trash2}
              loading={actionLoading === "cleanup"}
              onClick={cleanupFake}
            />
            <ActionButton
              title="Kampanya Seç"
              subtitle="Fırsat ürünleri"
              icon={Megaphone}
              loading={actionLoading === "campaigns"}
              onClick={loadCampaigns}
            />
            <ActionButton
              title="Kâr Analizi"
              subtitle="Marjları gör"
              icon={TrendingUp}
              loading={actionLoading === "profit"}
              onClick={loadProfit}
            />
            <ActionButton
              title="Stok Analizi"
              subtitle="Eksikleri gör"
              icon={Warehouse}
              loading={actionLoading === "stock"}
              onClick={loadStock}
            />
          </div>

          {/* Nasıl çalışır */}
          <div className="bg-secondary/30 rounded-xl p-3 text-[11px] text-muted-foreground space-y-1">
            <p className="font-semibold text-foreground">Önerilen Sıra</p>
            <p>1. <strong>Sahteleri Temizle</strong> → Test/demo ürünleri pasife al</p>
            <p>2. <strong>Gerçek Tedarikçi Bul</strong> → URL eksik ürünler için otomatik bul + doğrula</p>
            <p>3. <strong>Ürün Bul</strong> → Katalogdan yeni öneri oluştur</p>
            <p>4. <strong>Ürünler</strong> sekmesinden onayla → Ürün Yönetimi'ne ekle</p>
          </div>

          {/* Finder logs */}
          {finderLogs.length > 0 && (
            <div className="space-y-2">
              <p className="text-xs font-bold flex items-center gap-1.5">
                <Info className="h-3.5 w-3.5 text-primary" />
                Tedarikçi Bulucu Sonuçları
              </p>
              <div className="space-y-1.5 max-h-72 overflow-y-auto">
                {finderLogs.map((log, i) => (
                  <div
                    key={i}
                    className={cn(
                      "flex items-start gap-2 rounded-lg px-3 py-2 text-[11px]",
                      log.status === "accepted"
                        ? "bg-green-500/10 border border-green-500/20"
                        : "bg-red-500/10 border border-red-500/20",
                    )}
                  >
                    {log.status === "accepted" ? (
                      <CheckCircle2 className="h-3.5 w-3.5 text-green-500 mt-0.5 shrink-0" />
                    ) : (
                      <XCircle className="h-3.5 w-3.5 text-red-500 mt-0.5 shrink-0" />
                    )}
                    <div className="flex-1 min-w-0">
                      <p className="font-semibold">{log.name}</p>
                      {log.supplier && <p className="text-muted-foreground">{log.supplier}</p>}
                      {log.url && (
                        <a
                          href={log.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-primary underline truncate block"
                        >
                          {log.url.slice(0, 60)}…
                        </a>
                      )}
                      <p className="text-muted-foreground">{log.reason}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* ── Ürünler (Pending Suggestions from DB) ── */}
      {tab === "urunler" && (
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-sm font-black">Onay Bekleyen Ürünler</h2>
              <p className="text-[11px] text-muted-foreground">Onayla → Ürün Yönetimi'ne eklenir</p>
            </div>
            <Button
              size="sm"
              variant="outline"
              onClick={scanProducts}
              disabled={actionLoading === "scan"}
              className="text-xs h-8"
            >
              {actionLoading === "scan" ? (
                <Loader2 className="h-3.5 w-3.5 animate-spin" />
              ) : (
                <RefreshCw className="h-3.5 w-3.5 mr-1.5" />
              )}
              Yeniden Tara
            </Button>
          </div>

          {suggestionsLoading ? (
            <div className="flex items-center justify-center h-32 text-muted-foreground gap-2">
              <Loader2 className="h-4 w-4 animate-spin" /> Yükleniyor…
            </div>
          ) : pendingSuggestions.length === 0 ? (
            <Card className="border-dashed border-border bg-card/30">
              <CardContent className="p-8 text-center space-y-2">
                <Package className="h-8 w-8 mx-auto text-muted-foreground opacity-30" />
                <p className="text-sm font-bold">Onay bekleyen öneri yok</p>
                <p className="text-xs text-muted-foreground">
                  Komuta sekmesinden "Ürün Bul" başlatın.
                </p>
                <Button
                  size="sm"
                  onClick={scanProducts}
                  disabled={actionLoading === "scan"}
                  className="mt-2 text-xs"
                >
                  {actionLoading === "scan" ? (
                    <Loader2 className="h-3 w-3 animate-spin mr-1" />
                  ) : (
                    <Scan className="h-3 w-3 mr-1" />
                  )}
                  Tedarikçi Kataloğunu Tara
                </Button>
              </CardContent>
            </Card>
          ) : (
            pendingSuggestions.map((s) => {
              const sellPrice = parseFloat(s.estimatedSellPrice ?? "0") || 0;
              const costPrice = parseFloat(s.estimatedCostPrice ?? "0") || 0;
              const margin =
                s.profitMargin ??
                (sellPrice > 0 ? Math.round(((sellPrice - costPrice) / sellPrice) * 100) : 0);
              const netProfit = sellPrice - costPrice;
              const isApproving = approveMutation.isPending && approveMutation.variables === s.id;
              const isRejecting = rejectMutation.isPending && rejectMutation.variables === s.id;

              return (
                <Card key={s.id} className="border-border bg-card/60">
                  <CardContent className="p-3 space-y-3">
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-bold leading-tight">{s.name}</p>
                        {s.brand && <p className="text-[10px] text-muted-foreground">{s.brand}</p>}
                        {s.categoryName && (
                          <p className="text-[10px] text-muted-foreground">{s.categoryName}</p>
                        )}
                      </div>
                      {margin > 0 && (
                        <Badge
                          className={cn(
                            "text-[10px] border-0 shrink-0",
                            margin >= 35
                              ? "bg-green-500/20 text-green-400"
                              : margin >= 20
                                ? "bg-yellow-500/20 text-yellow-400"
                                : "bg-orange-500/20 text-orange-400",
                          )}
                        >
                          %{margin} kâr
                        </Badge>
                      )}
                    </div>

                    <div className="grid grid-cols-3 gap-2 text-[10px]">
                      <div className="bg-secondary/40 rounded-lg p-2 text-center">
                        <div className="text-muted-foreground">Alış</div>
                        <div className="font-black">
                          {costPrice > 0 ? formatCurrency(costPrice) : "—"}
                        </div>
                      </div>
                      <div className="bg-secondary/40 rounded-lg p-2 text-center">
                        <div className="text-muted-foreground">Satış</div>
                        <div className="font-black text-primary">
                          {sellPrice > 0 ? formatCurrency(sellPrice) : "—"}
                        </div>
                      </div>
                      <div
                        className={cn(
                          "rounded-lg p-2 text-center",
                          netProfit > 0 ? "bg-green-500/10" : "bg-secondary/40",
                        )}
                      >
                        <div className="text-muted-foreground">Net Kâr</div>
                        <div
                          className={cn(
                            "font-black",
                            netProfit > 0 ? "text-green-500" : "text-muted-foreground",
                          )}
                        >
                          {netProfit > 0 ? formatCurrency(netProfit) : "—"}
                        </div>
                      </div>
                    </div>

                    {s.supplierVerified ? (
                      <div className="flex items-center gap-2 bg-green-500/10 border border-green-500/20 rounded-lg px-2.5 py-2">
                        <ShieldCheck className="h-3.5 w-3.5 text-green-600 shrink-0" />
                        <div className="flex-1 min-w-0">
                          <span className="text-[11px] font-bold text-green-700">
                            Tedarikçi Doğrulandı
                          </span>
                          {s.supplierName && (
                            <span className="text-[11px] text-green-600 ml-1.5">
                              · {s.supplierName}
                            </span>
                          )}
                          {s.supplierShippingDays && s.supplierShippingDays > 0 && (
                            <span className="text-[11px] text-green-600 ml-1.5 inline-flex items-center gap-0.5">
                              · <Truck className="h-2.5 w-2.5" /> {s.supplierShippingDays} gün
                            </span>
                          )}
                        </div>
                        {s.supplierProductUrl && (
                          <a
                            href={s.supplierProductUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-[11px] text-green-700 hover:text-green-900 font-semibold flex items-center gap-0.5 shrink-0"
                          >
                            <ExternalLink className="h-3 w-3" />
                            Ürüne Git
                          </a>
                        )}
                      </div>
                    ) : (
                      <div className="flex items-center gap-2 bg-yellow-500/10 border border-yellow-500/20 rounded-lg px-2.5 py-2">
                        <ShieldX className="h-3.5 w-3.5 text-yellow-600 shrink-0" />
                        <span className="text-[11px] font-bold text-yellow-700">
                          Tedarikçi doğrulanmadı
                        </span>
                        {s.supplierProductUrl && (
                          <a
                            href={s.supplierProductUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="ml-auto text-[11px] text-yellow-700 flex items-center gap-0.5 shrink-0"
                          >
                            <Link2 className="h-3 w-3" /> Link
                          </a>
                        )}
                      </div>
                    )}

                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        className="flex-1 h-9 bg-green-600 hover:bg-green-700 text-white text-xs font-bold"
                        onClick={() => approveMutation.mutate(s.id)}
                        disabled={
                          isApproving ||
                          isRejecting ||
                          approveMutation.isPending ||
                          rejectMutation.isPending
                        }
                      >
                        {isApproving ? (
                          <Loader2 className="h-3.5 w-3.5 animate-spin" />
                        ) : (
                          <>
                            <CheckCircle2 className="h-3.5 w-3.5 mr-1.5" />
                            Onayla ve Ürüne Ekle
                          </>
                        )}
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        className="flex-1 h-9 text-xs border-red-300 text-red-600 hover:bg-red-50"
                        onClick={() => rejectMutation.mutate(s.id)}
                        disabled={
                          isApproving ||
                          isRejecting ||
                          approveMutation.isPending ||
                          rejectMutation.isPending
                        }
                      >
                        {isRejecting ? (
                          <Loader2 className="h-3.5 w-3.5 animate-spin" />
                        ) : (
                          <>
                            <XCircle className="h-3.5 w-3.5 mr-1.5" />
                            Reddet
                          </>
                        )}
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              );
            })
          )}
        </div>
      )}

      {/* ── Kampanya ── */}
      {tab === "kampanya" && (
        <div className="space-y-2">
          {campaigns.length === 0 ? (
            <Empty title="Kampanya önerisi yok" text="Komuta sekmesinden kampanya seç." />
          ) : (
            campaigns.map((c, i) => (
              <Card key={c.id || i} className="border-border bg-card/60">
                <CardContent className="p-3 space-y-1.5">
                  <p className="text-sm font-bold">{c.title}</p>
                  <p className="text-[11px] text-muted-foreground">
                    {c.description || "Açıklama yok"}
                  </p>
                  {c.estimatedImpact && (
                    <Badge className="text-[10px] bg-green-500/20 text-green-400 border-0">
                      {c.estimatedImpact}
                    </Badge>
                  )}
                </CardContent>
              </Card>
            ))
          )}
        </div>
      )}

      {/* ── Kâr ── */}
      {tab === "kar" && (
        <div className="space-y-2">
          {profitProducts.length === 0 ? (
            <Empty title="Kâr analizi yok" text="Komuta sekmesinden kâr analizi yap." />
          ) : (
            profitProducts.map((p) => (
              <Card key={p.id} className="border-border bg-card/60">
                <CardContent className="p-3 flex items-center justify-between gap-2">
                  <div className="min-w-0">
                    <p className="text-sm font-bold truncate">{p.name}</p>
                    <p className="text-[10px] text-muted-foreground">
                      Satış: {formatCurrency(p.price)}
                    </p>
                  </div>
                  <Badge className="text-[10px] bg-green-500/20 text-green-400 border-0">
                    %{p.margin ?? 0}
                  </Badge>
                </CardContent>
              </Card>
            ))
          )}
        </div>
      )}

      {/* ── Stok ── */}
      {tab === "stok" && (
        <div className="space-y-2">
          {stockProducts.length === 0 ? (
            <Empty title="Stok analizi yok" text="Komuta sekmesinden stok analizi yap." />
          ) : (
            stockProducts.map((p) => (
              <Card key={p.id} className="border-border bg-card/60">
                <CardContent className="p-3 flex items-center justify-between gap-2">
                  <div className="min-w-0">
                    <p className="text-sm font-bold truncate">{p.name}</p>
                    <p className="text-[10px] text-muted-foreground">
                      {p.reorderSuggestion || "Stok kontrol edildi"}
                    </p>
                  </div>
                  <Badge
                    className={cn(
                      "text-[10px] border-0",
                      p.stock <= 5
                        ? "bg-red-500/20 text-red-400"
                        : "bg-green-500/20 text-green-400",
                    )}
                  >
                    {p.stock} adet
                  </Badge>
                </CardContent>
              </Card>
            ))
          )}
        </div>
      )}
    </div>
  );
}

function ActionButton({
  title,
  subtitle,
  icon: Icon,
  loading,
  onClick,
  highlight,
}: {
  title: string;
  subtitle: string;
  icon: React.ElementType;
  loading: boolean;
  onClick: () => void;
  highlight?: boolean;
}) {
  return (
    <button
      onClick={onClick}
      disabled={loading}
      className={cn(
        "flex items-center gap-2.5 rounded-xl border px-3 py-3 text-left transition-colors disabled:opacity-50",
        highlight
          ? "border-primary/30 bg-primary/10 hover:bg-primary/20"
          : "border-border bg-card/60 hover:bg-secondary/60",
      )}
    >
      <div className={cn("shrink-0", highlight ? "text-primary" : "text-primary")}>
        {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Icon className="h-4 w-4" />}
      </div>
      <div className="min-w-0">
        <p className="text-[11px] font-bold leading-tight">{title}</p>
        <p className="text-[9px] text-muted-foreground">{subtitle}</p>
      </div>
    </button>
  );
}

function Empty({ title, text }: { title: string; text: string }) {
  return (
    <Card className="border-dashed border-border bg-card/30">
      <CardContent className="p-8 text-center space-y-2">
        <Package className="h-8 w-8 mx-auto text-muted-foreground opacity-30" />
        <p className="text-sm font-bold">{title}</p>
        <p className="text-xs text-muted-foreground">{text}</p>
      </CardContent>
    </Card>
  );
}
