import { ModulePage } from "@/components/module-page";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Archive, Download, Database, FileText } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function Backup() {
  const { toast } = useToast();
  return (
    <div className="space-y-4 animate-in fade-in duration-500">
      <div className="flex items-start gap-3">
        <div className="w-10 h-10 bg-secondary rounded-xl flex items-center justify-center shrink-0 border border-border">
          <Archive className="h-5 w-5 text-muted-foreground" />
        </div>
        <div>
          <h1 className="text-xl font-black">💾 Yedekleme & Dışa Aktarma</h1>
          <p className="text-xs text-muted-foreground mt-0.5">Veritabanı yedeği ve veri dışa aktarma</p>
        </div>
      </div>

      <div className="grid gap-3 sm:grid-cols-2">
        {[
          { icon: Database, label: "Veritabanı Yedeği", desc: "Tüm veriyi SQL formatında indir", color: "text-blue-400", action: "db" },
          { icon: FileText, label: "Ürünleri CSV İndir", desc: "Tüm ürün listesini Excel/CSV olarak indir", color: "text-green-400", action: "products" },
          { icon: FileText, label: "Siparişleri CSV İndir", desc: "Tüm sipariş verilerini CSV olarak indir", color: "text-yellow-400", action: "orders" },
          { icon: FileText, label: "Müşterileri CSV İndir", desc: "Müşteri listesini CSV olarak indir", color: "text-purple-400", action: "customers" },
        ].map(item => {
          const Icon = item.icon;
          return (
            <Card key={item.action} className="border-border bg-card/60 cursor-pointer hover:border-primary/30 transition-all" onClick={() => toast({ title: "İndirme başlatıldı", description: `${item.label} hazırlanıyor...` })}>
              <CardContent className="p-4 flex items-center gap-3">
                <div className="w-10 h-10 bg-secondary rounded-lg flex items-center justify-center shrink-0">
                  <Icon className={`h-5 w-5 ${item.color}`} />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="font-semibold text-sm">{item.label}</div>
                  <p className="text-xs text-muted-foreground">{item.desc}</p>
                </div>
                <Download className="h-4 w-4 text-muted-foreground shrink-0" />
              </CardContent>
            </Card>
          );
        })}
      </div>

      <Card className="border-border bg-card/60">
        <CardContent className="p-4">
          <div className="text-xs text-muted-foreground space-y-1">
            <p className="font-semibold text-foreground text-sm mb-2">Son Yedekler</p>
            {["2026-06-07 03:00 — Otomatik yedek — 2.4 MB", "2026-06-06 03:00 — Otomatik yedek — 2.3 MB", "2026-06-05 03:00 — Otomatik yedek — 2.2 MB"].map(b => (
              <div key={b} className="flex items-center justify-between py-1 border-b border-border/40 last:border-0">
                <span>{b}</span>
                <Button variant="ghost" size="sm" className="h-6 text-[10px] gap-1"><Download className="h-3 w-3" /> İndir</Button>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
