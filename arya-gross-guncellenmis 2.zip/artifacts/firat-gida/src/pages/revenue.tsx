import { useState } from "react";
import { useGetRevenueAnalysis, useGetViralScore, useListProducts } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { formatCurrency } from "@/lib/format";
import { TrendingUp, TrendingDown, DollarSign, AlertCircle, Rocket, Target, Activity } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";

export default function Revenue() {
  const [selectedProductForViral, setSelectedProductForViral] = useState<string>("");
  const { data: analysis, isLoading: isLoadingAnalysis } = useGetRevenueAnalysis();
  const { data: products } = useListProducts();
  
  // Conditionally fetch viral score only if a product is selected
  const { data: viralScore, isLoading: isLoadingViral } = useGetViralScore(
    Number(selectedProductForViral),
    { query: { enabled: !!selectedProductForViral, queryKey: ["viralScore", selectedProductForViral] } }
  );

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div>
        <h1 className="text-3xl font-bold tracking-tighter uppercase text-foreground flex items-center gap-3">
          <TrendingUp className="h-8 w-8 text-primary" />
          Gelir Optimizasyonu
        </h1>
        <p className="text-muted-foreground">Veriye dayalı kâr maksimizasyonu ve performans analizi.</p>
      </div>

      {isLoadingAnalysis ? (
        <div className="grid gap-6 md:grid-cols-3">
          {[1,2,3].map(i => <Card key={i} className="h-40 bg-secondary/30 animate-pulse border-border" />)}
        </div>
      ) : analysis && (
        <>
          <div className="grid gap-6 md:grid-cols-3">
            <Card className="border-primary/30 bg-primary/5">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium uppercase tracking-wider text-primary">Kaçırılan Potansiyel</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-4xl font-bold text-primary">{formatCurrency(analysis.totalPotentialRevenue)}</div>
                <p className="text-xs text-muted-foreground mt-2">Optimizasyon önerileri uygulanırsa beklenen aylık artış</p>
              </CardContent>
            </Card>

            <Card className="border-border bg-card/50">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium uppercase tracking-wider text-muted-foreground flex justify-between">
                  Top Performans
                  <Rocket className="h-4 w-4 text-accent" />
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3 mt-2">
                  {analysis.topPerformers.slice(0, 3).map((p, i) => (
                    <div key={p.productId} className="flex justify-between items-center text-sm">
                      <span className="font-medium truncate max-w-[150px]"><span className="text-accent mr-1">#{i+1}</span> {p.name}</span>
                      <span className="font-mono font-bold text-accent">{formatCurrency(p.revenue)}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card className="border-border bg-card/50">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium uppercase tracking-wider text-muted-foreground flex justify-between">
                  Kritik Uyarılar
                  <TrendingDown className="h-4 w-4 text-destructive" />
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3 mt-2">
                  {analysis.underperformers.slice(0, 3).map((p) => (
                    <div key={p.productId} className="flex justify-between items-center text-sm">
                      <span className="font-medium truncate max-w-[150px]">{p.name}</span>
                      <Badge variant="outline" className="text-[10px] text-destructive border-destructive/30">Müdahale Et</Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="grid gap-6 lg:grid-cols-2">
            <Card className="border-border bg-card/50">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Target className="h-5 w-5 text-primary" />
                  Fiyat Optimizasyon Fırsatları
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {analysis.priceOptimizations.map((opt, i) => (
                    <div key={i} className="p-4 border border-border rounded-lg bg-secondary/20 relative overflow-hidden group">
                      <div className="absolute left-0 top-0 bottom-0 w-1 bg-primary"></div>
                      <div className="flex justify-between items-start mb-2">
                        <h4 className="font-bold">{opt.name}</h4>
                      </div>
                      <div className="flex items-center gap-4 text-sm font-mono mb-3">
                        <span className="text-muted-foreground line-through">{formatCurrency(opt.currentPrice)}</span>
                        <TrendingUp className="h-4 w-4 text-primary" />
                        <span className="font-bold text-primary text-lg">{formatCurrency(opt.suggestedPrice)}</span>
                      </div>
                      <p className="text-sm text-muted-foreground">{opt.reason}</p>
                    </div>
                  ))}
                  {analysis.priceOptimizations.length === 0 && (
                    <div className="text-center py-8 text-muted-foreground">Şu an için fiyat optimizasyon önerisi yok.</div>
                  )}
                </div>
              </CardContent>
            </Card>

            <div className="space-y-6">
              <Card className="border-border bg-card/50">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Activity className="h-5 w-5 text-accent" />
                    Viral Skor Analizi
                  </CardTitle>
                  <CardDescription>Bir ürünün sosyal medyada patlama potansiyelini ölçün.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <Select value={selectedProductForViral} onValueChange={setSelectedProductForViral}>
                    <SelectTrigger className="bg-secondary/50">
                      <SelectValue placeholder="Analiz edilecek ürün seçin..." />
                    </SelectTrigger>
                    <SelectContent>
                      {products?.map(p => (
                        <SelectItem key={p.id} value={p.id.toString()}>{p.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>

                  {isLoadingViral ? (
                    <div className="py-8 text-center text-muted-foreground animate-pulse">Analiz ediliyor...</div>
                  ) : viralScore && (
                    <div className="mt-4 space-y-6">
                      <div className="flex items-center justify-center p-6 border border-border rounded-lg bg-secondary/10">
                        <div className="text-center flex flex-col items-center">
                          <span className="text-xs uppercase tracking-widest text-muted-foreground mb-2">Genel Skor</span>
                          <div className={`text-6xl font-black ${
                            viralScore.score >= 80 ? 'text-accent' : 
                            viralScore.score >= 50 ? 'text-yellow-500' : 'text-destructive'
                          }`}>
                            {viralScore.score}
                          </div>
                          <Badge className="mt-2 uppercase" variant={viralScore.score >= 80 ? 'default' : 'secondary'}>
                            {viralScore.level}
                          </Badge>
                        </div>
                      </div>

                      <div className="space-y-3">
                        <h4 className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Etki Faktörleri</h4>
                        {viralScore.factors.map((factor, i) => (
                          <div key={i} className="flex items-center gap-2 text-sm bg-secondary/30 p-2 rounded">
                            <Zap className="h-4 w-4 text-accent flex-shrink-0" />
                            <span>{factor}</span>
                          </div>
                        ))}
                      </div>
                      
                      <div className="space-y-3">
                        <h4 className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Nasıl Artırılır?</h4>
                        {viralScore.tips.map((tip, i) => (
                          <div key={i} className="flex gap-2 text-sm text-muted-foreground border-l-2 border-primary/50 pl-3 py-1">
                            {tip}
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </div>
        </>
      )}
    </div>
  );
}

// Temporary Zap icon if not imported above
function Zap(props: any) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2" />
    </svg>
  )
}
