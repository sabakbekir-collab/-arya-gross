import { useState } from "react";
import { useListProducts, useGenerateAd, useListAds, getListAdsQueryKey } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Megaphone, Play, Video, RefreshCw, Smartphone, Copy } from "lucide-react";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { formatDate } from "@/lib/format";

export default function AdsGenerator() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedProduct, setSelectedProduct] = useState<string>("");
  const [platform, setPlatform] = useState<string>("tiktok");

  const { data: products } = useListProducts();
  const { data: ads, isLoading: isLoadingAds } = useListAds();

  const generateAd = useGenerateAd({
    mutation: {
      onSuccess: () => {
        toast({ title: "Reklam Hazır", description: "Viral içerik başarıyla oluşturuldu." });
        queryClient.invalidateQueries({ queryKey: getListAdsQueryKey() });
      }
    }
  });

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({ title: "Kopyalandı", description: "Metin panoya kopyalandı." });
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <div>
        <h1 className="text-3xl font-bold tracking-tighter uppercase text-foreground flex items-center gap-3">
          <Megaphone className="h-8 w-8 text-[#ff0050]" />
          Viral Reklam Üretici
        </h1>
        <p className="text-muted-foreground">TikTok ve Instagram Reels için yüksek dönüşümlü viral senaryolar.</p>
      </div>

      <div className="grid gap-6 lg:grid-cols-12">
        <Card className="lg:col-span-5 border-border bg-card/50 backdrop-blur h-fit">
          <CardHeader>
            <CardTitle>Yeni Kampanya</CardTitle>
            <CardDescription>Ürün seçin, platform belirleyin, viral senaryoyu kapın.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium uppercase tracking-wider text-muted-foreground">Hedef Ürün</label>
              <Select value={selectedProduct} onValueChange={setSelectedProduct}>
                <SelectTrigger className="bg-secondary/50">
                  <SelectValue placeholder="Reklamı yapılacak ürün..." />
                </SelectTrigger>
                <SelectContent>
                  {products?.map(p => (
                    <SelectItem key={p.id} value={p.id.toString()}>{p.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium uppercase tracking-wider text-muted-foreground">Platform</label>
              <div className="grid grid-cols-2 gap-2">
                <Button 
                  type="button"
                  variant="outline" 
                  className={`h-12 ${platform === 'tiktok' ? 'border-[#ff0050] text-[#ff0050] bg-[#ff0050]/10' : 'text-muted-foreground'}`}
                  onClick={() => setPlatform('tiktok')}
                >
                  <Smartphone className="mr-2 h-4 w-4" /> TikTok
                </Button>
                <Button 
                  type="button"
                  variant="outline" 
                  className={`h-12 ${platform === 'instagram' ? 'border-[#E1306C] text-[#E1306C] bg-[#E1306C]/10' : 'text-muted-foreground'}`}
                  onClick={() => setPlatform('instagram')}
                >
                  <Video className="mr-2 h-4 w-4" /> Instagram Reels
                </Button>
              </div>
            </div>

            <Button 
              className={`w-full font-bold h-12 mt-4 tracking-widest uppercase ${platform === 'tiktok' ? 'bg-[#ff0050] hover:bg-[#ff0050]/90 text-white' : 'bg-[#E1306C] hover:bg-[#E1306C]/90 text-white'}`}
              disabled={!selectedProduct || generateAd.isPending}
              onClick={() => generateAd.mutate({ data: { productId: Number(selectedProduct), platform } })}
            >
              {generateAd.isPending ? <RefreshCw className="mr-2 h-5 w-5 animate-spin" /> : <Play className="mr-2 h-5 w-5" />}
              {generateAd.isPending ? "SENARYO YAZILIYOR..." : "VİRAL SENARYO ÜRET"}
            </Button>
          </CardContent>
        </Card>

        <div className="lg:col-span-7 space-y-6">
          {generateAd.data && (
            <Card className={`border-2 animate-in zoom-in-95 duration-300 bg-card ${generateAd.data.platform === 'tiktok' ? 'border-[#ff0050]/50' : 'border-[#E1306C]/50'}`}>
              <CardHeader className="pb-3 border-b border-border">
                <div className="flex justify-between items-start">
                  <div>
                    <Badge className="mb-2 uppercase tracking-widest">{generateAd.data.platform}</Badge>
                    <CardTitle className="text-xl">{generateAd.data.emotionalTitle}</CardTitle>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="pt-4 space-y-6">
                <div>
                  <h4 className="text-xs font-bold uppercase tracking-wider text-muted-foreground flex items-center gap-2 mb-2">
                    <span className="w-2 h-2 rounded-full bg-red-500"></span> Hook (İlk 3 Saniye)
                  </h4>
                  <p className="font-bold text-lg leading-tight p-3 bg-secondary/50 rounded-md border-l-4 border-red-500">{generateAd.data.hook}</p>
                </div>
                
                <div>
                  <h4 className="text-xs font-bold uppercase tracking-wider text-muted-foreground mb-2">Video Fikri</h4>
                  <p className="text-sm text-muted-foreground italic">{generateAd.data.videoIdea}</p>
                </div>

                <div>
                  <h4 className="text-xs font-bold uppercase tracking-wider text-muted-foreground mb-2 flex justify-between">
                    Senaryo
                    <Button variant="ghost" size="sm" className="h-5 px-2 text-xs" onClick={() => copyToClipboard(generateAd.data.scenario)}>Kopyala</Button>
                  </h4>
                  <div className="p-3 bg-secondary/30 rounded-md font-mono text-sm whitespace-pre-wrap text-foreground/80">
                    {generateAd.data.scenario}
                  </div>
                </div>

                <div>
                  <h4 className="text-xs font-bold uppercase tracking-wider text-muted-foreground mb-2">Açıklama & Etiketler</h4>
                  <div className="p-3 bg-secondary/30 rounded-md text-sm">
                    <p className="mb-2">{generateAd.data.adText}</p>
                    <p className="text-accent">{generateAd.data.hashtags.map(h => `#${h}`).join(' ')}</p>
                  </div>
                </div>

                <div className="text-center pt-2">
                  <Badge variant="outline" className="px-4 py-2 text-sm font-bold border-primary text-primary">CTA: {generateAd.data.cta}</Badge>
                </div>
              </CardContent>
            </Card>
          )}

          <div className="space-y-4">
            <h3 className="font-bold uppercase tracking-widest text-sm text-muted-foreground">Geçmiş Senaryolar</h3>
            {isLoadingAds ? (
              <div className="text-center py-4 text-muted-foreground">Yükleniyor...</div>
            ) : !ads || ads.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground border border-dashed border-border rounded-lg">Henüz reklam üretilmedi</div>
            ) : (
              <div className="grid gap-3">
                {ads.slice(0, 5).map(ad => (
                  <div key={ad.id} className="p-4 border border-border rounded-lg bg-card/30 hover:bg-secondary/20 transition-colors cursor-pointer group flex justify-between items-center">
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <Badge variant="outline" className="text-[10px] uppercase">
                          {ad.platform === 'tiktok' ? <Smartphone className="h-3 w-3 mr-1 inline text-[#ff0050]" /> : <Video className="h-3 w-3 mr-1 inline text-[#E1306C]" />}
                          {ad.platform}
                        </Badge>
                        <span className="text-xs text-muted-foreground">{formatDate(ad.createdAt)}</span>
                      </div>
                      <h4 className="font-bold text-sm line-clamp-1">{ad.emotionalTitle || ad.hook}</h4>
                      <p className="text-xs text-muted-foreground mt-1">{ad.productName}</p>
                    </div>
                    <Button variant="ghost" size="icon" className="opacity-0 group-hover:opacity-100" onClick={() => copyToClipboard(ad.scenario || ad.hook)}>
                      <Copy className="h-4 w-4" />
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
