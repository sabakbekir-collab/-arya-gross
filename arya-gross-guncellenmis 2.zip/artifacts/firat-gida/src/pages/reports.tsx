import { useListOrders } from "@workspace/api-client-react";
import { formatCurrency, formatDate } from "@/lib/format";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { FileText, Download, TrendingUp, ShoppingBag, Users, Package } from "lucide-react";
import { useMemo } from "react";

export default function Reports() {
  const { data: orders } = useListOrders();

  const stats = useMemo(() => {
    const all = orders || [];
    const delivered = all.filter(o => o.status === "teslim edildi");
    const totalRevenue = delivered.reduce((s, o) => s + Number(o.total), 0);
    const avgOrder = delivered.length > 0 ? totalRevenue / delivered.length : 0;

    const byStatus = {
      beklemede:         all.filter(o => o.status === "beklemede").length,
      "kabul-edildi":    all.filter(o => o.status === "kabul-edildi").length,
      hazirlaniyor:      all.filter(o => o.status === "hazirlaniyor").length,
      kargoda:           all.filter(o => o.status === "kargoda").length,
      "teslim edildi":   delivered.length,
      iptal:             all.filter(o => o.status === "iptal").length,
    };

    const uniqueCustomers = new Set(all.map(o => o.customerEmail || o.customerName)).size;
    return { totalRevenue, avgOrder, byStatus, delivered: delivered.length, total: all.length, uniqueCustomers };
  }, [orders]);

  return (
    <div className="space-y-4 animate-in fade-in duration-500">
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-start gap-3">
          <div className="w-10 h-10 bg-blue-500/20 rounded-xl flex items-center justify-center shrink-0 border border-blue-500/30">
            <FileText className="h-5 w-5 text-blue-400" />
          </div>
          <div>
            <h1 className="text-xl font-black">📊 Raporlar</h1>
            <p className="text-xs text-muted-foreground mt-0.5">Satış ve performans raporları</p>
          </div>
        </div>
        <Button size="sm" variant="outline" className="gap-1.5 h-8 text-xs shrink-0">
          <Download className="h-3.5 w-3.5" /> Dışa Aktar
        </Button>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {[
          { label: "Toplam Ciro", val: formatCurrency(stats.totalRevenue), icon: TrendingUp, color: "text-primary" },
          { label: "Sipariş", val: stats.total, icon: ShoppingBag, color: "text-blue-400" },
          { label: "Müşteri", val: stats.uniqueCustomers, icon: Users, color: "text-cyan-400" },
          { label: "Ort. Sipariş", val: formatCurrency(stats.avgOrder), icon: Package, color: "text-accent" },
        ].map(s => (
          <Card key={s.label} className="border-border bg-card/60">
            <CardContent className="p-3">
              <div className="flex items-center justify-between mb-1">
                <span className="text-[10px] text-muted-foreground uppercase tracking-wider">{s.label}</span>
                <s.icon className={`h-3.5 w-3.5 ${s.color}`} />
              </div>
              <div className={`text-xl font-black ${s.color}`}>{s.val}</div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card className="border-border bg-card/60">
        <CardHeader className="py-3 px-4 pb-2">
          <CardTitle className="text-sm">Sipariş Durumu Dağılımı</CardTitle>
        </CardHeader>
        <CardContent className="px-4 pb-4 space-y-2">
          {[
            { key: "teslim edildi", label: "Teslim Edildi", color: "bg-green-500" },
            { key: "beklemede", label: "Beklemede", color: "bg-yellow-500" },
            { key: "hazirlaniyor", label: "Hazırlanıyor", color: "bg-blue-500" },
            { key: "kargoda", label: "Kargoda", color: "bg-purple-500" },
            { key: "iptal", label: "İptal", color: "bg-red-500" },
          ].map(s => {
            const count = stats.byStatus[s.key as keyof typeof stats.byStatus] || 0;
            const pct = stats.total > 0 ? Math.round((count / stats.total) * 100) : 0;
            return (
              <div key={s.key}>
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-muted-foreground">{s.label}</span>
                  <span className="font-mono font-bold">{count} ({pct}%)</span>
                </div>
                <div className="h-2 bg-secondary rounded-full overflow-hidden">
                  <div className={`h-full ${s.color} rounded-full transition-all duration-700`} style={{ width: `${pct}%` }} />
                </div>
              </div>
            );
          })}
        </CardContent>
      </Card>
    </div>
  );
}
