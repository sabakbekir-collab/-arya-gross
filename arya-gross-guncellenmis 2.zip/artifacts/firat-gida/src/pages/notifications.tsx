import { useListOrders, useListProducts } from "@workspace/api-client-react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Bell, Package, ShoppingBag, AlertTriangle, CheckCircle2, Clock } from "lucide-react";
import { useMemo } from "react";
import { formatCurrency, formatDate } from "@/lib/format";

interface Notification {
  id: string;
  type: "order" | "stock" | "done";
  icon: React.ElementType;
  color: string;
  bg: string;
  title: string;
  desc: string;
  time: string;
  read: boolean;
}

export default function Notifications() {
  const { data: orders } = useListOrders();
  const { data: products } = useListProducts();

  const notifications = useMemo<Notification[]>(() => {
    const list: Notification[] = [];

    const now = new Date();
    const oneDayAgo = new Date(now.getTime() - 24 * 60 * 60 * 1000);

    for (const o of (orders || [])) {
      const created = new Date(o.createdAt);
      const isRecent = created > oneDayAgo;
      const diffMin = Math.round((now.getTime() - created.getTime()) / 60000);
      const timeLabel = diffMin < 60
        ? `${diffMin} dk önce`
        : diffMin < 1440
          ? `${Math.round(diffMin / 60)} saat önce`
          : formatDate(o.createdAt);

      if (o.status === "beklemede") {
        list.push({
          id: `order-new-${o.id}`,
          type: "order",
          icon: ShoppingBag,
          color: "text-yellow-400",
          bg: "bg-yellow-500/20",
          title: "Yeni sipariş bekliyor",
          desc: `#${o.id} — ${o.customerName || "Müşteri"} — ${formatCurrency(o.total)}`,
          time: timeLabel,
          read: !isRecent,
        });
      } else if (o.status === "teslim edildi") {
        list.push({
          id: `order-done-${o.id}`,
          type: "done",
          icon: CheckCircle2,
          color: "text-green-400",
          bg: "bg-green-500/20",
          title: "Sipariş tamamlandı",
          desc: `#${o.id} teslim edildi — ${formatCurrency(o.total)}`,
          time: timeLabel,
          read: true,
        });
      }
    }

    for (const p of (products || [])) {
      if (p.stock < 5) {
        list.push({
          id: `stock-critical-${p.id}`,
          type: "stock",
          icon: AlertTriangle,
          color: "text-red-400",
          bg: "bg-red-500/20",
          title: "Kritik stok uyarısı",
          desc: `${p.name} — ${p.stock} adet kaldı`,
          time: "Şimdi",
          read: false,
        });
      } else if (p.stock < 15) {
        list.push({
          id: `stock-low-${p.id}`,
          type: "stock",
          icon: AlertTriangle,
          color: "text-yellow-400",
          bg: "bg-yellow-500/20",
          title: "Düşük stok uyarısı",
          desc: `${p.name} — ${p.stock} adet`,
          time: "Şimdi",
          read: true,
        });
      }
    }

    list.sort((a, b) => (a.read ? 1 : 0) - (b.read ? 1 : 0));
    return list;
  }, [orders, products]);

  const unread = notifications.filter(n => !n.read).length;

  return (
    <div className="space-y-4 animate-in fade-in duration-500">
      <div className="flex items-start gap-3">
        <div className="w-10 h-10 bg-yellow-500/20 rounded-xl flex items-center justify-center shrink-0 border border-yellow-500/30">
          <Bell className="h-5 w-5 text-yellow-400" />
        </div>
        <div>
          <h1 className="text-xl font-black flex items-center gap-2">
            🔔 Bildirim Merkezi
            {unread > 0 && <Badge className="bg-primary text-white text-xs">{unread}</Badge>}
          </h1>
          <p className="text-xs text-muted-foreground mt-0.5">Gerçek zamanlı sipariş ve stok bildirimleri</p>
        </div>
      </div>

      {notifications.length === 0 ? (
        <Card className="border-dashed border-border bg-card/30">
          <div className="py-10 text-center space-y-2">
            <Clock className="h-8 w-8 text-muted-foreground mx-auto" />
            <p className="text-sm font-semibold">Bildirim yok</p>
            <p className="text-xs text-muted-foreground">Yeni sipariş veya stok uyarısı oluştuğunda burada görünecek.</p>
          </div>
        </Card>
      ) : (
        <div className="space-y-2">
          {notifications.map(n => {
            const Icon = n.icon;
            return (
              <Card key={n.id} className={`border transition-all ${!n.read ? "border-primary/20 bg-primary/5" : "border-border bg-card/60 opacity-75"}`}>
                <CardContent className="p-3 flex items-start gap-3">
                  <div className={`w-8 h-8 ${n.bg} rounded-lg flex items-center justify-center shrink-0 mt-0.5`}>
                    <Icon className={`h-4 w-4 ${n.color}`} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-semibold">{n.title}</span>
                      {!n.read && <Badge className="bg-primary/20 text-primary border-primary/30 text-[9px]">Yeni</Badge>}
                    </div>
                    <p className="text-xs text-muted-foreground mt-0.5 truncate">{n.desc}</p>
                  </div>
                  <span className="text-[10px] text-muted-foreground shrink-0 whitespace-nowrap">{n.time}</span>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}
