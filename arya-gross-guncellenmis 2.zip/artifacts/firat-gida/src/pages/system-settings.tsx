import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Settings, Save, Eye, EyeOff, CheckCircle2, XCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface Setting { key: string; label: string; value: string; type: "text" | "password" | "select"; required: boolean; group: string; status: "ok" | "missing" | "demo"; }

const SETTINGS: Setting[] = [
  { key: "DATABASE_URL", label: "Veritabanı URL", value: "postgresql://***", type: "password", required: true, group: "Veritabanı", status: "ok" },
  { key: "AI_API_KEY", label: "AI API Anahtarı", value: "", type: "password", required: false, group: "AI", status: "missing" },
  { key: "AI_PROVIDER", label: "AI Sağlayıcı", value: "openai", type: "select", required: false, group: "AI", status: "demo" },
  { key: "WHATSAPP_PHONE", label: "WhatsApp Telefon", value: "", type: "text", required: false, group: "WhatsApp", status: "missing" },
  { key: "PAYMENT_PROVIDER", label: "Ödeme Sağlayıcı", value: "", type: "text", required: false, group: "Ödeme", status: "missing" },
  { key: "PAYTR_MERCHANT_ID", label: "PayTR Merchant ID", value: "", type: "text", required: false, group: "Ödeme", status: "missing" },
  { key: "JWT_SECRET", label: "JWT Gizli Anahtar", value: "***", type: "password", required: true, group: "Güvenlik", status: "ok" },
  { key: "ADMIN_EMAIL", label: "Admin E-posta", value: "", type: "text", required: true, group: "Güvenlik", status: "missing" },
];

export default function SystemSettings() {
  const { toast } = useToast();
  const [values, setValues] = useState<Record<string, string>>(Object.fromEntries(SETTINGS.map(s => [s.key, s.value])));
  const [shown, setShown] = useState<Record<string, boolean>>({});

  const groups = [...new Set(SETTINGS.map(s => s.group))];

  return (
    <div className="space-y-4 animate-in fade-in duration-500">
      <div className="flex items-start gap-3">
        <div className="w-10 h-10 bg-secondary rounded-xl flex items-center justify-center shrink-0 border border-border">
          <Settings className="h-5 w-5 text-muted-foreground" />
        </div>
        <div>
          <h1 className="text-xl font-black">⚙️ Sistem Ayarları</h1>
          <p className="text-xs text-muted-foreground mt-0.5">Ortam değişkenleri ve sistem yapılandırması</p>
        </div>
      </div>

      <Card className="border-yellow-500/20 bg-yellow-500/5">
        <CardContent className="p-3">
          <p className="text-xs text-yellow-300">⚠️ Gerçek API anahtarları için Replit <strong>Secrets</strong> bölümünü veya sunucuda <strong>.env</strong> dosyasını kullanın. Bu ekranda görüntülenenler demo değerlerdir.</p>
        </CardContent>
      </Card>

      <div className="grid grid-cols-3 gap-3">
        {[
          { label: "Aktif", val: SETTINGS.filter(s => s.status === "ok").length, color: "text-green-400" },
          { label: "Eksik", val: SETTINGS.filter(s => s.status === "missing").length, color: "text-red-400" },
          { label: "Demo", val: SETTINGS.filter(s => s.status === "demo").length, color: "text-yellow-400" },
        ].map(s => (
          <Card key={s.label} className="border-border bg-card/60">
            <CardContent className="p-3 text-center">
              <div className={`text-2xl font-black ${s.color}`}>{s.val}</div>
              <div className="text-[10px] text-muted-foreground">{s.label}</div>
            </CardContent>
          </Card>
        ))}
      </div>

      {groups.map(group => (
        <Card key={group} className="border-border bg-card/60">
          <CardHeader className="py-3 px-4 pb-2">
            <CardTitle className="text-sm">{group}</CardTitle>
          </CardHeader>
          <CardContent className="px-4 pb-4 space-y-3">
            {SETTINGS.filter(s => s.group === group).map(setting => (
              <div key={setting.key} className="space-y-1">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-medium text-muted-foreground">{setting.label}</label>
                  <Badge className={`text-[9px] ${setting.status === "ok" ? "bg-green-500/20 text-green-400 border-green-500/30" : setting.status === "demo" ? "bg-yellow-500/20 text-yellow-400 border-yellow-500/30" : "bg-red-500/20 text-red-400 border-red-500/30"}`}>
                    {setting.status === "ok" ? <><CheckCircle2 className="h-2.5 w-2.5 mr-0.5" />Aktif</> : setting.status === "demo" ? "Demo" : <><XCircle className="h-2.5 w-2.5 mr-0.5" />Eksik</>}
                  </Badge>
                </div>
                <div className="relative">
                  <Input
                    type={setting.type === "password" && !shown[setting.key] ? "password" : "text"}
                    value={values[setting.key] || ""}
                    onChange={e => setValues(v => ({ ...v, [setting.key]: e.target.value }))}
                    placeholder={setting.status === "missing" ? "Tanımlanmadı" : ""}
                    className="bg-secondary/50 h-8 text-xs pr-8"
                  />
                  {setting.type === "password" && (
                    <button className="absolute right-2 top-1.5 text-muted-foreground" onClick={() => setShown(s => ({ ...s, [setting.key]: !s[setting.key] }))}>
                      {shown[setting.key] ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </button>
                  )}
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      ))}

      <Button onClick={() => toast({ title: "Ayarlar kaydedildi", description: "Gerçek ortamda .env dosyasını güncelleyin." })} className="w-full gap-2 bg-primary hover:bg-primary/90 text-white">
        <Save className="h-4 w-4" /> Ayarları Kaydet
      </Button>
    </div>
  );
}
