import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { UserCog, Plus, Shield, Eye, Edit2, Trash2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const ROLES = [
  { key: "admin", label: "Admin", color: "bg-primary/20 text-primary border-primary/30", perms: ["Tüm yetkiler"] },
  { key: "personel", label: "Personel", color: "bg-blue-500/20 text-blue-400 border-blue-500/30", perms: ["Siparişler", "Ürünler", "Stok"] },
  { key: "muhasebe", label: "Muhasebe", color: "bg-green-500/20 text-green-400 border-green-500/30", perms: ["Muhasebe", "Raporlar"] },
  { key: "depo", label: "Depo", color: "bg-cyan-500/20 text-cyan-400 border-cyan-500/30", perms: ["Stok", "Ürünler"] },
  { key: "izleyici", label: "Sadece İzleme", color: "bg-secondary text-muted-foreground border-border", perms: ["Dashboard görüntüle"] },
];

interface User { id: string; name: string; email: string; role: string; active: boolean; lastLogin: string; }

const INITIAL_USERS: User[] = [
  { id: "u1", name: "Admin Kullanıcı", email: "admin@aryagross.com", role: "admin", active: true, lastLogin: "2026-06-07" },
  { id: "u2", name: "Satış Personeli", email: "satis@aryagross.com", role: "personel", active: true, lastLogin: "2026-06-06" },
  { id: "u3", name: "Depo Görevlisi", email: "depo@aryagross.com", role: "depo", active: false, lastLogin: "2026-06-01" },
];

export default function Users() {
  const { toast } = useToast();
  const [users, setUsers] = useState<User[]>(INITIAL_USERS);

  return (
    <div className="space-y-4 animate-in fade-in duration-500">
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-start gap-3">
          <div className="w-10 h-10 bg-primary/20 rounded-xl flex items-center justify-center shrink-0 border border-primary/30">
            <UserCog className="h-5 w-5 text-primary" />
          </div>
          <div>
            <h1 className="text-xl font-black">👤 Kullanıcı & Yetki</h1>
            <p className="text-xs text-muted-foreground mt-0.5">Admin kullanıcıları ve rol bazlı yetki yönetimi</p>
          </div>
        </div>
        <Button size="sm" className="bg-primary hover:bg-primary/90 text-white gap-1.5 shrink-0" onClick={() => toast({ title: "Yakında", description: "Kullanıcı ekleme backend entegrasyonu gerekiyor." })}>
          <Plus className="h-4 w-4" /> Kullanıcı Ekle
        </Button>
      </div>

      {/* Roles */}
      <div>
        <h2 className="text-[10px] font-bold uppercase tracking-widest text-muted-foreground mb-3">Roller & Yetkiler</h2>
        <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
          {ROLES.map(role => (
            <Card key={role.key} className="border-border bg-card/60">
              <CardContent className="p-3">
                <div className="flex items-center gap-2 mb-2">
                  <Shield className="h-4 w-4 text-muted-foreground" />
                  <Badge className={`text-[10px] ${role.color}`}>{role.label}</Badge>
                </div>
                <div className="space-y-0.5">
                  {role.perms.map(p => <div key={p} className="text-[11px] text-muted-foreground">• {p}</div>)}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Users */}
      <div>
        <h2 className="text-[10px] font-bold uppercase tracking-widest text-muted-foreground mb-3">Kullanıcılar</h2>
        <div className="space-y-2">
          {users.map(u => {
            const role = ROLES.find(r => r.key === u.role);
            return (
              <Card key={u.id} className={`border transition-all ${u.active ? "border-border bg-card/60" : "border-border bg-card/30 opacity-60"}`}>
                <CardContent className="p-3">
                  <div className="flex items-center justify-between gap-3">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-semibold text-sm">{u.name}</span>
                        <Badge className={`text-[9px] ${role?.color || ""}`}>{role?.label}</Badge>
                        {!u.active && <Badge className="bg-secondary text-muted-foreground text-[9px]">Pasif</Badge>}
                      </div>
                      <div className="text-[11px] text-muted-foreground mt-0.5">{u.email}</div>
                      <div className="text-[10px] text-muted-foreground">Son giriş: {u.lastLogin}</div>
                    </div>
                    <div className="flex gap-1 shrink-0">
                      <Button variant="ghost" size="icon" className="h-7 w-7 text-muted-foreground hover:text-foreground"><Eye className="h-3.5 w-3.5" /></Button>
                      <Button variant="ghost" size="icon" className="h-7 w-7 text-muted-foreground hover:text-foreground"><Edit2 className="h-3.5 w-3.5" /></Button>
                      <Button variant="ghost" size="icon" className="h-7 w-7 text-muted-foreground hover:text-destructive" onClick={() => toast({ title: "Silme onayı gerekiyor" })}><Trash2 className="h-3.5 w-3.5" /></Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>
    </div>
  );
}
