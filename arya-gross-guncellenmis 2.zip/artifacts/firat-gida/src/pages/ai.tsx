import { useState } from "react";
import { useAiGenerateProduct, useAiOptimizePrice, useListProducts } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { formatCurrency } from "@/lib/format";
import { BrainCircuit, Sparkles, TrendingUp, RefreshCw, Zap } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";

export default function AiEngine() {
  const { toast } = useToast();
  const [idea, setIdea] = useState("");
  const [selectedProduct, setSelectedProduct] = useState<string>("");
  const [targetMargin, setTargetMargin] = useState<string>("40");

  const { data: products } = useListProducts();

  const generateProduct = useAiGenerateProduct({
    mutation: {
      onSuccess: () => {
        toast({ title: "AI İşlemi Tamamlandı", description: "Ürün konsepti başarıyla üretildi." });
      },
      onError: () => {
        toast({ title: "Hata", description: "AI işlemi başarısız oldu.", variant: "destructive" });
      }
    }
  });

  const optimizePrice = useAiOptimizePrice({
    mutation: {
      onSuccess: () => {
        toast({ title: "Optimizasyon Tamamlandı", description: "Fiyat analizi başarıyla tamamlandı." });
      }
    }
  });

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <div>
        <h1 className="text-3xl font-bold tracking-tighter uppercase text-foreground flex items-center gap-3">
          <BrainCircuit className="h-8 w-8 text-accent" />
          AI Ürün Motoru
        </h1>
        <p className="text-muted-foreground">Yapay zeka ile ürün fikirlerini gerçeğe, fiyatları kara dönüştürün.</p>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <Card className="border-accent/20 bg-card/50 backdrop-blur relative overflow-hidden">
          <div className="absolute top-0 right-0 p-4 opacity-10 pointer-events-none">
            <Sparkles className="w-32 h-32 text-accent" />
          </div>
          <CardHeader>
            <CardTitle className="text-xl text-accent">Ürün Üretici</CardTitle>
            <CardDescription>Sadece bir fikir verin, AI satacak ürünü tasarlasın.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4 relative z-10">
            <div className="space-y-2">
              <label className="text-sm font-medium uppercase tracking-wider text-muted-foreground">Ürün Fikri</label>
              <Textarea 
                placeholder="Örn: Evcil hayvanlar için otomatik su kabı, minimalist tasarım, app kontrollü..." 
                className="bg-secondary/50 h-32 resize-none"
                value={idea}
                onChange={e => setIdea(e.target.value)}
              />
            </div>
          </CardContent>
          <CardFooter>
            <Button 
              className="w-full bg-accent hover:bg-accent/90 text-accent-foreground font-bold tracking-wide" 
              onClick={() => generateProduct.mutate({ data: { idea } })}
              disabled={!idea || generateProduct.isPending}
            >
              {generateProduct.isPending ? <RefreshCw className="mr-2 h-4 w-4 animate-spin" /> : <Zap className="mr-2 h-4 w-4" />}
              {generateProduct.isPending ? "AI DÜŞÜNÜYOR..." : "ÜRET"}
            </Button>
          </CardFooter>

          {generateProduct.data && (
            <div className="mx-6 mb-6 p-4 rounded-lg bg-accent/10 border border-accent/20 space-y-4 animate-in slide-in-from-top-4">
              <div className="flex justify-between items-start">
                <div>
                  <h3 className="font-bold text-lg text-accent">{generateProduct.data.name}</h3>
                  <Badge variant="outline" className="mt-1 border-accent/30 text-accent">{generateProduct.data.category}</Badge>
                </div>
                <Badge className={
                  generateProduct.data.viralPotential === "yuksek" ? "bg-red-500 hover:bg-red-600" :
                  generateProduct.data.viralPotential === "orta" ? "bg-yellow-500 hover:bg-yellow-600" : "bg-blue-500 hover:bg-blue-600"
                }>
                  Viral: {generateProduct.data.viralPotential.toUpperCase()}
                </Badge>
              </div>
              <p className="text-sm text-muted-foreground">{generateProduct.data.description}</p>
              
              <div className="grid grid-cols-3 gap-2 py-2 border-y border-accent/10 text-center">
                <div>
                  <div className="text-[10px] uppercase text-muted-foreground">Maliyet</div>
                  <div className="font-mono font-bold">{formatCurrency(generateProduct.data.estimatedCost)}</div>
                </div>
                <div>
                  <div className="text-[10px] uppercase text-muted-foreground">Satış Fiyatı</div>
                  <div className="font-mono font-bold text-accent">{formatCurrency(generateProduct.data.suggestedPrice)}</div>
                </div>
                <div>
                  <div className="text-[10px] uppercase text-muted-foreground">Kâr</div>
                  <div className="font-mono font-bold text-primary">{formatCurrency(generateProduct.data.estimatedProfit)}</div>
                </div>
              </div>

              <div>
                <div className="text-xs uppercase text-muted-foreground mb-1">Anahtar Kelimeler</div>
                <div className="text-xs font-mono text-accent/80">{generateProduct.data.keywords}</div>
              </div>
            </div>
          )}
        </Card>

        <Card className="border-primary/20 bg-card/50 backdrop-blur relative overflow-hidden">
          <div className="absolute top-0 right-0 p-4 opacity-10 pointer-events-none">
            <TrendingUp className="w-32 h-32 text-primary" />
          </div>
          <CardHeader>
            <CardTitle className="text-xl text-primary">Fiyat Optimizasyonu</CardTitle>
            <CardDescription>Mevcut ürünlerinizin fiyatını kârı maksimize edecek şekilde optimize edin.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4 relative z-10">
            <div className="space-y-2">
              <label className="text-sm font-medium uppercase tracking-wider text-muted-foreground">Ürün Seçin</label>
              <Select value={selectedProduct} onValueChange={setSelectedProduct}>
                <SelectTrigger className="bg-secondary/50">
                  <SelectValue placeholder="Optimize edilecek ürün..." />
                </SelectTrigger>
                <SelectContent>
                  {products?.map(p => (
                    <SelectItem key={p.id} value={p.id.toString()}>{p.name} - {formatCurrency(p.price)}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium uppercase tracking-wider text-muted-foreground">Hedef Kâr Marjı (%)</label>
              <Input 
                type="number" 
                value={targetMargin} 
                onChange={e => setTargetMargin(e.target.value)} 
                className="bg-secondary/50 font-mono"
              />
            </div>
          </CardContent>
          <CardFooter>
            <Button 
              className="w-full bg-primary hover:bg-primary/90 text-primary-foreground font-bold tracking-wide"
              onClick={() => optimizePrice.mutate({ data: { productId: Number(selectedProduct), targetMargin: Number(targetMargin) } })}
              disabled={!selectedProduct || optimizePrice.isPending}
            >
              {optimizePrice.isPending ? <RefreshCw className="mr-2 h-4 w-4 animate-spin" /> : <TrendingUp className="mr-2 h-4 w-4" />}
              {optimizePrice.isPending ? "ANALİZ EDİLİYOR..." : "FİYATI OPTİMİZE ET"}
            </Button>
          </CardFooter>

          {optimizePrice.data && (
            <div className="mx-6 mb-6 p-4 rounded-lg bg-primary/10 border border-primary/20 space-y-4 animate-in slide-in-from-top-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="p-3 bg-card/50 rounded border border-border text-center">
                  <div className="text-xs uppercase text-muted-foreground mb-1">Mevcut Fiyat</div>
                  <div className="font-mono text-xl text-muted-foreground line-through decoration-destructive">{formatCurrency(optimizePrice.data.currentPrice)}</div>
                </div>
                <div className="p-3 bg-primary/20 rounded border border-primary/30 text-center">
                  <div className="text-xs uppercase text-primary mb-1 font-bold">Önerilen Fiyat</div>
                  <div className="font-mono text-xl font-bold text-primary">{formatCurrency(optimizePrice.data.suggestedPrice)}</div>
                </div>
              </div>
              
              <div className="flex items-center gap-2 text-sm">
                <TrendingUp className="h-4 w-4 text-primary" />
                <span className="text-muted-foreground">Tahmini Gelir Artışı:</span>
                <span className="font-bold font-mono text-primary">+{formatCurrency(optimizePrice.data.estimatedRevenueLift)}</span>
              </div>

              <div className="p-3 bg-secondary/50 rounded text-sm text-muted-foreground italic border-l-2 border-primary">
                "{optimizePrice.data.reasoning}"
              </div>
            </div>
          )}
        </Card>
      </div>
    </div>
  );
}
