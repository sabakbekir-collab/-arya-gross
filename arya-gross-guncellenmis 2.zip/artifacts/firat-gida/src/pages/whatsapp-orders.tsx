import { useState } from "react";
import { useListOrders, useUpdateOrderStatus, getListOrdersQueryKey } from "@workspace/api-client-react";
import { formatCurrency, formatDate } from "@/lib/format";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { MessageCircle, Copy, ExternalLink, ClipboardList, Phone } from "lucide-react";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";

const WHATSAPP_PHONE = import.meta.env.VITE_WHATSAPP_PHONE || "905352765849";

const WA_STATUSES = [
  { value: "beklemede", label: "Yeni Sipariş", color: "bg-yellow-500/20 text-yellow-400" },
  { value: "hazirlaniyor", label: "Hazırlanıyor", color: "bg-blue-500/20 text-blue-400" },
  { value: "kargoda", label: "Teslimatta", color: "bg-purple-500/20 text-purple-400" },
  { value: "teslim edildi", label: "Tamamlandı", color: "bg-green-500/20 text-green-400" },
  { value: "iptal", label: "İptal Edildi", color: "bg-red-500/20 text-red-400" },
];

function buildWAMessage(order: any) {
  const itemLines = (order.items || []).map((item: any) =>
    `${item.quantity}x ${item.name} — ${formatCurrency(item.subtotal)}`
  ).join("\n");

  return `Merhaba Arya Gross! 🛒

*SİPARİŞ NO: AG-2026-${String(order.id).padStart(4, "0")}*

📦 Ürünler:
${itemLines}

💰 Toplam: *${formatCurrency(order.total)}*

👤 Ad Soyad: ${order.customerName || "—"}
📞 Telefon: ${order.customerPhone || "—"}
📍 Adres: ${order.address || "Belirtilmedi"}`;
}

function buildWAUrl(order: any) {
  const msg = encodeURIComponent(buildWAMessage(order));
  return `https://wa.me/${WHATSAPP_PHONE}?text=${msg}`;
}

export default function WhatsAppOrders() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [statusFilter, setStatusFilter] = useState("all");
  const { data: orders, isLoading } = useListOrders({ status: statusFilter !== "all" ? statusFilter : undefined });
  const updateStatus = useUpdateOrderStatus({
    mutation: {
      onSuccess: () => {
        toast({ title: "Durum güncellendi" });
        queryClient.invalidateQueries({ queryKey: getListOrdersQueryKey() });
      }
    }
  });

  const copyMsg = (order: any) => {
    navigator.clipboard.writeText(buildWAMessage(order));
    toast({ title: "Kopyalandı", description: "WhatsApp mesajı panoya kopyalandı." });
  };

  return (
    <div className="space-y-4 animate-in fade-in duration-500">
      <div className="flex items-start gap-3">
        <div className="w-10 h-10 bg-green-500/20 rounded-xl flex items-center justify-center shrink-0 border border-green-500/30">
          <MessageCircle className="h-5 w-5 text-green-400" />
        </div>
        <div>
          <h1 className="text-xl font-black">💬 WhatsApp Siparişleri</h1>
          <p className="text-xs text-muted-foreground mt-0.5">Siparişleri WhatsApp üzerinden takip et ve müşterilere mesaj gönder</p>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {[
          { label: "Toplam Sipariş", val: orders?.length || 0, color: "text-foreground" },
          { label: "Bekleyen", val: orders?.filter(o => o.status === "beklemede").length || 0, color: "text-yellow-400" },
          { label: "Hazırlanıyor", val: orders?.filter(o => o.status === "hazirlaniyor").length || 0, color: "text-blue-400" },
          { label: "Tamamlanan", val: orders?.filter(o => o.status === "teslim edildi").length || 0, color: "text-green-400" },
        ].map(s => (
          <Card key={s.label} className="border-border bg-card/60">
            <CardContent className="p-3">
              <div className="text-[10px] text-muted-foreground uppercase tracking-wider mb-1">{s.label}</div>
              <div className={`text-2xl font-black ${s.color}`}>{s.val}</div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Filter */}
      <Select value={statusFilter} onValueChange={setStatusFilter}>
        <SelectTrigger className="w-full sm:w-[200px] bg-secondary/50 border-border h-9 text-sm">
          <SelectValue placeholder="Durum Filtrele" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="all">Tüm Siparişler</SelectItem>
          {WA_STATUSES.map(s => <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>)}
        </SelectContent>
      </Select>

      {/* Orders list */}
      {isLoading ? (
        <div className="space-y-2">{[1, 2, 3].map(i => <div key={i} className="h-24 bg-secondary/30 animate-pulse rounded-xl" />)}</div>
      ) : !orders || orders.length === 0 ? (
        <Card className="border-dashed border-border bg-card/30">
          <div className="py-10 text-center space-y-2">
            <MessageCircle className="h-8 w-8 text-muted-foreground mx-auto" />
            <p className="text-sm text-muted-foreground">Sipariş bulunamadı</p>
          </div>
        </Card>
      ) : (
        <div className="space-y-3">
          {orders.map(order => {
            const statusInfo = WA_STATUSES.find(s => s.value === order.status) || WA_STATUSES[0];
            return (
              <Card key={order.id} className="border-border bg-card/60 hover:border-green-500/20 transition-all">
                <CardContent className="p-4">
                  <div className="flex items-start justify-between gap-3 mb-3">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-mono text-xs text-primary font-bold">AG-2026-{String(order.id).padStart(4, "0")}</span>
                        <Badge className={`text-[10px] ${statusInfo.color}`}>{statusInfo.label}</Badge>
                      </div>
                      <div className="font-semibold mt-1">{order.customerName || "Bilinmiyor"}</div>
                      {order.customerPhone && (
                        <div className="flex items-center gap-1 text-xs text-muted-foreground mt-0.5">
                          <Phone className="h-3 w-3" />{order.customerPhone}
                        </div>
                      )}
                    </div>
                    <div className="text-right shrink-0">
                      <div className="font-black text-lg text-primary">{formatCurrency(order.total)}</div>
                      <div className="text-[10px] text-muted-foreground">{formatDate(order.createdAt)}</div>
                    </div>
                  </div>

                  {/* Items */}
                  <div className="text-xs text-muted-foreground bg-secondary/30 rounded-lg p-2 mb-3 space-y-1">
                    {(order.items || []).map((item: any, i: number) => (
                      <div key={i} className="flex justify-between">
                        <span>{item.quantity}x {item.name}</span>
                        <span className="font-mono">{formatCurrency(item.subtotal)}</span>
                      </div>
                    ))}
                  </div>

                  {/* Status update + WA buttons */}
                  <div className="flex items-center gap-2 flex-wrap">
                    <Select value={order.status} onValueChange={val => updateStatus.mutate({ id: order.id, data: { status: val } })}>
                      <SelectTrigger className="h-8 text-xs bg-secondary/50 border-border flex-1 min-w-[130px]">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {WA_STATUSES.map(s => <SelectItem key={s.value} value={s.value} className="text-xs">{s.label}</SelectItem>)}
                      </SelectContent>
                    </Select>

                    <Button variant="outline" size="sm" className="h-8 gap-1.5 border-border text-xs" onClick={() => copyMsg(order)}>
                      <Copy className="h-3.5 w-3.5" /> Kopyala
                    </Button>

                    <a href={buildWAUrl(order)} target="_blank" rel="noopener noreferrer">
                      <Button size="sm" className="h-8 gap-1.5 bg-green-600 hover:bg-green-700 text-white text-xs">
                        <MessageCircle className="h-3.5 w-3.5" /> WhatsApp
                      </Button>
                    </a>

                    <Dialog>
                      <DialogTrigger asChild>
                        <Button variant="ghost" size="sm" className="h-8 gap-1 text-xs text-muted-foreground">
                          <ClipboardList className="h-3.5 w-3.5" /> Mesaj
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="border-border bg-card max-w-sm">
                        <DialogHeader>
                          <DialogTitle className="text-sm font-bold">WhatsApp Mesajı</DialogTitle>
                        </DialogHeader>
                        <pre className="text-xs font-mono bg-secondary/50 p-3 rounded-lg whitespace-pre-wrap leading-relaxed">{buildWAMessage(order)}</pre>
                        <Button onClick={() => copyMsg(order)} className="w-full gap-2 bg-green-600 hover:bg-green-700 text-white">
                          <Copy className="h-4 w-4" /> Kopyala ve WhatsApp'ta Gönder
                        </Button>
                      </DialogContent>
                    </Dialog>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}
