import { ModulePage } from "@/components/module-page";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Search, Globe, FileCode, Save } from "lucide-react";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";

export default function Seo() {
  const { toast } = useToast();
  const [form, setForm] = useState({ title: "Arya Gross — Toptan Gıda | Gaziantep", description: "Arya Gross ile doğal, organik ve taze gıda ürünlerine toptan fiyatıyla ulaşın. Kuruyemiş, bakliyat, baharatlar ve daha fazlası.", keywords: "arya gross, toptan gıda, kuruyemiş, bakliyat, organik, Gaziantep" });

  return (
    <div className="space-y-4 animate-in fade-in duration-500">
      <div className="flex items-start gap-3">
        <div className="w-10 h-10 bg-violet-500/20 rounded-xl flex items-center justify-center shrink-0 border border-violet-500/30">
          <Search className="h-5 w-5 text-violet-400" />
        </div>
        <div>
          <h1 className="text-xl font-black">🔍 SEO Yönetimi</h1>
          <p className="text-xs text-muted-foreground mt-0.5">Arama motoru optimizasyonu ayarları</p>
        </div>
      </div>

      <Card className="border-border bg-card/60">
        <CardHeader className="py-3 px-4 pb-2"><CardTitle className="text-sm flex items-center gap-2"><Globe className="h-4 w-4" /> Ana Sayfa SEO</CardTitle></CardHeader>
        <CardContent className="px-4 pb-4 space-y-3">
          <div>
            <label className="text-xs text-muted-foreground mb-1 block">SEO Başlığı <span className="text-[10px]">({form.title.length}/60)</span></label>
            <Input value={form.title} onChange={e => setForm(f => ({ ...f, title: e.target.value }))} className="bg-secondary/50 h-9 text-sm" maxLength={60} />
          </div>
          <div>
            <label className="text-xs text-muted-foreground mb-1 block">Meta Açıklama <span className="text-[10px]">({form.description.length}/160)</span></label>
            <Textarea value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))} className="bg-secondary/50 resize-none h-20 text-sm" maxLength={160} />
          </div>
          <div>
            <label className="text-xs text-muted-foreground mb-1 block">Anahtar Kelimeler</label>
            <Input value={form.keywords} onChange={e => setForm(f => ({ ...f, keywords: e.target.value }))} className="bg-secondary/50 h-9 text-sm" placeholder="virgülle ayırın" />
          </div>
          <Button size="sm" className="gap-2 bg-primary hover:bg-primary/90 text-white" onClick={() => toast({ title: "SEO ayarları kaydedildi" })}>
            <Save className="h-3.5 w-3.5" /> Kaydet
          </Button>
        </CardContent>
      </Card>

      <Card className="border-border bg-card/60">
        <CardHeader className="py-3 px-4 pb-2"><CardTitle className="text-sm flex items-center gap-2"><FileCode className="h-4 w-4" /> Teknik SEO</CardTitle></CardHeader>
        <CardContent className="px-4 pb-4 space-y-2">
          {[
            { label: "sitemap.xml", status: "ok" },
            { label: "robots.txt", status: "ok" },
            { label: "Open Graph Etiketleri", status: "ok" },
            { label: "Schema.org (Ürün)", status: "missing" },
            { label: "Canonical URL", status: "missing" },
          ].map(item => (
            <div key={item.label} className="flex items-center justify-between">
              <span className="text-xs">{item.label}</span>
              <Badge className={`text-[9px] ${item.status === "ok" ? "bg-green-500/20 text-green-400 border-green-500/30" : "bg-red-500/20 text-red-400 border-red-500/30"}`}>
                {item.status === "ok" ? "Aktif" : "Eksik"}
              </Badge>
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  );
}
