import { useState } from "react";
import { useListOrders, getListOrdersQueryKey, useUpdateOrderPaymentStatus } from "@workspace/api-client-react";
import { formatCurrency, formatDate } from "@/lib/format";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { CheckCircle2, XCircle, MessageCircle, FileText, Download, AlertTriangle, Clock, Banknote, ChevronRight, Copy, RefreshCcw } from "lucide-react";
import { cn } from "@/lib/utils";

const IBAN = "TR66 0001 0000 9587 1394 3350 01";
const WHATSAPP_PHONE = import.meta.env.VITE_WHATSAPP_PHONE || "905352765849";
const ADMIN_NAME = "Admin";

const PAYMENT_STATUSES = [
  { value: "odeme-bekleniyor", label: "Ödeme Bekleniyor", color: "bg-yellow-500/20 text-yellow-400 border-yellow-500/30" },
  { value: "dekont-bekleniyor", label: "Dekont Bekleniyor", color: "bg-orange-500/20 text-orange-400 border-orange-500/30" },
  { value: "kontrol-ediliyor", label: "Kontrol Ediliyor", color: "bg-blue-500/20 text-blue-400 border-blue-500/30" },
  { value: "odendi", label: "Ödendi ✓", color: "bg-green-500/20 text-green-400 border-green-500/30" },
  { value: "odeme-reddedildi", label: "Reddedildi", color: "bg-red-500/20 text-red-400 border-red-500/30" },
  { value: "iade-edildi", label: "İade Edildi", color: "bg-purple-500/20 text-purple-400 border-purple-500/30" },
  { value: "iptal-edildi", label: "İptal Edildi", color: "bg-gray-500/20 text-gray-400 border-gray-500/30" },
];

const DECONT_STATUSES = [
  { value: "bekleniyor", label: "Bekleniyor" },
  { value: "alindi", label: "Alındı" },
  { value: "reddedildi", label: "Reddedildi" },
];

function PaymentStatusBadge({ status }: { status?: string | null }) {
  const info = PAYMENT_STATUSES.find(s => s.value === status) || PAYMENT_STATUSES[0];
  return <Badge className={cn("text-[10px] border shrink-0 font-semibold", info.color)}>{info.label}</Badge>;
}

function OrderPaymentDialog({ order }: { order: any }) {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [confirmBy, setConfirmBy] = useState(ADMIN_NAME);

  const updatePayment = useUpdateOrderPaymentStatus({
    mutation: {
      onSuccess: () => {
        toast({ title: "Güncellendi", description: "Ödeme durumu değiştirildi." });
        queryClient.invalidateQueries({ queryKey: getListOrdersQueryKey() });
      }
    }
  });

  const handleAction = (paymentStatus: string, decontStatus?: string) => {
    updatePayment.mutate({
      id: order.id,
      data: {
        paymentStatus,
        ...(decontStatus && { decontStatus }),
        ...(paymentStatus === "odendi" && { paymentConfirmedBy: confirmBy }),
      }
    });
  };

  const waDecontMsg = encodeURIComponent(
    `Merhaba ${order.customerName || "Müşteri"}! Arya Gross sipariş ödemeniz için dekontu WhatsApp üzerinden bizimle paylaşabilir misiniz?\n\nSipariş No: #${order.id}\nTutar: ${formatCurrency(order.total)}\n\nIBAN: ${IBAN} (Ziraat Bankası)`
  );
  const waConfirmMsg = encodeURIComponent(
    `Merhaba ${order.customerName || "Müşteri"}! Arya Gross #${order.id} numaralı siparişiniz için ödemeniz onaylandı. Siparişiniz hazırlanmaya başlanacaktır. Teşekkürler!`
  );

  const copyIban = () => {
    navigator.clipboard.writeText(IBAN);
    toast({ title: "IBAN kopyalandı" });
  };

  const currentPayStatus = order.paymentStatus || "odeme-bekleniyor";
  const isHavale = order.paymentMethod === "havale";

  return (
    <DialogContent className="sm:max-w-[640px] border-primary/20 bg-card max-h-[90vh] overflow-y-auto">
      <DialogHeader>
        <DialogTitle className="flex items-center gap-2 text-base font-black">
          <span className="text-primary">#{order.id}</span>
          <PaymentStatusBadge status={currentPayStatus} />
        </DialogTitle>
      </DialogHeader>

      <div className="space-y-4">
        {/* Müşteri Bilgileri */}
        <div className="grid grid-cols-2 gap-3">
          <div className="bg-secondary/30 rounded-xl p-3 space-y-1">
            <p className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">Müşteri</p>
            <p className="font-semibold text-sm">{order.customerName || "—"}</p>
            <p className="text-xs text-muted-foreground">{order.customerPhone}</p>
            {order.address && <p className="text-xs text-muted-foreground">{order.address}</p>}
          </div>
          <div className="bg-secondary/30 rounded-xl p-3 space-y-1">
            <p className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">Ödeme Detayı</p>
            <p className="text-xl font-black text-primary">{formatCurrency(order.total)}</p>
            <p className="text-xs text-muted-foreground">{formatDate(order.createdAt)}</p>
            <div className="flex items-center gap-1 text-xs">
              <Banknote className="h-3 w-3 text-yellow-400" />
              <span className="text-yellow-400 font-semibold">Havale/EFT</span>
            </div>
          </div>
        </div>

        {/* IBAN */}
        {isHavale && (
          <div className="bg-yellow-500/10 border border-yellow-500/20 rounded-xl p-3 space-y-2">
            <p className="text-xs font-bold text-yellow-400">📢 Müşteriye gösterilecek mesaj:</p>
            <p className="text-xs text-muted-foreground italic border border-yellow-500/20 rounded-lg p-2 bg-yellow-500/5">
              "Havale/EFT yaptıktan sonra dekontu WhatsApp üzerinden gönderiniz. Siparişiniz ödeme onayından sonra hazırlanacaktır."
            </p>
            <div className="flex items-center justify-between bg-secondary/30 rounded-lg p-2">
              <div>
                <p className="text-[10px] text-muted-foreground">IBAN (Ziraat Bankası)</p>
                <p className="font-mono font-bold text-sm">{IBAN}</p>
              </div>
              <Button variant="ghost" size="icon" className="h-8 w-8" onClick={copyIban}>
                <Copy className="h-3.5 w-3.5" />
              </Button>
            </div>
          </div>
        )}

        {/* Dekont Durumu */}
        <div className="flex items-center gap-3 bg-secondary/20 rounded-xl p-3">
          <div className="flex-1">
            <p className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground mb-1">Dekont Durumu</p>
            <Select
              value={order.decontStatus || "bekleniyor"}
              onValueChange={(val) => handleAction(currentPayStatus, val)}
            >
              <SelectTrigger className="h-8 bg-secondary/50 border-border text-xs">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {DECONT_STATUSES.map(s => <SelectItem key={s.value} value={s.value} className="text-xs">{s.label}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          {order.paymentConfirmedBy && (
            <div className="text-right shrink-0">
              <p className="text-[10px] text-muted-foreground">Onaylayan</p>
              <p className="text-xs font-semibold">{order.paymentConfirmedBy}</p>
              {order.paymentConfirmedAt && (
                <p className="text-[10px] text-muted-foreground">{formatDate(order.paymentConfirmedAt)}</p>
              )}
            </div>
          )}
        </div>

        {/* Ödeme Durumu Güncelle */}
        <div>
          <p className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground mb-2">Ödeme Durumunu Güncelle</p>
          <Select value={currentPayStatus} onValueChange={(val) => handleAction(val)}>
            <SelectTrigger className="bg-secondary/50 border-border h-9 text-sm">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {PAYMENT_STATUSES.map(s => <SelectItem key={s.value} value={s.value} className="text-xs">{s.label}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>

        {/* Onaylayan admin adı */}
        {currentPayStatus !== "odendi" && (
          <div>
            <p className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground mb-1">Onaylayan Admin Adı</p>
            <Input value={confirmBy} onChange={e => setConfirmBy(e.target.value)} className="h-8 bg-secondary/50 text-sm" />
          </div>
        )}

        {/* Aksiyon Butonları */}
        <div>
          <p className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground mb-2">⚡ Hızlı İşlemler</p>
          <div className="flex flex-wrap gap-2">
            <Button variant="outline" size="sm" className="gap-1.5 text-xs h-8 border-green-500/30 text-green-400 hover:bg-green-500/10"
              disabled={updatePayment.isPending}
              onClick={() => handleAction("odendi", "alindi")}>
              <CheckCircle2 className="h-3.5 w-3.5" /> Ödeme Geldi
            </Button>
            <Button variant="outline" size="sm" className="gap-1.5 text-xs h-8 border-red-500/30 text-red-400 hover:bg-red-500/10"
              disabled={updatePayment.isPending}
              onClick={() => handleAction("odeme-reddedildi")}>
              <XCircle className="h-3.5 w-3.5" /> Ödeme Gelmedi
            </Button>
            <a href={`https://wa.me/${WHATSAPP_PHONE}?text=${waDecontMsg}`} target="_blank" rel="noopener noreferrer">
              <Button variant="outline" size="sm" className="gap-1.5 text-xs h-8 border-orange-500/30 text-orange-400 hover:bg-orange-500/10">
                <FileText className="h-3.5 w-3.5" /> Dekont İste
              </Button>
            </a>
            <a href={`https://wa.me/${WHATSAPP_PHONE}?text=${waConfirmMsg}`} target="_blank" rel="noopener noreferrer">
              <Button variant="outline" size="sm" className="gap-1.5 text-xs h-8 border-green-500/30 text-green-400 hover:bg-green-500/10">
                <MessageCircle className="h-3.5 w-3.5" /> WhatsApp Gönder
              </Button>
            </a>
            <Button variant="outline" size="sm" className="gap-1.5 text-xs h-8 border-purple-500/30 text-purple-400 hover:bg-purple-500/10"
              disabled={updatePayment.isPending}
              onClick={() => handleAction("iade-edildi")}>
              <RefreshCcw className="h-3.5 w-3.5" /> İade Et
            </Button>
          </div>
        </div>

        {/* Ürünler */}
        <div>
          <p className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground mb-2">Sipariş İçeriği</p>
          <div className="space-y-1">
            {order.items.map((item: any) => (
              <div key={item.productId} className="flex justify-between text-sm px-3 py-1.5 bg-secondary/20 rounded-lg">
                <span>{item.name} <span className="text-muted-foreground">×{item.quantity}</span></span>
                <span className="font-semibold text-primary">{formatCurrency(item.subtotal)}</span>
              </div>
            ))}
            <div className="flex justify-between pt-2 border-t border-border font-bold">
              <span>Toplam</span>
              <span className="text-primary">{formatCurrency(order.total)}</span>
            </div>
          </div>
        </div>
      </div>
    </DialogContent>
  );
}

export default function PaymentApproval() {
  const [filter, setFilter] = useState<string>("all");
  const { data: allOrders, isLoading } = useListOrders({});

  const orders = (allOrders || []).filter(o => {
    if (filter === "all") return o.paymentMethod === "havale" || o.paymentMethod === "whatsapp";
    return (o.paymentMethod === "havale" || o.paymentMethod === "whatsapp") && (o.paymentStatus || "odeme-bekleniyor") === filter;
  });

  const handleExcelExport = () => {
    window.open("/api/reports/export-excel", "_blank");
  };

  const stats = {
    bekleyen: allOrders?.filter(o => (o.paymentStatus || "odeme-bekleniyor") === "odeme-bekleniyor" && (o.paymentMethod === "havale" || o.paymentMethod === "whatsapp")).length || 0,
    dekont: allOrders?.filter(o => o.paymentStatus === "dekont-bekleniyor").length || 0,
    odendi: allOrders?.filter(o => o.paymentStatus === "odendi").length || 0,
    reddedildi: allOrders?.filter(o => o.paymentStatus === "odeme-reddedildi").length || 0,
  };

  return (
    <div className="space-y-4 animate-in fade-in duration-500">
      {/* Header */}
      <div className="flex items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-black tracking-tight flex items-center gap-2">
            💳 Ödeme Onay Merkezi
            {stats.bekleyen > 0 && <Badge className="bg-yellow-500/20 text-yellow-400 border-yellow-500/30 text-xs">{stats.bekleyen} bekliyor</Badge>}
          </h1>
          <p className="text-xs text-muted-foreground mt-0.5">Havale/EFT ödemelerini takip edin ve onaylayın</p>
        </div>
        <Button size="sm" variant="outline" className="gap-1.5 text-xs border-green-500/30 text-green-400 hover:bg-green-500/10"
          onClick={handleExcelExport}>
          <Download className="h-3.5 w-3.5" /> Excel'e Aktar
        </Button>
      </div>

      {/* IBAN Banner */}
      <div className="bg-yellow-500/10 border border-yellow-500/20 rounded-xl p-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Banknote className="h-5 w-5 text-yellow-400 shrink-0" />
          <div>
            <p className="text-xs font-bold text-yellow-400">Ziraat Bankası — IBAN</p>
            <p className="font-mono font-bold text-sm">{IBAN}</p>
          </div>
        </div>
        <Button variant="ghost" size="sm" className="gap-1 text-xs text-muted-foreground"
          onClick={() => { navigator.clipboard.writeText(IBAN); }}>
          <Copy className="h-3.5 w-3.5" /> Kopyala
        </Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-4 gap-2">
        {[
          { label: "Bekleyen", count: stats.bekleyen, color: "text-yellow-400", filter: "odeme-bekleniyor" },
          { label: "Dekont İsteniyor", count: stats.dekont, color: "text-orange-400", filter: "dekont-bekleniyor" },
          { label: "Ödendi", count: stats.odendi, color: "text-green-400", filter: "odendi" },
          { label: "Reddedildi", count: stats.reddedildi, color: "text-red-400", filter: "odeme-reddedildi" },
        ].map(s => (
          <button key={s.filter}
            onClick={() => setFilter(filter === s.filter ? "all" : s.filter)}
            className={cn("bg-secondary/30 rounded-xl p-3 text-center border-2 transition-all hover:border-border",
              filter === s.filter ? "border-primary bg-primary/10" : "border-transparent")}>
            <div className={cn("text-xl font-black", s.color)}>{s.count}</div>
            <div className="text-[9px] text-muted-foreground mt-0.5 leading-tight">{s.label}</div>
          </button>
        ))}
      </div>

      {/* Orders List */}
      <Card className="border-border bg-card/50">
        <CardHeader className="pb-3 pt-4 px-4">
          <div className="flex items-center justify-between">
            <CardTitle className="text-sm font-bold flex items-center gap-2">
              <Banknote className="h-4 w-4 text-primary" />
              {orders.length} Havale/EFT Siparişi
            </CardTitle>
            <Select value={filter} onValueChange={setFilter}>
              <SelectTrigger className="w-[160px] h-8 bg-secondary/50 border-border text-xs">
                <SelectValue placeholder="Tümü" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all" className="text-xs">Tümü</SelectItem>
                {PAYMENT_STATUSES.map(s => <SelectItem key={s.value} value={s.value} className="text-xs">{s.label}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
        </CardHeader>
        <CardContent className="px-4 pb-4">
          {isLoading ? (
            <div className="space-y-2">{[1,2,3].map(i => <div key={i} className="h-14 bg-secondary/30 rounded-xl animate-pulse" />)}</div>
          ) : orders.length === 0 ? (
            <div className="text-center py-10 text-muted-foreground border-2 border-dashed border-border rounded-xl">
              <Banknote className="h-8 w-8 mx-auto mb-2 opacity-20" />
              <p className="text-sm">Bu filtrede havale siparişi yok.</p>
            </div>
          ) : (
            <div className="space-y-2">
              {orders.map(order => {
                const payStatus = order.paymentStatus || "odeme-bekleniyor";
                const isUrgent = payStatus === "odeme-bekleniyor" || payStatus === "dekont-bekleniyor";
                return (
                  <Dialog key={order.id}>
                    <DialogTrigger asChild>
                      <div className={cn(
                        "flex items-center gap-3 p-3 rounded-xl border cursor-pointer hover:border-primary/30 transition-all group",
                        isUrgent ? "border-yellow-500/30 bg-yellow-500/5" : "border-border bg-secondary/20"
                      )}>
                        <div className="shrink-0 w-10 text-center">
                          <div className="font-black text-sm text-primary">#{order.id}</div>
                          {isUrgent && <AlertTriangle className="h-3 w-3 text-yellow-400 mx-auto mt-0.5" />}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="font-semibold text-sm">{order.customerName || "—"}</div>
                          <div className="flex items-center gap-2 mt-0.5">
                            <PaymentStatusBadge status={payStatus} />
                            {order.decontStatus && order.decontStatus !== "bekleniyor" && (
                              <span className={cn("text-[9px] font-semibold", order.decontStatus === "alindi" ? "text-green-400" : "text-red-400")}>
                                Dekont: {order.decontStatus === "alindi" ? "Alındı" : "Reddedildi"}
                              </span>
                            )}
                          </div>
                        </div>
                        <div className="text-right shrink-0">
                          <div className="font-black text-primary">{formatCurrency(order.total)}</div>
                          <div className="text-[10px] text-muted-foreground flex items-center gap-1 justify-end mt-0.5">
                            <Clock className="h-3 w-3" />
                            {formatDate(order.createdAt)}
                          </div>
                        </div>
                        <ChevronRight className="h-4 w-4 text-muted-foreground shrink-0 group-hover:text-primary" />
                      </div>
                    </DialogTrigger>
                    <OrderPaymentDialog order={order} />
                  </Dialog>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
