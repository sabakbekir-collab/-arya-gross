import React from "react";
import { createRoot } from "react-dom/client";
import "./index.css";

declare global {
  interface Window {
    __ARYA_MOUNTED__?: boolean;
    __ARYA_BUILD__?: string;
  }
}

const root = document.getElementById("root");

function showFatal(error: unknown) {
  const message =
    error instanceof Error
      ? `${error.message}\n\n${error.stack || ""}`
      : String(error || "Bilinmeyen hata");

  if (!root) return;

  root.innerHTML = "";

  const page = document.createElement("main");
  page.className = "fatal-page";

  const card = document.createElement("section");
  card.className = "fatal-card";

  const title = document.createElement("h1");
  title.textContent = "Arya Gross açılış hatası";

  const text = document.createElement("p");
  text.textContent =
    "Uygulama dosyası çalıştırılırken hata oluştu. Verileriniz silinmedi.";

  const detail = document.createElement("pre");
  detail.textContent = message;

  const button = document.createElement("button");
  button.textContent = "Sayfayı Yenile";
  button.onclick = () => location.reload();

  card.append(title, text, detail, button);
  page.append(card);
  root.append(page);
}

window.addEventListener("error", (event) => {
  console.error("ARYA_GLOBAL_ERROR", event.error || event.message);
  showFatal(event.error || event.message);
});

window.addEventListener("unhandledrejection", (event) => {
  console.error("ARYA_UNHANDLED_REJECTION", event.reason);
  showFatal(event.reason);
});

if (!root) {
  throw new Error("#root elementi bulunamadı");
}

class Boundary extends React.Component<
  React.PropsWithChildren,
  { failed: boolean; message: string }
> {
  state = {
    failed: false,
    message: "",
  };

  static getDerivedStateFromError(error: unknown) {
    return {
      failed: true,
      message:
        error instanceof Error
          ? `${error.message}\n\n${error.stack || ""}`
          : String(error),
    };
  }

  componentDidCatch(error: unknown) {
    console.error("ARYA_RENDER_ERROR", error);
  }

  render() {
    if (this.state.failed) {
      return (
        <main className="fatal-page">
          <section className="fatal-card">
            <h1>Sayfa görüntülenemedi</h1>
            <p>Bu bölümde bir hata oluştu. Verileriniz korunuyor.</p>
            <pre>{this.state.message}</pre>
            <button onClick={() => location.reload()}>
              Yenile
            </button>
          </section>
        </main>
      );
    }

    return this.props.children;
  }
}

(async () => {
  try {
    console.log("ARYA: App dynamic import başlıyor");

    window.__ARYA_MOUNTED__ = true;

    const { default: App } = await import("./App");

    console.log("ARYA: App dynamic import başarılı");

    createRoot(root).render(
      <React.StrictMode>
        <Boundary>
          <App />
        </Boundary>
      </React.StrictMode>,
    );

    console.log("ARYA: React render çağrıldı");
  } catch (error) {
    console.error("ARYA_APP_IMPORT_ERROR", error);
    showFatal(error);
  }
})();
