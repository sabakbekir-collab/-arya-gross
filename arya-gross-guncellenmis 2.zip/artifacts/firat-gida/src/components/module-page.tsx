import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Construction } from "lucide-react";

interface StatCard {
  label: string;
  value: string;
  color?: string;
}

interface ModulePageProps {
  emoji: string;
  title: string;
  description: string;
  stats?: StatCard[];
  children?: React.ReactNode;
  badge?: string;
}

export function ModulePage({ emoji, title, description, stats, children, badge }: ModulePageProps) {
  return (
    <div className="space-y-4 animate-in fade-in duration-500">
      <div className="flex items-start gap-3">
        <div className="w-10 h-10 bg-primary/10 rounded-xl flex items-center justify-center text-xl shrink-0 border border-primary/20">
          {emoji}
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <h1 className="text-xl font-black tracking-tight">{title}</h1>
            {badge && <Badge className="bg-primary/20 text-primary border-primary/30 text-[10px]">{badge}</Badge>}
          </div>
          <p className="text-xs text-muted-foreground mt-0.5">{description}</p>
        </div>
      </div>

      {stats && stats.length > 0 && (
        <div className={`grid gap-3 ${stats.length <= 2 ? "grid-cols-2" : stats.length <= 3 ? "grid-cols-3" : "grid-cols-2 sm:grid-cols-4"}`}>
          {stats.map((stat, i) => (
            <Card key={i} className="border-border bg-card/60">
              <CardContent className="p-3">
                <div className="text-[10px] text-muted-foreground uppercase tracking-wider mb-1">{stat.label}</div>
                <div className={`text-xl font-black ${stat.color || "text-foreground"}`}>{stat.value}</div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {children || (
        <Card className="border-dashed border-border bg-card/30">
          <CardContent className="py-12 text-center space-y-3">
            <Construction className="h-8 w-8 text-muted-foreground mx-auto" />
            <p className="text-sm font-semibold text-muted-foreground">Modül Geliştiriliyor</p>
            <p className="text-xs text-muted-foreground max-w-xs mx-auto">
              Bu modül yakında aktif olacak. Backend API bağlantısı kurulduğunda tüm işlevler devreye girecek.
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
