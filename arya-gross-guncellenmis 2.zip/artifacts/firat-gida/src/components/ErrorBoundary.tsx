import { Component, type ErrorInfo, type ReactNode } from "react";

type Props = { children: ReactNode };
type State = { hasError: boolean };

export class ErrorBoundary extends Component<Props, State> {
  state: State = { hasError: false };

  static getDerivedStateFromError(): State {
    return { hasError: true };
  }

  componentDidCatch(error: Error, info: ErrorInfo) {
    console.error("ARYA_FRONTEND_ERROR", error, info.componentStack);
  }

  render() {
    if (!this.state.hasError) return this.props.children;

    return (
      <main className="min-h-screen bg-slate-950 text-white grid place-items-center p-6">
        <section className="w-full max-w-lg rounded-3xl border border-white/10 bg-white/5 p-7 text-center shadow-2xl">
          <div className="text-5xl mb-4">🛠️</div>
          <h1 className="text-2xl font-black mb-2">Sayfa yüklenirken bir sorun oluştu</h1>
          <p className="text-slate-300 mb-5">Verileriniz silinmedi. Sayfayı yenileyerek tekrar deneyin.</p>
          <button
            type="button"
            onClick={() => window.location.reload()}
            className="rounded-xl bg-red-600 px-5 py-3 font-bold hover:bg-red-700"
          >
            Sayfayı Yenile
          </button>
        </section>
      </main>
    );
  }
}
