import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { useGetCart, useListCategories } from "@workspace/api-client-react";
import { Search, ShoppingCart, Phone, ChevronDown, Menu, X, Star, Truck, Shield, RotateCcw, MessageCircle } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

const WHATSAPP_PHONE = import.meta.env.VITE_WHATSAPP_PHONE || "905352765849";

const CATEGORIES_NAV = [
  { label: "Gıda", icon: "🥗", slug: "gida" },
  { label: "İçecek", icon: "🥤", slug: "icecek" },
  { label: "Kahvaltılık", icon: "🍳", slug: "kahvaltilik" },
  { label: "Temizlik", icon: "🧹", slug: "temizlik" },
  { label: "Atıştırmalık", icon: "🍿", slug: "atistirmalik" },
  { label: "Bebek", icon: "🍼", slug: "bebek" },
  { label: "Kişisel Bakım", icon: "💄", slug: "kisisel-bakim" },
  { label: "Ev Ürünleri", icon: "🏠", slug: "ev-urunleri" },
];

export function StoreLayout({ children }: { children: React.ReactNode }) {
  const [search, setSearch] = useState("");
  const [mobileOpen, setMobileOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [, navigate] = useLocation();
  const { data: cart } = useGetCart();

  const cartCount = cart?.items?.reduce((sum, i) => sum + i.quantity, 0) ?? 0;

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 10);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (search.trim()) navigate(`/magaza/urunler?q=${encodeURIComponent(search.trim())}`);
  };

  return (
    <div id="store-layout" className="min-h-screen bg-gray-50 flex flex-col overflow-x-hidden">
      {/* Announcement Bar */}
      <div className="bg-[#DC2626] text-white text-center text-xs sm:text-sm py-2 px-4">
        <span className="font-medium">🛡️ Arya Gross güvencesiyle tedarik edilir</span>
        <span className="mx-3 opacity-50">|</span>
        <span>📱 WhatsApp sipariş hattı: <a href={`https://wa.me/${WHATSAPP_PHONE}`} className="underline font-bold">{WHATSAPP_PHONE}</a></span>
      </div>

      {/* Header */}
      <header className={`sticky top-0 z-50 bg-white transition-shadow duration-200 ${scrolled ? "shadow-md" : "shadow-sm"}`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="flex items-center gap-3 h-16 sm:h-20">
            {/* Mobile Menu */}
            <button className="sm:hidden p-2 text-gray-600" onClick={() => setMobileOpen(!mobileOpen)}>
              {mobileOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>

            {/* Logo */}
            <Link href="/magaza" className="flex items-center gap-2 shrink-0">
              <div className="w-10 h-10 bg-[#DC2626] rounded-lg flex items-center justify-center">
                <span className="text-white font-black text-sm">AG</span>
              </div>
              <div className="hidden sm:block">
                <div className="text-lg font-black text-gray-900 leading-none">ARYA GROSS</div>
                <div className="text-[10px] text-gray-500 uppercase tracking-widest">Online Market</div>
              </div>
            </Link>

            {/* Search */}
            <form onSubmit={handleSearch} className="flex-1 min-w-0 flex max-w-2xl mx-auto">
              <div className="relative w-full flex min-w-0">
                <Input
                  value={search}
                  onChange={e => setSearch(e.target.value)}
                  placeholder="Ürün ara..."
                  className="rounded-r-none border-2 border-r-0 border-[#DC2626] h-11 text-sm focus-visible:ring-0 focus-visible:border-[#DC2626] min-w-0"
                />
                <Button type="submit" className="rounded-l-none bg-[#DC2626] hover:bg-[#b91c1c] h-11 px-5">
                  <Search className="h-4 w-4" />
                </Button>
              </div>
            </form>

            {/* Right Actions */}
            <div className="flex items-center gap-2">
              <a href={`https://wa.me/${WHATSAPP_PHONE}`} target="_blank" rel="noopener noreferrer"
                className="hidden md:flex items-center gap-2 text-sm text-gray-600 hover:text-green-600 transition-colors">
                <MessageCircle className="h-5 w-5 text-green-500" />
                <span className="text-xs leading-none">WhatsApp<br/><strong>Sipariş</strong></span>
              </a>
              <Link href="/magaza/sepet">
                <Button variant="outline" size="sm" className="relative border-2 border-gray-200 h-11 px-3 gap-2 hover:border-[#DC2626]">
                  <ShoppingCart className="h-5 w-5 text-gray-700" />
                  {cartCount > 0 && (
                    <Badge className="absolute -top-2 -right-2 h-5 w-5 p-0 flex items-center justify-center bg-[#DC2626] text-white text-xs rounded-full border-2 border-white">
                      {cartCount}
                    </Badge>
                  )}
                  <span className="hidden sm:block text-xs font-medium">Sepet</span>
                </Button>
              </Link>
              <Link href="/">
                <Button size="sm" className="hidden sm:flex bg-gray-900 hover:bg-gray-700 text-white h-11 px-3 text-xs">
                  Yönetim
                </Button>
              </Link>
            </div>
          </div>
        </div>

        {/* Category Nav */}
        <div className="bg-gray-900 hidden sm:block">
          <div className="max-w-7xl mx-auto px-4 sm:px-6">
            <div className="flex items-center gap-1 overflow-x-auto scrollbar-hide">
              <Link href="/magaza/urunler"
                className="flex items-center gap-1 px-3 py-2.5 text-white text-sm font-semibold whitespace-nowrap hover:bg-[#DC2626] transition-colors rounded-sm">
                🏷️ Tüm Ürünler
              </Link>
              {CATEGORIES_NAV.map(c => (
                <Link key={c.slug} href={`/magaza/urunler?kat=${c.slug}`}
                  className="flex items-center gap-1 px-3 py-2.5 text-gray-300 text-sm whitespace-nowrap hover:bg-[#DC2626] hover:text-white transition-colors rounded-sm">
                  <span>{c.icon}</span> {c.label}
                </Link>
              ))}
            </div>
          </div>
        </div>
      </header>

      {/* Mobile Menu */}
      {mobileOpen && (
        <div className="sm:hidden fixed inset-0 z-40 bg-black/50" onClick={() => setMobileOpen(false)}>
          <div className="bg-white w-72 h-full shadow-xl" onClick={e => e.stopPropagation()}>
            <div className="p-4 bg-[#DC2626] text-white font-bold text-lg">Kategoriler</div>
            {CATEGORIES_NAV.map(c => (
              <Link key={c.slug} href={`/magaza/urunler?kat=${c.slug}`}
                onClick={() => setMobileOpen(false)}
                className="flex items-center gap-3 px-4 py-3 text-gray-700 border-b hover:bg-red-50 hover:text-[#DC2626] transition-colors">
                <span className="text-xl">{c.icon}</span>
                <span className="font-medium">{c.label}</span>
              </Link>
            ))}
          </div>
        </div>
      )}

      {/* Main */}
      <main className="flex-1">{children}</main>

      {/* Trust Strip */}
      <div className="bg-white border-t border-gray-100 py-6 mt-8">
        <div className="max-w-7xl mx-auto px-4 grid grid-cols-2 sm:grid-cols-4 gap-4 text-center">
          {[
            { icon: <Truck className="h-6 w-6 text-[#DC2626]" />, title: "Tedarik Teslimat", desc: "Tahmini teslimat tedarikçiye göre değişir" },
            { icon: <Shield className="h-6 w-6 text-[#DC2626]" />, title: "Güvenli Ödeme", desc: "256-bit SSL şifreleme" },
            { icon: <RotateCcw className="h-6 w-6 text-[#DC2626]" />, title: "Kolay İade", desc: "Sipariş onayı sonrası iade" },
            { icon: <Star className="h-6 w-6 text-[#DC2626]" />, title: "Arya Gross Güvencesi", desc: "Kaliteli tedarik garantisi" },
          ].map((item, i) => (
            <div key={i} className="flex flex-col items-center gap-2">
              <div className="w-12 h-12 bg-red-50 rounded-full flex items-center justify-center">{item.icon}</div>
              <div className="font-bold text-gray-900 text-sm">{item.title}</div>
              <div className="text-xs text-gray-500">{item.desc}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-gray-900 text-white pt-10 pb-6">
        <div className="max-w-7xl mx-auto px-4 grid grid-cols-2 sm:grid-cols-4 gap-8 mb-8">
          <div>
            <div className="font-black text-lg mb-3">ARYA GROSS</div>
            <p className="text-gray-400 text-sm leading-relaxed">Kaliteli ürünler, toptan fiyatlar. Arya Gross güvencesiyle.</p>
            <div className="flex gap-2 mt-4">
              <a href={`https://wa.me/${WHATSAPP_PHONE}`} target="_blank" rel="noopener noreferrer"
                className="bg-green-600 hover:bg-green-700 text-white px-3 py-1.5 rounded text-xs font-medium flex items-center gap-1">
                <MessageCircle className="h-3 w-3" /> WhatsApp
              </a>
            </div>
          </div>
          <div>
            <div className="font-bold mb-3 text-[#FBBF24]">Kategoriler</div>
            <ul className="space-y-1.5 text-gray-400 text-sm">
              {CATEGORIES_NAV.slice(0, 5).map(c => (
                <li key={c.slug}><Link href={`/magaza/urunler?kat=${c.slug}`} className="hover:text-white transition-colors">{c.label}</Link></li>
              ))}
            </ul>
          </div>
          <div>
            <div className="font-bold mb-3 text-[#FBBF24]">Müşteri Hizmetleri</div>
            <ul className="space-y-1.5 text-gray-400 text-sm">
              {["SSS", "Kargo Takibi", "İade & Değişim", "Gizlilik Politikası", "Kullanım Koşulları"].map(s => (
                <li key={s}><a href="#" className="hover:text-white transition-colors">{s}</a></li>
              ))}
            </ul>
          </div>
          <div>
            <div className="font-bold mb-3 text-[#FBBF24]">Güvenli Ödeme</div>
            <div className="flex flex-wrap gap-2">
              {["iyzico", "PayTR", "Visa", "Mastercard", "Kapıda"].map(p => (
                <span key={p} className="bg-gray-800 px-2 py-1 rounded text-xs text-gray-300">{p}</span>
              ))}
            </div>
            <div className="mt-4 text-xs text-gray-500">
              <div className="flex items-center gap-1 mb-1"><Shield className="h-3 w-3" /> 256-bit SSL güvenli bağlantı</div>
              <div className="flex items-center gap-1"><Star className="h-3 w-3" /> %100 Müşteri Memnuniyeti</div>
            </div>
          </div>
        </div>
        <div className="border-t border-gray-800 pt-4 text-center text-gray-500 text-xs">
          © 2026 Arya Gross. Tüm hakları saklıdır.
        </div>
      </footer>

      {/* WhatsApp Floating Button */}
      <a href={`https://wa.me/${WHATSAPP_PHONE}`} target="_blank" rel="noopener noreferrer"
        className="fixed bottom-6 right-6 z-50 bg-green-500 hover:bg-green-600 text-white w-14 h-14 rounded-full shadow-xl flex items-center justify-center transition-transform hover:scale-110 active:scale-95">
        <MessageCircle className="h-7 w-7" />
      </a>
    </div>
  );
}
