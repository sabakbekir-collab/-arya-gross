import { useState } from "react";
import { Link, useLocation } from "wouter";
import {
  LayoutDashboard, BrainCircuit, ShieldCheck, Zap,
  Package, Tags, BarChart2, ClipboardList, MessageCircle,
  Users, Megaphone, Ticket, Radio, Share2, Search,
  FileText, Image, CreditCard, Truck, Bell, AlertCircle,
  Bot, Settings, UserCog, Archive, TrendingUp, ChevronDown,
  ChevronRight, Menu, X, Banknote, FileSpreadsheet, Sparkles,
} from "lucide-react";
import { cn } from "@/lib/utils";

interface NavItem {
  name: string;
  href: string;
  icon: React.ElementType;
  badge?: string;
}

interface NavGroup {
  label: string;
  items: NavItem[];
  defaultOpen?: boolean;
}

const NAV_GROUPS: NavGroup[] = [
  {
    label: "",
    defaultOpen: true,
    items: [
      { name: "Dashboard", href: "/", icon: LayoutDashboard },
    ],
  },
  {
    label: "AI & Otomasyon",
    defaultOpen: true,
    items: [
      { name: "Gerçek Ürün Bul", href: "/arya", icon: BrainCircuit, badge: "AI" },
      { name: "Arya Chat", href: "/arya-chat", icon: MessageCircle, badge: "YENİ" },
      { name: "Günlük Otomasyon", href: "/arya-otomasyon", icon: Zap },
      { name: "Tedarikçi Tarama", href: "/supplier-import", icon: FileSpreadsheet },
    ],
  },
  {
    label: "Satış & Müşteri",
    defaultOpen: true,
    items: [
      { name: "Siparişler", href: "/orders", icon: ClipboardList },
      { name: "Ödeme Onay Merkezi", href: "/payment-approval", icon: Banknote, badge: "YENİ" },
      { name: "WhatsApp Siparişleri", href: "/whatsapp-orders", icon: MessageCircle },
      { name: "Müşteri Yönetimi", href: "/customers", icon: Users },
    ],
  },
  {
    label: "Ürün & Stok",
    defaultOpen: true,
    items: [
      { name: "Ürün Yönetimi", href: "/products", icon: Package },
      { name: "Ürün Önerileri", href: "/product-suggestions", icon: Sparkles, badge: "YENİ" },
      { name: "Kategori Yönetimi", href: "/categories", icon: Tags },
      { name: "Stok Yönetimi", href: "/stock", icon: BarChart2 },
    ],
  },
  {
    label: "Pazarlama",
    defaultOpen: false,
    items: [
      { name: "Kampanya Yönetimi", href: "/campaigns", icon: Megaphone },
      { name: "Kupon Yönetimi", href: "/coupons", icon: Ticket },
      { name: "Reklam Yönetimi", href: "/ads", icon: Radio },
      { name: "Sosyal Medya", href: "/social-media", icon: Share2 },
      { name: "SEO Yönetimi", href: "/seo", icon: Search },
      { name: "Banner / Slider", href: "/banners", icon: Image },
    ],
  },
  {
    label: "Finans",
    defaultOpen: false,
    items: [
      { name: "Muhasebe & Kâr", href: "/accounting", icon: TrendingUp },
      { name: "Raporlar", href: "/reports", icon: FileText },
      { name: "Excel Yönetimi", href: "/excel-management", icon: FileSpreadsheet },
    ],
  },
  {
    label: "Sistem",
    defaultOpen: false,
    items: [
      { name: "İçerik Yönetimi", href: "/content", icon: FileText },
      { name: "Ödeme Yönetimi", href: "/payments", icon: CreditCard },
      { name: "Kargo & Teslimat", href: "/delivery", icon: Truck },
      { name: "Bildirim Merkezi", href: "/notifications", icon: Bell },
      { name: "Hata Takip", href: "/error-tracking", icon: AlertCircle },
      { name: "AI Araçları", href: "/ai", icon: Bot },
      { name: "Sistem Ayarları", href: "/system-settings", icon: Settings },
      { name: "Kullanıcı & Yetki", href: "/users", icon: UserCog },
      { name: "Yedekleme", href: "/backup", icon: Archive },
    ],
  },
];

const BOTTOM_NAV = [
  { name: "Panel", href: "/", icon: LayoutDashboard },
  { name: "Arya", href: "/arya", icon: BrainCircuit },
  { name: "Siparişler", href: "/orders", icon: ClipboardList },
  { name: "Ürünler", href: "/products", icon: Package },
  { name: "Muhasebe", href: "/accounting", icon: TrendingUp },
];

function NavSection({
  group,
  location,
  onNavigate,
}: {
  group: NavGroup;
  location: string;
  onNavigate: (href: string) => void;
}) {
  const [open, setOpen] = useState(group.defaultOpen ?? false);

  if (!group.label) {
    return (
      <div className="mb-1">
        {group.items.map((item) => {
          const isActive = location === item.href;
          const Icon = item.icon;
          return (
            <button
              key={item.href}
              type="button"
              onClick={() => onNavigate(item.href)}
              className={cn(
                "w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-sm font-medium transition-all cursor-pointer",
                isActive
                  ? "bg-secondary text-foreground"
                  : "text-muted-foreground hover:bg-secondary/60 hover:text-foreground"
              )}
            >
              <Icon className="h-4 w-4 shrink-0" />
              <span className="flex-1 text-left">{item.name}</span>
            </button>
          );
        })}
      </div>
    );
  }

  return (
    <div className="mb-1">
      <button
        type="button"
        onClick={() => setOpen(!open)}
        className="w-full flex items-center gap-2 px-3 py-1.5 text-[10px] font-bold uppercase tracking-widest text-muted-foreground/70 hover:text-muted-foreground transition-colors"
      >
        <span className="flex-1 text-left">{group.label}</span>
        {open ? <ChevronDown className="h-3 w-3" /> : <ChevronRight className="h-3 w-3" />}
      </button>
      {open && (
        <div className="space-y-0.5">
          {group.items.map((item) => {
            const isActive =
              location === item.href ||
              (item.href !== "/" && location.startsWith(item.href));
            const Icon = item.icon;
            return (
              <button
                key={item.href}
                type="button"
                onClick={() => onNavigate(item.href)}
                className={cn(
                  "w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-sm font-medium transition-all cursor-pointer",
                  isActive
                    ? item.href === "/arya"
                      ? "bg-primary text-white shadow-md shadow-primary/20"
                      : "bg-secondary text-foreground"
                    : "text-muted-foreground hover:bg-secondary/60 hover:text-foreground"
                )}
              >
                <Icon className="h-4 w-4 shrink-0" />
                <span className="flex-1 text-left truncate">{item.name}</span>
                {item.badge && (
                  <span className="text-[9px] font-black bg-primary/20 text-primary px-1.5 py-0.5 rounded-full">
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}

export function Layout({ children }: { children: React.ReactNode }) {
  const [location, navigate] = useLocation();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const handleNavigate = (href: string) => {
    navigate(href);
    setSidebarOpen(false);
  };

  const currentName =
    NAV_GROUPS.flatMap((g) => g.items).find(
      (n) => location === n.href || (n.href !== "/" && location.startsWith(n.href))
    )?.name || "Panel";

  return (
    <div className="flex h-screen bg-background text-foreground overflow-hidden">
      {/* Mobile overlay */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 z-40 bg-black/75 md:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside
        className={cn(
          "fixed md:static inset-y-0 left-0 z-50 w-60 border-r border-border bg-card flex flex-col transition-transform duration-300 md:translate-x-0",
          sidebarOpen ? "translate-x-0" : "-translate-x-full"
        )}
      >
        {/* Logo */}
        <div className="h-14 px-4 border-b border-border flex items-center justify-between shrink-0">
          <button
            type="button"
            onClick={() => handleNavigate("/")}
            className="flex items-center gap-2 cursor-pointer"
          >
            <div className="w-7 h-7 bg-primary rounded-lg flex items-center justify-center text-white font-black text-xs">
              A
            </div>
            <div>
              <div className="font-black text-sm tracking-wide leading-none">ARYA GROSS</div>
              <div className="text-[9px] text-muted-foreground tracking-widest">ADMIN PANEL</div>
            </div>
          </button>
          <button
            type="button"
            className="md:hidden text-muted-foreground"
            onClick={() => setSidebarOpen(false)}
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Nav */}
        <nav className="flex-1 overflow-y-auto p-2 space-y-0.5">
          {NAV_GROUPS.map((group, i) => (
            <NavSection
              key={i}
              group={group}
              location={location}
              onNavigate={handleNavigate}
            />
          ))}
        </nav>

        {/* Müşteri Sitesi */}
        <div className="px-3 pb-2 shrink-0">
          <button
            type="button"
            onClick={() => handleNavigate("/magaza")}
            className="flex items-center gap-2 w-full px-3 py-2 rounded-lg bg-primary/10 hover:bg-primary/20 text-primary text-xs font-semibold transition-colors"
          >
            <span>🛒</span>
            <span>Müşteri Sitesini Gör</span>
          </button>
        </div>

        {/* Status */}
        <div className="p-3 border-t border-border shrink-0">
          <div className="flex items-center gap-2">
            <div className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse" />
            <span className="text-[10px] text-muted-foreground font-mono">SİSTEM AKTİF</span>
          </div>
        </div>
      </aside>

      {/* Main */}
      <main className="flex-1 flex flex-col overflow-hidden min-w-0">
        <header className="h-14 border-b border-border bg-card/80 backdrop-blur-md flex items-center px-4 gap-3 shrink-0 z-30">
          <button
            type="button"
            className="md:hidden text-muted-foreground p-1"
            onClick={() => setSidebarOpen(true)}
          >
            <Menu className="h-5 w-5" />
          </button>
          <div className="flex-1 min-w-0">
            <h2 className="text-xs font-mono text-muted-foreground uppercase tracking-widest truncate">
              {currentName}
            </h2>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <div className="w-1.5 h-1.5 rounded-full bg-primary animate-pulse" />
            <span className="text-[10px] font-mono text-primary hidden sm:block">CANLI</span>
          </div>
        </header>

        <div className="flex-1 overflow-y-auto pb-20 md:pb-4">
          <div className="p-4 md:p-5 max-w-7xl mx-auto">{children}</div>
        </div>
      </main>

      {/* Mobile bottom nav */}
      <nav className="fixed bottom-0 left-0 right-0 z-40 md:hidden bg-card border-t border-border">
        <div className="flex">
          {BOTTOM_NAV.map((item) => {
            const isActive =
              location === item.href ||
              (item.href !== "/" && location.startsWith(item.href));
            const Icon = item.icon;
            return (
              <button
                key={item.href}
                type="button"
                onClick={() => navigate(item.href)}
                className="flex-1"
              >
                <div
                  className={cn(
                    "flex flex-col items-center justify-center py-2 gap-0.5 transition-colors",
                    isActive ? "text-primary" : "text-muted-foreground"
                  )}
                >
                  <Icon className="h-5 w-5" />
                  <span className="text-[9px] font-medium leading-none">{item.name}</span>
                  {isActive && (
                    <div className="w-1 h-1 rounded-full bg-primary mt-0.5" />
                  )}
                </div>
              </button>
            );
          })}
        </div>
      </nav>
    </div>
  );
}
