import { Switch, Route, Router as WouterRouter, useLocation } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Layout } from "@/components/layout";
import { StoreLayout } from "@/components/store-layout";
import { setBaseUrl } from "@workspace/api-client-react";
import NotFound from "@/pages/not-found";

import Dashboard from "@/pages/dashboard";
import Arya from "@/pages/arya";
import AiBrain from "@/pages/ai-brain";
import AryaBrain from "@/pages/arya-brain";
import ApprovalAutomation from "@/pages/approval";
import AutomationCenter from "@/pages/automation-center";
import AryaOtomasyon from "@/pages/arya-otomasyon";
import AryaChat from "@/pages/arya-chat";
import SupplierImport from "@/pages/supplier-import";
import Products from "@/pages/products";
import ProductSuggestions from "@/pages/product-suggestions";
import Categories from "@/pages/categories";
import Cart from "@/pages/cart";
import Orders from "@/pages/orders";
import PaymentApproval from "@/pages/payment-approval";
import ExcelManagement from "@/pages/excel-management";
import WhatsAppOrders from "@/pages/whatsapp-orders";
import Customers from "@/pages/customers";
import Stock from "@/pages/stock";
import Campaigns from "@/pages/campaigns";
import Coupons from "@/pages/coupons";
import AdsGenerator from "@/pages/ads";
import SocialMedia from "@/pages/social-media";
import Seo from "@/pages/seo";
import Banners from "@/pages/banners";
import Accounting from "@/pages/accounting";
import Reports from "@/pages/reports";
import Content from "@/pages/content";
import Payments from "@/pages/payments";
import Delivery from "@/pages/delivery";
import Notifications from "@/pages/notifications";
import ErrorTracking from "@/pages/error-tracking";
import AiEngine from "@/pages/ai";
import SystemSettings from "@/pages/system-settings";
import Users from "@/pages/users";
import Backup from "@/pages/backup";
import Revenue from "@/pages/revenue";

import StoreHome from "@/pages/store/home";
import ProductList from "@/pages/store/product-list";
import ProductDetail from "@/pages/store/product-detail";
import StoreCart from "@/pages/store/store-cart";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: false,
      refetchOnWindowFocus: false,
      staleTime: 30000,
    },
  },
});

function Router() {
  const [location] = useLocation();

  const isStore =
    location === "/magaza" ||
    location.startsWith("/magaza/") ||
    location === "/urunler" ||
    location.startsWith("/urun/") ||
    location === "/sepet";

  if (isStore) {
    return (
      <StoreLayout>
        <Switch>
          <Route path="/magaza" component={StoreHome} />
          <Route path="/magaza/urunler" component={ProductList} />
          <Route path="/magaza/urun/:id" component={ProductDetail} />
          <Route path="/magaza/sepet" component={StoreCart} />
          <Route path="/urunler" component={ProductList} />
          <Route path="/urun/:id" component={ProductDetail} />
          <Route path="/sepet" component={StoreCart} />
          <Route component={NotFound} />
        </Switch>
      </StoreLayout>
    );
  }

  return (
    <Layout>
      <Switch>
        <Route path="/" component={Dashboard} />
        <Route path="/arya" component={Arya} />
        <Route path="/ai-brain" component={AiBrain} />
        <Route path="/arya-brain" component={AryaBrain} />
        <Route path="/arya-chat" component={AryaChat} />
        <Route path="/arya-otomasyon" component={AryaOtomasyon} />
        <Route path="/supplier-import" component={SupplierImport} />
        <Route path="/approval" component={ApprovalAutomation} />
        <Route path="/automation-center" component={AutomationCenter} />

        <Route path="/orders" component={Orders} />
        <Route path="/payment-approval" component={PaymentApproval} />
        <Route path="/whatsapp-orders" component={WhatsAppOrders} />
        <Route path="/customers" component={Customers} />

        <Route path="/products" component={Products} />
        <Route path="/product-suggestions" component={ProductSuggestions} />
        <Route path="/categories" component={Categories} />
        <Route path="/stock" component={Stock} />
        <Route path="/cart" component={Cart} />

        <Route path="/campaigns" component={Campaigns} />
        <Route path="/coupons" component={Coupons} />
        <Route path="/ads" component={AdsGenerator} />
        <Route path="/social-media" component={SocialMedia} />
        <Route path="/seo" component={Seo} />
        <Route path="/banners" component={Banners} />

        <Route path="/accounting" component={Accounting} />
        <Route path="/reports" component={Reports} />
        <Route path="/excel-management" component={ExcelManagement} />
        <Route path="/revenue" component={Revenue} />

        <Route path="/content" component={Content} />
        <Route path="/payments" component={Payments} />
        <Route path="/delivery" component={Delivery} />
        <Route path="/notifications" component={Notifications} />
        <Route path="/error-tracking" component={ErrorTracking} />
        <Route path="/ai" component={AiEngine} />
        <Route path="/system-settings" component={SystemSettings} />
        <Route path="/users" component={Users} />
        <Route path="/backup" component={Backup} />

        <Route component={NotFound} />
      </Switch>
    </Layout>
  );
}

if (import.meta.env.VITE_API_URL) {
  setBaseUrl(import.meta.env.VITE_API_URL as string);
}

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base="/">
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}