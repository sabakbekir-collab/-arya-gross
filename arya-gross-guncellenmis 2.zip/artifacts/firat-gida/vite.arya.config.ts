import { defineConfig, mergeConfig, type ConfigEnv, type UserConfig } from "vite";
import baseConfigExport from "./vite.config";

export default defineConfig(async (env: ConfigEnv): Promise<UserConfig> => {
  const base = typeof baseConfigExport === "function"
    ? await baseConfigExport(env)
    : await baseConfigExport;

  return mergeConfig(base ?? {}, {
    server: {
      host: "0.0.0.0",
      port: 18733,
      strictPort: true,
      proxy: {
        "/api": {
          target: "http://127.0.0.1:8080",
          changeOrigin: true,
          secure: false,
        },
      },
    },
    preview: {
      host: "0.0.0.0",
      port: 18733,
      strictPort: true,
    },
  });
});
