#!/usr/bin/env bash
set -e

ROOT_DIR="$(cd "$(dirname "$0")/../../.." && pwd)"
FRONT_DIR="$ROOT_DIR/artifacts/firat-gida"
API_DIR="$ROOT_DIR/artifacts/api-server"

echo "=================================================="
echo " ARYA GROSS TEMİZ BAŞLATMA"
echo "=================================================="

echo "Eski çalışan Vite/API süreçleri kapatılıyor..."
pkill -9 -f "vite" 2>/dev/null || true
pkill -9 -f "tsx" 2>/dev/null || true
pkill -9 -f "api-server" 2>/dev/null || true

sleep 3

echo "API başlatılıyor..."
cd "$API_DIR"
PORT=8080 pnpm run dev > /tmp/arya-api.log 2>&1 &

sleep 6

echo "API kontrol ediliyor..."
curl -sS --max-time 10 http://localhost:8080/api/products/admin-real-rules || {
  echo ""
  echo "API başlamadı. Log:"
  cat /tmp/arya-api.log
  exit 1
}

echo ""
echo "API çalışıyor ✅"

echo "Frontend başlatılıyor..."
cd "$FRONT_DIR"

./node_modules/.bin/vite --config vite.config.ts --host 0.0.0.0
