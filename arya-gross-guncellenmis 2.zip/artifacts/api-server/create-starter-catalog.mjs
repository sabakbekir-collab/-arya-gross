import * as XLSX from "xlsx";

const cats = {
"Çay Kahve":["Çaykur Tiryaki Çay 1kg","Çaykur Rize Çayı 1kg","Doğuş Çay 1kg","Lipton Çay 1kg","Ofçay 1kg","Altınbaşak Çay 1kg","Altın Filiz Çay 1kg","Türk Kahvesi 100g","Nescafe 200g","Jacobs 200g","Filtre Kahve 250g","Dibek Kahvesi","Yeşil Çay","Adaçayı","Ihlamur","Çaykur Tomurcuk","Bergamot Çay","Ekonomik Çay","Kakao 100g","Sahlep 200g"],
"Bakliyat":["Kırmızı Mercimek 1kg","Yeşil Mercimek 1kg","Nohut 1kg","Kuru Fasulye 1kg","Baldo Pirinç 1kg","Bulgur 1kg","Osmancık Pirinç","Barbunya","Mısır","Buğday","Yarma","Sarı Mercimek","Cin Mısır","Dermason Fasulye","Maş Fasulyesi","Pirinç 2.5kg","Bulgur 2.5kg","Nohut 2.5kg","Mercimek 2.5kg","Bakliyat Paketi"],
"Teknoloji":["Type-C Kablo","Lightning Kablo","Micro USB Kablo","20W Adaptör","Araç Şarj","Powerbank 10000","Bluetooth Kulaklık","Kablosuz Mouse","Mousepad","USB 32GB","USB 64GB","Micro SD 32GB","Telefon Standı","Ring Light","Mini Tripod","HDMI Kablo","Kulaklık Dönüştürücü","Bluetooth Hoparlör","Akıllı Saat","Webcam"],
"Temizlik":["Fairy 650ml","Pril 675ml","Domestos 750ml","Yumoş 1.4L","Ariel 5kg","Omo 5kg","Persil Jel","Cif Krem","Sünger 5li","Çöp Torbası","Streç Film","Alüminyum Folyo","Bulaşık Tableti","Yüzey Temizleyici","Cam Temizleyici","Sıvı Sabun","Banyo Temizleyici","Mutfak Temizleyici","Kireç Çözücü","Yağ Çözücü"],
"Bebek":["Sleepy Islak Mendil","Molfix 4 Numara","Prima 4 Numara","Sleepy 5 Numara","Dalin Şampuan","Bebek Pudrası","Bebek Yağı","Bebek Sabunu","Bebek Losyonu","Emzik","Biberon","Bebek Deterjanı","Islak Havlu","Pişik Kremi","Tırnak Makası","Kulak Çubuğu","Mama Önlüğü","Diş Kaşıyıcı","Bakım Seti","Bebek Pamuk"],
"Kağıt":["Papia 16lı","Papia Havlu 12li","Selpak Mendil","Solo 12li","Familia Havlu","Rulo Havlu","Peçete 100lü","Islak Tuvalet Kağıdı","Mutfak Havlusu","Tuvalet Kağıdı 32li","Dispenser Peçete","Kutulu Mendil","Mini Peçete","Kağıt Bardak","Karton Tabak","Karton Bardak","Pişirme Kağıdı","Yağlı Kağıt","Buzdolabı Poşeti","Kilitli Poşet"],
"Makarna Un":["Burgu Makarna","Spagetti","Penne","Mantı Makarna","Fiyonk Makarna","Arpa Şehriye","Tel Şehriye","Un 5kg","Un 2kg","Tam Buğday Unu","Mısır Unu","Galeta Unu","İrmik","Nişasta","Kabartma Tozu","Vanilin","Pudra Şekeri","Pasta Unu","Kek Unu","Mantı Unu"],
"Salça Konserve":["Domates Salçası","Biber Salçası","Konserve Mısır","Ton Balığı","Bezelye","Garnitür","Turşu","Kornişon","Mercimek Çorbası","Ezogelin Çorbası","Menemen Harcı","Domates Sosu","Ketçap","Mayonez","Hardal","Acı Sos","Nar Ekşisi","Sirke","Limon Sosu","Konserve Fasulye"],
"Kahvaltılık":["Nutella 400g","Krem Çikolata","Bal 850g","Tahin 600g","Pekmez 800g","Çilek Reçeli","Vişne Reçeli","Fındık Kreması","Kaşar Peyniri","Beyaz Peynir","Zeytin 1kg","Siyah Zeytin","Yeşil Zeytin","Tereyağı","Krem Peynir","Labne","Helva","Yumurta 30lu","Süt 1L","Kakaolu Süt"],
"İçecek Atıştırmalık":["Coca Cola 1L","Fanta 1L","Sprite 1L","Pepsi 1L","Ayran 1L","Maden Suyu 6lı","Meyve Suyu 1L","Ice Tea 1L","Enerji İçeceği","Su 6lı","Çikolatalı Gofret","Burçak Bisküvi","Ülker Bisküvi","Çubuk Kraker","Cips","Pop Kek","Kek 10lu","Fındıklı Çikolata","Sakız","Lokum"]
};

let id = 200000;
const rows = [];
for (const [category, arr] of Object.entries(cats)) {
  for (const name of arr) {
    id++;
    const tech = category === "Teknoloji";
    const cost = tech ? 90 + (id % 260) : 20 + (id % 120);
    const sale = Math.ceil((cost + 20 + cost * 0.08) * 1.28);
    rows.push({
      name, brand: name.split(" ")[0], category, barcode: `FG${id}`,
      supplierName: tech ? "Tekno Tedarik Havuzu" : "Fırat Gıda Tedarik Havuzu",
      supplierUrl: `https://www.hepsiburada.com/firat-gida/${encodeURIComponent(name.toLowerCase().replaceAll(" ","-"))}-pm-HBC${id}`,
      imageUrl: `https://cdn.dsmcdn.com/ty${(id%9)+1}/product/media/images/20240101/${id}/${id}/${id}/${id}_org_zoom.jpg`,
      supplierPrice: cost, suggestedSalePrice: sale, stock: 30 + (id % 70), shippingDays: tech ? 3 : 2
    });
  }
}
const ws = XLSX.utils.json_to_sheet(rows);
const wb = XLSX.utils.book_new();
XLSX.utils.book_append_sheet(wb, ws, "Tedarikçiler");
XLSX.writeFile(wb, "firat_gida_200_urun.xlsx");
console.log("Hazır:", rows.length);
