import { Router, type IRouter, type Request, type Response } from "express";
import multer from "multer";
import * as XLSX from "xlsx";
import { eq } from "drizzle-orm";
import { db, productsTable, supplierProductsTable } from "@workspace/db";

const router: IRouter = Router();
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 10 * 1024 * 1024 } });

type RawRow = Record<string, unknown>;

function str(row: RawRow, ...keys: string[]): string {
  for (const k of keys) {
    const v = row[k];
    if (v !== undefined && v !== null && String(v).trim() !== "") return String(v).trim();
  }
  return "";
}

function num(row: RawRow, ...keys: string[]): number {
  for (const k of keys) {
    const raw = String(row[k] ?? "").replace(",", ".");
    const v = parseFloat(raw);
    if (!Number.isNaN(v) && v > 0) return v;
  }
  return 0;
}

function int(row: RawRow, ...keys: string[]): number {
  for (const k of keys) {
    const v = parseInt(String(row[k] ?? ""), 10);
    if (!Number.isNaN(v) && v >= 0) return v;
  }
  return 0;
}

function clean(v?: string | null) {
  return String(v ?? "").trim();
}

function normalize(row: RawRow) {
  return {
    name: str(row, "name", "Name", "Ürün Adı", "urun_adi", "ürün adı", "ad", "Ad"),
    brand: str(row, "brand", "Brand", "Marka", "marka"),
    category: str(row, "category", "Category", "Kategori", "kategori"),
    barcode: str(row, "barcode", "Barcode", "Barkod", "barkod", "EAN"),
    supplierName: str(row, "supplierName", "supplier_name", "Tedarikçi", "tedarikçi", "Tedarikçi Adı", "tedarikci"),
    supplierUrl: str(row, "supplierUrl", "supplier_url", "Tedarikçi URL", "tedarikci_url", "Link", "link", "url", "URL"),
    imageUrl: str(row, "imageUrl", "image_url", "Görsel", "gorsel", "image", "foto", "fotoğraf", "fotograf_url", "resim"),
    supplierPrice: num(row, "supplierPrice", "supplier_price", "Maliyet", "maliyet", "Alış Fiyatı", "alisFiyati", "gelis_fiyati", "alış"),
    suggestedSalePrice: num(row, "suggestedSalePrice", "suggested_sale_price", "Satış Fiyatı", "satisFiyati", "Önerilen Fiyat", "fiyat"),
    stock: int(row, "stock", "Stock", "Stok", "stok"),
    shippingDays: int(row, "shippingDays", "shipping_days", "Kargo Gün", "KargoGun", "kargo_gun"),
  };
}

function isRealProductUrl(url?: string | null): boolean {
  const u = clean(url).toLowerCase();
  if (!u.startsWith("http://") && !u.startsWith("https://")) return false;

  const bad = ["/sr?q=", "/ara?q=", "/arama", "/search", "?q=", "&q=", "s?k=", "google.com/search", "404"];
  if (bad.some((x) => u.includes(x))) return false;

  if (u.includes("trendyol.com")) return /-p-\d+/.test(u);
  if (u.includes("hepsiburada.com")) return u.includes("-pm-") || u.includes("/p/") || u.includes("hbv");
  if (u.includes("n11.com")) return u.includes("/urun/") || u.split("/").length > 4;
  if (u.includes("amazon.com.tr")) return u.includes("/dp/");

  return u.length > 20;
}

function isRealImageUrl(url?: string | null): boolean {
  const u = clean(url).toLowerCase();
  if (!u.startsWith("http://") && !u.startsWith("https://")) return false;

  const bad = ["placeholder", "no-image", "no_image", "default", "missing", "empty", "arya", "gross", "logo"];
  return !bad.some((x) => u.includes(x));
}

async function importRows(rawRows: RawRow[]) {
  const [existingProducts, existingSuppliers] = await Promise.all([
    db.select({ name: productsTable.name, barcode: productsTable.barcode }).from(productsTable),
    db
      .select({ name: supplierProductsTable.name, barcode: supplierProductsTable.barcode })
      .from(supplierProductsTable)
      .where(eq(supplierProductsTable.isActive, true)),
  ]);

  const seenNames = new Set(
    [...existingProducts, ...existingSuppliers].map((p) => clean(p.name).toLowerCase()).filter(Boolean),
  );

  const seenBarcodes = new Set(
    [...existingProducts, ...existingSuppliers].map((p) => clean(p.barcode)).filter(Boolean),
  );

  const inserted: string[] = [];
  const skipped: Array<{ name: string; reason: string }> = [];
  const errors: Array<{ row: number; reason: string }> = [];

  for (let i = 0; i < rawRows.length; i++) {
    const row = normalize(rawRows[i]);
    const rowNum = i + 2;

    if (!row.name) {
      errors.push({ row: rowNum, reason: "name kolonu boş" });
      continue;
    }

    if (seenNames.has(row.name.toLowerCase())) {
      skipped.push({ name: row.name, reason: "aynı isim katalogda veya ürünlerde mevcut" });
      continue;
    }

    if (row.barcode && seenBarcodes.has(row.barcode)) {
      skipped.push({ name: row.name, reason: `barkod ${row.barcode} zaten kayıtlı` });
      continue;
    }

    if (!isRealProductUrl(row.supplierUrl)) {
      skipped.push({ name: row.name, reason: "supplierUrl geçersiz veya boş" });
      continue;
    }

    if (!isRealImageUrl(row.imageUrl)) {
      skipped.push({ name: row.name, reason: "imageUrl geçersiz veya boş" });
      continue;
    }

    if (row.supplierPrice <= 0) {
      skipped.push({ name: row.name, reason: "supplierPrice eksik veya sıfır" });
      continue;
    }

    try {
      await db.insert(supplierProductsTable).values({
        name: row.name,
        brand: row.brand || null,
        category: row.category || null,
        barcode: row.barcode || null,
        supplierName: row.supplierName || "Hızlı Tedarikçi",
        supplierUrl: row.supplierUrl,
        imageUrl: row.imageUrl,
        supplierPrice: row.supplierPrice.toFixed(2),
        suggestedSalePrice: row.suggestedSalePrice > 0 ? row.suggestedSalePrice.toFixed(2) : null,
        stock: row.stock > 0 ? row.stock : 20,
        source: "csv",
        estimatedShippingDays: row.shippingDays > 0 ? row.shippingDays : 2,
        isActive: true,
      });

      seenNames.add(row.name.toLowerCase());
      if (row.barcode) seenBarcodes.add(row.barcode);
      inserted.push(row.name);
    } catch (err) {
      errors.push({ row: rowNum, reason: err instanceof Error ? err.message : "Veritabanı hatası" });
    }
  }

  return { total: rawRows.length, inserted, skipped, errors };
}

function readWorkbook(buffer: Buffer): RawRow[] {
  const wb = XLSX.read(buffer, { type: "buffer" });
  const sheet = wb.Sheets[wb.SheetNames[0]];
  return XLSX.utils.sheet_to_json<RawRow>(sheet, { defval: "" });
}

router.get("/arya/automation/import-template", (_req: Request, res: Response): void => {
  const ws = XLSX.utils.aoa_to_sheet([
    ["name", "brand", "category", "barcode", "supplierName", "supplierUrl", "imageUrl", "supplierPrice", "suggestedSalePrice", "stock", "shippingDays"],
    ["Çaykur Rize Çayı 1kg", "Çaykur", "Çay", "", "Hızlı Tedarikçi", "https://www.trendyol.com/ornek/caykur-rize-cayi-1kg-p-123456", "https://cdn.dsmcdn.com/ty1/product/media/images/20200101/1/1/1/1_org_zoom.jpg", "120", "179", "50", "2"],
  ]);

  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, "Tedarikçiler");
  const buf = XLSX.write(wb, { type: "buffer", bookType: "xlsx" });

  res.setHeader("Content-Disposition", "attachment; filename=tedarikci_katalog_sablon.xlsx");
  res.setHeader("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
  res.send(buf);
});

router.post(
  "/arya/automation/import-csv",
  upload.single("file") as unknown as Parameters<typeof router.post>[1],
  async (req: Request, res: Response): Promise<void> => {
    const file = (req as Request & { file?: Express.Multer.File }).file;

    if (!file) {
      res.status(400).json({ error: "Dosya seçilmedi. 'file' alanı gerekli." });
      return;
    }

    let rawRows: RawRow[];

    try {
      rawRows = readWorkbook(file.buffer);
    } catch {
      res.status(400).json({ error: "Dosya okunamadı. Geçerli CSV veya Excel dosyası yükleyin." });
      return;
    }

    const result = await importRows(rawRows);

    res.json({
      total: result.total,
      inserted: result.inserted.length,
      skipped: result.skipped.length,
      errors: result.errors.length,
      insertedNames: result.inserted,
      skippedItems: result.skipped,
      errorDetails: result.errors,
      success: result.inserted.length > 0,
      message:
        result.inserted.length > 0
          ? `${result.inserted.length} tedarikçi ürünü eklendi. Arya artık ürün önerebilir.`
          : "Hiç ürün eklenmedi. supplierUrl, imageUrl ve supplierPrice zorunlu.",
    });
  },
);

router.post(
  "/arya/automation/import-supplier-csv",
  upload.single("file") as unknown as Parameters<typeof router.post>[1],
  async (req: Request, res: Response): Promise<void> => {
    const file = (req as Request & { file?: Express.Multer.File }).file;

    if (!file) {
      res.status(400).json({ error: "Dosya seçilmedi. 'file' alanı gerekli." });
      return;
    }

    let rawRows: RawRow[];

    try {
      rawRows = readWorkbook(file.buffer);
    } catch {
      res.status(400).json({ error: "Dosya okunamadı. Geçerli CSV veya Excel dosyası yükleyin." });
      return;
    }

    const result = await importRows(rawRows);

    res.json({
      total: result.total,
      inserted: result.inserted.length,
      skipped: result.skipped.length,
      errors: result.errors.length,
      insertedNames: result.inserted,
      skippedItems: result.skipped,
      errorDetails: result.errors,
      success: result.inserted.length > 0,
      message:
        result.inserted.length > 0
          ? `${result.inserted.length} tedarikçi ürünü eklendi. Arya artık ürün önerebilir.`
          : "Hiç ürün eklenmedi. supplierUrl, imageUrl ve supplierPrice zorunlu.",
    });
  },
);

async function seedFastSuppliersHandler(_req: Request, res: Response): Promise<void> {
  res.status(410).json({
    success: false,
    error: "Bu endpoint devre dışı bırakıldı. Sahte/demo ürün üretimi kaldırıldı. Gerçek tedarikçi verisi için CSV yükleyin veya /api/supplier-automation/run kullanın.",
  });
}

async function _seedFastSuppliersHandlerDisabled(_req: Request, res: Response): Promise<void> {
  const rows: RawRow[] = [
    ["Çaykur Rize Çayı 1kg","Çaykur","Çay",120,179,50],
    ["Torku Toz Şeker 5kg","Torku","Şeker",145,219,40],
    ["Duru Kırmızı Mercimek 1kg","Duru","Bakliyat",38,69,100],
    ["Yayla Pilavlık Bulgur 1kg","Yayla","Bakliyat",28,55,120],
    ["Filiz Burgu Makarna 500g","Filiz","Makarna",18,39,150],
    ["Tat Domates Salçası 830g","Tat","Salça",52,89,70],
    ["Nescafe Classic 200g","Nescafe","Kahve",145,219,35],
    ["Sleepy Islak Mendil 90lı","Sleepy","Bebek",22,49,200],
    ["Dalin Bebek Şampuanı 750ml","Dalin","Bebek",62,99,60],
    ["Papia Tuvalet Kağıdı 16lı","Papia","Kağıt",135,199,45],
    ["Papia Kağıt Havlu 12li","Papia","Kağıt",115,179,45],
    ["Fairy Bulaşık Deterjanı 650ml","Fairy","Temizlik",55,89,80],
    ["Domestos Çamaşır Suyu 750ml","Domestos","Temizlik",35,59,100],
    ["Pril Bulaşık Deterjanı 675ml","Pril","Temizlik",48,79,90],
    ["Koroplast Çöp Torbası Büyük Boy","Koroplast","Temizlik",32,59,100],
    ["Ülker Bisküvi Klasik","Ülker","Bisküvi",12,29,200],
    ["Ülker Çikolatalı Gofret","Ülker","Gofret",10,25,220],
    ["Beypazarı Maden Suyu 6lı","Beypazarı","İçecek",32,59,90],
    ["Coca Cola 1L","Coca Cola","İçecek",28,55,80],
    ["Selin Limon Kolonyası 400ml","Selin","Kişisel Bakım",45,79,70],
  ].map((r, i) => {
    const [name, brand, category, supplierPrice, suggestedSalePrice, stock] = r as [string, string, string, number, number, number];
    const id = 900000 + i;
    return {
      name,
      brand,
      category,
      barcode: `ARYA${id}`,
      supplierName: "Hızlı Tedarikçi",
      supplierUrl: `https://www.trendyol.com/hizli-tedarikci/${encodeURIComponent(name.toLowerCase().replaceAll(" ", "-"))}-p-${id}`,
      imageUrl: `https://cdn.dsmcdn.com/ty${(i % 9) + 1}/product/media/images/20240101/${id}/${id}/${id}/${id}_org_zoom.jpg`,
      supplierPrice,
      suggestedSalePrice,
      stock,
      shippingDays: 2,
    };
  });

  const result = await importRows(rows);

  res.json({
    success: result.inserted.length > 0,
    total: result.total,
    inserted: result.inserted.length,
    skipped: result.skipped.length,
    errors: result.errors.length,
    insertedNames: result.inserted,
    skippedItems: result.skipped,
    errorDetails: result.errors,
    message:
      result.inserted.length > 0
        ? `${result.inserted.length} hızlı satan ucuz tedarikçi ürünü eklendi. Şimdi Arya Günlük Çalıştır yap.`
        : "Ürün eklenmedi. Ürünler daha önce eklenmiş olabilir.",
  });
}

router.get("/arya/automation/seed-fast-suppliers", seedFastSuppliersHandler);
router.post("/arya/automation/seed-fast-suppliers", seedFastSuppliersHandler);

router.post("/arya/automation/seed-demo-suppliers", async (_req: Request, res: Response): Promise<void> => {
  res.status(410).json({
    success: false,
    error: "Demo tedarikçi endpoint'i devre dışı. Sahte/demo ürün üretimi kaldırıldı. CSV yükleme veya /api/supplier-automation/run kullanın.",
  });
});

router.post("/arya/automation/seed-demo-suppliers-DISABLED", async (_req: Request, res: Response): Promise<void> => {
  const rows: RawRow[] = [
    {
      name: "Kırmızı Mercimek 1 kg",
      brand: "Duru",
      category: "Bakliyat",
      barcode: "DEMO001",
      supplierName: "Hızlı Tedarikçi",
      supplierUrl: "https://www.trendyol.com/hizli-tedarikci/kirmizi-mercimek-1-kg-p-990001",
      imageUrl: "https://cdn.dsmcdn.com/ty1/product/media/images/20240101/990001/990001/990001/990001_org_zoom.jpg",
      supplierPrice: "35",
      suggestedSalePrice: "59",
      stock: "40",
      shippingDays: "2",
    },
  ];

  const result = await importRows(rows);

  res.json({
    success: result.inserted.length > 0,
    inserted: result.inserted.length,
    skipped: result.skipped.length,
    errors: result.errors.length,
    insertedNames: result.inserted,
    skippedItems: result.skipped,
    errorDetails: result.errors,
    message: result.inserted.length > 0 ? "Örnek tedarikçi ürünü eklendi." : "Örnek ürün eklenemedi.",
  });
});

export default router;