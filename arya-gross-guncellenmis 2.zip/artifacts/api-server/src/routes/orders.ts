import { Router, type IRouter, type Request, type Response } from "express";
import { and, desc, eq, gte, sql } from "drizzle-orm";
import { db, ordersTable, productsTable } from "@workspace/db";
import {
  CreateOrderBody,
  GetOrderParams,
  GetOrderResponse,
  ListOrdersQueryParams,
  ListOrdersResponse,
  UpdateOrderPaymentStatusBody,
  UpdateOrderPaymentStatusParams,
  UpdateOrderPaymentStatusResponse,
  UpdateOrderStatusBody,
  UpdateOrderStatusParams,
  UpdateOrderStatusResponse,
} from "@workspace/api-zod";
import { clearCartForSession, getCartSessionId } from "./cart";

const router: IRouter = Router();
const FREE_SHIPPING_LIMIT = 500;
const SHIPPING_FEE = 49.9;

type OrderRow = typeof ordersTable.$inferSelect;

function toIso(value: unknown): string | null {
  if (value === null || value === undefined || value === "") return null;
  if (value instanceof Date) return value.toISOString();
  const date = new Date(String(value));
  return Number.isNaN(date.getTime()) ? null : date.toISOString();
}

function formatOrder(row: OrderRow) {
  const rawItems = Array.isArray(row.items) ? row.items : [];
  return {
    ...row,
    total: Number(row.total),
    profitEstimate:
      row.profitEstimate === null || row.profitEstimate === undefined
        ? null
        : Number(row.profitEstimate),
    paymentConfirmedAt: toIso(row.paymentConfirmedAt),
    items: rawItems.map((item) => ({
      productId: Number(item.productId),
      name: String(item.name),
      price: Number(item.price),
      quantity: Number(item.quantity),
      subtotal: Number(item.subtotal),
    })),
    createdAt: toIso(row.createdAt) ?? new Date(0).toISOString(),
  };
}

function requiredText(value: unknown, field: string): string {
  const result = String(value ?? "").trim();
  if (!result) throw new Error(`${field} zorunludur.`);
  return result;
}

router.get("/orders", async (req: Request, res: Response): Promise<void> => {
  try {
    const query = ListOrdersQueryParams.safeParse(req.query);
    if (!query.success) {
      res.status(400).json({ error: query.error.message });
      return;
    }

    let rows = await db.select().from(ordersTable).orderBy(desc(ordersTable.createdAt));
    if (query.data.status) rows = rows.filter((row) => row.status === query.data.status);

    res.json(ListOrdersResponse.parse(rows.map(formatOrder)));
  } catch (error) {
    res.status(500).json({ error: error instanceof Error ? error.message : String(error) });
  }
});

router.post("/orders", async (req: Request, res: Response): Promise<void> => {
  try {
    const parsed = CreateOrderBody.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: parsed.error.message });
      return;
    }

    if (parsed.data.items.length === 0) {
      res.status(400).json({ error: "Sepet boş olamaz." });
      return;
    }

    const customerName = requiredText(parsed.data.customerName, "Ad soyad");
    const customerPhone = requiredText(parsed.data.customerPhone, "Telefon");
    const address = requiredText(parsed.data.address, "Teslimat adresi");

    const orderItems: Array<{
      productId: number;
      name: string;
      price: number;
      quantity: number;
      subtotal: number;
    }> = [];
    const stockChanges: Array<{ id: number; stock: number; quantity: number }> = [];
    let subtotal = 0;

    for (const item of parsed.data.items) {
      const quantity = Math.max(1, Math.floor(item.quantity));
      const [product] = await db
        .select()
        .from(productsTable)
        .where(eq(productsTable.id, item.productId));

      if (!product || !product.isActive || (product.productStatus && product.productStatus !== "active")) {
        res.status(404).json({ error: `Satışta olan ürün bulunamadı: ${item.productId}` });
        return;
      }
      if (product.stock < quantity) {
        res.status(400).json({ error: `${product.name} için yeterli stok yok.` });
        return;
      }

      const price = Number(product.price);
      const itemSubtotal = Number((price * quantity).toFixed(2));
      subtotal += itemSubtotal;
      orderItems.push({ productId: product.id, name: product.name, price, quantity, subtotal: itemSubtotal });
      stockChanges.push({ id: product.id, stock: product.stock, quantity });
    }

    const shipping = subtotal >= FREE_SHIPPING_LIMIT ? 0 : SHIPPING_FEE;
    const total = Number((subtotal + shipping).toFixed(2));
    const paymentMethod = String(parsed.data.paymentMethod ?? "kapida").trim() || "kapida";
    const paymentStatus = ["havale", "bank_transfer"].includes(paymentMethod)
      ? "havale-bekleniyor"
      : "odeme-bekleniyor";

    const [order] = await db.transaction(async (tx) => {
      for (const change of stockChanges) {
        const updated = await tx
          .update(productsTable)
          .set({ stock: sql` - ` })
          .where(and(eq(productsTable.id, change.id), gte(productsTable.stock, change.quantity)))
          .returning({ id: productsTable.id });
        if (updated.length !== 1) throw new Error("Stok sipariş sırasında değişti. Lütfen sepetinizi yenileyin.");
      }
      return tx.insert(ordersTable).values({
        customerName, customerEmail: String(parsed.data.customerEmail ?? "").trim() || null, customerPhone, address,
        notes: String(parsed.data.notes ?? "").trim() || null, paymentMethod, paymentStatus,
        orderType: String(parsed.data.orderType ?? "normal").trim() || "normal",
        adminApprovalStatus: "bekliyor", sourcingStatus: "bekliyor", status: "beklemede", total: total.toFixed(2), items: orderItems,
      }).returning();
    });
    await clearCartForSession(getCartSessionId(req, res));

    res.status(201).json(GetOrderResponse.parse(formatOrder(order)));
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    const status = message.endsWith("zorunludur.") ? 400 : 500;
    res.status(status).json({ error: message });
  }
});

router.get("/orders/:id", async (req: Request, res: Response): Promise<void> => {
  try {
    const params = GetOrderParams.safeParse(req.params);
    if (!params.success) {
      res.status(400).json({ error: params.error.message });
      return;
    }

    const [row] = await db.select().from(ordersTable).where(eq(ordersTable.id, params.data.id));
    if (!row) {
      res.status(404).json({ error: "Sipariş bulunamadı" });
      return;
    }
    res.json(GetOrderResponse.parse(formatOrder(row)));
  } catch (error) {
    res.status(500).json({ error: error instanceof Error ? error.message : String(error) });
  }
});

router.patch("/orders/:id/status", async (req: Request, res: Response): Promise<void> => {
  try {
    const params = UpdateOrderStatusParams.safeParse(req.params);
    const parsed = UpdateOrderStatusBody.safeParse(req.body);
    if (!params.success || !parsed.success) {
      res.status(400).json({ error: !params.success ? params.error.message : parsed.error.message });
      return;
    }

    const [row] = await db
      .update(ordersTable)
      .set({
        status: parsed.data.status,
        ...(parsed.data.adminApprovalStatus !== undefined
          ? { adminApprovalStatus: parsed.data.adminApprovalStatus }
          : {}),
        ...(parsed.data.sourcingStatus !== undefined
          ? { sourcingStatus: parsed.data.sourcingStatus }
          : {}),
        ...(parsed.data.supplierPurchaseStatus !== undefined
          ? { supplierPurchaseStatus: parsed.data.supplierPurchaseStatus }
          : {}),
      })
      .where(eq(ordersTable.id, params.data.id))
      .returning();

    if (!row) {
      res.status(404).json({ error: "Sipariş bulunamadı" });
      return;
    }

    res.json(UpdateOrderStatusResponse.parse(formatOrder(row)));
  } catch (error) {
    res.status(500).json({ error: error instanceof Error ? error.message : String(error) });
  }
});

router.patch("/orders/:id/payment-status", async (req: Request, res: Response): Promise<void> => {
  try {
    const params = UpdateOrderPaymentStatusParams.safeParse(req.params);
    const parsed = UpdateOrderPaymentStatusBody.safeParse(req.body);
    if (!params.success || !parsed.success) {
      res.status(400).json({ error: !params.success ? params.error.message : parsed.error.message });
      return;
    }

    if (!parsed.data.paymentStatus && !parsed.data.decontStatus && !parsed.data.paymentConfirmedBy) {
      res.status(400).json({ error: "Güncellenecek ödeme alanı gönderilmedi." });
      return;
    }

    const [row] = await db
      .update(ordersTable)
      .set({
        ...(parsed.data.paymentStatus !== undefined
          ? { paymentStatus: parsed.data.paymentStatus }
          : {}),
        ...(parsed.data.decontStatus !== undefined
          ? { decontStatus: parsed.data.decontStatus }
          : {}),
        ...(parsed.data.paymentConfirmedBy !== undefined
          ? {
              paymentConfirmedBy: parsed.data.paymentConfirmedBy,
              paymentConfirmedAt: new Date(),
              ...(parsed.data.paymentStatus === "odendi"
                ? { adminApprovalStatus: "onaylandi" }
                : {}),
            }
          : {}),
      })
      .where(eq(ordersTable.id, params.data.id))
      .returning();

    if (!row) {
      res.status(404).json({ error: "Sipariş bulunamadı" });
      return;
    }

    res.json(UpdateOrderPaymentStatusResponse.parse(formatOrder(row)));
  } catch (error) {
    res.status(500).json({ error: error instanceof Error ? error.message : String(error) });
  }
});

export default router;
