import { Router, type IRouter } from "express";
import { eq, desc } from "drizzle-orm";
import { db, productsTable, ordersTable, categoriesTable } from "@workspace/db";

const router: IRouter = Router();

function normalize(s: string) {
  return s.toLowerCase().trim().replace(/\s+/g, " ");
}

function isBadTrendyolUrl(url: string | null | undefined): boolean {
  if (!url) return false;
  const trimmed = url.trim();
  return trimmed === "https://www.trendyol.com" || trimmed === "https://www.trendyol.com/";
}

router.get("/ai-brain/analysis", async (_req, res): Promise<void> => {
  const [products, orders, categories] = await Promise.all([
    db.select().from(productsTable),
    db.select().from(ordersTable).orderBy(desc(ordersTable.createdAt)),
    db.select().from(categoriesTable),
  ]);

  const activeProducts = products.filter(p => p.productStatus === "active" || p.isActive);

  const criticalIssues: Array<{
    id: string; title: string; description: string; severity: "critical" | "warning" | "info";
    count: number; affectedProducts: Array<{ id: number; name: string }>;
    suggestedAction: string; actionType: string | null; actionData: Record<string, unknown> | null;
  }> = [];

  const productIssues: typeof criticalIssues = [];
  const stockWarnings: typeof criticalIssues = [];
  const profitOpportunities: typeof criticalIssues = [];
  const storeAppearance: typeof criticalIssues = [];
  const dailyTasks: Array<{ id: string; title: string; description: string; priority: "high" | "medium" | "low" }> = [];

  let deductions = 0;

  const activeNoImage = activeProducts.filter(p => !p.imageUrl || !p.imageUrl.startsWith("http"));
  if (activeNoImage.length > 0) {
    deductions += Math.min(activeNoImage.length * 10, 30);
    criticalIssues.push({
      id: "active-no-image",
      title: "Görselsiz Yayındaki Ürünler",
      description: `${activeNoImage.length} ürün yayında ama geçerli görseli yok. Müşteriler görselsiz ürün almaz.`,
      severity: "critical",
      count: activeNoImage.length,
      affectedProducts: activeNoImage.map(p => ({ id: p.id, name: p.name })),
      suggestedAction: "Bu ürünleri taslak durumuna al (draft) — görsel eklenince tekrar yayınla",
      actionType: "set-draft",
      actionData: { ids: activeNoImage.map(p => p.id) },
    });
  }

  const badTrendyolProducts = products.filter(p => isBadTrendyolUrl(p.supplierProductUrl));
  if (badTrendyolProducts.length > 0) {
    deductions += Math.min(badTrendyolProducts.length * 5, 20);
    criticalIssues.push({
      id: "bad-trendyol-url",
      title: "Hatalı Trendyol Linkleri",
      description: `${badTrendyolProducts.length} üründe satıcı linki ana sayfaya gidiyor. Ürün adına göre arama linkine çevrilmeli.`,
      severity: "critical",
      count: badTrendyolProducts.length,
      affectedProducts: badTrendyolProducts.map(p => ({ id: p.id, name: p.name })),
      suggestedAction: `Trendyol ana sayfa linkini → trendyol.com/sr?q=ÜRÜN_ADI formatına çevir`,
      actionType: "fix-trendyol-urls",
      actionData: { ids: badTrendyolProducts.map(p => p.id) },
    });
  }

  const activeNoSupplierUrl = activeProducts.filter(p => !p.supplierProductUrl && !isBadTrendyolUrl(p.supplierProductUrl));
  if (activeNoSupplierUrl.length > 0) {
    deductions += Math.min(activeNoSupplierUrl.length * 3, 12);
    criticalIssues.push({
      id: "active-no-supplier-url",
      title: "Yayındaki Ürünlerde Satıcı Linki Yok",
      description: `${activeNoSupplierUrl.length} yayındaki üründe satıcı tedarik linki tanımlı değil.`,
      severity: "warning",
      count: activeNoSupplierUrl.length,
      affectedProducts: activeNoSupplierUrl.map(p => ({ id: p.id, name: p.name })),
      suggestedAction: "Ürün düzenleme sayfasından tedarikçi linkini ekleyin",
      actionType: null,
      actionData: null,
    });
  }

  const nameCount: Record<string, number[]> = {};
  for (const p of products) {
    const key = normalize(p.name);
    if (!nameCount[key]) nameCount[key] = [];
    nameCount[key].push(p.id);
  }
  const duplicates = Object.entries(nameCount).filter(([, ids]) => ids.length > 1);
  if (duplicates.length > 0) {
    deductions += Math.min(duplicates.length * 4, 16);
    const dupProducts = duplicates.flatMap(([name, ids]) =>
      ids.slice(1).map(id => {
        const p = products.find(x => x.id === id);
        return { id, name: p?.name ?? name };
      })
    );
    criticalIssues.push({
      id: "duplicate-products",
      title: "Tekrar Eden Ürünler",
      description: `${duplicates.length} farklı isimde birden fazla ürün var. Bunlar müşteride karışıklık yaratır.`,
      severity: "warning",
      count: dupProducts.length,
      affectedProducts: dupProducts,
      suggestedAction: "Tekrar eden ürünleri inceleyin ve birini silin ya da birleştirin",
      actionType: null,
      actionData: null,
    });
  }

  const noDescription = products.filter(p => !p.description || p.description.trim().length < 20);
  if (noDescription.length > 0) {
    deductions += Math.min(noDescription.length * 2, 10);
    productIssues.push({
      id: "no-description",
      title: "Açıklaması Eksik Ürünler",
      description: `${noDescription.length} üründe açıklama yok ya da çok kısa (20 karakterden az). SEO ve dönüşüm oranını olumsuz etkiler.`,
      severity: "warning",
      count: noDescription.length,
      affectedProducts: noDescription.slice(0, 10).map(p => ({ id: p.id, name: p.name })),
      suggestedAction: "Her ürüne en az 50 kelimelik açıklama ekleyin",
      actionType: null,
      actionData: null,
    });
  }

  const noCostPrice = products.filter(p => !p.costPrice || Number(p.costPrice) === 0);
  if (noCostPrice.length > 0) {
    productIssues.push({
      id: "no-cost-price",
      title: "Maliyet Fiyatı Girilmemiş Ürünler",
      description: `${noCostPrice.length} üründe maliyet fiyatı yok. Muhasebe hesaplamaları bu ürünler için tahmini %45 kullanıyor.`,
      severity: "warning",
      count: noCostPrice.length,
      affectedProducts: noCostPrice.slice(0, 10).map(p => ({ id: p.id, name: p.name })),
      suggestedAction: "Tedarik maliyetini girerek kâr hesaplamasını gerçekçi yapın",
      actionType: null,
      actionData: null,
    });
  }

  const zeroStock = products.filter(p => p.stock === 0 && p.isActive);
  if (zeroStock.length > 0) {
    deductions += Math.min(zeroStock.length * 5, 20);
    stockWarnings.push({
      id: "zero-stock",
      title: "Stoku Tükenen Aktif Ürünler",
      description: `${zeroStock.length} aktif ürünün stoğu sıfır. Müşteriler sipariş veremez.`,
      severity: "critical",
      count: zeroStock.length,
      affectedProducts: zeroStock.map(p => ({ id: p.id, name: p.name })),
      suggestedAction: "Bu ürünleri pasife alın ya da acil stok temin edin",
      actionType: null,
      actionData: null,
    });
  }

  const criticalStock = products.filter(p => p.stock > 0 && p.stock <= 5 && p.isActive);
  if (criticalStock.length > 0) {
    deductions += Math.min(criticalStock.length * 2, 10);
    stockWarnings.push({
      id: "critical-stock",
      title: "Kritik Stok Seviyesi (≤5 adet)",
      description: `${criticalStock.length} üründe stok 5 adetten az. Kısa sürede tükenir.`,
      severity: "critical",
      count: criticalStock.length,
      affectedProducts: criticalStock.map(p => ({ id: p.id, name: p.name })),
      suggestedAction: "Bu ürünler için acil sipariş verin ya da kampanya durdurun",
      actionType: null,
      actionData: null,
    });
  }

  const lowStock = products.filter(p => p.stock > 5 && p.stock <= 10 && p.isActive);
  if (lowStock.length > 0) {
    stockWarnings.push({
      id: "low-stock",
      title: "Düşük Stok Uyarısı (≤10 adet)",
      description: `${lowStock.length} üründe stok 10 adetten az. Yakında tükenebilir.`,
      severity: "warning",
      count: lowStock.length,
      affectedProducts: lowStock.map(p => ({ id: p.id, name: p.name })),
      suggestedAction: "Bu ürünler için stok siparişi planlayın",
      actionType: null,
      actionData: null,
    });
  }

  const soldProductIds = new Set<number>();
  for (const order of orders) {
    for (const item of (order.items as Array<{ productId: number }>)) {
      soldProductIds.add(item.productId);
    }
  }

  const neverSold = activeProducts.filter(p => !soldProductIds.has(p.id));
  if (neverSold.length > 0) {
    profitOpportunities.push({
      id: "never-sold",
      title: "Hiç Satılmayan Aktif Ürünler",
      description: `${neverSold.length} yayındaki ürün hiç sipariş almamış. Bunları kampanyaya alın.`,
      severity: "warning",
      count: neverSold.length,
      affectedProducts: neverSold.slice(0, 10).map(p => ({ id: p.id, name: p.name })),
      suggestedAction: "Bu ürünleri kampanyaya alın veya WhatsApp ile tanıtın",
      actionType: null,
      actionData: null,
    });
  }

  const lowMargin = products.filter(p => {
    if (!p.costPrice || Number(p.costPrice) === 0) return false;
    const margin = (Number(p.price) - Number(p.costPrice)) / Number(p.price);
    return margin < 0.25;
  });
  if (lowMargin.length > 0) {
    profitOpportunities.push({
      id: "low-margin",
      title: "Kâr Oranı Düşük Ürünler (%25 altı)",
      description: `${lowMargin.length} üründe kâr marjı %25'in altında. Fiyat optimizasyonu yapılabilir.`,
      severity: "warning",
      count: lowMargin.length,
      affectedProducts: lowMargin.slice(0, 10).map(p => ({
        id: p.id,
        name: `${p.name} (%${Math.round(((Number(p.price) - Number(p.costPrice)) / Number(p.price)) * 100)} marj)`,
      })),
      suggestedAction: "Kâr Analizi sayfasında fiyat önerisi alın veya maliyeti düşürün",
      actionType: null,
      actionData: null,
    });
  }

  const highMarginProducts = products.filter(p => {
    if (!p.costPrice || Number(p.costPrice) === 0) return false;
    const margin = (Number(p.price) - Number(p.costPrice)) / Number(p.price);
    return margin >= 0.4 && !soldProductIds.has(p.id);
  }).slice(0, 5);
  if (highMarginProducts.length > 0) {
    profitOpportunities.push({
      id: "high-margin-no-sales",
      title: "Yüksek Kârlı Ama Satışsız Ürünler",
      description: `${highMarginProducts.length} üründe kâr marjı %40+ ama henüz satış yok. Bunları öne çıkarın!`,
      severity: "info",
      count: highMarginProducts.length,
      affectedProducts: highMarginProducts.map(p => ({ id: p.id, name: p.name })),
      suggestedAction: "Bu ürünlere öncelikli reklam ve kampanya verin",
      actionType: null,
      actionData: null,
    });
  }

  const activeCount = activeProducts.length;
  const totalProducts = products.length;
  const categoryIds = new Set(products.map(p => p.categoryId).filter(Boolean));
  const totalCategories = categories.length;
  const usedCategories = categoryIds.size;

  if (activeCount < 5) {
    deductions += 15;
    storeAppearance.push({
      id: "few-active-products",
      title: "Mağazada Az Ürün Var",
      description: `Mağazada sadece ${activeCount} aktif ürün var. Müşteri güveni için en az 10 ürün önerilir.`,
      severity: "warning",
      count: activeCount,
      affectedProducts: [],
      suggestedAction: "Ürün Önerileri sayfasından yeni ürünler onaylayıp yayına alın",
      actionType: null,
      actionData: null,
    });
  }

  if (usedCategories < totalCategories) {
    storeAppearance.push({
      id: "unused-categories",
      title: "Boş Kategoriler Var",
      description: `${totalCategories - usedCategories} kategoride hiç ürün yok. Mağaza menüsü dağınık görünür.`,
      severity: "info",
      count: totalCategories - usedCategories,
      affectedProducts: [],
      suggestedAction: "Boş kategorileri silin veya ürün atayın",
      actionType: null,
      actionData: null,
    });
  }

  const orderStatuses = {
    pending: orders.filter(o => o.status === "beklemede").length,
    inProgress: orders.filter(o => ["hazirlaniyor", "kargoda"].includes(o.status)).length,
    delivered: orders.filter(o => o.status === "teslim edildi").length,
    cancelled: orders.filter(o => o.status === "iptal").length,
    total: orders.length,
    totalRevenue: orders.filter(o => o.status === "teslim edildi").reduce((s, o) => s + Number(o.total), 0),
    pendingRevenue: orders.filter(o => o.status === "beklemede").reduce((s, o) => s + Number(o.total), 0),
  };

  const customerMap: Record<string, { name: string; count: number; total: number }> = {};
  for (const order of orders) {
    const key = order.customerPhone || order.customerName || "bilinmiyor";
    if (!customerMap[key]) customerMap[key] = { name: order.customerName || "Bilinmiyor", count: 0, total: 0 };
    customerMap[key].count++;
    customerMap[key].total += Number(order.total);
  }
  const customers = Object.values(customerMap);
  const topCustomer = customers.sort((a, b) => b.total - a.total)[0] ?? null;
  const repeatCustomers = customers.filter(c => c.count > 1).length;

  const customerStats = {
    total: customers.length,
    repeat: repeatCustomers,
    topCustomer: topCustomer ? { name: topCustomer.name, total: topCustomer.total, orders: topCustomer.count } : null,
  };

  if (orderStatuses.pending > 0) {
    dailyTasks.push({ id: "dt-pending", title: `${orderStatuses.pending} bekleyen sipariş var`, description: "Siparişleri onaylayın ve hazırlığa başlayın", priority: "high" });
  }
  if (criticalStock.length > 0) {
    dailyTasks.push({ id: "dt-stock", title: `${criticalStock.length} üründe kritik stok`, description: "Acil stok siparişi vermeyi düşünün", priority: "high" });
  }
  if (activeNoImage.length > 0) {
    dailyTasks.push({ id: "dt-image", title: `${activeNoImage.length} yayındaki ürüne görsel ekle`, description: "Görselsiz ürünler satışı engeller", priority: "high" });
  }
  if (neverSold.length > 0) {
    dailyTasks.push({ id: "dt-promo", title: `${neverSold.length} ürünü tanıtım için WhatsApp'a gönder`, description: "Hiç satış yapmayan ürünleri öne çıkarın", priority: "medium" });
  }
  if (noDescription.length > 0) {
    dailyTasks.push({ id: "dt-desc", title: `${Math.min(5, noDescription.length)} ürüne açıklama yaz`, description: "SEO ve dönüşüm için açıklama kritik", priority: "medium" });
  }
  dailyTasks.push({ id: "dt-check", title: "Günlük sipariş takibini yap", description: "Teslimattaki siparişleri kontrol edin", priority: "low" });

  const criticalCount = criticalIssues.filter(i => i.severity === "critical").length
    + stockWarnings.filter(i => i.severity === "critical").length;
  const warningCount = criticalIssues.filter(i => i.severity === "warning").length
    + productIssues.filter(i => i.severity === "warning").length
    + stockWarnings.filter(i => i.severity === "warning").length
    + profitOpportunities.filter(i => i.severity === "warning").length;

  const productsToFixCount = new Set([
    ...activeNoImage.map(p => p.id),
    ...badTrendyolProducts.map(p => p.id),
    ...activeNoSupplierUrl.map(p => p.id),
    ...noDescription.map(p => p.id),
    ...noCostPrice.map(p => p.id),
  ]).size;

  const healthScore = Math.max(20, 100 - deductions);

  res.json({
    healthScore,
    criticalCount,
    warningCount,
    productsToFixCount,
    todaySuggestionsCount: dailyTasks.length,
    totalProducts,
    activeProductCount: activeCount,
    criticalErrors: criticalIssues,
    productIssues,
    stockWarnings,
    profitOpportunities,
    orderStats: orderStatuses,
    customerStats,
    storeAppearance,
    dailyTasks,
  });
});

router.post("/ai-brain/apply", async (req, res): Promise<void> => {
  const { actionType, ids } = req.body as { actionType: string; ids: number[] };

  if (!actionType || !Array.isArray(ids) || ids.length === 0) {
    res.status(400).json({ error: "actionType ve ids zorunludur" });
    return;
  }

  let applied = 0;

  if (actionType === "set-draft") {
    for (const id of ids) {
      await db.update(productsTable)
        .set({ productStatus: "draft", isActive: false })
        .where(eq(productsTable.id, id));
      applied++;
    }
    res.json({ applied, message: `${applied} ürün taslak durumuna alındı. Görsel eklenince tekrar yayınlayabilirsiniz.` });
    return;
  }

  if (actionType === "fix-trendyol-urls") {
    for (const id of ids) {
      const [product] = await db.select().from(productsTable).where(eq(productsTable.id, id));
      if (product && isBadTrendyolUrl(product.supplierProductUrl)) {
        const searchUrl = `https://www.trendyol.com/sr?q=${encodeURIComponent(product.name)}`;
        await db.update(productsTable)
          .set({ supplierProductUrl: searchUrl })
          .where(eq(productsTable.id, id));
        applied++;
      }
    }
    res.json({ applied, message: `${applied} ürünün Trendyol linki ürün adına göre arama linkine çevrildi.` });
    return;
  }

  res.status(400).json({ error: `Bilinmeyen actionType: ${actionType}` });
});

export default router;
