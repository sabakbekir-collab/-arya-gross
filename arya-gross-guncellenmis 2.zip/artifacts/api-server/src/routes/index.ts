import { Router, type IRouter } from "express";

import adsRouter from "./ads";
import aiBrainRouter from "./ai-brain";
import aiRouter from "./ai";
import aryaAutomationRouter from "./arya-automation";
import aryaRouter from "./arya";
import automationRouter from "./automation";
import automationsRouter from "./automations";
import campaignsRouter from "./campaigns";
import cartRouter from "./cart";
import categoriesRouter from "./categories";
import dashboardRouter from "./dashboard";
import healthRouter from "./health";
import ordersRouter from "./orders";
import productAutomationRouter from "./product-automation";
import productsRouter from "./products";
import reportsRouter from "./reports";
import revenueRouter from "./revenue";
import supplierAutomationRouter from "./supplier-automation";
import supplierBrainRouter from "./supplier-brain";
import supplierImportRouter from "./supplier-import";

const router: IRouter = Router();

router.use(healthRouter);
router.use(dashboardRouter);
router.use(categoriesRouter);
router.use(productsRouter);
router.use(cartRouter);
router.use(ordersRouter);
router.use(campaignsRouter);
router.use(aiRouter);
router.use(aiBrainRouter);
router.use(adsRouter);
router.use(revenueRouter);
router.use(automationsRouter);
router.use(reportsRouter);
router.use(aryaAutomationRouter);
router.use(supplierImportRouter);
router.use(supplierAutomationRouter);
router.use(aryaRouter);
router.use(productAutomationRouter);
router.use(automationRouter);
router.use(supplierBrainRouter);

export default router;
