import { Router, type IRouter, type Request, type Response } from "express";
import { desc, eq } from "drizzle-orm";
import { db, productsTable, categoriesTable } from "@workspace/db";
import {
  CreateProductBody,
  DeleteProductParams,
  GetProductParams,
  GetProductResponse,
  ListProductsQueryParams,
  ListProductsResponse,
  UpdateProductBody,
  UpdateProductParams,
  UpdateProductResponse,
  UpdateStockBody,
  UpdateStockParams,
  UpdateStockResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

type ProductRow = typeof productsTable.$inferSelect;

function text(value: unknown): string {
  return String(value ?? "").trim();
}

function numberOrNull(value: unknown): number | null {
  if (value === null || value === undefined || value === "") return null;
  const n = Number(value);
  return Number.isFinite(n) ? n : null;
}

function isBadImageUrl(value: unknown): boolean {
  const url = text(value).toLowerCase();
  if (!url.startsWith("http://") && !url.startsWith("https://") && !url.startsWith("/")) return true;
  return [
    "placeholder",
    "placehold.co",
    "no-image",
    "no_image",
    "default-image",
    "missing-image",
    "dummy",
    "logo",
  ].some((token) => url.includes(token));
}

function isBadSupplierUrl(value: unknown): boolean {
  const raw = text(value);
  if (!raw) return false;
  const lower = raw.toLowerCase();
  if (!lower.startsWith("http://") && !lower.startsWith("https://")) return true;
  if ([
    "/sr?q=",
    "/ara?q=",
    "/arama?",
    "/search?",
    "?q=",
    "&q=",
    "s?k=",
    "google.com/search",
    "product-not-found",
    "urun-bulunamadi",
    "sayfa-bulunamadi",
  ].some((token) => lower.includes(token))) return true;

  try {
    const parsed = new URL(raw);
    const host = parsed.hostname.toLowerCase();
    const path = parsed.pathname.toLowerCase();
    if (!path || path === "/") return true;
    if (host.includes("trendyol.com")) return !/-p-\d+/.test(path);
    if (host.includes("hepsiburada.com")) return !(/-pm-|\/p\/|hbv|hbc/.test(path));
    if (host.includes("n11.com")) return !path.includes("/urun/");
    if (host.includes("amazon.com.tr")) return !path.includes("/dp/");
    return false;
  } catch {
    return true;
  }
}

async function categoryNames(): Promise<Map<number, string>> {
  const rows = await db.select().from(categoriesTable);
  return new Map(rows.map((row) => [row.id, row.name]));
}

function formatProduct(row: ProductRow, names: Map<number, string>) {
  return {
    id: row.id,
    name: row.name,
    description: row.description ?? null,
    price: Number(row.price),
    costPrice: numberOrNull(row.costPrice),
    stock: Number(row.stock ?? 0),
    categoryId: row.categoryId ?? null,
    categoryName: row.categoryId ? names.get(row.categoryId) ?? null : null,
    imageUrl: row.imageUrl ?? null,
    keywords: row.keywords ?? null,
    isActive: row.isActive,
    supplierName: row.supplierName ?? null,
    supplierProductUrl: row.supplierProductUrl ?? null,
    supplierPrice: numberOrNull(row.supplierPrice),
    riskScore: numberOrNull(row.riskScore),
    demandScore: numberOrNull(row.demandScore),
    opportunityScore: numberOrNull(row.opportunityScore),
    productStatus: row.productStatus ?? null,
    estimatedShippingDays: numberOrNull(row.estimatedShippingDays),
    createdAt: row.createdAt instanceof Date ? row.createdAt.toISOString() : String(row.createdAt),
  };
}

function validatePublishable(product: {
  name?: unknown;
  price?: unknown;
  stock?: unknown;
  imageUrl?: unknown;
  supplierProductUrl?: unknown;
}) {
  const errors: string[] = [];
  if (text(product.name).length < 2) errors.push("Ürün adı en az 2 karakter olmalıdır.");
  if (!(Number(product.price) > 0)) errors.push("Satış fiyatı sıfırdan büyük olmalıdır.");
  if (!(Number(product.stock) > 0)) errors.push("Yayınlanan ürünün stoğu en az 1 olmalıdır.");
  if (isBadImageUrl(product.imageUrl)) errors.push("Geçerli bir ürün görseli gereklidir.");
  if (text(product.supplierProductUrl) && isBadSupplierUrl(product.supplierProductUrl)) {
    errors.push("Tedarikçi bağlantısı doğrudan ürün sayfası olmalıdır.");
  }
  return errors;
}

function dbProductValues(body: Record<string, unknown>) {
  const values: Record<string, unknown> = {};
  const textFields = [
    "name",
    "description",
    "imageUrl",
    "keywords",
    "supplierName",
    "supplierProductUrl",
    "productStatus",
  ];
  const integerFields = [
    "stock",
    "categoryId",
    "riskScore",
    "demandScore",
    "opportunityScore",
    "estimatedShippingDays",
  ];
  const moneyFields = ["price", "costPrice", "supplierPrice"];

  for (const key of textFields) {
    if (body[key] !== undefined) values[key] = text(body[key]) || null;
  }
  for (const key of integerFields) {
    if (body[key] !== undefined) values[key] = Math.round(Number(body[key]));
  }
  for (const key of moneyFields) {
    if (body[key] !== undefined) values[key] = Number(body[key]).toFixed(2);
  }
  if (body.isActive !== undefined) values.isActive = Boolean(body.isActive);

  return values;
}

router.get("/products", async (req: Request, res: Response): Promise<void> => {
  try {
    const parsed = ListProductsQueryParams.safeParse(req.query);
    if (!parsed.success) {
      res.status(400).json({ error: parsed.error.message });
      return;
    }

    const [rows, names] = await Promise.all([
      db.select().from(productsTable).orderBy(desc(productsTable.createdAt)),
      categoryNames(),
    ]);

    let items = rows.map((row) => formatProduct(row, names));
    const search = text(parsed.data.search).toLocaleLowerCase("tr-TR");
    const activeParam = text(req.query.active).toLowerCase();

    if (parsed.data.categoryId !== null && parsed.data.categoryId !== undefined) {
      items = items.filter((item) => item.categoryId === parsed.data.categoryId);
    }
    if (parsed.data.inStock === true) items = items.filter((item) => item.stock > 0);
    if (parsed.data.productStatus) {
      items = items.filter((item) => item.productStatus === parsed.data.productStatus);
    }
    if (activeParam === "true") items = items.filter((item) => item.isActive === true);
    if (activeParam === "false") items = items.filter((item) => item.isActive === false);
    if (search) {
      items = items.filter((item) =>
        `${item.name} ${item.description ?? ""} ${item.categoryName ?? ""} ${item.supplierName ?? ""}`
          .toLocaleLowerCase("tr-TR")
          .includes(search),
      );
    }

    res.json(ListProductsResponse.parse(items));
  } catch (error) {
    res.status(500).json({ error: error instanceof Error ? error.message : String(error) });
  }
});

router.get("/products/:id", async (req: Request, res: Response): Promise<void> => {
  try {
    const params = GetProductParams.safeParse(req.params);
    if (!params.success) {
      res.status(400).json({ error: params.error.message });
      return;
    }

    const [row] = await db.select().from(productsTable).where(eq(productsTable.id, params.data.id));
    if (!row) {
      res.status(404).json({ error: "Ürün bulunamadı" });
      return;
    }

    const names = await categoryNames();
    res.json(GetProductResponse.parse(formatProduct(row, names)));
  } catch (error) {
    res.status(500).json({ error: error instanceof Error ? error.message : String(error) });
  }
});

router.post("/products", async (req: Request, res: Response): Promise<void> => {
  try {
    const parsed = CreateProductBody.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: parsed.error.message });
      return;
    }

    const status = parsed.data.productStatus ?? "draft";
    if (status === "active") {
      const errors = validatePublishable(parsed.data);
      if (errors.length) {
        res.status(400).json({ error: errors.join(" "), errors });
        return;
      }
    }

    const [row] = await db.insert(productsTable).values({
      ...dbProductValues(parsed.data as unknown as Record<string, unknown>),
      name: parsed.data.name.trim(),
      price: parsed.data.price.toFixed(2),
      stock: Math.round(parsed.data.stock),
      productStatus: status,
      isActive: status === "active",
    } as typeof productsTable.$inferInsert).returning();

    const names = await categoryNames();
    res.status(201).json(GetProductResponse.parse(formatProduct(row, names)));
  } catch (error) {
    res.status(500).json({ error: error instanceof Error ? error.message : String(error) });
  }
});

router.patch("/products/:id", async (req: Request, res: Response): Promise<void> => {
  try {
    const params = UpdateProductParams.safeParse(req.params);
    const parsed = UpdateProductBody.safeParse(req.body);
    if (!params.success || !parsed.success) {
      res.status(400).json({ error: !params.success ? params.error.message : parsed.error.message });
      return;
    }

    const [existing] = await db.select().from(productsTable).where(eq(productsTable.id, params.data.id));
    if (!existing) {
      res.status(404).json({ error: "Ürün bulunamadı" });
      return;
    }

    const merged = { ...existing, ...parsed.data };
    const shouldPublish = parsed.data.isActive === true || parsed.data.productStatus === "active";
    if (shouldPublish) {
      const errors = validatePublishable(merged);
      if (errors.length) {
        res.status(400).json({ error: errors.join(" "), errors });
        return;
      }
    }

    const update = dbProductValues(parsed.data as unknown as Record<string, unknown>);
    if (parsed.data.productStatus === "active") update.isActive = true;
    if (parsed.data.productStatus && parsed.data.productStatus !== "active") update.isActive = false;

    const [row] = await db
      .update(productsTable)
      .set(update as Partial<typeof productsTable.$inferInsert>)
      .where(eq(productsTable.id, params.data.id))
      .returning();

    const names = await categoryNames();
    res.json(UpdateProductResponse.parse(formatProduct(row, names)));
  } catch (error) {
    res.status(500).json({ error: error instanceof Error ? error.message : String(error) });
  }
});

router.delete("/products/:id", async (req: Request, res: Response): Promise<void> => {
  try {
    const params = DeleteProductParams.safeParse(req.params);
    if (!params.success) {
      res.status(400).json({ error: params.error.message });
      return;
    }
    await db.delete(productsTable).where(eq(productsTable.id, params.data.id));
    res.sendStatus(204);
  } catch (error) {
    res.status(500).json({ error: error instanceof Error ? error.message : String(error) });
  }
});

router.patch("/products/:id/stock", async (req: Request, res: Response): Promise<void> => {
  try {
    const params = UpdateStockParams.safeParse(req.params);
    const parsed = UpdateStockBody.safeParse(req.body);
    if (!params.success || !parsed.success) {
      res.status(400).json({ error: !params.success ? params.error.message : parsed.error.message });
      return;
    }

    const [row] = await db
      .update(productsTable)
      .set({ stock: Math.max(0, Math.round(parsed.data.stock)) })
      .where(eq(productsTable.id, params.data.id))
      .returning();

    if (!row) {
      res.status(404).json({ error: "Ürün bulunamadı" });
      return;
    }

    const names = await categoryNames();
    res.json(UpdateStockResponse.parse(formatProduct(row, names)));
  } catch (error) {
    res.status(500).json({ error: error instanceof Error ? error.message : String(error) });
  }
});

router.post("/products/cleanup", async (_req: Request, res: Response): Promise<void> => {
  try {
    const rows = await db.select().from(productsTable);
    let deactivated = 0;

    for (const row of rows) {
      const invalid =
        Number(row.price) <= 0 ||
        Number(row.stock) < 0 ||
        isBadImageUrl(row.imageUrl) ||
        (Boolean(text(row.supplierProductUrl)) && isBadSupplierUrl(row.supplierProductUrl));

      if (invalid && (row.isActive || row.productStatus === "active")) {
        await db
          .update(productsTable)
          .set({ isActive: false, productStatus: "draft" })
          .where(eq(productsTable.id, row.id));
        deactivated += 1;
      }
    }

    res.json({ success: true, deactivated, message: `${deactivated} sorunlu ürün taslağa alındı.` });
  } catch (error) {
    res.status(500).json({ success: false, error: error instanceof Error ? error.message : String(error) });
  }
});

function imageFromHtml(html: string): string | null {
  const patterns = [
    /property=["']og:image["'][^>]+content=["']([^"']+)["']/i,
    /content=["']([^"']+)["'][^>]+property=["']og:image["']/i,
    /"image"\s*:\s*"([^"]+)"/i,
  ];
  for (const pattern of patterns) {
    const match = html.match(pattern);
    if (match?.[1]) {
      const value = match[1].replace(/\\u002F/g, "/").replace(/\\/g, "");
      return value.startsWith("//") ? `https:${value}` : value;
    }
  }
  return null;
}

function priceFromHtml(html: string): number | null {
  const patterns = [
    /"price"\s*:\s*"?([0-9]+(?:[.,][0-9]+)?)"?/i,
    /product:price:amount["'][^>]+content=["']([0-9]+(?:[.,][0-9]+)?)/i,
  ];
  for (const pattern of patterns) {
    const match = html.match(pattern);
    if (match?.[1]) {
      const value = Number(match[1].replace(",", "."));
      if (Number.isFinite(value) && value > 0) return value;
    }
  }
  return null;
}

async function refreshSupplierData(_req: Request, res: Response): Promise<void> {
  try {
    const rows = await db.select().from(productsTable).orderBy(desc(productsTable.createdAt)).limit(30);
    let updated = 0;
    let skipped = 0;
    let failed = 0;

    for (const row of rows) {
      if (!row.supplierProductUrl || isBadSupplierUrl(row.supplierProductUrl)) {
        skipped += 1;
        continue;
      }
      try {
        const response = await fetch(row.supplierProductUrl, {
          headers: { "user-agent": "Mozilla/5.0", accept: "text/html" },
          signal: AbortSignal.timeout(8_000),
        });
        if (!response.ok) {
          failed += 1;
          continue;
        }
        const html = await response.text();
        const imageUrl = imageFromHtml(html);
        const supplierPrice = priceFromHtml(html);
        const update: Partial<typeof productsTable.$inferInsert> = {};
        if (imageUrl && !isBadImageUrl(imageUrl)) update.imageUrl = imageUrl;
        if (supplierPrice) {
          update.supplierPrice = supplierPrice.toFixed(2);
          update.costPrice = supplierPrice.toFixed(2);
        }
        if (Object.keys(update).length === 0) {
          skipped += 1;
          continue;
        }
        await db.update(productsTable).set(update).where(eq(productsTable.id, row.id));
        updated += 1;
      } catch {
        failed += 1;
      }
    }

    res.json({ success: true, updated, skipped, failed, message: `${updated} ürünün tedarikçi bilgisi yenilendi.` });
  } catch (error) {
    res.status(500).json({ success: false, error: error instanceof Error ? error.message : String(error) });
  }
}

router.post("/products/refresh-supplier-data", refreshSupplierData);
router.get("/admin/refresh-supplier-data", refreshSupplierData);

export default router;
