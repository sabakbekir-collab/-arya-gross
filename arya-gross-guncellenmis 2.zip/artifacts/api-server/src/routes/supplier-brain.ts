import { Router, type IRouter, type Request, type Response } from "express";
import { db, pendingSuggestionsTable, categoriesTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import {
  findRealProduct,
  validateProductUrl,
  normalizeProductName,
  type BrainOffer,
} from "../lib/real-supplier-brain.js";

const router: IRouter = Router();

// ─────────────────────────────────────────────────────────────────
// GET /supplier-brain/find?query=ürünadı
// ─────────────────────────────────────────────────────────────────

router.get("/supplier-brain/find", async (req: Request, res: Response) => {
  const query = (req.query.query as string | undefined)?.trim();
  if (!query || query.length < 2) {
    return res.status(400).json({ error: "Ürün adı en az 2 karakter olmalı" });
  }
  if (query.length > 120) {
    return res.status(400).json({ error: "Ürün adı çok uzun (max 120 karakter)" });
  }

  req.log.info({ query }, "supplier-brain find başlatıldı");

  try {
    const result = await findRealProduct(query);
    req.log.info(
      { query, ok: result.ok, offersCount: result.offers.length },
      "supplier-brain find tamamlandı"
    );
    return res.json(result);
  } catch (err) {
    req.log.error({ err, query }, "supplier-brain find hatası");
    return res.status(500).json({ error: "Tedarikçi taraması sırasında hata oluştu" });
  }
});

// ─────────────────────────────────────────────────────────────────
// POST /supplier-brain/validate-url
// Tek bir URL'yi doğrula
// Body: { url: string, productName: string }
// ─────────────────────────────────────────────────────────────────

router.post("/supplier-brain/validate-url", async (req: Request, res: Response) => {
  const { url, productName } = req.body as { url?: string; productName?: string };
  if (!url || !url.startsWith("http")) {
    return res.status(400).json({ error: "Geçerli bir URL giriniz" });
  }
  const name = productName?.trim() || "";

  try {
    const result = await validateProductUrl(url, name);
    return res.json({
      valid: result.ok,
      offer: result.offer ?? null,
      reason: result.reason ?? null,
    });
  } catch (err) {
    req.log.error({ err, url }, "validate-url hatası");
    return res.status(500).json({ error: "URL doğrulama sırasında hata oluştu" });
  }
});

// ─────────────────────────────────────────────────────────────────
// POST /supplier-brain/add-to-pending
// Bulunan gerçek ürünü onay listesine ekle
// Body: { offer: BrainOffer, query: string, allOffers: BrainOffer[] }
// ─────────────────────────────────────────────────────────────────

router.post("/supplier-brain/add-to-pending", async (req: Request, res: Response) => {
  const { offer, query, allOffers } = req.body as {
    offer?: BrainOffer;
    query?: string;
    allOffers?: BrainOffer[];
  };

  if (!offer || !offer.url || !offer.supplier) {
    return res.status(400).json({ error: "Geçerli teklif verisi gerekli" });
  }
  if (offer.linkBroken) {
    return res.status(400).json({ error: "Bozuk link ürün onaya eklenemez" });
  }
  if (!offer.price || offer.price <= 0) {
    return res.status(400).json({ error: "Geçerli fiyat bilgisi gerekli" });
  }

  const productName = (query ?? offer.title ?? "").trim();
  if (!productName) {
    return res.status(400).json({ error: "Ürün adı gerekli" });
  }

  // Find matching category
  const categories = await db.select().from(categoriesTable);
  const nameLower = normalizeProductName(productName);
  let categoryId: number | null = null;
  let categoryName: string | null = null;

  for (const cat of categories) {
    const catLower = cat.name.toLowerCase();
    if (
      nameLower.split(" ").some((w) => w.length > 3 && catLower.includes(w)) ||
      catLower.split(" ").some((w) => w.length > 3 && nameLower.includes(w))
    ) {
      categoryId = cat.id;
      categoryName = cat.name;
      break;
    }
  }

  // Estimate sell price (cost × 1.45)
  const costPrice = offer.price;
  const sellPrice = Math.round(costPrice * 1.45 * 100) / 100;

  const supplierOffersJson = (allOffers ?? [offer]).map((o) => ({
    supplierName: o.supplier,
    supplierUrl: o.url,
    price: o.price,
    verified: o.verified,
    httpStatus: o.httpStatus,
  }));

  try {
    const [inserted] = await db
      .insert(pendingSuggestionsTable)
      .values({
        name: offer.title || productName,
        brand: null,
        description: `Tedarikçi: ${offer.supplier} — Gerçek ürün taramasıyla bulundu`,
        estimatedSellPrice: sellPrice.toFixed(2),
        estimatedCostPrice: costPrice.toFixed(2),
        profitMargin: Math.round(((sellPrice - costPrice) / sellPrice) * 100),
        supplierVerified: offer.verified,
        supplierName: offer.supplier,
        supplierProductUrl: offer.url,
        imageUrl: offer.imageUrl || null,
        categoryId,
        categoryName: categoryName ?? "Genel",
        source: "supplier-brain",
        status: "pending",
        demandScore: 7,
        riskScore: 3,
        opportunityScore: 7,
        linkBroken: offer.linkBroken,
        supplierOffers: supplierOffersJson,
      })
      .returning();

    req.log.info({ id: inserted.id, name: inserted.name }, "supplier-brain ürün onay listesine eklendi");
    return res.json({
      added: true,
      suggestion: inserted,
      message: `"${inserted.name}" onay listesine eklendi.`,
    });
  } catch (err: unknown) {
    req.log.error({ err }, "add-to-pending insert hatası");
    const message = err instanceof Error ? err.message : String(err);
    if (message.includes("unique") || message.includes("duplicate")) {
      return res.status(409).json({ error: "Bu ürün zaten onay listesinde mevcut" });
    }
    return res.status(500).json({ error: "Ürün eklenirken hata oluştu" });
  }
});

export default router;
