import { Router, type IRouter } from "express";
import * as XLSX from "xlsx";
import { db, ordersTable, productsTable, categoriesTable } from "@workspace/db";
import { eq } from "drizzle-orm";

const router: IRouter = Router();

router.get("/reports/export-excel", async (req, res): Promise<void> => {
  const wb = XLSX.utils.book_new();
  const dateStr = new Date().toISOString().split("T")[0];

  // 1. SİPARİŞLER
  const orders = await db.select().from(ordersTable).orderBy(ordersTable.createdAt);
  const ordersData = orders.map(o => ({
    "Sipariş No": o.id,
    "Müşteri": o.customerName ?? "",
    "Telefon": o.customerPhone ?? "",
    "Adres": o.address ?? "",
    "Ürünler": Array.isArray(o.items) ? (o.items as any[]).map((i: any) => `${i.name} x${i.quantity}`).join(", ") : "",
    "Toplam (₺)": Number(o.total),
    "Ödeme Yöntemi": o.paymentMethod ?? "",
    "Ödeme Durumu": o.paymentStatus ?? "",
    "Sipariş Durumu": o.status,
    "Tarih": o.createdAt instanceof Date ? o.createdAt.toLocaleDateString("tr-TR") : String(o.createdAt),
  }));
  XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(ordersData), "Siparişler");

  // 2. ÖDEMELER
  const havalOrders = orders.filter(o => o.paymentMethod === "havale" || o.paymentMethod === "whatsapp");
  const paymentsData = havalOrders.map(o => ({
    "Sipariş No": o.id,
    "Müşteri": o.customerName ?? "",
    "Telefon": o.customerPhone ?? "",
    "Tutar (₺)": Number(o.total),
    "Ödeme Yöntemi": o.paymentMethod ?? "",
    "Ödeme Durumu": o.paymentStatus ?? "",
    "Dekont Durumu": o.decontStatus ?? "",
    "Tarih": o.createdAt instanceof Date ? o.createdAt.toLocaleDateString("tr-TR") : String(o.createdAt),
    "Onaylayan Admin": o.paymentConfirmedBy ?? "",
  }));
  XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(paymentsData), "Ödemeler");

  // 3. ÜRÜNLER
  const products = await db
    .select({ p: productsTable, catName: categoriesTable.name })
    .from(productsTable)
    .leftJoin(categoriesTable, eq(productsTable.categoryId, categoriesTable.id));

  const productsData = products.map(({ p, catName }) => {
    const price = Number(p.price);
    const cost = p.costPrice ? Number(p.costPrice) : 0;
    const profit = price - cost;
    const profitPct = price > 0 ? Math.round((profit / price) * 100) : 0;
    return {
      "Ürün Adı": p.name,
      "Kategori": catName ?? "",
      "Tedarikçi": p.supplierName ?? "",
      "Tedarik Fiyatı (₺)": p.supplierPrice ? Number(p.supplierPrice) : (cost || ""),
      "Satış Fiyatı (₺)": price,
      "Kâr (₺)": profit,
      "Kâr Oranı (%)": profitPct,
      "Stok": p.stock,
      "Durum": p.productStatus ?? (p.isActive ? "active" : "passive"),
    };
  });
  XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(productsData), "Ürünler");

  // 4. MÜŞTERİLER
  const customerMap = new Map<string, any>();
  for (const o of orders) {
    if (!o.customerPhone) continue;
    if (!customerMap.has(o.customerPhone)) {
      customerMap.set(o.customerPhone, {
        ad: o.customerName ?? "",
        tel: o.customerPhone,
        email: o.customerEmail ?? "",
        adres: o.address ?? "",
        siparisCount: 0,
        toplamHarcama: 0,
      });
    }
    const c = customerMap.get(o.customerPhone)!;
    c.siparisCount++;
    c.toplamHarcama += Number(o.total);
  }
  const customersData = Array.from(customerMap.values()).map(c => ({
    "Müşteri Adı": c.ad,
    "Telefon": c.tel,
    "E-posta": c.email,
    "Adres": c.adres,
    "Sipariş Sayısı": c.siparisCount,
    "Toplam Harcama (₺)": c.toplamHarcama,
  }));
  XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(customersData), "Müşteriler");

  // 5. STOKLAR
  const stockData = products.map(({ p }) => ({
    "Ürün Adı": p.name,
    "Stok": p.stock,
    "Satış Fiyatı (₺)": Number(p.price),
    "Stok Değeri (₺)": Math.round(p.stock * Number(p.price)),
    "Durum": p.stock === 0 ? "Tükendi" : p.stock < 10 ? "Kritik" : "Normal",
  }));
  XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(stockData), "Stoklar");

  // 6. KÂR ANALİZİ
  const completedOrders = orders.filter(o => o.status === "teslim edildi");
  const karData = completedOrders.map(o => {
    const items = Array.isArray(o.items) ? (o.items as any[]) : [];
    const total = Number(o.total);
    return {
      "Sipariş No": o.id,
      "Müşteri": o.customerName ?? "",
      "Toplam Satış (₺)": total,
      "Kâr Tahmini (₺)": o.profitEstimate ? Number(o.profitEstimate) : Math.round(total * 0.3),
      "Tarih": o.createdAt instanceof Date ? o.createdAt.toLocaleDateString("tr-TR") : String(o.createdAt),
    };
  });
  XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(karData), "Kâr");

  // 7. TEDARİKÇİLER
  const supplierMap = new Map<string, any>();
  for (const { p } of products) {
    if (!p.supplierName) continue;
    if (!supplierMap.has(p.supplierName)) {
      supplierMap.set(p.supplierName, { ad: p.supplierName, urunCount: 0, url: p.supplierProductUrl ?? "" });
    }
    supplierMap.get(p.supplierName)!.urunCount++;
  }
  const suppliersData = Array.from(supplierMap.values()).map(s => ({
    "Tedarikçi Adı": s.ad,
    "Ürün Sayısı": s.urunCount,
    "URL": s.url,
  }));
  XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(suppliersData.length ? suppliersData : [{ "Tedarikçi": "Henüz yok" }]), "Tedarikçiler");

  // 8. İPTALLER
  const cancelled = orders.filter(o => o.status === "iptal");
  const cancelData = cancelled.map(o => ({
    "Sipariş No": o.id,
    "Müşteri": o.customerName ?? "",
    "Telefon": o.customerPhone ?? "",
    "Tutar (₺)": Number(o.total),
    "Ödeme Yöntemi": o.paymentMethod ?? "",
    "Tarih": o.createdAt instanceof Date ? o.createdAt.toLocaleDateString("tr-TR") : String(o.createdAt),
    "Not": o.notes ?? "",
  }));
  XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(cancelData.length ? cancelData : [{ "Durum": "İptal yok" }]), "İptaller");

  // Excel buffer oluştur ve gönder
  const buf = XLSX.write(wb, { type: "buffer", bookType: "xlsx" });
  res.setHeader("Content-Disposition", `attachment; filename="arya-gross-tum-raporlar-${dateStr}.xlsx"`);
  res.setHeader("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
  res.send(buf);
});

export default router;
