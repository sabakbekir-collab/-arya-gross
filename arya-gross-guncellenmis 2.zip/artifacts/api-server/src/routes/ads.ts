import { Router, type IRouter } from "express";
import { eq, desc } from "drizzle-orm";
import { db, productsTable, adsTable } from "@workspace/db";
import {
  GenerateAdBody,
  GenerateAdResponse,
  ListAdsResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

const HOOKS = {
  tiktok: [
    "POV: Bu ürünü deneyen herkes bağımlı oldu...",
    "3 günde bitti — yeniden sipariş verdim",
    "Annem bunu görünce şoke oldu",
    "Bu ürün neden bu kadar ucuz?? SATIN AL",
    "Hayatımı değiştiren tek şey bu oldu",
    "Herkes sordu, sonunda paylaşıyorum",
    "Bu ürünü görünce durdum — alamadım gözümü",
  ],
  instagram: [
    "Swipe et, şoklanmaya hazır ol 👇",
    "Bu ürünü görmeden karar verme",
    "Binlerce kişinin tercih ettiği ürün",
    "Yorumlar kendisi konuşuyor...",
    "Neden bu kadar uygun fiyatlı?",
  ],
};

const VIDEO_IDEAS = [
  "Unboxing videosu: Kutu açılışı, ürün yakın çekim, ilk deneme anı, yüz ifadesi",
  "Before-After: Ürün öncesi ve sonrası karşılaştırması, dramatik müzik",
  "POV Shot: Kullanıcı bakışından ürünü deneme, spontane tepkiler",
  "Saat baskısı: Sayaç geri sayıyor, stok azalıyor, kişi aceleyle sipariş veriyor",
  "Sosyal kanıt: Farklı insanların kısa yorumları, hızlı kesme",
];

const CTAS = [
  "Linke tıkla, bugün sipariş ver!",
  "Stok tükenince üzülme — HEMEN AL",
  "Bio'daki linke git, son fırsatı yakala!",
  "DM at veya linke tıkla — sınırlı stok!",
  "Şimdi sipariş ver, 24 saatte kargoda!",
];

function generateAdContent(productName: string, platform: string) {
  const platformHooks = HOOKS[platform as keyof typeof HOOKS] ?? HOOKS.tiktok;
  const hook = platformHooks[Math.floor(Math.random() * platformHooks.length)];
  const videoIdea = VIDEO_IDEAS[Math.floor(Math.random() * VIDEO_IDEAS.length)];
  const cta = CTAS[Math.floor(Math.random() * CTAS.length)];

  const scenario = `[0-3sn] HOOK: "${hook}" yazısı ekranda belirir.\n[3-10sn] Ürün (${productName}) gösterilir — yakın plan, estetik açı.\n[10-20sn] Ürün kullanımı veya faydası gösterilir.\n[20-30sn] Fiyat vurgusu + stok uyarısı + CTA: "${cta}"`;

  const adText = `🔥 ${productName} — BUGÜN SON GÜN!\n\n✅ Gerçek müşteri yorumları mükemmel\n✅ Hızlı kargo, güvenli ödeme\n⚠️ Stok ÇIKTI bitti!\n\n${cta}`;

  const hashtags = [
    `#${productName.replace(/\s+/g, "")}`,
    "#türkiye",
    "#eticaret",
    "#indirim",
    "#viral",
    "#keşfet",
    "#alışveriş",
    "#sınırlıstok",
    "#trending",
    "#fomo",
  ];

  const emotionalTitles = [
    `${productName} ile hayatın daha güzel`,
    `Herkes soruyor: "${productName}" nerede?`,
    `Bu fiyata son kez!`,
    `${productName} — Türkiye'nin konuştuğu ürün`,
    `Stoklar tükeniyor — son şans!`,
  ];
  const emotionalTitle = emotionalTitles[Math.floor(Math.random() * emotionalTitles.length)];

  return { hook, scenario, videoIdea, adText, hashtags, emotionalTitle, cta, platform };
}

router.post("/ads/generate", async (req, res): Promise<void> => {
  const parsed = GenerateAdBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [product] = await db.select().from(productsTable).where(eq(productsTable.id, parsed.data.productId));
  if (!product) {
    res.status(404).json({ error: "Ürün bulunamadı" });
    return;
  }

  const platform = parsed.data.platform ?? "tiktok";
  const adContent = generateAdContent(product.name, platform);

  await db.insert(adsTable).values({
    productId: product.id,
    productName: product.name,
    platform,
    hook: adContent.hook,
    scenario: adContent.scenario,
    videoIdea: adContent.videoIdea,
    adText: adContent.adText,
    hashtags: adContent.hashtags,
    emotionalTitle: adContent.emotionalTitle,
    cta: adContent.cta,
  });

  res.json(GenerateAdResponse.parse(adContent));
});

router.get("/ads/history", async (_req, res): Promise<void> => {
  const rows = await db.select().from(adsTable).orderBy(desc(adsTable.createdAt)).limit(50);
  res.json(ListAdsResponse.parse(rows.map((row) => ({
    id: row.id,
    productId: row.productId,
    productName: row.productName,
    platform: row.platform,
    hook: row.hook,
    scenario: row.scenario ?? undefined,
    videoIdea: row.videoIdea ?? undefined,
    adText: row.adText ?? undefined,
    hashtags: Array.isArray(row.hashtags) ? row.hashtags : [],
    emotionalTitle: row.emotionalTitle ?? undefined,
    cta: row.cta ?? undefined,
    createdAt: row.createdAt.toISOString(),
  }))));
});

export default router;
