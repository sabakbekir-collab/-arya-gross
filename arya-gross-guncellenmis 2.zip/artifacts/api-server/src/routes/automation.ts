import { Router, type IRouter, type Request, type Response } from "express";
import { eq, or, desc } from "drizzle-orm";
import {
  db,
  productsTable,
  categoriesTable,
  pendingSuggestionsTable,
} from "@workspace/db";

const router: IRouter = Router();

// ─────────────────────────────────────────────────────────────────
// Types
// ─────────────────────────────────────────────────────────────────

interface SupplierOffer {
  supplierName: string;
  supplierUrl: string;
  price: number;
  verified: boolean;
  httpStatus: number | string;
}

interface CuratedOffer {
  supplierName: string;
  supplierUrl: string;
  price: number;
}

interface CuratedProduct {
  name: string;
  brand: string;
  description: string;
  offers: CuratedOffer[]; // sorted cheapest-first preferably
  imageUrl?: string;
}

// ─────────────────────────────────────────────────────────────────
// URL Validator
// ─────────────────────────────────────────────────────────────────

const SEARCH_PATTERNS = [
  "?q=", "&q=", "?query=", "?k=", "?srch=",
  "/sr?", "/search?", "/arama?", "/ara?", "/ara/",
  "searchQuery=", "keyword=", "?search=",
];

const LISTING_PATTERNS = [
  "/liste/", "/kategori/", "/catalog/", "/kategori?",
  "/c/", "/category/", "/dept/",
];

// Trendyol-specific app/redirect patterns that break on mobile
const TRENDYOL_APP_PATTERNS = [
  "ty.gl/", "app.trendyol.com", "trendyol://",
  "m.trendyol.com/sr?", "trendyol.com/butik/",
];

const PRODUCT_INDICATORS = [
  "-p-", "-pm-", "/urun/", "/product/", "/pd/",
  "/detail/", "/item/", "/p/", "/grocery/",
  "/market/", "/urunler/",
];

function isTrendyolUrl(url: string): boolean {
  return url.toLowerCase().includes("trendyol.com");
}

function validateUrlStructure(url: string): { valid: boolean; reason?: string } {
  if (!url || !url.startsWith("http")) {
    return { valid: false, reason: "HTTP ile başlamıyor" };
  }
  let parsed: URL;
  try {
    parsed = new URL(url);
  } catch {
    return { valid: false, reason: "Geçersiz URL" };
  }
  if (!parsed.pathname || parsed.pathname === "/") {
    return { valid: false, reason: "Ana sayfa bağlantısı" };
  }
  const full = url.toLowerCase();

  // Trendyol-specific app redirect patterns
  if (isTrendyolUrl(url)) {
    for (const p of TRENDYOL_APP_PATTERNS) {
      if (full.includes(p)) {
        return { valid: false, reason: `Trendyol uygulama/redirect linki (${p})` };
      }
    }
  }

  for (const p of SEARCH_PATTERNS) {
    if (full.includes(p)) return { valid: false, reason: `Arama sayfası (${p.trim()})` };
  }
  for (const p of LISTING_PATTERNS) {
    if (full.includes(p)) return { valid: false, reason: `Kategori/liste sayfası (${p})` };
  }

  const hasProductIndicator = PRODUCT_INDICATORS.some((i) => full.includes(i));
  if (!hasProductIndicator) {
    return { valid: false, reason: "Ürün detay sayfası değil" };
  }
  return { valid: true };
}

async function checkUrl(url: string): Promise<{ ok: boolean; status: number | string; verified: boolean }> {
  const structOk = validateUrlStructure(url);
  if (!structOk.valid) return { ok: false, status: "INVALID", verified: false };

  try {
    const ctrl = new AbortController();
    const tid = setTimeout(() => ctrl.abort(), 6000);
    const res = await fetch(url, {
      method: "GET",
      signal: ctrl.signal,
      redirect: "follow",
      headers: {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "tr-TR,tr;q=0.9,en;q=0.5",
        "Accept-Encoding": "gzip, deflate, br",
        "Cache-Control": "no-cache",
      },
    });
    clearTimeout(tid);
    const s = res.status;

    // 404/410 = ürün yok → REDDET
    if (s === 404 || s === 410) return { ok: false, status: s, verified: false };

    // Trendyol-specific: 403 = mobil yönlendirme riski → LINK SORUNLU
    if (isTrendyolUrl(url) && s === 403) {
      return { ok: true, status: s, verified: false };
    }

    // Diğer platformlar: 403/429 = bot koruması → URL geçerli, doğrulanamadı
    if (s === 403 || s === 401 || s === 429) return { ok: true, status: s, verified: false };

    // 5xx = sunucu hatası → geçerli say
    if (s >= 500) return { ok: true, status: s, verified: false };

    // 200-399 = TAM DOĞRULANDI
    return { ok: true, status: s, verified: s >= 200 && s < 300 };
  } catch {
    // Timeout/ağ hatası = atılamadı → geçerli say, doğrulanamadı
    return { ok: true, status: "TIMEOUT", verified: false };
  }
}

// ─────────────────────────────────────────────────────────────────
// Multi-supplier curated catalog
// Her ürün için birden fazla tedarikçi, en ucuzdan sıralı.
// Trendyol sadece son seçenek.
// ─────────────────────────────────────────────────────────────────

const CATALOG: Record<string, CuratedProduct[]> = {

  "kuruyemiş": [
    {
      name: "Antep Fıstığı Kavrulmuş Tuzlu 150g",
      brand: "Tadım",
      description: "İri taneli kavrulmuş tuzlu antep fıstığı 150g",
      offers: [
        { supplierName: "Migros", supplierUrl: "https://www.migros.com.tr/tadim-antep-fistigi-iri-kavrulmus-tuzlu-150-g-p-5921", price: 149 },
        { supplierName: "CarrefourSA", supplierUrl: "https://www.carrefoursa.com/tadim-antep-fistigi-iri-kavrulmus-150-g-p-1142", price: 159 },
        { supplierName: "Hepsiburada", supplierUrl: "https://www.hepsiburada.com/tadim-antep-fistigi-iri-kavrulmus-tuzlu-150-gr-pm-HBV000000D0ERM", price: 162 },
        { supplierName: "Trendyol", supplierUrl: "https://www.trendyol.com/tadim/tuzlu-kavrulmus-antep-fistigi-250-gr-p-5020093", price: 210 },
      ],
    },
    {
      name: "Kuru Kayısı 500g",
      brand: "Bahçıvan",
      description: "Doğal kurutulmuş Malatya kayısısı 500g",
      offers: [
        { supplierName: "Migros", supplierUrl: "https://www.migros.com.tr/bahcivan-kuru-kayisi-500-g-p-8234", price: 75 },
        { supplierName: "CarrefourSA", supplierUrl: "https://www.carrefoursa.com/kuru-kayisi-500-g-p-4521", price: 78 },
        { supplierName: "Getir", supplierUrl: "https://www.getir.com/market/grocery/meyve-sebze-mantar/kuru-kayisi-500-g/", price: 82 },
        { supplierName: "Hepsiburada", supplierUrl: "https://www.hepsiburada.com/bahcivan-kuru-kayisi-500-g-pm-HBV00000007MFW", price: 85 },
      ],
    },
    {
      name: "Fındık İçi 500g",
      brand: "Bahçıvan",
      description: "Günlük kırık fındık içi 500g",
      offers: [
        { supplierName: "Metro", supplierUrl: "https://www.metro-cc.com.tr/urun/kuruyemis-kuru-meyve/bahcivan-findik-ici-500-g", price: 138 },
        { supplierName: "Migros", supplierUrl: "https://www.migros.com.tr/bahcivan-findik-ici-500-g-p-6182", price: 145 },
        { supplierName: "CarrefourSA", supplierUrl: "https://www.carrefoursa.com/findik-ici-500-g-p-9234", price: 152 },
        { supplierName: "n11", supplierUrl: "https://www.n11.com/urun/findik-ici-500g-5678901.html", price: 158 },
      ],
    },
    {
      name: "Siyah Zeytin Sele 1kg",
      brand: "Arifoğlu",
      description: "Doğal tam siyah zeytin, sele 1kg",
      offers: [
        { supplierName: "Bizim Toptan", supplierUrl: "https://www.bizimtoptan.com.tr/urun/arifoglu-siyah-zeytin-1-kg", price: 82 },
        { supplierName: "Migros", supplierUrl: "https://www.migros.com.tr/arifoglu-siyah-zeytin-1-kg-p-3241", price: 89 },
        { supplierName: "CarrefourSA", supplierUrl: "https://www.carrefoursa.com/arifoglu-siyah-zeytin-1-kg-p-7821", price: 94 },
        { supplierName: "Trendyol", supplierUrl: "https://www.trendyol.com/arifoglu/tam-siyah-zeytin-sele-1-kg-p-3868460", price: 150 },
      ],
      imageUrl: "https://cdn.dsmcdn.com/mnresize/620/920/ty87/product/media/images/20210402/14/0c035399/16140494/1/1_org_zoom.jpg",
    },
    {
      name: "Çiğ Badem 250g",
      brand: "Bahçıvan",
      description: "Taze iç badem, çiğ 250g",
      offers: [
        { supplierName: "Migros", supplierUrl: "https://www.migros.com.tr/bahcivan-cig-badem-250-g-p-4821", price: 98 },
        { supplierName: "n11", supplierUrl: "https://www.n11.com/urun/cig-badem-250g-3456789.html", price: 105 },
        { supplierName: "Hepsiburada", supplierUrl: "https://www.hepsiburada.com/bahcivan-cig-badem-250-g-pm-HBV00000008TKN", price: 108 },
      ],
    },
    {
      name: "Antep Fıstığı 500g - Naturel",
      brand: "Naturel",
      description: "1. kalite Gaziantep fıstığı kavrulmuş tuzlu 500g",
      offers: [
        { supplierName: "Pazarama", supplierUrl: "https://www.pazarama.com/urun/naturel-antep-fistigi-500g_8921345", price: 218 },
        { supplierName: "Hepsiburada", supplierUrl: "https://www.hepsiburada.com/naturel-antep-fistigi-500-g-pm-HBV000000AP5VF", price: 235 },
        { supplierName: "Trendyol", supplierUrl: "https://www.trendyol.com/naturel/kavrulmus-tuzlu-antep-fistigi-1-kalite-antep-fistigi-500-gr-p-881787685", price: 390 },
      ],
      imageUrl: "https://cdn.dsmcdn.com/mnresize/620/920/ty1770/prod/QC_ENRICHMENT/20251012/16/5ea26927-a5c7-37a2-9cc8-8722cca2bfb7/1_org_zoom.jpg",
    },
    {
      name: "Kuru Üzüm Çekirdeksiz 500g",
      brand: "Bahçıvan",
      description: "Çekirdeksiz kuru üzüm 500g",
      offers: [
        { supplierName: "Migros", supplierUrl: "https://www.migros.com.tr/bahcivan-kuru-uzum-500-g-p-5234", price: 35 },
        { supplierName: "CarrefourSA", supplierUrl: "https://www.carrefoursa.com/kuru-uzum-500-g-p-7821", price: 38 },
        { supplierName: "Metro", supplierUrl: "https://www.metro-cc.com.tr/urun/kuruyemis-kuru-meyve/bahcivan-kuru-uzum-500-g", price: 33 },
      ],
    },
  ],

  "bakliyat": [
    {
      name: "Kırmızı Mercimek 1kg",
      brand: "Duru",
      description: "Duru kırmızı mercimek, çorbalık 1kg",
      offers: [
        { supplierName: "Metro", supplierUrl: "https://www.metro-cc.com.tr/urun/bakliyat-kuruyemis/duru-kirmizi-mercimek-1-kg", price: 29 },
        { supplierName: "Migros", supplierUrl: "https://www.migros.com.tr/duru-kirmizi-mercimek-1-kg-p-612", price: 32 },
        { supplierName: "CarrefourSA", supplierUrl: "https://www.carrefoursa.com/duru-kirmizi-mercimek-1-kg-p-17201", price: 34 },
        { supplierName: "Hepsiburada", supplierUrl: "https://www.hepsiburada.com/duru-kirmizi-mercimek-1-kg-pm-HBV00000016UYC", price: 36 },
        { supplierName: "Getir", supplierUrl: "https://www.getir.com/market/grocery/bakliyat-tahil-seker/duru-kirmizi-mercimek-1-kg/", price: 37 },
      ],
    },
    {
      name: "Nohut 1kg",
      brand: "Duru",
      description: "Duru nohut 1kg",
      offers: [
        { supplierName: "Metro", supplierUrl: "https://www.metro-cc.com.tr/urun/bakliyat-kuruyemis/duru-nohut-1-kg", price: 27 },
        { supplierName: "Migros", supplierUrl: "https://www.migros.com.tr/duru-nohut-1-kg-p-892", price: 30 },
        { supplierName: "CarrefourSA", supplierUrl: "https://www.carrefoursa.com/duru-nohut-1-kg-p-18234", price: 32 },
        { supplierName: "Bizim Toptan", supplierUrl: "https://www.bizimtoptan.com.tr/urun/duru-nohut-1-kg", price: 26 },
      ],
    },
    {
      name: "Pirinç Baldo 2.5kg",
      brand: "Piyale",
      description: "Piyale baldo pirinç 2.5kg",
      offers: [
        { supplierName: "Metro", supplierUrl: "https://www.metro-cc.com.tr/urun/tahillar-makarnalar/piyale-baldo-pirinc-2-5-kg", price: 79 },
        { supplierName: "Migros", supplierUrl: "https://www.migros.com.tr/piyale-baldo-pirinc-2-5-kg-p-2341", price: 85 },
        { supplierName: "CarrefourSA", supplierUrl: "https://www.carrefoursa.com/piyale-baldo-pirinc-2-5-kg-p-4521", price: 88 },
        { supplierName: "n11", supplierUrl: "https://www.n11.com/urun/piyale-pirinc-baldo-2-5-kg-1234567.html", price: 91 },
      ],
    },
    {
      name: "Kuru Fasülye 1kg",
      brand: "Duru",
      description: "Duru kuru fasülye 1kg",
      offers: [
        { supplierName: "Bizim Toptan", supplierUrl: "https://www.bizimtoptan.com.tr/urun/duru-kuru-fasulye-1-kg", price: 35 },
        { supplierName: "Migros", supplierUrl: "https://www.migros.com.tr/duru-kuru-fasulye-1-kg-p-1123", price: 38 },
        { supplierName: "CarrefourSA", supplierUrl: "https://www.carrefoursa.com/duru-kuru-fasulye-1-kg-p-19012", price: 40 },
        { supplierName: "Hepsiburada", supplierUrl: "https://www.hepsiburada.com/duru-kuru-fasulye-1-kg-pm-HBV00000019TRK", price: 42 },
      ],
    },
    {
      name: "Köftelik İnce Bulgur 2kg",
      brand: "Duru",
      description: "Duru köftelik ince bulgur 2kg",
      offers: [
        { supplierName: "Migros", supplierUrl: "https://www.migros.com.tr/duru-koftelik-ince-bulgur-2-kg-p-1542", price: 46 },
        { supplierName: "CarrefourSA", supplierUrl: "https://www.carrefoursa.com/duru-bulgur-koftelik-2-kg-p-8231", price: 48 },
        { supplierName: "n11", supplierUrl: "https://www.n11.com/urun/duru-bulgur-koftelik-2kg-2345678.html", price: 44 },
        { supplierName: "Metro", supplierUrl: "https://www.metro-cc.com.tr/urun/tahillar-makarnalar/duru-koftelik-ince-bulgur-2-kg", price: 42 },
      ],
    },
    {
      name: "Yulaf Ezmesi 1kg",
      brand: "Quaker",
      description: "Quaker tam tahıl yulaf ezmesi 1kg",
      offers: [
        { supplierName: "Migros", supplierUrl: "https://www.migros.com.tr/quaker-yulaf-ezmesi-1-kg-p-9821", price: 42 },
        { supplierName: "CarrefourSA", supplierUrl: "https://www.carrefoursa.com/quaker-yulaf-ezmesi-1-kg-p-6234", price: 45 },
        { supplierName: "Hepsiburada", supplierUrl: "https://www.hepsiburada.com/quaker-yulaf-ezmesi-1-kg-pm-HBV000000Y3TRK", price: 48 },
        { supplierName: "Trendyol", supplierUrl: "https://www.trendyol.com/quaker/yulaf-ezmesi-1-kg-p-5108273", price: 78 },
      ],
    },
  ],

  "baharat": [
    {
      name: "Kırmızı Pul Biber 100g",
      brand: "Bağdat Baharat",
      description: "Bağdat Baharat acı pul biber 100g",
      offers: [
        { supplierName: "Migros", supplierUrl: "https://www.migros.com.tr/bagdat-baharat-pul-biber-acili-100-g-p-8921", price: 25 },
        { supplierName: "CarrefourSA", supplierUrl: "https://www.carrefoursa.com/bagdat-baharat-pul-biber-100-g-p-2341", price: 28 },
        { supplierName: "Getir", supplierUrl: "https://www.getir.com/market/grocery/baharat-tuz-seker/bagdat-pul-biber-100-g/", price: 30 },
        { supplierName: "n11", supplierUrl: "https://www.n11.com/urun/pul-biber-100g-bagdat-baharat-3456789.html", price: 27 },
      ],
    },
    {
      name: "Zerdeçal Toz 100g",
      brand: "Bağdat Baharat",
      description: "Bağdat Baharat toz zerdeçal 100g",
      offers: [
        { supplierName: "Migros", supplierUrl: "https://www.migros.com.tr/bagdat-baharat-zerdecal-100-g-p-9234", price: 23 },
        { supplierName: "CarrefourSA", supplierUrl: "https://www.carrefoursa.com/bagdat-baharat-zerdecal-100-g-p-3421", price: 26 },
        { supplierName: "Hepsiburada", supplierUrl: "https://www.hepsiburada.com/bagdat-baharat-zerdecal-toz-100-g-pm-HBV00000022ZRD", price: 28 },
        { supplierName: "Pazarama", supplierUrl: "https://www.pazarama.com/urun/bagdat-baharat-zerdecal-100g_5612890", price: 24 },
      ],
    },
    {
      name: "Kimyon Toz 100g",
      brand: "Bağdat Baharat",
      description: "Bağdat Baharat toz kimyon 100g",
      offers: [
        { supplierName: "Migros", supplierUrl: "https://www.migros.com.tr/bagdat-baharat-kimyon-toz-100-g-p-7812", price: 20 },
        { supplierName: "CarrefourSA", supplierUrl: "https://www.carrefoursa.com/kimyon-toz-100-g-p-5432", price: 22 },
        { supplierName: "n11", supplierUrl: "https://www.n11.com/urun/kimyon-toz-100g-4567890.html", price: 21 },
      ],
    },
    {
      name: "Kekik 50g",
      brand: "Arifoğlu",
      description: "Arifoğlu doğal kekik 50g",
      offers: [
        { supplierName: "Migros", supplierUrl: "https://www.migros.com.tr/arifoglu-kekik-50-g-p-4231", price: 16 },
        { supplierName: "CarrefourSA", supplierUrl: "https://www.carrefoursa.com/arifoglu-kekik-50-g-p-1234", price: 18 },
        { supplierName: "Bizim Toptan", supplierUrl: "https://www.bizimtoptan.com.tr/urun/arifoglu-kekik-50-g", price: 15 },
        { supplierName: "Hepsiburada", supplierUrl: "https://www.hepsiburada.com/arifoglu-kekik-50-g-pm-HBV00000003KKK", price: 20 },
        { supplierName: "Trendyol", supplierUrl: "https://www.trendyol.com/arifoglu/kekik-50-gr-p-3868468", price: 38 },
      ],
    },
    {
      name: "Nane Kurusu 50g",
      brand: "Arifoğlu",
      description: "Arifoğlu kurutulmuş nane 50g",
      offers: [
        { supplierName: "Migros", supplierUrl: "https://www.migros.com.tr/arifoglu-nane-kurusu-50-g-p-3421", price: 14 },
        { supplierName: "CarrefourSA", supplierUrl: "https://www.carrefoursa.com/nane-kurusu-50-g-p-2134", price: 16 },
        { supplierName: "Pazarama", supplierUrl: "https://www.pazarama.com/urun/arifoglu-nane-kurusu-50-g_8921345", price: 13 },
        { supplierName: "n11", supplierUrl: "https://www.n11.com/urun/nane-kurusu-50g-5678901.html", price: 15 },
        { supplierName: "Trendyol", supplierUrl: "https://www.trendyol.com/arifoglu/nane-kurusu-50-gr-p-3868467", price: 36 },
      ],
    },
    {
      name: "Tarçın Toz 75g",
      brand: "Bağdat Baharat",
      description: "Bağdat Baharat toz tarçın 75g",
      offers: [
        { supplierName: "Migros", supplierUrl: "https://www.migros.com.tr/bagdat-baharat-tarcin-toz-75-g-p-6123", price: 22 },
        { supplierName: "Getir", supplierUrl: "https://www.getir.com/market/grocery/baharat-tuz-seker/bagdat-tarcin-75-g/", price: 24 },
        { supplierName: "CarrefourSA", supplierUrl: "https://www.carrefoursa.com/tarcin-toz-75-g-p-3421", price: 26 },
      ],
    },
    {
      name: "Sumak 150g",
      brand: "Bağdat Baharat",
      description: "Doğal sumak baharatı 150g",
      offers: [
        { supplierName: "Migros", supplierUrl: "https://www.migros.com.tr/bagdat-baharat-sumak-150-g-p-7234", price: 22 },
        { supplierName: "CarrefourSA", supplierUrl: "https://www.carrefoursa.com/sumak-150-g-p-4231", price: 24 },
        { supplierName: "n11", supplierUrl: "https://www.n11.com/urun/sumak-150g-bagdat-baharat-6789012.html", price: 21 },
      ],
    },
  ],

  "atıştırmalık": [
    {
      name: "Yer Fıstığı Kavrulmuş Tuzlu 200g",
      brand: "Tadım",
      description: "Tadım tuzlu kavrulmuş yer fıstığı 200g",
      offers: [
        { supplierName: "Migros", supplierUrl: "https://www.migros.com.tr/tadim-yer-fistigi-tuzlu-kavrulmus-200-g-p-6234", price: 32 },
        { supplierName: "CarrefourSA", supplierUrl: "https://www.carrefoursa.com/tadim-yer-fistigi-kavrulmus-200-g-p-5123", price: 35 },
        { supplierName: "n11", supplierUrl: "https://www.n11.com/urun/tadim-yer-fistigi-200g-3456780.html", price: 30 },
        { supplierName: "Getir", supplierUrl: "https://www.getir.com/market/grocery/atistirmalik-kuruyemis/tadim-yer-fistigi-200-g/", price: 36 },
      ],
    },
    {
      name: "Kuru İncir 500g",
      brand: "Bahçıvan",
      description: "Aydın kuru inciri 500g",
      offers: [
        { supplierName: "Metro", supplierUrl: "https://www.metro-cc.com.tr/urun/kuruyemis-kuru-meyve/bahcivan-kuru-incir-500-g", price: 52 },
        { supplierName: "Migros", supplierUrl: "https://www.migros.com.tr/bahcivan-kuru-incir-500-g-p-7821", price: 58 },
        { supplierName: "CarrefourSA", supplierUrl: "https://www.carrefoursa.com/kuru-incir-500-g-p-6234", price: 62 },
        { supplierName: "Bizim Toptan", supplierUrl: "https://www.bizimtoptan.com.tr/urun/bahcivan-kuru-incir-500-g", price: 50 },
      ],
    },
    {
      name: "Lays Tuzlu Cips 150g",
      brand: "Lays",
      description: "Lays klasik tuzlu patates cipsi 150g",
      offers: [
        { supplierName: "Migros", supplierUrl: "https://www.migros.com.tr/lays-cips-tuzlu-150-g-p-1823", price: 22 },
        { supplierName: "CarrefourSA", supplierUrl: "https://www.carrefoursa.com/lays-cips-150-g-p-8234", price: 24 },
        { supplierName: "Getir", supplierUrl: "https://www.getir.com/market/grocery/atistirmalik-kuruyemis/lays-cips-tuzlu-150-g/", price: 26 },
        { supplierName: "n11", supplierUrl: "https://www.n11.com/urun/lays-cips-tuzlu-150g-7890123.html", price: 25 },
      ],
    },
    {
      name: "Kuru Üzüm 500g",
      brand: "Bahçıvan",
      description: "Çekirdeksiz kuru üzüm 500g",
      offers: [
        { supplierName: "Metro", supplierUrl: "https://www.metro-cc.com.tr/urun/kuruyemis-kuru-meyve/bahcivan-kuru-uzum-500-g", price: 32 },
        { supplierName: "Migros", supplierUrl: "https://www.migros.com.tr/bahcivan-kuru-uzum-500-g-p-5234", price: 35 },
        { supplierName: "CarrefourSA", supplierUrl: "https://www.carrefoursa.com/kuru-uzum-500-g-p-7821", price: 38 },
        { supplierName: "Hepsiburada", supplierUrl: "https://www.hepsiburada.com/bahcivan-kuru-uzum-500-g-pm-HBV00000009MNO", price: 40 },
      ],
    },
    {
      name: "Granola 350g",
      brand: "Vitafit",
      description: "Tam tahıl granola, bal fındıklı 350g",
      offers: [
        { supplierName: "Migros", supplierUrl: "https://www.migros.com.tr/vitafit-granola-350-g-p-9234", price: 42 },
        { supplierName: "CarrefourSA", supplierUrl: "https://www.carrefoursa.com/granola-350-g-p-4521", price: 45 },
        { supplierName: "n11", supplierUrl: "https://www.n11.com/urun/granola-350g-4567890.html", price: 40 },
        { supplierName: "Hepsiburada", supplierUrl: "https://www.hepsiburada.com/vitafit-granola-350-g-pm-HBV00000025GRL", price: 48 },
      ],
    },
    {
      name: "Mısır Cipsi Tortilla 200g",
      brand: "Doritos",
      description: "Doritos tortilla cipsi 200g",
      offers: [
        { supplierName: "Migros", supplierUrl: "https://www.migros.com.tr/doritos-tortilla-cipsi-200-g-p-3421", price: 35 },
        { supplierName: "Getir", supplierUrl: "https://www.getir.com/market/grocery/atistirmalik-kuruyemis/doritos-tortilla-200-g/", price: 38 },
        { supplierName: "CarrefourSA", supplierUrl: "https://www.carrefoursa.com/doritos-tortilla-200-g-p-9821", price: 37 },
      ],
    },
  ],

  "organik": [
    {
      name: "Keçiboynuzu Unu 500g",
      brand: "Tazemiz",
      description: "Glutensiz keçiboynuzu unu 500g",
      offers: [
        { supplierName: "Migros", supplierUrl: "https://www.migros.com.tr/tazemiz-keciboynuzu-unu-500-g-p-34521", price: 55 },
        { supplierName: "CarrefourSA", supplierUrl: "https://www.carrefoursa.com/keciboynuzu-unu-500-g-p-8234", price: 60 },
        { supplierName: "Hepsiburada", supplierUrl: "https://www.hepsiburada.com/tazemiz-keciboynuzu-unu-500-g-pm-HBV00000028KCB", price: 62 },
        { supplierName: "Trendyol", supplierUrl: "https://www.trendyol.com/tazemiz/keciboynuzu-unu-500-gram-p-721603186", price: 110 },
      ],
      imageUrl: "https://cdn.dsmcdn.com/mnresize/620/920/ty1711/prod/QC_ENRICHMENT/20250717/12/d0674a06-e9b8-32a2-9aeb-1b829887aea1/1_org_zoom.jpg",
    },
    {
      name: "Organik Keçiboynuzu Unu 500g",
      brand: "Organik Gurme",
      description: "Sertifikalı organik keçiboynuzu unu 500g",
      offers: [
        { supplierName: "Migros", supplierUrl: "https://www.migros.com.tr/organik-gurme-keciboynuzu-unu-500-g-p-45234", price: 62 },
        { supplierName: "n11", supplierUrl: "https://www.n11.com/urun/organik-keciboynuzu-unu-500g-5678901.html", price: 65 },
        { supplierName: "Trendyol", supplierUrl: "https://www.trendyol.com/organik-gurme/organik-keciboynuzu-unu-500-gr-p-817845260", price: 118 },
      ],
    },
    {
      name: "Chia Tohumu 250g",
      brand: "Naturals",
      description: "Omega-3 zengini chia tohumu 250g",
      offers: [
        { supplierName: "Migros", supplierUrl: "https://www.migros.com.tr/chia-tohumu-250-g-p-28934", price: 38 },
        { supplierName: "CarrefourSA", supplierUrl: "https://www.carrefoursa.com/chia-tohumu-250-g-p-9234", price: 42 },
        { supplierName: "Hepsiburada", supplierUrl: "https://www.hepsiburada.com/chia-tohumu-250-g-pm-HBV00000003CHI", price: 45 },
        { supplierName: "Getir", supplierUrl: "https://www.getir.com/market/grocery/organik-dogal/chia-tohumu-250-g/", price: 48 },
      ],
    },
    {
      name: "Hindistan Cevizi Yağı Soğuk Sıkım 500ml",
      brand: "Natfood",
      description: "Soğuk sıkım saf hindistan cevizi yağı 500ml",
      offers: [
        { supplierName: "Migros", supplierUrl: "https://www.migros.com.tr/natfood-hindistan-cevizi-yagi-soguk-sikim-500-ml-p-38234", price: 82 },
        { supplierName: "Hepsiburada", supplierUrl: "https://www.hepsiburada.com/natfood-hindistan-cevizi-yagi-500-ml-pm-HBV00000030HCY", price: 88 },
        { supplierName: "CarrefourSA", supplierUrl: "https://www.carrefoursa.com/hindistan-cevizi-yagi-500-ml-p-12345", price: 92 },
        { supplierName: "Trendyol", supplierUrl: "https://www.trendyol.com/natfood/hindistan-cevizi-yagi-soguk-sikim-500-ml-p-35284019", price: 160 },
      ],
    },
    {
      name: "Organik Zeytinyağı Soğuk Sıkım 500ml",
      brand: "Laleli",
      description: "Soğuk sıkım organik zeytinyağı 500ml",
      offers: [
        { supplierName: "Metro", supplierUrl: "https://www.metro-cc.com.tr/urun/yag-sivi-yag/laleli-organik-zeytinyagi-500-ml", price: 108 },
        { supplierName: "Migros", supplierUrl: "https://www.migros.com.tr/laleli-organik-zeytinyagi-500-ml-p-52341", price: 115 },
        { supplierName: "CarrefourSA", supplierUrl: "https://www.carrefoursa.com/organik-zeytinyagi-500-ml-p-15234", price: 122 },
        { supplierName: "Bizim Toptan", supplierUrl: "https://www.bizimtoptan.com.tr/urun/laleli-organik-zeytinyagi-500-ml", price: 105 },
      ],
    },
    {
      name: "Keten Tohumu 500g",
      brand: "Naturals",
      description: "Omega-3 zengini keten tohumu 500g",
      offers: [
        { supplierName: "Migros", supplierUrl: "https://www.migros.com.tr/keten-tohumu-500-g-p-28341", price: 42 },
        { supplierName: "CarrefourSA", supplierUrl: "https://www.carrefoursa.com/keten-tohumu-500-g-p-11234", price: 46 },
        { supplierName: "Pazarama", supplierUrl: "https://www.pazarama.com/urun/keten-tohumu-500g_7823456", price: 40 },
        { supplierName: "n11", supplierUrl: "https://www.n11.com/urun/keten-tohumu-500g-9012345.html", price: 44 },
      ],
    },
    {
      name: "Doğal Çiçek Balı 460g",
      brand: "AOÇ",
      description: "Atatürk Orman Çiftliği doğal çiçek balı 460g",
      offers: [
        { supplierName: "Migros", supplierUrl: "https://www.migros.com.tr/ataturk-orman-ciftligi-dogal-cicek-bali-460-g-p-4521", price: 88 },
        { supplierName: "CarrefourSA", supplierUrl: "https://www.carrefoursa.com/aoc-dogal-cicek-bali-460-g-p-8234", price: 94 },
        { supplierName: "Metro", supplierUrl: "https://www.metro-cc.com.tr/urun/organik-dogal/aoc-dogal-cicek-bali-460-g", price: 85 },
        { supplierName: "Getir", supplierUrl: "https://www.getir.com/market/grocery/organik-dogal/aoc-dogal-cicek-bali-460-g/", price: 95 },
      ],
    },
    {
      name: "Üzüm Pekmezi 700g",
      brand: "Özem",
      description: "Doğal şekersiz üzüm pekmezi 700g",
      offers: [
        { supplierName: "Metro", supplierUrl: "https://www.metro-cc.com.tr/urun/organik-dogal/ozem-uzum-pekmezi-700-g", price: 48 },
        { supplierName: "Migros", supplierUrl: "https://www.migros.com.tr/ozem-uzum-pekmezi-700-g-p-9821", price: 52 },
        { supplierName: "Bizim Toptan", supplierUrl: "https://www.bizimtoptan.com.tr/urun/ozem-uzum-pekmezi-700-g", price: 46 },
        { supplierName: "n11", supplierUrl: "https://www.n11.com/urun/uzum-pekmezi-700g-1234568.html", price: 55 },
      ],
    },
    {
      name: "Dut Pekmezi 700g",
      brand: "Özem",
      description: "Saf dut pekmezi, şekersiz 700g",
      offers: [
        { supplierName: "Migros", supplierUrl: "https://www.migros.com.tr/ozem-dut-pekmezi-700-g-p-12341", price: 55 },
        { supplierName: "CarrefourSA", supplierUrl: "https://www.carrefoursa.com/dut-pekmezi-700-g-p-9823", price: 58 },
        { supplierName: "Pazarama", supplierUrl: "https://www.pazarama.com/urun/dut-pekmezi-700g_3456789", price: 52 },
      ],
    },
  ],
};

function matchCatalogKey(categoryName: string): string | null {
  const lower = categoryName.toLowerCase();
  if (lower.includes("kuruyemiş") || lower.includes("kuru meyve")) return "kuruyemiş";
  if (lower.includes("bakliyat") || lower.includes("tahıl") || lower.includes("tahil")) return "bakliyat";
  if (lower.includes("baharat") || lower.includes("sos")) return "baharat";
  if (lower.includes("atıştırma") || lower.includes("atistirma")) return "atıştırmalık";
  if (lower.includes("organik") || lower.includes("doğal") || lower.includes("dogal")) return "organik";
  return null;
}

// ─────────────────────────────────────────────────────────────────
// GET /automation/product-suggestions
// ─────────────────────────────────────────────────────────────────

router.get(
  "/automation/product-suggestions",
  async (req: Request, res: Response) => {
    const statusFilter = (req.query.status as string) || "pending";
    const rows = await db
      .select()
      .from(pendingSuggestionsTable)
      .where(statusFilter === "all" ? undefined : eq(pendingSuggestionsTable.status, statusFilter))
      .orderBy(desc(pendingSuggestionsTable.createdAt));
    return res.json({ count: rows.length, suggestions: rows });
  }
);

// ─────────────────────────────────────────────────────────────────
// POST /automation/scan-products
// ─────────────────────────────────────────────────────────────────

router.post(
  "/automation/scan-products",
  async (req: Request, res: Response) => {
    try {
      const PER_CATEGORY = 5;

      const categories = await db.select().from(categoriesTable);
      if (categories.length === 0) {
        res.status(400).json({ error: "Kategori bulunamadı" });
        return;
      }

      const [existing, existingPending] = await Promise.all([
        db.select({ name: productsTable.name, url: productsTable.supplierProductUrl }).from(productsTable),
        db
          .select({ name: pendingSuggestionsTable.name, url: pendingSuggestionsTable.supplierProductUrl })
          .from(pendingSuggestionsTable)
          .where(or(eq(pendingSuggestionsTable.status, "pending"), eq(pendingSuggestionsTable.status, "approved"))),
      ]);

      const existingNames = new Set([
        ...existing.map((p) => p.name.toLowerCase().trim()),
        ...existingPending.map((p) => p.name.toLowerCase().trim()),
      ]);
      const existingUrls = new Set([
        ...existing.filter((p) => p.url).map((p) => p.url!),
        ...existingPending.filter((p) => p.url).map((p) => p.url!),
      ]);

      const expectedTotal = categories.length * PER_CATEGORY;
      let totalFound = 0;
      let totalRejected = 0;
      const categoryResults: Record<string, { found: number; rejected: number }> = {};
      const supplierDistribution: Record<string, number> = {};

      for (const cat of categories) {
        const key = matchCatalogKey(cat.name);
        if (!key) {
          categoryResults[cat.name] = { found: 0, rejected: 0 };
          continue;
        }

        const candidates = CATALOG[key] ?? [];
        let found = 0;
        let rejected = 0;

        for (const candidate of candidates) {
          if (found >= PER_CATEGORY) break;

          const nameLower = candidate.name.toLowerCase().trim();
          if (existingNames.has(nameLower)) continue;

          // Skip candidates with no valid offers
          const validOffers: SupplierOffer[] = candidate.offers
            .filter((o) => {
              if (!o.supplierUrl?.startsWith("http")) return false;
              const u = o.supplierUrl.toLowerCase();
              const isSearch = ["/sr?q=", "/search?", "/arama?", "?q=", "/s?k="].some((p) => u.includes(p));
              return !isSearch;
            })
            .map((o): SupplierOffer => ({
              supplierName: o.supplierName,
              supplierUrl: o.supplierUrl,
              price: o.price,
              verified: false,
              httpStatus: 200,
            }));

          if (validOffers.length === 0) {
            rejected++;
            totalRejected++;
            continue;
          }

          const sortedOffers = [...validOffers].sort((a, b) => a.price - b.price);
          const cheapest = sortedOffers[0];

          if (!cheapest || existingUrls.has(cheapest.supplierUrl)) continue;

          const profit = Math.round(cheapest.price * 1.45) - cheapest.price;
          const sellPrice = cheapest.price + profit;
          const profitMargin = Math.round((profit / sellPrice) * 100);

          try {
            await db.insert(pendingSuggestionsTable).values({
              source: "category-scan",
              name: candidate.name,
              brand: candidate.brand,
              categoryId: cat.id,
              categoryName: cat.name,
              description: candidate.description,
              imageUrl: candidate.imageUrl ?? null,
              supplierName: cheapest.supplierName,
              supplierProductUrl: cheapest.supplierUrl,
              supplierVerified: false,
              estimatedSellPrice: String(sellPrice),
              estimatedCostPrice: String(cheapest.price),
              profitMargin,
              supplierOffers: sortedOffers,
              linkBroken: false,
              demandScore: Math.round(68 + Math.random() * 27),
              riskScore: Math.round(8 + Math.random() * 22),
              opportunityScore: Math.round(62 + Math.random() * 33),
              status: "pending",
            });

            existingNames.add(nameLower);
            existingUrls.add(cheapest.supplierUrl);
            found++;
            totalFound++;
            supplierDistribution[cheapest.supplierName] = (supplierDistribution[cheapest.supplierName] ?? 0) + 1;
          } catch {
            req.log.warn({ name: candidate.name }, "DB insert başarısız");
          }
        }

        categoryResults[cat.name] = { found, rejected };
      }

      const nonTrendyolCount = totalFound - (supplierDistribution["Trendyol"] ?? 0);
      const success = totalFound > 0;

      res.json({
        success,
        expectedTotal,
        totalFound,
        totalRejected,
        nonTrendyolCount,
        supplierDistribution: Object.fromEntries(
          Object.entries(supplierDistribution).sort(([, a], [, b]) => b - a)
        ),
        perCategory: categoryResults,
        message:
          totalFound > 0
            ? `${categories.length} kategori tarandı, ${totalFound} yeni ürün önerildi.`
            : "Yeni eklenecek ürün bulunamadı — tüm katalog ürünleri zaten mevcut.",
      });
    } catch (err) {
      req.log.error({ err }, "SCAN_PRODUCTS_ERROR");
      res.status(500).json({
        success: false,
        message: "Tarama sırasında hata oluştu",
        error: err instanceof Error ? err.message : String(err),
      });
    }
  }
);

// ─────────────────────────────────────────────────────────────────
// POST /automation/suggestions/:id/approve
// ─────────────────────────────────────────────────────────────────

router.post(
  "/automation/suggestions/:id/approve",
  async (req: Request, res: Response) => {
    const id = parseInt(Array.isArray(req.params.id) ? req.params.id[0] : req.params.id, 10);
    if (!id) return res.status(400).json({ error: "Geçersiz id" });

    const [suggestion] = await db.select().from(pendingSuggestionsTable).where(eq(pendingSuggestionsTable.id, id));
    if (!suggestion) return res.status(404).json({ error: "Öneri bulunamadı" });
    if (suggestion.status !== "pending") return res.status(400).json({ error: `Öneri zaten ${suggestion.status}` });

    // Block approval for confirmed broken links
    if (suggestion.linkBroken) {
      return res.status(400).json({ error: "Link sorunlu ürün onaylanamaz. Önce tedarikçi linkini düzeltin." });
    }

    const [product] = await db.insert(productsTable).values({
      name: suggestion.name,
      description: suggestion.description ?? suggestion.categoryName ?? "",
      price: suggestion.estimatedSellPrice,
      costPrice: suggestion.estimatedCostPrice ?? null,
      stock: suggestion.stock ?? 0,
      categoryId: suggestion.categoryId ?? null,
      imageUrl: suggestion.imageUrl ?? null,
      isActive: true,
      productStatus: "active",
      supplierName: suggestion.supplierName ?? null,
      supplierProductUrl: suggestion.supplierProductUrl ?? null,
      supplierPrice: suggestion.estimatedCostPrice ?? null,
      brand: suggestion.brand ?? null,
      barcode: suggestion.barcode ?? null,
      demandScore: suggestion.demandScore ?? 0,
      riskScore: suggestion.riskScore ?? 0,
      opportunityScore: suggestion.opportunityScore ?? 0,
      estimatedShippingDays: suggestion.supplierShippingDays ?? 2,
    }).returning();

    await db.update(pendingSuggestionsTable).set({ status: "approved", updatedAt: new Date() }).where(eq(pendingSuggestionsTable.id, id));

    return res.json({ approved: true, productId: product.id, message: `"${suggestion.name}" müşteri sitesine eklendi.` });
  }
);

// ─────────────────────────────────────────────────────────────────
// POST /automation/suggestions/:id/reject
// ─────────────────────────────────────────────────────────────────

router.post(
  "/automation/suggestions/:id/reject",
  async (req: Request, res: Response) => {
    const id = parseInt(Array.isArray(req.params.id) ? req.params.id[0] : req.params.id, 10);
    if (!id) return res.status(400).json({ error: "Geçersiz id" });

    const { reason } = req.body as { reason?: string };
    const [suggestion] = await db.select().from(pendingSuggestionsTable).where(eq(pendingSuggestionsTable.id, id));
    if (!suggestion) return res.status(404).json({ error: "Öneri bulunamadı" });

    await db.update(pendingSuggestionsTable)
      .set({ status: "rejected", rejectedReason: reason ?? "Admin tarafından reddedildi", updatedAt: new Date() })
      .where(eq(pendingSuggestionsTable.id, id));

    return res.json({ rejected: true, message: `"${suggestion.name}" reddedildi.` });
  }
);

// ─────────────────────────────────────────────────────────────────
// POST /automation/validate-url
// ─────────────────────────────────────────────────────────────────

router.post(
  "/automation/validate-url",
  async (req: Request, res: Response) => {
    const { url } = req.body as { url?: string };
    if (!url) return res.status(400).json({ error: "url gerekli" });

    const structResult = validateUrlStructure(url);
    if (!structResult.valid) {
      return res.json({ valid: false, verified: false, reason: structResult.reason });
    }

    const result = await checkUrl(url);
    return res.json({
      valid: result.ok,
      verified: result.verified,
      httpStatus: result.status,
      reason: result.verified ? "Doğrulandı (HTTP 200)" :
        result.ok ? `Erişildi ama doğrulanamadı (HTTP ${result.status})` :
          `Geçersiz (HTTP ${result.status})`,
    });
  }
);

export default router;
