import { randomUUID } from "node:crypto";
import { Router, type IRouter, type Request, type Response } from "express";
import { and, eq } from "drizzle-orm";
import { db, cartItemsTable, cartsTable, productsTable } from "@workspace/db";
import {
  AddToCartBody, UpdateCartItemParams, UpdateCartItemBody, RemoveFromCartParams,
  GetCartResponse, AddToCartResponse, UpdateCartItemResponse, RemoveFromCartResponse, ClearCartResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();
const COOKIE_NAME = "arya_cart_session";
const COOKIE_MAX_AGE = 1000 * 60 * 60 * 24 * 30;

type CartItem = { productId: number; name: string; price: number; quantity: number; subtotal: number; imageUrl: string | null };

export function getCartSessionId(req: Request, res: Response): string {
  const existing = typeof req.cookies?.[COOKIE_NAME] === "string" ? req.cookies[COOKIE_NAME] : "";
  if (/^[a-f0-9-]{36}$/i.test(existing)) return existing;
  const sessionId = randomUUID();
  res.cookie(COOKIE_NAME, sessionId, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    maxAge: COOKIE_MAX_AGE,
    path: "/",
  });
  return sessionId;
}

async function getOrCreateCart(sessionId: string) {
  await db.insert(cartsTable).values({ sessionId }).onConflictDoNothing();
  const [cart] = await db.select().from(cartsTable).where(eq(cartsTable.sessionId, sessionId)).limit(1);
  if (!cart) throw new Error("Sepet oluşturulamadı.");
  return cart;
}

async function buildCart(sessionId: string) {
  const cart = await getOrCreateCart(sessionId);
  const rows = await db.select().from(cartItemsTable).where(eq(cartItemsTable.cartId, cart.id));
  const items: CartItem[] = [];
  for (const row of rows) {
    const [product] = await db.select().from(productsTable).where(eq(productsTable.id, row.productId)).limit(1);
    if (!product || !product.isActive || product.productStatus !== "active" || product.stock <= 0) continue;
    const quantity = Math.min(row.quantity, product.stock);
    items.push({ productId: product.id, name: product.name, price: Number(product.price), quantity, subtotal: Number(product.price) * quantity, imageUrl: product.imageUrl });
  }
  const total = items.reduce((sum, item) => sum + item.subtotal, 0);
  const itemCount = items.reduce((sum, item) => sum + item.quantity, 0);
  return { cart, response: { items, total, itemCount } };
}

export async function clearCartForSession(sessionId: string) {
  const [cart] = await db.select().from(cartsTable).where(eq(cartsTable.sessionId, sessionId)).limit(1);
  if (cart) await db.delete(cartItemsTable).where(eq(cartItemsTable.cartId, cart.id));
}

router.get("/cart", async (req, res): Promise<void> => {
  try {
    const { response } = await buildCart(getCartSessionId(req, res));
    res.json(GetCartResponse.parse(response));
  } catch (error) { res.status(500).json({ error: error instanceof Error ? error.message : String(error) }); }
});

router.post("/cart/items", async (req, res): Promise<void> => {
  try {
    const parsed = AddToCartBody.safeParse(req.body);
    if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }
    const sessionId = getCartSessionId(req, res);
    const cart = await getOrCreateCart(sessionId);
    const [product] = await db.select().from(productsTable).where(eq(productsTable.id, parsed.data.productId)).limit(1);
    if (!product || !product.isActive || product.productStatus !== "active") { res.status(404).json({ error: "Satışta ürün bulunamadı" }); return; }
    const [existing] = await db.select().from(cartItemsTable).where(and(eq(cartItemsTable.cartId, cart.id), eq(cartItemsTable.productId, product.id))).limit(1);
    const quantity = (existing?.quantity ?? 0) + parsed.data.quantity;
    if (quantity > product.stock) { res.status(400).json({ error: "Yetersiz stok" }); return; }
    if (existing) await db.update(cartItemsTable).set({ quantity, updatedAt: new Date() }).where(eq(cartItemsTable.id, existing.id));
    else await db.insert(cartItemsTable).values({ cartId: cart.id, productId: product.id, quantity });
    const { response } = await buildCart(sessionId);
    res.json(AddToCartResponse.parse(response));
  } catch (error) { res.status(500).json({ error: error instanceof Error ? error.message : String(error) }); }
});

router.patch("/cart/items/:productId", async (req, res): Promise<void> => {
  try {
    const params = UpdateCartItemParams.safeParse(req.params); const parsed = UpdateCartItemBody.safeParse(req.body);
    if (!params.success || !parsed.success) { res.status(400).json({ error: !params.success ? params.error.message : parsed.error.message }); return; }
    const sessionId = getCartSessionId(req, res); const cart = await getOrCreateCart(sessionId);
    const [item] = await db.select().from(cartItemsTable).where(and(eq(cartItemsTable.cartId, cart.id), eq(cartItemsTable.productId, params.data.productId))).limit(1);
    if (!item) { res.status(404).json({ error: "Sepette bu ürün yok" }); return; }
    if (parsed.data.quantity <= 0) await db.delete(cartItemsTable).where(eq(cartItemsTable.id, item.id));
    else {
      const [product] = await db.select().from(productsTable).where(eq(productsTable.id, item.productId)).limit(1);
      if (!product || !product.isActive || product.productStatus !== "active" || parsed.data.quantity > product.stock) { res.status(400).json({ error: "İstenen adet için stok uygun değil" }); return; }
      await db.update(cartItemsTable).set({ quantity: parsed.data.quantity, updatedAt: new Date() }).where(eq(cartItemsTable.id, item.id));
    }
    const { response } = await buildCart(sessionId); res.json(UpdateCartItemResponse.parse(response));
  } catch (error) { res.status(500).json({ error: error instanceof Error ? error.message : String(error) }); }
});

router.delete("/cart/items/:productId", async (req, res): Promise<void> => {
  try {
    const params = RemoveFromCartParams.safeParse(req.params);
    if (!params.success) { res.status(400).json({ error: params.error.message }); return; }
    const sessionId = getCartSessionId(req, res); const cart = await getOrCreateCart(sessionId);
    await db.delete(cartItemsTable).where(and(eq(cartItemsTable.cartId, cart.id), eq(cartItemsTable.productId, params.data.productId)));
    const { response } = await buildCart(sessionId); res.json(RemoveFromCartResponse.parse(response));
  } catch (error) { res.status(500).json({ error: error instanceof Error ? error.message : String(error) }); }
});

router.delete("/cart/clear", async (req, res): Promise<void> => {
  try { const sessionId = getCartSessionId(req, res); await clearCartForSession(sessionId); res.json(ClearCartResponse.parse({ items: [], total: 0, itemCount: 0 })); }
  catch (error) { res.status(500).json({ error: error instanceof Error ? error.message : String(error) }); }
});

export default router;
