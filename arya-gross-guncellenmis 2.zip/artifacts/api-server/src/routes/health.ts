import { Router, type IRouter, type Request, type Response } from "express";
import { HealthCheckResponse } from "@workspace/api-zod";

const router: IRouter = Router();

function healthHandler(_req: Request, res: Response): void {
  res.json(HealthCheckResponse.parse({ status: "ok" }));
}

router.get("/health", healthHandler);
router.get("/healthz", healthHandler);

export default router;
