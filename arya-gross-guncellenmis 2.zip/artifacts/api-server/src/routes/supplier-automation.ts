import { Router, type IRouter, type Request, type Response } from "express";
import { desc, eq, and, gt, or } from "drizzle-orm";
import {
  db,
  pendingSuggestionsTable,
  productsTable,
  categoriesTable,
  supplierProductsTable,
} from "@workspace/db";

const router: IRouter = Router();

function num(v: unknown): number {
  const n = Number(v);
  return Number.isFinite(n) ? n : 0;
}

function clean(v: unknown): string {
  return String(v ?? "").trim();
}

function envNumber(key: string, fallback: number): number {
  const raw = process.env[key];
  if (!raw) return fallback;
  const n = Number(raw);
  return Number.isFinite(n) ? n : fallback;
}

function cargoFee(): number {
  return envNumber("AUTOMATION_CARGO_FEE", 20);
}

function platformRate(): number {
  return envNumber("AUTOMATION_PLATFORM_COMMISSION", 0.08);
}

function defaultProfitRate(): number {
  return envNumber("AUTOMATION_PROFIT_RATE", 0.25);
}

function calcSalePrice(cost: number, profitRate: number): number {
  const totalCost = cost + cargoFee() + cost * platformRate();
  return Math.ceil(totalCost * (1 + profitRate));
}

function isBadUrl(url?: string | null): boolean {
  const u = clean(url).toLowerCase();
  if (!u.startsWith("http://") && !u.startsWith("https://")) return true;

  const bad = [
    "/sr?q=",
    "/ara?q=",
    "/arama",
    "/search",
    "?q=",
    "&q=",
    "s?k=",
    "google.com/search",
    "404",
    "product-not-found",
    "urun-bulunamadi",
  ];

  return bad.some((x) => u.includes(x));
}

function validImageUrl(value: unknown): string | null {
  const raw = clean(value);
  const lower = raw.toLowerCase();
  if (!raw.startsWith("http://") && !raw.startsWith("https://")) return null;
  if (["placeholder", "placehold.co", "no-image", "no_image", "default", "missing", "logo"]
    .some((token) => lower.includes(token))) return null;
  return raw;
}

async function guessCategory(productName: string): Promise<{ categoryId: number | null; categoryName: string }> {
  try {
    const categories = await db.select().from(categoriesTable);
    const normalized = productName.toLowerCase();

    for (const cat of categories as any[]) {
      const catName = String(cat.name ?? "").toLowerCase();
      if (catName && normalized.includes(catName)) {
        return { categoryId: cat.id, categoryName: cat.name };
      }
    }
  } catch {}

  return { categoryId: null, categoryName: "Genel" };
}

async function alreadyPending(name: string, supplierUrl: string) {
  const [existing] = await db
    .select()
    .from(pendingSuggestionsTable)
    .where(
      or(
        eq(pendingSuggestionsTable.name, name),
        eq(pendingSuggestionsTable.supplierProductUrl, supplierUrl),
      ),
    )
    .limit(1);

  return Boolean(existing);
}

router.get("/supplier-automation/health", (_req: Request, res: Response): void => {
  res.json({
    success: true,
    status: "ok",
    mode: "supplier-pool-brain",
    internetScraper: false,
    fakeProducts: false,
    cargoFee: cargoFee(),
    platformCommissionRate: platformRate(),
    defaultProfitRate: defaultProfitRate(),
  });
});

router.get("/supplier-automation/suggestions", async (_req: Request, res: Response): Promise<void> => {
  try {
    const rows = await db
      .select()
      .from(pendingSuggestionsTable)
      .where(eq(pendingSuggestionsTable.source, "supplier-automation"))
      .orderBy(desc(pendingSuggestionsTable.createdAt));

    res.json({ success: true, items: rows, total: rows.length });
  } catch (err) {
    res.status(500).json({ success: false, error: err instanceof Error ? err.message : String(err) });
  }
});

router.post("/supplier-automation/run", async (req: Request, res: Response): Promise<void> => {
  try {
    const body = req.body as { limit?: number; profitRate?: number };

    const limit = Math.max(1, Math.min(Number(body.limit ?? 20), 50));
    const profitRate = Number.isFinite(Number(body.profitRate))
      ? Number(body.profitRate)
      : defaultProfitRate();

    const supplierRows = await db
      .select()
      .from(supplierProductsTable)
      .where(and(eq(supplierProductsTable.isActive, true), gt(supplierProductsTable.stock, 0)))
      .orderBy(desc(supplierProductsTable.stock))
      .limit(300);

    const inserted: any[] = [];
    const skipped: any[] = [];
    const errors: string[] = [];

    for (const p of supplierRows) {
      if (inserted.length >= limit) break;

      try {
        const name = clean((p as any).name);
        const supplierUrl = clean((p as any).supplierUrl);
        const supplierPrice = num((p as any).supplierPrice);
        const imageUrl = validImageUrl((p as any).imageUrl);

        if (!name) {
          skipped.push({ name, reason: "Ürün adı boş" });
          continue;
        }

        if (supplierPrice <= 0) {
          skipped.push({ name, reason: "Tedarikçi fiyatı yok" });
          continue;
        }

        if (isBadUrl(supplierUrl)) {
          skipped.push({ name, reason: "Direkt ürün linki geçersiz" });
          continue;
        }

        if (!imageUrl) {
          skipped.push({ name, reason: "Gerçek ürün görseli yok" });
          continue;
        }

        if (await alreadyPending(name, supplierUrl)) {
          skipped.push({ name, reason: "Zaten öneri kuyruğunda" });
          continue;
        }

        const category = await guessCategory(clean((p as any).category || name));
        const salePrice = num((p as any).suggestedSalePrice) > supplierPrice
          ? num((p as any).suggestedSalePrice)
          : calcSalePrice(supplierPrice, profitRate);

        const profit = salePrice - supplierPrice - cargoFee() - supplierPrice * platformRate();
        const profitMargin = Math.max(1, Math.round((profit / Math.max(salePrice, 1)) * 100));

        const [row] = await (db as any)
          .insert(pendingSuggestionsTable)
          .values({
            source: "supplier-automation",
            name,
            brand: (p as any).brand ?? null,
            barcode: (p as any).barcode ?? null,
            categoryId: category.categoryId,
            categoryName: (p as any).category ?? category.categoryName,
            description: `${name} tedarikçi havuzundan seçildi. Tedarikçi: ${(p as any).supplierName ?? "Tedarikçi"}`,
            supplierName: (p as any).supplierName ?? "Tedarikçi",
            supplierProductUrl: supplierUrl,
            imageUrl,
            supplierVerified: true,
            estimatedSellPrice: salePrice.toFixed(2),
            estimatedCostPrice: supplierPrice.toFixed(2),
            profitMargin,
            opportunityScore: Math.min(100, Math.max(60, profitMargin + 55)),
            demandScore: 75,
            riskScore: 20,
            linkBroken: false,
            stock: (p as any).stock ?? 10,
            status: "pending",
            supplierOffers: [
              {
                supplierName: (p as any).supplierName ?? "Tedarikçi",
                supplierUrl,
                price: supplierPrice,
                verified: true,
                httpStatus: "supplier-pool",
              },
            ],
          })
          .returning();

        inserted.push(row);
      } catch (err) {
        errors.push(err instanceof Error ? err.message : String(err));
      }
    }

    res.json({
      success: true,
      mode: "supplier-pool-brain",
      fakeProducts: false,
      internetScraper: false,
      poolCount: supplierRows.length,
      insertedCount: inserted.length,
      notFoundCount: Math.max(0, limit - inserted.length),
      errorCount: errors.length,
      items: inserted,
      skipped,
      errors,
      message:
        inserted.length > 0
          ? `${inserted.length} ürün tedarikçi havuzundan öneri kuyruğuna eklendi.`
          : "Tedarikçi havuzunda uygun ürün yok. Excel/CSV ürün listesi yükleyin.",
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err instanceof Error ? err.message : String(err) });
  }
});

router.post("/supplier-automation/approve/:id", async (req: Request, res: Response): Promise<void> => {
  try {
    const id = Number(req.params.id);

    if (!Number.isInteger(id)) {
      res.status(400).json({ success: false, error: "Geçersiz ID" });
      return;
    }

    const [row] = await db
      .select()
      .from(pendingSuggestionsTable)
      .where(eq(pendingSuggestionsTable.id, id));

    if (!row) {
      res.status(404).json({ success: false, error: "Öneri bulunamadı" });
      return;
    }

    if (row.linkBroken || !row.supplierProductUrl) {
      res.status(400).json({ success: false, error: "Bozuk veya eksik tedarikçi linki olan ürün onaylanamaz." });
      return;
    }

    const salePrice = Number(row.estimatedSellPrice ?? 0);
    const costPrice = Number(row.estimatedCostPrice ?? 0);

    if (!Number.isFinite(salePrice) || salePrice <= 0) {
      res.status(400).json({ success: false, error: "Satış fiyatı geçersiz." });
      return;
    }

    const [product] = await (db as any)
      .insert(productsTable)
      .values({
        name: row.name,
        price: salePrice.toFixed(2),
        categoryId: row.categoryId ?? null,
        brand: row.brand ?? "",
        imageUrl: row.imageUrl ?? "",
        description: row.description ?? "",
        stock: Number(row.stock ?? 10),
        supplierProductUrl: row.supplierProductUrl ?? "",
        costPrice: Number.isFinite(costPrice) ? costPrice.toFixed(2) : "0.00",
        productStatus: "active",
        isActive: true,
      })
      .returning();

    await db
      .update(pendingSuggestionsTable)
      .set({ status: "approved", updatedAt: new Date() })
      .where(eq(pendingSuggestionsTable.id, id));

    res.json({ success: true, product, message: "Ürün onaylandı ve siteye eklendi." });
  } catch (err) {
    res.status(500).json({ success: false, error: err instanceof Error ? err.message : String(err) });
  }
});

router.post("/supplier-automation/reject/:id", async (req: Request, res: Response): Promise<void> => {
  try {
    const id = Number(req.params.id);

    if (!Number.isInteger(id)) {
      res.status(400).json({ success: false, error: "Geçersiz ID" });
      return;
    }

    const body = req.body as { reason?: string };

    await db
      .update(pendingSuggestionsTable)
      .set({
        status: "rejected",
        rejectedReason: body.reason ?? "Admin reddetti",
        updatedAt: new Date(),
      })
      .where(eq(pendingSuggestionsTable.id, id));

    res.json({ success: true, message: "Öneri reddedildi." });
  } catch (err) {
    res.status(500).json({ success: false, error: err instanceof Error ? err.message : String(err) });
  }
});

router.delete("/supplier-automation/:id", async (req: Request, res: Response): Promise<void> => {
  try {
    const id = Number(req.params.id);

    if (!Number.isInteger(id)) {
      res.status(400).json({ success: false, error: "Geçersiz ID" });
      return;
    }

    await db.delete(pendingSuggestionsTable).where(eq(pendingSuggestionsTable.id, id));

    res.json({ success: true, message: "Öneri silindi." });
  } catch (err) {
    res.status(500).json({ success: false, error: err instanceof Error ? err.message : String(err) });
  }
});

export default router;
