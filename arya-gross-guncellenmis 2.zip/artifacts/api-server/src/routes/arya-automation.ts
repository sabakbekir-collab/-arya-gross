import { Router, type IRouter, type Request, type Response } from "express";
import { desc, eq, or } from "drizzle-orm";
import {
  automationRunsTable,
  db,
  pendingSuggestionsTable,
  productsTable,
  supplierProductsTable,
} from "@workspace/db";

const router: IRouter = Router();
const CARGO_FEE = 20;
const PLATFORM_COMMISSION_RATE = 0.08;

type ProductRow = typeof productsTable.$inferSelect;

function clean(value: unknown): string {
  return String(value ?? "").trim();
}

function num(value: unknown): number {
  const result = Number(value);
  return Number.isFinite(result) ? result : 0;
}

function validDirectUrl(value: unknown): string | null {
  const raw = clean(value);
  const lower = raw.toLowerCase();
  if (!raw.startsWith("http://") && !raw.startsWith("https://")) return null;
  if ([
    "/sr?q=", "/ara?q=", "/arama", "/search", "?q=", "&q=", "s?k=",
    "google.com/search", "product-not-found", "urun-bulunamadi", "sayfa-bulunamadi", "404",
  ].some((token) => lower.includes(token))) return null;

  try {
    const url = new URL(raw);
    if (!url.pathname || url.pathname === "/") return null;
    if (url.hostname.includes("trendyol.com") && !/-p-\d+/.test(url.pathname)) return null;
    if (url.hostname.includes("n11.com") && !url.pathname.includes("/urun/")) return null;
    if (url.hostname.includes("amazon.com.tr") && !url.pathname.includes("/dp/")) return null;
    return raw;
  } catch {
    return null;
  }
}

function validImageUrl(value: unknown): string | null {
  const raw = clean(value);
  const lower = raw.toLowerCase();
  if (!raw.startsWith("http://") && !raw.startsWith("https://")) return null;
  if (["placeholder", "placehold.co", "no-image", "no_image", "default", "missing", "logo"]
    .some((token) => lower.includes(token))) return null;
  return raw;
}

function calcSalePrice(cost: number): number {
  return cost > 0 ? Math.ceil((cost + CARGO_FEE) / (1 - PLATFORM_COMMISSION_RATE)) : 0;
}

async function createPendingSuggestionFromProduct(product: ProductRow): Promise<boolean> {
  const supplierUrl = validDirectUrl(product.supplierProductUrl);
  const imageUrl = validImageUrl(product.imageUrl);
  if (!supplierUrl || !imageUrl) return false;

  const supplierPrice = num(product.supplierPrice ?? product.costPrice ?? product.price);
  if (supplierPrice <= 0) return false;
  const sellPrice = Math.max(num(product.price), calcSalePrice(supplierPrice));

  const [existing] = await db
    .select({ id: pendingSuggestionsTable.id })
    .from(pendingSuggestionsTable)
    .where(
      or(
        eq(pendingSuggestionsTable.name, product.name),
        eq(pendingSuggestionsTable.supplierProductUrl, supplierUrl),
      ),
    )
    .limit(1);
  if (existing) return false;

  const profit = sellPrice - supplierPrice - CARGO_FEE - supplierPrice * PLATFORM_COMMISSION_RATE;
  const profitMargin = Math.round((profit / Math.max(sellPrice, 1)) * 100);

  await db.insert(pendingSuggestionsTable).values({
    source: "arya-automation",
    name: product.name,
    brand: product.brand ?? null,
    barcode: product.barcode ?? null,
    categoryId: product.categoryId ?? null,
    description: product.description ?? `${product.name} için otomatik ürün önerisi.`,
    imageUrl,
    estimatedSellPrice: sellPrice.toFixed(2),
    estimatedCostPrice: supplierPrice.toFixed(2),
    profitMargin,
    stock: product.stock > 0 ? product.stock : 0,
    supplierName: product.supplierName ?? "Tedarikçi",
    supplierProductUrl: supplierUrl,
    supplierVerified: true,
    supplierShippingDays: product.estimatedShippingDays ?? 3,
    demandScore: product.demandScore ?? 0,
    riskScore: product.riskScore ?? 0,
    opportunityScore: product.opportunityScore ?? 0,
    status: "pending",
    linkBroken: false,
    supplierOffers: [{
      supplierName: product.supplierName ?? "Tedarikçi",
      supplierUrl,
      price: supplierPrice,
      verified: true,
      httpStatus: "existing-product",
    }],
  });

  return true;
}

async function runAutomation(triggeredBy: string) {
  const startedAt = Date.now();
  let scannedProducts = 0;
  let suggestionsGenerated = 0;
  let errorsFound = 0;
  const logs: string[] = [];

  try {
    const products = await db
      .select()
      .from(productsTable)
      .orderBy(desc(productsTable.createdAt))
      .limit(30);

    for (const product of products) {
      scannedProducts += 1;
      try {
        const created = await createPendingSuggestionFromProduct(product);
        if (created) {
          suggestionsGenerated += 1;
          logs.push(`${product.name}: onay kuyruğuna eklendi`);
        } else {
          logs.push(`${product.name}: gerçek görsel/direkt link yok veya zaten mevcut`);
        }
      } catch (error) {
        errorsFound += 1;
        logs.push(`${product.name}: ${error instanceof Error ? error.message : String(error)}`);
      }
    }

    const summary = {
      scannedProducts,
      suggestionsGenerated,
      campaignCandidates: 0,
      adsGenerated: 0,
      errorsFound,
    };

    await db.insert(automationRunsTable).values({
      status: errorsFound > 0 ? "completed_with_errors" : "success",
      triggeredBy,
      summary,
      durationMs: Date.now() - startedAt,
      completedAt: new Date(),
    });

    return {
      success: errorsFound === 0,
      ...summary,
      logs,
      message: `${suggestionsGenerated} gerçek ürün önerisi oluşturuldu.`,
    };
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    await db.insert(automationRunsTable).values({
      status: "failed",
      triggeredBy,
      summary: {
        scannedProducts,
        suggestionsGenerated,
        campaignCandidates: 0,
        adsGenerated: 0,
        errorsFound: errorsFound + 1,
      },
      errorMessage: message,
      durationMs: Date.now() - startedAt,
      completedAt: new Date(),
    }).catch(() => undefined);
    throw error;
  }
}

async function runHandler(req: Request, res: Response): Promise<void> {
  try {
    const triggeredBy = clean(req.body?.triggeredBy) || "manual";
    res.json(await runAutomation(triggeredBy));
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error instanceof Error ? error.message : "Otomasyon çalıştırılamadı",
    });
  }
}

router.get("/arya-automation/health", (_req: Request, res: Response): void => {
  res.json({ ok: true, service: "arya-automation" });
});

router.post("/arya-automation/run", runHandler);
router.post("/arya-automation/daily", runHandler);
router.post("/arya-automation/start", runHandler);
router.post("/arya/automation/run", runHandler);
router.post("/arya/automation/daily", runHandler);
router.post("/arya/automation/start", runHandler);
router.post("/arya/daily-automation", runHandler);
router.post("/arya/run-daily", runHandler);
router.post("/arya/run", runHandler);

router.post("/arya/cleanup-search-urls", async (_req: Request, res: Response): Promise<void> => {
  try {
    const products = await db.select().from(productsTable);
    let deactivatedCount = 0;
    for (const product of products) {
      if (product.supplierProductUrl && !validDirectUrl(product.supplierProductUrl)) {
        await db
          .update(productsTable)
          .set({ isActive: false, productStatus: "draft" })
          .where(eq(productsTable.id, product.id));
        deactivatedCount += 1;
      }
    }
    res.json({
      success: true,
      deactivatedCount,
      message: `${deactivatedCount} geçersiz bağlantılı ürün taslağa alındı.`,
    });
  } catch (error) {
    res.status(500).json({ error: error instanceof Error ? error.message : String(error) });
  }
});

router.get("/arya-automation/suppliers", async (_req: Request, res: Response): Promise<void> => {
  try {
    const suppliers = await db.select().from(supplierProductsTable).limit(50);
    res.json({ suppliers, count: suppliers.length });
  } catch (error) {
    res.status(500).json({ error: error instanceof Error ? error.message : String(error) });
  }
});

router.get("/arya-automation/history", async (req: Request, res: Response): Promise<void> => {
  try {
    const limit = Math.max(1, Math.min(num(req.query.limit) || 20, 100));
    const runs = await db
      .select()
      .from(automationRunsTable)
      .orderBy(desc(automationRunsTable.startedAt))
      .limit(limit);
    res.json({ success: true, runs, total: runs.length });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error instanceof Error ? error.message : String(error),
    });
  }
});

export default router;
