import { Router, type IRouter } from "express";
import { eq } from "drizzle-orm";
import { db, productsTable } from "@workspace/db";
import {
  AiGenerateProductBody,
  AiOptimizePriceBody,
  AiGenerateProductResponse,
  AiOptimizePriceResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

const VIRAL_KEYWORDS = [
  "organik",
  "doğal",
  "el yapımı",
  "sınırlı stok",
  "tükeniyor",
  "trend",
  "viral",
  "indirim",
  "son fiyat",
  "özel teklif",
  "çok satanlar",
  "yeni",
  "taze",
  "geleneksel",
  "sağlıklı",
];

const CATEGORIES = [
  "Gıda",
  "İçecek",
  "Atıştırmalık",
  "Tatlı",
  "Baharat & Sos",
  "Konserve",
  "Tahıl & Bakliyat",
  "Kuruyemiş",
  "Süt Ürünleri",
];

function generateProductFromIdea(idea: string) {
  const lowerIdea = idea.toLowerCase();
  const isOrganic = lowerIdea.includes("organik") || lowerIdea.includes("doğal");
  const isHandmade = lowerIdea.includes("el yapımı") || lowerIdea.includes("ev");

  const basePrice = 50 + Math.floor(Math.random() * 200);
  const markup = isOrganic || isHandmade ? 2.5 : 2.0;
  const costPrice = Math.round(basePrice / markup);
  const estimatedProfit = basePrice - costPrice;

  const keywords = VIRAL_KEYWORDS.filter(() => Math.random() > 0.6).slice(0, 5);
  if (isOrganic) keywords.unshift("organik");
  if (isHandmade) keywords.unshift("el yapımı");

  const viralPotential =
    keywords.length >= 3 ? "yuksek" : keywords.length >= 2 ? "orta" : "dusuk";

  const category = CATEGORIES[Math.floor(Math.random() * CATEGORIES.length)];
  const name = generateSeoName(idea);
  const description = generateDescription(idea, isOrganic, isHandmade);

  const imageIdea = `${idea} ürününün profesyonel, aydınlık, iştah açıcı ürün fotoğrafı. Beyaz veya ahşap arka plan, doğal ışık.`;

  return {
    name,
    description,
    suggestedPrice: basePrice,
    estimatedCost: costPrice,
    estimatedProfit,
    category,
    keywords: keywords.join(", "),
    imageIdea,
    viralPotential,
  };
}

function generateSeoName(idea: string): string {
  const cleaned = idea.trim();
  const suffixes = ["Premium", "Özel", "Geleneksel", "Ev Yapımı", "Sınırlı Stok", "Seçme"];
  const suffix = suffixes[Math.floor(Math.random() * suffixes.length)];

  return `${suffix} ${cleaned.charAt(0).toUpperCase() + cleaned.slice(1)}`;
}

function generateDescription(idea: string, isOrganic: boolean, isHandmade: boolean): string {
  const urgency = [
    "Stoklar tükenmeden sipariş verin!",
    "Son 24 saat fiyatı!",
    "Bugün sipariş ver, yarın kargoda!",
  ];

  const social = [
    "Binlerce müşteri tercih etti.",
    "Türkiye'nin 4 bir yanına gönderim.",
    "Müşteri yorumları mükemmel.",
  ];

  const fomo = [
    "Bu fiyatla sınırlı stok!",
    "Kaçırmayın — çok az kaldı!",
    "Şu an en popüler ürünümüz!",
  ];

  let desc = `${idea.charAt(0).toUpperCase() + idea.slice(1)} — `;

  if (isOrganic) {
    desc += "yüzde yüz doğal ve organik içeriklerle üretilmiştir. ";
  }

  if (isHandmade) {
    desc += "özenle el yapımı, sanayi katkısı yoktur. ";
  }

  desc += `${social[Math.floor(Math.random() * social.length)]} `;
  desc += `${fomo[Math.floor(Math.random() * fomo.length)]} `;
  desc += urgency[Math.floor(Math.random() * urgency.length)];

  return desc;
}

router.post("/ai/generate-product", async (req, res): Promise<void> => {
  const parsed = AiGenerateProductBody.safeParse(req.body);

  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const result = generateProductFromIdea(parsed.data.idea);
  res.json(AiGenerateProductResponse.parse(result));
});

router.post("/ai/optimize-price", async (req, res): Promise<void> => {
  const parsed = AiOptimizePriceBody.safeParse(req.body);

  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [product] = await db
    .select()
    .from(productsTable)
    .where(eq(productsTable.id, parsed.data.productId));

  if (!product) {
    res.status(404).json({ error: "Ürün bulunamadı" });
    return;
  }

  const currentPrice = Number(product.price);
  const costPrice = product.costPrice ? Number(product.costPrice) : currentPrice * 0.4;
  const targetMargin = parsed.data.targetMargin ?? 0.4;

  const minPrice = costPrice / (1 - targetMargin);
  const marketMultiplier = 1.1 + Math.random() * 0.3;
  const suggestedPrice = Math.round(minPrice * marketMultiplier);
  const estimatedRevenueLift = ((suggestedPrice - currentPrice) / currentPrice) * 100;

  const reasoning =
    suggestedPrice > currentPrice
      ? `Mevcut fiyat (${currentPrice}₺) pazar ortalamasının altında. ${suggestedPrice}₺'ye çıkarmak kâr marjını artırır. FOMO etkisi için fiyat yükselmeden önce "SON FİYAT" etiketi ekleyin.`
      : `Mevcut fiyat rekabetçi. ${suggestedPrice}₺ optimize edilmiş fiyat, dönüşüm oranını artırabilir. Stok azalınca fiyatı kademeli artırın.`;

  res.json(
    AiOptimizePriceResponse.parse({
      currentPrice,
      suggestedPrice,
      estimatedRevenueLift: Math.round(estimatedRevenueLift * 10) / 10,
      reasoning,
    }),
  );
});

router.post("/ai/arya-chat", async (req, res): Promise<void> => {
  try {
    const apiKey = process.env.OPENAI_API_KEY;

    const userMessage = String(req.body?.message || "").trim();

    if (!userMessage) {
      res.status(400).json({ error: "Mesaj boş olamaz" });
      return;
    }

    const products = await db.select().from(productsTable).limit(80);

    const storeContext = {
      productCount: products.length,
      activeProductCount: products.filter((p) => p.isActive).length,
      missingImages: products
        .filter((p) => !p.imageUrl || String(p.imageUrl).includes("placeholder"))
        .map((p) => p.name),
      missingSupplierLinks: products
        .filter((p) => !p.supplierProductUrl)
        .map((p) => p.name),
      wrongTrendyolLinks: products
        .filter((p) => p.supplierProductUrl === "https://www.trendyol.com")
        .map((p) => p.name),
      lowStockProducts: products
        .filter((p) => Number(p.stock || 0) <= 10)
        .map((p) => ({
          name: p.name,
          stock: p.stock,
        })),
      products: products.map((p) => ({
        id: p.id,
        name: p.name,
        price: p.price,
        costPrice: p.costPrice,
        stock: p.stock,
        imageUrl: p.imageUrl,
        supplierProductUrl: p.supplierProductUrl,
        isActive: p.isActive,
      })),
    };

    if (!apiKey) {
      res.json({
        mode: "lite",
        message: `Arya Lite aktif.

Mağaza özeti:
- Toplam ürün: ${storeContext.productCount}
- Yayındaki ürün: ${storeContext.activeProductCount}
- Görsel eksik ürün: ${storeContext.missingImages.length}
- Satıcı linki eksik ürün: ${storeContext.missingSupplierLinks.length}
- Hatalı Trendyol linki: ${storeContext.wrongTrendyolLinks.length}
- Düşük stoklu ürün: ${storeContext.lowStockProducts.length}

OpenAI API anahtarı eklenirse seninle gerçek sohbet edebilirim.`,
      });
      return;
    }

    const openAiResponse = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "gpt-4.1-mini",
        input: [
          {
            role: "system",
            content:
              "Sen Arya'sın. Arya Gross admin panelinin profesyonel mağaza yöneticisi yapay zekasısın. Kısa, net, satış ve kâr odaklı konuş. Ürün, stok, kâr, görsel eksikleri ve satıcı linklerini analiz et. Asla izinsiz ürün silme, fiyat değiştirme, sipariş değiştirme veya veri değiştirme. Önce öner, sonra onay iste.",
          },
          {
            role: "user",
            content: `Mağaza verisi:\n${JSON.stringify(storeContext)}\n\nAbdullah'ın mesajı:\n${userMessage}`,
          },
        ],
      }),
    });

    const data = (await openAiResponse.json()) as any;

    if (!openAiResponse.ok) {
      res.status(500).json({
        error: "OpenAI isteği başarısız",
        detail: data?.error?.message || data,
      });
      return;
    }

    const answer =
      data.output_text ||
      data.output?.[0]?.content?.[0]?.text ||
      data.output?.[0]?.content?.[0]?.content ||
      "Arya cevap oluşturamadı.";

    res.json({
      mode: "pro",
      message: answer,
    });
  } catch (error) {
    res.status(500).json({
      error: "Arya sohbet hatası",
      detail: error instanceof Error ? error.message : String(error),
    });
  }
});

export default router;