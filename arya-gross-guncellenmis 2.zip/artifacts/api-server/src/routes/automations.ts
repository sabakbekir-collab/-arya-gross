import { Router } from "express";
import { and, eq, gt, lt } from "drizzle-orm";
import { db, productsTable as products, ordersTable as orders, supplierProductsTable } from "@workspace/db";

const router = Router();

const CARGO_FEE = 20;
const PLATFORM_COMMISSION_RATE = 0.08;

function normalize(name: string): string {
  return name.toLowerCase().replace(/\s+/g, " ").trim();
}

function calcProfitBreakdown(supplierPrice: number, salePrice: number) {
  const platformCommission = Math.round(salePrice * PLATFORM_COMMISSION_RATE);
  const netProfit = salePrice - supplierPrice - platformCommission - CARGO_FEE;
  const margin = salePrice > 0 ? Math.round((netProfit / salePrice) * 100) : 0;
  return { salePrice, platformCommission, cargoFee: CARGO_FEE, netProfit, margin };
}

router.post("/automations/pre-check", async (req, res) => {
  try {
    const checks: Record<string, { ok: boolean; note: string }> = {};

    try {
      await db.select().from(products).limit(1);
      checks.database = { ok: true, note: "PostgreSQL bağlantısı aktif" };
    } catch {
      checks.database = { ok: false, note: "Veritabanı bağlantısı başarısız" };
    }

    const aiKey = process.env.OPENAI_API_KEY;
    checks.ai = aiKey && aiKey.length > 10
      ? { ok: true, note: `OpenAI API hazır` }
      : { ok: false, note: "OPENAI_API_KEY tanımlanmamış — AI özellikler devre dışı" };

    const waPhone = process.env.VITE_WHATSAPP_PHONE ?? process.env.WHATSAPP_PHONE;
    checks.whatsapp = waPhone
      ? { ok: true, note: `WhatsApp aktif: ${waPhone}` }
      : { ok: false, note: "WHATSAPP_PHONE tanımlanmamış" };

    const productCount = await db.$count(products);
    checks.products = {
      ok: productCount > 0,
      note: productCount > 0 ? `${productCount} ürün mevcut` : "Ürün bulunamadı",
    };

    const supplierCount = await db.$count(supplierProductsTable, eq(supplierProductsTable.isActive, true));
    checks.supplierCatalog = {
      ok: supplierCount > 0,
      note: supplierCount > 0
        ? `${supplierCount} tedarikçi ürünü mevcut`
        : "Tedarikçi kataloğu boş — CSV yükleyin",
    };

    const lowStock = await db.select().from(products).where(lt(products.stock, 10));
    checks.stock = {
      ok: true,
      note: lowStock.length > 0 ? `${lowStock.length} üründe kritik stok` : "Stok durumu normal",
    };

    const allOk = Object.values(checks).every((c) => c.ok);
    const riskyOps = ["Ürün yayınlama", "Fiyat değiştirme", "Kampanya başlatma", "Stok güncelleme"];

    res.json({ checks, allOk, riskyOps, canRun: checks.database.ok && checks.products.ok });
  } catch {
    res.status(500).json({ error: "Pre-check başarısız" });
  }
});

router.post("/automations/product-finder", async (req, res) => {
  try {
    const { count = 20 } = req.body as { count?: number };
    const requestCount = Math.min(Number(count) || 20, 50);

    const existingProducts = await db.select({ name: products.name }).from(products);
    const existingNames = new Set(existingProducts.map((p) => normalize(p.name)));

    const supplierProducts = await db
      .select()
      .from(supplierProductsTable)
      .where(and(eq(supplierProductsTable.isActive, true), gt(supplierProductsTable.stock, 0)));

    const candidates = supplierProducts.filter((sp) => {
      if (!sp.name?.trim()) return false;
      if (existingNames.has(normalize(sp.name))) return false;
      if (Number(sp.supplierPrice ?? 0) <= 0) return false;
      return true;
    });

    if (candidates.length === 0) {
      res.json({
        found: 0,
        shown: 0,
        products: [],
        message: "Tedarikçi kataloğunda uygun ürün bulunamadı. Önce Tedarikçi Yükle sayfasından CSV ekleyin.",
      });
      return;
    }

    const withProfit = candidates
      .map((sp) => {
        const cost = Number(sp.supplierPrice ?? 0);
        const suggested = Number(sp.suggestedSalePrice ?? 0);
        const salePrice = suggested > 0 ? suggested : Math.round(cost * 1.45);
        const { netProfit, margin, platformCommission, cargoFee } = calcProfitBreakdown(cost, salePrice);
        return { ...sp, salePrice, netProfit, margin, platformCommission, cargoFee };
      })
      .sort((a, b) => b.margin - a.margin)
      .slice(0, requestCount);

    res.json({
      found: candidates.length,
      shown: withProfit.length,
      products: withProfit.map((p) => ({
        name: p.name,
        brand: p.brand ?? null,
        supplierName: p.supplierName ?? null,
        supplierUrl: p.supplierUrl ?? null,
        imageUrl: p.imageUrl ?? null,
        stock: p.stock ?? 0,
        supplierPrice: Number(p.supplierPrice),
        salePrice: p.salePrice,
        platformCommission: p.platformCommission,
        cargoFee: p.cargoFee,
        netProfit: p.netProfit,
        margin: p.margin,
      })),
      message: `Tedarikçi kataloğunda ${candidates.length} uygun ürün bulundu. En kârlı ${withProfit.length} ürün listelendi.`,
    });
  } catch (error) {
    req.log?.error({ error }, "product-finder error");
    res.status(500).json({ error: "Ürün bulucu başarısız" });
  }
});

router.post("/automations/price-calculator", async (req, res) => {
  const { costPrice } = req.body as { productId?: number; costPrice?: number };
  const cost = Number(costPrice) || 100;
  const salePrice = Math.round(cost * 1.45);
  const { netProfit, margin, platformCommission, cargoFee } = calcProfitBreakdown(cost, salePrice);

  res.json({
    costPrice: cost,
    salePrice,
    platformCommission,
    cargoFee,
    netProfit,
    profitRate: margin,
    recommendation: `₺${salePrice} satış fiyatı ile ₺${netProfit} net kâr (kargo + %8 komisyon dahil).`,
  });
});

router.post("/automations/campaign-selector", async (req, res) => {
  const allProducts = await db.select().from(products).where(eq(products.isActive, true));
  const selected = allProducts.slice(0, 5).map((p) => ({
    id: p.id,
    name: p.name,
    price: p.price,
    campaignPrice: Math.round(Number(p.price) * 0.85),
    discount: 15,
  }));
  res.json({ selected, count: selected.length });
});

router.post("/automations/ad-generator", async (req, res) => {
  const { productName = "Ürün", price = 100, platform = "instagram" } = req.body as {
    productName?: string; price?: number; platform?: string;
  };
  const ads: Record<string, object> = {
    instagram: {
      caption: `✨ ${productName}\n\n💰 Sadece ₺${price}!\n\nArya Gross kalitesi — doğal, taze, lezzetli. 🌿\n\n#aryagross #doğal #toptan #gaziantep`,
      hashtags: ["#aryagross", "#doğal", "#organik", "#toptan", "#gaziantep", "#kuruyemiş"],
    },
    tiktok: {
      hook: `Bu fiyatı görünce şok olacaksın! 😱`,
      script: `${productName} — sadece ₺${price}! Arya Gross'ta toptan kalite. Hemen sipariş ver!`,
      hashtags: ["#aryagross", "#fırsat", "#keşfet", "#trend"],
    },
    google: {
      headline: `${productName} — ₺${price} | Arya Gross`,
      description: `Taze ve doğal ürünler, toptan fiyatıyla. Hemen sipariş verin, kapınıza gelsin.`,
      keywords: [productName, "toptan gıda", "doğal ürün", "Gaziantep"],
    },
    whatsapp: {
      message: `🎉 *ARYA GROSS KAMPANYA*\n\n${productName} şimdi *₺${price}*!\n\nSınırlı stok — kaçırmayın!`,
    },
    facebook: {
      caption: `🛒 ${productName} şimdi Arya Gross'ta!\n💰 Fiyat: ₺${price}\n📦 Hızlı kargo, güvenli teslimat.\n\nHemen sipariş vermek için mesaj gönderin!`,
      hashtags: ["#aryagross", "#gıda", "#toptan", "#fırsat"],
    },
  };
  res.json({ platform, ad: ads[platform] ?? ads.instagram });
});

router.post("/automations/report-generator", async (req, res) => {
  try {
    const allOrders = await db.select().from(orders);
    const delivered = allOrders.filter((o) => o.status === "teslim edildi");
    const totalRevenue = delivered.reduce((s, o) => s + Number(o.total), 0);
    const pending = allOrders.filter((o) => o.status === "beklemede" || o.status === "hazirlaniyor");
    res.json({
      date: new Date().toISOString().split("T")[0],
      totalOrders: allOrders.length,
      deliveredOrders: delivered.length,
      pendingOrders: pending.length,
      totalRevenue,
      estimatedNetProfit: Math.round(totalRevenue * 0.3),
      avgOrderValue: delivered.length > 0 ? Math.round(totalRevenue / delivered.length) : 0,
      topStatus: "teslim edildi",
      generatedAt: new Date().toISOString(),
    });
  } catch {
    res.status(500).json({ error: "Rapor oluşturulamadı" });
  }
});

router.post("/automations/approve-and-run", async (_req, res) => {
  res.json({
    message: "Otomasyon başlatıldı. /arya/automation/run endpoint'ini kullanın.",
    redirect: "/api/arya/automation/run",
  });
});

router.post("/automations/cancel", async (req, res) => {
  const { sessionId } = req.body as { sessionId?: string };
  res.json({ sessionId, cancelled: true, message: "Otomasyon iptal edildi" });
});

router.post("/automations/run-all", async (_req, res) => {
  res.json({ message: "Tam otomasyon için /api/arya/automation/run endpoint'ini kullanın." });
});

export default router;
