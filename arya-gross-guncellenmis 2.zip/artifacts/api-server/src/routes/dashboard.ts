import { Router, type IRouter } from "express";
import { desc, sql, lt } from "drizzle-orm";
import { db, ordersTable, productsTable } from "@workspace/db";
import {
  GetDashboardSummaryResponse,
  GetTopProductsResponse,
  GetRecentOrdersResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/dashboard/summary", async (_req, res): Promise<void> => {
  const orders = await db.select().from(ordersTable);
  const products = await db.select().from(productsTable);

  const totalRevenue = orders.reduce((sum, o) => sum + Number(o.total), 0);
  const totalOrders = orders.length;
  const totalProducts = products.length;
  const lowStockCount = products.filter(p => p.stock <= 5).length;
  const pendingOrders = orders.filter(o => o.status === "beklemede").length;

  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const todayRevenue = orders
    .filter(o => new Date(o.createdAt) >= today)
    .reduce((sum, o) => sum + Number(o.total), 0);

  res.json(GetDashboardSummaryResponse.parse({
    totalRevenue,
    totalOrders,
    totalProducts,
    lowStockCount,
    pendingOrders,
    todayRevenue,
  }));
});

router.get("/dashboard/top-products", async (_req, res): Promise<void> => {
  const orders = await db.select().from(ordersTable);
  const productSales = new Map<number, { name: string; totalSold: number; revenue: number }>();

  for (const order of orders) {
    for (const item of (order.items as Array<{ productId: number; name: string; quantity: number; subtotal: number }>)) {
      const existing = productSales.get(item.productId);
      if (existing) {
        existing.totalSold += item.quantity;
        existing.revenue += item.subtotal;
      } else {
        productSales.set(item.productId, { name: item.name, totalSold: item.quantity, revenue: item.subtotal });
      }
    }
  }

  const topProducts = Array.from(productSales.entries())
    .map(([productId, data]) => ({
      productId,
      ...data,
      viralPotential: data.totalSold >= 20 ? "yuksek" : data.totalSold >= 10 ? "orta" : "dusuk",
    }))
    .sort((a, b) => b.revenue - a.revenue)
    .slice(0, 10);

  if (topProducts.length === 0) {
    const products = await db.select().from(productsTable).limit(5);
    const fallback = products.map(p => ({
      productId: p.id,
      name: p.name,
      totalSold: 0,
      revenue: 0,
      viralPotential: "dusuk",
    }));
    res.json(GetTopProductsResponse.parse(fallback));
    return;
  }

  res.json(GetTopProductsResponse.parse(topProducts));
});

router.get("/dashboard/recent-orders", async (_req, res): Promise<void> => {
  const rows = await db.select().from(ordersTable).orderBy(desc(ordersTable.createdAt)).limit(10);
  res.json(GetRecentOrdersResponse.parse(rows.map(r => ({
    ...r,
    total: Number(r.total),
    createdAt: r.createdAt.toISOString(),
  }))));
});

export default router;
