import { Router, type IRouter, type Request, type Response } from "express";
import { desc, eq } from "drizzle-orm";
import { db, campaignsTable, productsTable } from "@workspace/db";

const router: IRouter = Router();

function text(v: unknown): string { return String(v ?? "").trim(); }
function num(v: unknown, fallback = 0): number { const n = Number(v); return Number.isFinite(n) ? n : fallback; }
function money(v: unknown): string { return num(v).toFixed(2); }
function format(row: any) {
  return {
    ...row,
    discountPercent: num(row.discountPercent),
    originalPrice: row.originalPrice == null ? null : num(row.originalPrice),
    campaignPrice: row.campaignPrice == null ? null : num(row.campaignPrice),
    isActive: row.isActive !== false,
    startDate: row.startDate instanceof Date ? row.startDate.toISOString() : row.startDate,
    endDate: row.endDate instanceof Date ? row.endDate.toISOString() : row.endDate,
    createdAt: row.createdAt instanceof Date ? row.createdAt.toISOString() : row.createdAt,
  };
}

router.get("/campaigns", async (req: Request, res: Response): Promise<void> => {
  try {
    const rows = await db.select().from(campaignsTable).orderBy(desc(campaignsTable.createdAt));
    const activeOnly = text(req.query.active || "") === "true";
    const items = rows.map(format).filter((c: any) => !activeOnly || c.isActive !== false);
    res.json({ success: true, items, campaigns: items, total: items.length });
  } catch (err) {
    res.status(500).json({ success: false, error: err instanceof Error ? err.message : String(err) });
  }
});

router.post("/campaigns", async (req: Request, res: Response): Promise<void> => {
  try {
    const body = req.body ?? {};
    const name = text(body.name);
    if (!name) {
      res.status(400).json({ success: false, error: "Kampanya adı zorunlu." });
      return;
    }
    const productId = body.productId == null || body.productId === "" ? null : Number(body.productId);
    let productName = text(body.productName) || null;
    let originalPrice = body.originalPrice == null ? null : num(body.originalPrice);
    if (Number.isInteger(productId)) {
      const [p] = await db.select().from(productsTable).where(eq(productsTable.id, productId as number));
      if (p) {
        productName = productName || p.name;
        originalPrice = originalPrice || num(p.price);
      }
    }
    const discountPercent = Math.max(0, Math.min(90, Math.round(num(body.discountPercent, 10))));
    const campaignPrice = originalPrice ? Math.ceil(originalPrice * (1 - discountPercent / 100)) : null;
    const [row] = await db.insert(campaignsTable).values({
      name,
      type: text(body.type) || "discount",
      productId: Number.isInteger(productId) ? productId : null,
      productName,
      discountPercent,
      originalPrice: originalPrice == null ? null : money(originalPrice),
      campaignPrice: campaignPrice == null ? null : money(campaignPrice),
      reason: text(body.reason) || "Arya kampanya önerisi",
      startDate: body.startDate ? new Date(body.startDate) : new Date(),
      endDate: body.endDate ? new Date(body.endDate) : null,
      isActive: body.isActive !== false,
    }).returning();
    res.status(201).json({ success: true, item: format(row), campaign: format(row), message: "Kampanya oluşturuldu." });
  } catch (err) {
    res.status(500).json({ success: false, error: err instanceof Error ? err.message : String(err) });
  }
});

router.post("/campaigns/generate", async (_req: Request, res: Response): Promise<void> => {
  try {
    const products = await db.select().from(productsTable).orderBy(desc(productsTable.opportunityScore)).limit(10);
    const p = products.find((x: any) => x.isActive !== false && x.productStatus !== "draft") || products[0];
    if (!p) {
      res.status(400).json({ success: false, error: "Kampanya için ürün bulunamadı." });
      return;
    }
    const discountPercent = 10;
    const original = num(p.price);
    const [row] = await db.insert(campaignsTable).values({
      name: `Bugünün fırsatı: ${p.name}`,
      type: "discount",
      productId: p.id,
      productName: p.name,
      discountPercent,
      originalPrice: money(original),
      campaignPrice: money(Math.ceil(original * 0.9)),
      reason: "Yüksek fırsat skoru ve kampanya adayı.",
      startDate: new Date(),
      endDate: null,
      isActive: true,
    }).returning();
    res.json({ success: true, item: format(row), campaign: format(row), message: "Otomatik kampanya üretildi." });
  } catch (err) {
    res.status(500).json({ success: false, error: err instanceof Error ? err.message : String(err) });
  }
});

router.patch("/campaigns/:id", async (req: Request, res: Response): Promise<void> => {
  try {
    const id = Number(req.params.id);
    const update: Record<string, unknown> = {};
    for (const k of ["name", "type", "productName", "reason"] as const) if (req.body?.[k] !== undefined) update[k] = text(req.body[k]);
    if (req.body?.discountPercent !== undefined) update.discountPercent = Math.max(0, Math.min(90, Math.round(num(req.body.discountPercent))));
    if (req.body?.isActive !== undefined) update.isActive = req.body.isActive !== false;
    const [row] = await db.update(campaignsTable).set(update as any).where(eq(campaignsTable.id, id)).returning();
    res.json({ success: true, item: row ? format(row) : null });
  } catch (err) {
    res.status(500).json({ success: false, error: err instanceof Error ? err.message : String(err) });
  }
});

router.delete("/campaigns/:id", async (req: Request, res: Response): Promise<void> => {
  try {
    const id = Number(req.params.id);
    const [row] = await db.update(campaignsTable).set({ isActive: false }).where(eq(campaignsTable.id, id)).returning();
    res.json({ success: true, item: row ? format(row) : null, message: "Kampanya pasife alındı." });
  } catch (err) {
    res.status(500).json({ success: false, error: err instanceof Error ? err.message : String(err) });
  }
});

export default router;
