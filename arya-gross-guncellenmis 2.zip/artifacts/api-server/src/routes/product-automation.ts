import { Router, type IRouter, type Request, type Response } from "express";
import { db } from "@workspace/db";
import { productsTable, categoriesTable } from "@workspace/db";

const router: IRouter = Router();

interface ProductSeed {
  name: string;
  category: string;
  sellPrice: number;
  costPrice: number;
  reason: string;
}

const PRODUCTS: ProductSeed[] = [
  // Elektronik
  { name: "Bluetooth Kablosuz Kulaklık", category: "Elektronik", sellPrice: 450, costPrice: 210, reason: "Her yaş grubunda yüksek talep, kompakt kargo avantajı" },
  { name: "USB-C Çoklu Şarj Kablosu 2m", category: "Elektronik", sellPrice: 120, costPrice: 45, reason: "Hızla tükenen aksesuar, yüksek tekrar satın alım" },
  { name: "Akıllı Saat Şarj Standı", category: "Elektronik", sellPrice: 180, costPrice: 70, reason: "Apple/Samsung uyumlu evrensel model, sürekli talep" },
  { name: "Mini Taşınabilir Hoparlör", category: "Elektronik", sellPrice: 380, costPrice: 160, reason: "Açık hava sezonu öncesi talep artışı bekleniyor" },
  { name: "Telefon Gimbal Stabilizatör", category: "Elektronik", sellPrice: 650, costPrice: 280, reason: "İçerik üretici kitlesinde viral ürün" },
  { name: "LED Masa Lambası Dokunmatik", category: "Elektronik", sellPrice: 320, costPrice: 130, reason: "Ofis ve öğrenci segmenti, yüksek talep" },
  { name: "Kablosuz Klavye Mouse Seti", category: "Elektronik", sellPrice: 580, costPrice: 250, reason: "Uzaktan çalışma trendi devam ediyor" },
  { name: "Akıllı Priz WiFi Kontrollü", category: "Elektronik", sellPrice: 220, costPrice: 90, reason: "Akıllı ev sistemi girişi, düşük birim maliyet" },
  { name: "Ring Işık Selfie Lambası 26cm", category: "Elektronik", sellPrice: 280, costPrice: 110, reason: "Sosyal medya büyümesiyle birlikte sürekli trend" },
  { name: "Type-C Hub 7 Port", category: "Elektronik", sellPrice: 350, costPrice: 145, reason: "MacBook ve laptop kullanıcıları için zorunlu aksesuar" },

  // Ev Ürünleri
  { name: "Bambu Mutfak Kesme Tahtası Seti", category: "Ev & Mutfak", sellPrice: 220, costPrice: 80, reason: "Doğal malzeme trendi, hediye kategorisinde popüler" },
  { name: "Vakumlu Saklama Kabı Seti 5li", category: "Ev & Mutfak", sellPrice: 280, costPrice: 110, reason: "Gıda israfı farkındalığıyla artan talep" },
  { name: "Silikon Pişirme Kalıp Seti", category: "Ev & Mutfak", sellPrice: 190, costPrice: 70, reason: "Ev yapımı tatlı trendi, sürekli yenileme ihtiyacı" },
  { name: "Cam Yağlı Sürahi 1L", category: "Ev & Mutfak", sellPrice: 150, costPrice: 55, reason: "Plastikten uzaklaşma trendi, yüksek dönüşüm" },
  { name: "Ahşap Baharatlık Seti 12li", category: "Ev & Mutfak", sellPrice: 340, costPrice: 140, reason: "Mutfak dekorasyonu ile fonksiyonellik bir arada" },
  { name: "Paslanmaz Çelik Termos 500ml", category: "Ev & Mutfak", sellPrice: 260, costPrice: 100, reason: "Okul/iş başlangıcı sezonlarında patlama yapıyor" },
  { name: "Çelik Peynir Rendesi 4'lü", category: "Ev & Mutfak", sellPrice: 120, costPrice: 45, reason: "Küçük mutfak aleti, yüksek marj" },
  { name: "Silikon Mutfak Gereçleri Seti 6lı", category: "Ev & Mutfak", sellPrice: 230, costPrice: 90, reason: "Takım satış avantajı, hediye paket fırsatı" },
  { name: "Döküm Tava 24cm", category: "Ev & Mutfak", sellPrice: 480, costPrice: 200, reason: "Uzun ömürlü pişirme aleti, bilinçli tüketici talebi" },
  { name: "Duvar Saati Dekoratif Ahşap", category: "Ev & Mutfak", sellPrice: 290, costPrice: 115, reason: "Ev dekorasyon kategorisi yüksek büyüme hızı" },

  // Oto Aksesuar
  { name: "Araç İçi Telefon Tutucu Mıknatıslı", category: "Oto Aksesuar", sellPrice: 160, costPrice: 55, reason: "Her araç sahibine hitap, yüksek tekrar talep" },
  { name: "Araba Şarj Cihazı Çift USB", category: "Oto Aksesuar", sellPrice: 130, costPrice: 45, reason: "Zorunlu aksesuar, düşük iade oranı" },
  { name: "Koltuk Arası Organizer", category: "Oto Aksesuar", sellPrice: 180, costPrice: 65, reason: "Pratik çözüm, kompakt kargo" },
  { name: "Araç Parfümü Premium", category: "Oto Aksesuar", sellPrice: 140, costPrice: 50, reason: "Tükenebilir ürün, tekrar satın alım yüksek" },
  { name: "Ön Cam Buz Çözücü Sprey", category: "Oto Aksesuar", sellPrice: 90, costPrice: 30, reason: "Mevsimsel patlama, kış öncesi stok fırsatı" },
  { name: "Araba Koltuk Koruyucu Pet", category: "Oto Aksesuar", sellPrice: 220, costPrice: 85, reason: "Evcil hayvan sahipliği artışıyla birlikte talep büyüdü" },
  { name: "Araç İçi Hava Temizleyici USB", category: "Oto Aksesuar", sellPrice: 280, costPrice: 110, reason: "Hava kalitesi farkındalığı ile talep artışı" },
  { name: "Güneşlik Araba Ön Cam", category: "Oto Aksesuar", sellPrice: 120, costPrice: 40, reason: "Yaz sezonunda patlayan satışlar" },
  { name: "Cam Sileceği Aparatı Seti", category: "Oto Aksesuar", sellPrice: 95, costPrice: 32, reason: "Rutin bakım ürünü, düzenli talep" },
  { name: "Çocuk Güneşliği Araba Pencere", category: "Oto Aksesuar", sellPrice: 110, costPrice: 38, reason: "Genç aileler için hedefli segment" },

  // Petshop
  { name: "Otomatik Mama Kabı Kedi/Köpek", category: "Petshop", sellPrice: 350, costPrice: 145, reason: "Evcil hayvan sahipliği rekor düzeyde artıyor" },
  { name: "Tüy Toplayıcı Silindir", category: "Petshop", sellPrice: 140, costPrice: 52, reason: "Tükenebilir ürün, yüksek tekrar satış" },
  { name: "Kedi Tırmalama Tahtası", category: "Petshop", sellPrice: 180, costPrice: 68, reason: "Zorunlu kedi aksesuarı, kırılgan olmayan kargo" },
  { name: "Köpek Tasma ve Gezdirme Seti", category: "Petshop", sellPrice: 220, costPrice: 85, reason: "Yeni evcil hayvan sahipleri için ilk alım" },
  { name: "Kedi Oyun Tüneli", category: "Petshop", sellPrice: 160, costPrice: 58, reason: "Düşük maliyet, yüksek memnuniyet skoru" },
  { name: "Akıllı Su Sebili Evcil Hayvan", category: "Petshop", sellPrice: 280, costPrice: 110, reason: "Sağlık bilincinin yükselişiyle birlikte talep artıyor" },
  { name: "Pet Taşıma Çantası Hava Geçirgen", category: "Petshop", sellPrice: 380, costPrice: 160, reason: "Seyahat sezonu başlamadan stoklama fırsatı" },
  { name: "Kedi Kumu Küreği Seti", category: "Petshop", sellPrice: 95, costPrice: 32, reason: "Düşük birim, yüksek hacim satış potansiyeli" },
  { name: "Köpek Oyuncak Seti 5li", category: "Petshop", sellPrice: 190, costPrice: 72, reason: "Takım satış, düşük iade oranı" },
  { name: "Evcil Hayvan Tarak Fırça Seti", category: "Petshop", sellPrice: 130, costPrice: 48, reason: "Tüm evcil hayvan sahiplerine hitap" },

  // Bebek & Çocuk
  { name: "Silikon Mama Sandalyesi Tabağı", category: "Bebek & Çocuk", sellPrice: 180, costPrice: 65, reason: "Bebek besleme kategorisinde trending ürün" },
  { name: "Ahşap Bebek Oyuncak Seti", category: "Bebek & Çocuk", sellPrice: 320, costPrice: 130, reason: "Doğal materyal talebi, hediye kategorisinde güçlü" },
  { name: "Bebek Monitörü WiFi Kameralı", category: "Bebek & Çocuk", sellPrice: 980, costPrice: 420, reason: "Genç ebeveyn segmenti, yüksek dönüşüm" },
  { name: "Çocuk Su Şişesi Pipetli 400ml", category: "Bebek & Çocuk", sellPrice: 130, costPrice: 48, reason: "Okul başlangıcı sezonu, toplu talep" },
  { name: "Silikon Diş Kaşıyıcı Set", category: "Bebek & Çocuk", sellPrice: 110, costPrice: 38, reason: "Zorunlu bebek ürünü, kompakt kargo" },
  { name: "Bebek Battaniyesi Organik Pamuk", category: "Bebek & Çocuk", sellPrice: 280, costPrice: 108, reason: "Organik ürün talebi artıyor, hediye paket fırsatı" },
  { name: "Çocuk Uyku Tulumu 6-18 Ay", category: "Bebek & Çocuk", sellPrice: 350, costPrice: 140, reason: "Kış öncesi talep patlıyor" },
  { name: "Eğitici Zeka Oyunu 3-6 Yaş", category: "Bebek & Çocuk", sellPrice: 240, costPrice: 92, reason: "Dijital oyunlara alternatif, ebeveyn onaylı kategori" },
  { name: "Bebek Arabası Çadırı UV Korumalı", category: "Bebek & Çocuk", sellPrice: 420, costPrice: 175, reason: "Yaz sezonu ürünü, hızlı satış potansiyeli" },
  { name: "Ahşap Alfabe Puzzle Seti", category: "Bebek & Çocuk", sellPrice: 190, costPrice: 72, reason: "Eğitici oyuncak segmenti yüksek büyüme hızı" },

  // Kırtasiye & Ofis
  { name: "Bambu Kalem Standı Masa Organizer", category: "Kırtasiye", sellPrice: 160, costPrice: 58, reason: "Uzaktan çalışma trendi, ofis masası aksesuar talebi" },
  { name: "Dolma Kalem Hediye Seti", category: "Kırtasiye", sellPrice: 280, costPrice: 108, reason: "Kurumsal hediye segmenti, yüksek marj" },
  { name: "Yapışkanlı Not Kağıdı Seti 10lu", category: "Kırtasiye", sellPrice: 90, costPrice: 30, reason: "Tükenebilir ofis malzemesi, sürekli talep" },
  { name: "Ergonomik Mouse Pad Bilek Destekli", category: "Kırtasiye", sellPrice: 180, costPrice: 68, reason: "Uzun saatler ekran başında çalışanlara zorunlu" },
  { name: "Dosyalama Seti Renkli 20li", category: "Kırtasiye", sellPrice: 140, costPrice: 50, reason: "Eylül okul başlangıcında patlayan satış" },
  { name: "Marker Kalem Seti 36 Renk", category: "Kırtasiye", sellPrice: 220, costPrice: 85, reason: "Sanat ve hobi trendi, geniş hedef kitle" },
  { name: "Spiral Defter A4 100 Sayfa", category: "Kırtasiye", sellPrice: 75, costPrice: 25, reason: "Düşük birim yüksek hacim, okul sezonu patlaması" },
  { name: "Masa Üstü Ajanda Organizer", category: "Kırtasiye", sellPrice: 195, costPrice: 75, reason: "Yıl başı talebi, kurumsal satış fırsatı" },
  { name: "Termal Laminasyon Poşeti 100lü", category: "Kırtasiye", sellPrice: 130, costPrice: 45, reason: "Ofis tüketimleri, düzenli yenileme ihtiyacı" },
  { name: "Profesyonel Makas Seti 3lü", category: "Kırtasiye", sellPrice: 160, costPrice: 60, reason: "Atölye ve ofis için çok amaçlı, uzun ömürlü" },

  // Kuruyemiş & Gıda
  { name: "Organik Fındık 500g", category: "Kuruyemiş & Gıda", sellPrice: 280, costPrice: 185, reason: "Sağlıklı atıştırmalık trendi, premium segment" },
  { name: "Karışık Kuruyemiş 1kg", category: "Kuruyemiş & Gıda", sellPrice: 420, costPrice: 280, reason: "Hediye kategorisi, yüksek tekrar alım" },
  { name: "Çiğ Badem 500g", category: "Kuruyemiş & Gıda", sellPrice: 310, costPrice: 205, reason: "Sağlık bilinci artışı, diyet segmenti" },
  { name: "Organik Kuru Üzüm 500g", category: "Kuruyemiş & Gıda", sellPrice: 150, costPrice: 85, reason: "Kahvaltılık segment, geniş hedef kitle" },
  { name: "Bal Kabağı Çekirdeği 500g", category: "Kuruyemiş & Gıda", sellPrice: 180, costPrice: 108, reason: "Süper gıda trendi, sağlıklı atıştırmalık" },
  { name: "Antep Fıstığı Çerezlik 250g", category: "Kuruyemiş & Gıda", sellPrice: 240, costPrice: 165, reason: "Premium konumlandırma, yüksek memnuniyet" },
  { name: "Organik Hurma 500g", category: "Kuruyemiş & Gıda", sellPrice: 200, costPrice: 120, reason: "Ramazan sezonu + yıl boyu sağlıklı atıştırmalık" },
  { name: "Susam Tahin 350g", category: "Kuruyemiş & Gıda", sellPrice: 130, costPrice: 75, reason: "Kahvaltılık zorunlu ürün, düzenli alım" },
  { name: "Kaju Fıstığı 250g", category: "Kuruyemiş & Gıda", sellPrice: 270, costPrice: 185, reason: "Premium kuruyemiş, hediye paketi fırsatı" },
  { name: "Çam Fıstığı 100g", category: "Kuruyemiş & Gıda", sellPrice: 180, costPrice: 122, reason: "Mutfak vazgeçilmezi, küçük gramaj avantajı" },

  // Küçük Ev Aletleri
  { name: "El Blenderi Çorba Smoothie", category: "Küçük Ev Aletleri", sellPrice: 480, costPrice: 200, reason: "Sağlıklı beslenme trendi, kolay kullanım" },
  { name: "Hava Fritözü Kompakt 2L", category: "Küçük Ev Aletleri", sellPrice: 890, costPrice: 380, reason: "En hızlı büyüyen mutfak aleti kategorisi" },
  { name: "Taşınabilir Mini Ütü", category: "Küçük Ev Aletleri", sellPrice: 280, costPrice: 110, reason: "Seyahat segmenti, kompakt ve hafif kargo" },
  { name: "Çok Fonksiyonlu Waffle Makinesi", category: "Küçük Ev Aletleri", sellPrice: 520, costPrice: 215, reason: "Kahvaltı trendi ile artan ev eğlencesi talebi" },
  { name: "Taşınabilir Şarjlı Süpürge", category: "Küçük Ev Aletleri", sellPrice: 650, costPrice: 275, reason: "Hızlı temizlik ihtiyacı, kablosuz avantajı" },
  { name: "Espresso Makinesi Moka Pot", category: "Küçük Ev Aletleri", sellPrice: 380, costPrice: 155, reason: "Kahve kültürü büyümesi, kahve dükkanı maliyetinden kaçış" },
  { name: "Mini Buzdolabı 15L Oda Tipi", category: "Küçük Ev Aletleri", sellPrice: 1100, costPrice: 460, reason: "Öğrenci ve ofis segmenti, yüksek birim değer" },
  { name: "Elektrikli Fırça Diş Fırçası Seti", category: "Küçük Ev Aletleri", sellPrice: 420, costPrice: 175, reason: "Sağlık bilinci artışı, tekrar başlık satışı" },
  { name: "Ultrasonik Hava Nemlendirici", category: "Küçük Ev Aletleri", sellPrice: 340, costPrice: 140, reason: "Kış sezonu patlayan ürün, sonbahar öncesi stok" },
  { name: "Saç Kurutma Makinesi İyonlu", category: "Küçük Ev Aletleri", sellPrice: 580, costPrice: 240, reason: "Saç bakım trendi, her mevsim talep" },

  // Spor & Outdoor
  { name: "Yoga Matı Kaymaz 6mm", category: "Spor & Outdoor", sellPrice: 250, costPrice: 95, reason: "Evde spor trendi, sürekli talep" },
  { name: "Direnç Bandı Seti 5li", category: "Spor & Outdoor", sellPrice: 180, costPrice: 65, reason: "Ev jimnastiği segment büyümesi" },
  { name: "Koşu Kolu Bandı Telefon Tutucu", category: "Spor & Outdoor", sellPrice: 130, costPrice: 45, reason: "Outdoor spor artışı, kompakt kargo" },
  { name: "Su Geçirmez Spor Çantası 20L", category: "Spor & Outdoor", sellPrice: 380, costPrice: 155, reason: "Aktif yaşam tarzı büyümesi" },
  { name: "Dumbbell Set Ayarlanabilir 10kg", category: "Spor & Outdoor", sellPrice: 690, costPrice: 290, reason: "Ev spor salonu trendi, yüksek birim değer" },
  { name: "Atlamalı İp Hız Siması", category: "Spor & Outdoor", sellPrice: 160, costPrice: 55, reason: "Kardio alternatifi, düşük maliyet" },
  { name: "Sporcu Dizliği Çift", category: "Spor & Outdoor", sellPrice: 220, costPrice: 85, reason: "Yaralanma önleme bilinci artışı" },
  { name: "Kamp Feneri LED Şarjlı", category: "Spor & Outdoor", sellPrice: 280, costPrice: 108, reason: "Kamp turizm patlaması, çok amaçlı kullanım" },
  { name: "Termal Spor Taytı", category: "Spor & Outdoor", sellPrice: 320, costPrice: 130, reason: "Kış sezonu sporları, aktif kıyafet büyümesi" },
  { name: "Sporcu Protein Shaker 700ml", category: "Spor & Outdoor", sellPrice: 140, costPrice: 50, reason: "Fitness kitlesi zorunlu aksesuar, tükenebilir" },

  // Temizlik & Bakım
  { name: "Bambu Diş Fırçası Seti 4lü", category: "Temizlik & Bakım", sellPrice: 120, costPrice: 40, reason: "Sürdürülebilirlik trendi, tekrar alım yüksek" },
  { name: "Doğal Sabun Seti El Yapımı 6lı", category: "Temizlik & Bakım", sellPrice: 240, costPrice: 90, reason: "Organik ürün talebi, hediye paketi fırsatı" },
  { name: "Buharlı Ütü Masası Katlanabilir", category: "Temizlik & Bakım", sellPrice: 580, costPrice: 240, reason: "Geniş yaş aralığı, dayanıklı ürün" },
  { name: "Mikrofiber Temizlik Bezi Seti 10lu", category: "Temizlik & Bakım", sellPrice: 130, costPrice: 45, reason: "Tükenebilir ev malzemesi, sürekli talep" },
  { name: "Lavanta Yağı Aromaterapi 10ml", category: "Temizlik & Bakım", sellPrice: 120, costPrice: 42, reason: "Stres yönetimi trendi, yüksek tekrar alım" },
  { name: "Kil Maskesi Doğal 200g", category: "Temizlik & Bakım", sellPrice: 150, costPrice: 55, reason: "Cilt bakımı kategorisi yüksek büyüme hızı" },
  { name: "Duş Başlığı Filtreli", category: "Temizlik & Bakım", sellPrice: 280, costPrice: 108, reason: "Su kalitesi farkındalığı, kolay montaj avantajı" },
  { name: "Zeytinyağlı Saç Maskesi 300ml", category: "Temizlik & Bakım", sellPrice: 160, costPrice: 60, reason: "Doğal saç bakımı trendi, tekrar alım" },
  { name: "El Dezenfektanı Jel 500ml", category: "Temizlik & Bakım", sellPrice: 90, costPrice: 30, reason: "Hijyen bilincinin kalıcı talebi" },
  { name: "Tıraş Kiti Bambu Jilet Tutacağı", category: "Temizlik & Bakım", sellPrice: 220, costPrice: 82, reason: "Sürdürülebilirlik premium segment" },
];

router.get(
  "/product-automation/suggestions",
  async (req: Request, res: Response) => {
    const existingProducts = await db
      .select({ name: productsTable.name })
      .from(productsTable);

    const existingNames = new Set(
      existingProducts.map((p) => p.name.toLowerCase().trim())
    );

    const categories = await db
      .select({ id: categoriesTable.id, name: categoriesTable.name })
      .from(categoriesTable);

    const categoryMap = new Map(categories.map((c) => [c.name, c.id]));

    const suggestions = PRODUCTS.filter(
      (p) => !existingNames.has(p.name.toLowerCase().trim())
    )
      .slice(0, 100)
      .map((p) => {
        const profit = p.sellPrice - p.costPrice;
        const profitMargin = Math.round((profit / p.sellPrice) * 100);
        const categoryId = categoryMap.get(p.category) ?? null;
        const encodedName = encodeURIComponent(p.name);

        return {
          name: p.name,
          categoryName: p.category,
          categoryId,
          estimatedSellPrice: p.sellPrice,
          estimatedCostPrice: p.costPrice,
          profit,
          profitMargin,
          supplierName: "Trendyol Tedarikçi",
          supplierProductUrl: `https://www.trendyol.com/sr?q=${encodedName}`,
          reason: p.reason,
          status: "suggestion",
        };
      });

    return res.json({
      total: suggestions.length,
      suggestions,
    });
  }
);

router.post(
  "/product-automation/create-drafts",
  async (req: Request, res: Response) => {
    const existingProducts = await db
      .select({ name: productsTable.name })
      .from(productsTable);

    const existingNames = new Set(
      existingProducts.map((p) => p.name.toLowerCase().trim())
    );

    const categories = await db
      .select({ id: categoriesTable.id, name: categoriesTable.name })
      .from(categoriesTable);

    const categoryMap = new Map(categories.map((c) => [c.name, c.id]));

    const toInsert = PRODUCTS.filter(
      (p) => !existingNames.has(p.name.toLowerCase().trim())
    ).slice(0, 100);

    if (toInsert.length === 0) {
      return res.json({
        inserted: 0,
        skipped: PRODUCTS.length,
        message: "Tüm ürünler zaten mevcut, yeni taslak eklenmedi.",
      });
    }

    const rows = toInsert.map((p) => {
      const encodedName = encodeURIComponent(p.name);
      return {
        name: p.name,
        description: p.reason,
        price: String(p.sellPrice),
        costPrice: String(p.costPrice),
        stock: 0,
        categoryId: categoryMap.get(p.category) ?? null,
        isActive: false,
        productStatus: "draft",
        supplierName: "Trendyol Tedarikçi",
        supplierProductUrl: `https://www.trendyol.com/sr?q=${encodedName}`,
        supplierPrice: String(p.costPrice),
      };
    });

    await db.insert(productsTable).values(rows);

    return res.json({
      inserted: rows.length,
      skipped: PRODUCTS.length - toInsert.length,
      message: `${rows.length} ürün taslak olarak eklendi.`,
    });
  }
);

export default router;
