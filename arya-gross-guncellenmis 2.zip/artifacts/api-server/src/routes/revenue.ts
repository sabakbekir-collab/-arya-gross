import { Router, type IRouter } from "express";
import { eq } from "drizzle-orm";
import { db, ordersTable, productsTable } from "@workspace/db";
import {
  GetViralScoreParams,
  GetRevenueAnalysisResponse,
  GetViralScoreResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/revenue/analysis", async (_req, res): Promise<void> => {
  const orders = await db.select().from(ordersTable);
  const products = await db.select().from(productsTable);

  const productStats = new Map<number, { name: string; revenue: number; sold: number; costPrice: number | null; price: number }>();

  for (const p of products) {
    productStats.set(p.id, {
      name: p.name,
      revenue: 0,
      sold: 0,
      costPrice: p.costPrice ? Number(p.costPrice) : null,
      price: Number(p.price),
    });
  }

  for (const order of orders) {
    for (const item of (order.items as Array<{ productId: number; quantity: number; subtotal: number }>)) {
      const stat = productStats.get(item.productId);
      if (stat) {
        stat.revenue += item.subtotal;
        stat.sold += item.quantity;
      }
    }
  }

  const allStats = Array.from(productStats.entries()).map(([productId, stat]) => {
    const margin = stat.costPrice
      ? ((stat.price - stat.costPrice) / stat.price) * 100
      : 50;
    return { productId, ...stat, margin: Math.round(margin) };
  });

  const sorted = [...allStats].sort((a, b) => b.revenue - a.revenue);
  const topPerformers = sorted.slice(0, 5).map(s => ({
    productId: s.productId,
    name: s.name,
    revenue: s.revenue,
    margin: s.margin,
    recommendation: s.margin >= 40
      ? "Stok artır ve viral reklam yap — yüksek kâr marjı"
      : "Fiyatı hafif artır — marj düşük",
  }));

  const underperformers = sorted.slice(-5).reverse().map(s => ({
    productId: s.productId,
    name: s.name,
    revenue: s.revenue,
    margin: s.margin,
    recommendation: "Fiyatı optimize et veya reklam bütçesi artır",
  }));

  const priceOptimizations = allStats
    .filter(s => s.costPrice !== null && s.margin < 35)
    .slice(0, 5)
    .map(s => ({
      productId: s.productId,
      name: s.name,
      currentPrice: s.price,
      suggestedPrice: Math.round(s.price * 1.2),
      reason: `Mevcut kar marji ${s.margin}% — hedef %40+. Fiyati ${Math.round(s.price * 1.2)}₺ yaparak marji iyilestir.`,
    }));

  const conversionTips = [
    "Urun fotograflarini profesyonel cektir — satis %30 artar",
    "Her urune 'Son X adet kaldi' etiketi ekle — FOMO etkisi",
    "Musteri yorumu olmayan urunlere yorum topla",
    "En cok satan 3 urunu ana sayfaya sabitle",
    "Terk edilen sepetler icin SMS/email hatirlatici kur",
    "Kargo ucretini 200₺ uzeri ucretsiz yap",
    "Flash indirim saatleri belirle (sabah 9, aksam 21)",
    "TikTok/Instagram reklamlarini aksam 19-23 arasi hedefle",
  ];

  const totalPotentialRevenue = priceOptimizations.reduce(
    (sum, p) => sum + (p.suggestedPrice - p.currentPrice) * 10,
    0,
  );

  res.json(GetRevenueAnalysisResponse.parse({
    topPerformers,
    underperformers,
    priceOptimizations,
    conversionTips,
    totalPotentialRevenue,
  }));
});

router.get("/revenue/viral-score/:productId", async (req, res): Promise<void> => {
  const params = GetViralScoreParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [product] = await db.select().from(productsTable).where(eq(productsTable.id, params.data.productId));
  if (!product) {
    res.status(404).json({ error: "Ürün bulunamadı" });
    return;
  }

  let score = 40;
  const factors: string[] = [];
  const tips: string[] = [];

  if (product.imageUrl) { score += 15; factors.push("Ürün görseli mevcut (+15)"); }
  else { tips.push("Profesyonel ürün fotoğrafı ekle (+15 puan)"); }

  if (product.description && product.description.length > 50) { score += 10; factors.push("Açıklama yeterli (+10)"); }
  else { tips.push("İkna edici uzun açıklama yaz (+10 puan)"); }

  if (product.keywords && product.keywords.split(",").length >= 3) { score += 15; factors.push("Trend anahtar kelimeler (+15)"); }
  else { tips.push("En az 5 viral anahtar kelime ekle (+15 puan)"); }

  if (Number(product.price) < 150) { score += 10; factors.push("Düşük giriş fiyatı — viral kolaylaşır (+10)"); }

  if (product.stock > 0 && product.stock <= 20) { score += 10; factors.push("Düşük stok — FOMO etkisi (+10)"); }

  const level = score >= 80 ? "yuksek" : score >= 55 ? "orta" : "dusuk";

  res.json(GetViralScoreResponse.parse({
    productId: params.data.productId,
    score: Math.min(score, 100),
    level,
    factors,
    tips,
  }));
});

export default router;
