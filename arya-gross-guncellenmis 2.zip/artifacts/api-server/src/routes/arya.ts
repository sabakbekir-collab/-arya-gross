import { Router, type IRouter, type Request, type Response } from "express";
import { eq, or, desc } from "drizzle-orm";
import { db, productsTable, pendingSuggestionsTable, supplierProductsTable } from "@workspace/db";

const router: IRouter = Router();

function clean(v: unknown): string {
  return typeof v === "string" ? v.trim() : "";
}

function isRealProductUrl(url?: string | null): boolean {
  const value = clean(url).toLowerCase();
  if (!value.startsWith("http")) return false;

  const bad = ["/sr?q=", "/ara?q=", "/arama", "/search", "?q=", "&q=", "google.com", "404"];
  if (bad.some((x) => value.includes(x))) return false;

  if (value.includes("trendyol.com")) return value.includes("-p-");
  if (value.includes("hepsiburada.com")) return value.includes("/p/") || value.includes("hbv") || value.includes("-pm-");
  if (value.includes("n11.com")) return value.includes("/urun/");
  if (value.includes("amazon.com.tr")) return value.includes("/dp/");

  return true;
}

function isRealImageUrl(url?: string | null): boolean {
  const value = clean(url).toLowerCase();
  if (!value.startsWith("http")) return false;

  const bad = ["placeholder", "no-image", "default", "arya", "gross", "logo", "missing"];
  return !bad.some((x) => value.includes(x));
}

function priceNumber(v: unknown): number {
  const n = Number(v);
  return Number.isFinite(n) ? n : 0;
}

function calcSellPrice(cost: number): string {
  return String(Math.ceil(cost * 1.25 + 20));
}

async function runAryaAutomation() {
  const products = await db.select().from(productsTable).orderBy(desc(productsTable.createdAt));

  let created = 0;
  let skipped = 0;
  let deactivated = 0;
  const logs: string[] = [];

  for (const p of products.slice(0, 30)) {
    const hasLink = isRealProductUrl(p.supplierProductUrl);
    const hasImage = isRealImageUrl(p.imageUrl);
    const hasPrice = priceNumber(p.price) > 0;

    if (!hasLink || !hasImage || !hasPrice) {
      await db
        .update(productsTable)
        .set({ isActive: false, productStatus: "draft" })
        .where(eq(productsTable.id, p.id));

      deactivated++;
      logs.push(`${p.name}: eksik link/görsel/fiyat nedeniyle taslağa alındı`);
      continue;
    }

    const [existing] = await db
      .select()
      .from(pendingSuggestionsTable)
      .where(
        or(
          eq(pendingSuggestionsTable.name, p.name),
          eq(pendingSuggestionsTable.supplierProductUrl, p.supplierProductUrl ?? ""),
        ),
      )
      .limit(1);

    if (existing) {
      skipped++;
      continue;
    }

    const cost = priceNumber(p.supplierPrice ?? p.costPrice ?? p.price);
    const sell = priceNumber(p.price) > cost ? priceNumber(p.price) : Number(calcSellPrice(cost));

    await db.insert(pendingSuggestionsTable).values({
      name: p.name,
      brand: p.brand ?? null,
      barcode: p.barcode ?? null,
      categoryId: p.categoryId ?? null,
      description: p.description ?? `${p.name} için gerçek tedarikçi önerisi.`,
      imageUrl: p.imageUrl ?? null,
      estimatedSellPrice: String(sell || 0),
      estimatedCostPrice: String(cost || 0),
      stock: p.stock ?? 10,
      supplierName: p.supplierName ?? "Tedarikçi",
      supplierProductUrl: p.supplierProductUrl ?? null,
      supplierShippingDays: p.estimatedShippingDays ?? 3,
      demandScore: p.demandScore ?? 70,
      riskScore: p.riskScore ?? 20,
      opportunityScore: p.opportunityScore ?? 75,
      status: "pending",
    });

    created++;
    logs.push(`${p.name}: öneri oluşturuldu`);
  }

  return {
    success: true,
    created,
    skipped,
    deactivated,
    logs,
    message: `${created} öneri oluşturuldu, ${deactivated} hatalı ürün taslağa alındı.`,
  };
}

router.get("/arya/test", async (_req: Request, res: Response): Promise<void> => {
  res.json({
    openaiConnected: !!process.env.OPENAI_API_KEY,
    system: "Arya çalışıyor",
  });
});

router.get("/arya/suggestions", async (req: Request, res: Response): Promise<void> => {
  const status = (req.query.status as string) || "pending";

  const rows = await db
    .select()
    .from(pendingSuggestionsTable)
    .where(eq(pendingSuggestionsTable.status, status))
    .orderBy(desc(pendingSuggestionsTable.createdAt));

  res.json({ suggestions: rows, count: rows.length });
});

router.post("/arya/run", async (_req: Request, res: Response): Promise<void> => {
  try {
    res.json(await runAryaAutomation());
  } catch (err: any) {
    res.status(500).json({ success: false, error: err?.message || "Arya çalıştırılamadı" });
  }
});

router.post("/arya/daily", async (_req: Request, res: Response): Promise<void> => {
  try {
    res.json(await runAryaAutomation());
  } catch (err: any) {
    res.status(500).json({ success: false, error: err?.message || "Arya günlük çalıştırılamadı" });
  }
});

router.post("/arya/automation", async (_req: Request, res: Response): Promise<void> => {
  try {
    res.json(await runAryaAutomation());
  } catch (err: any) {
    res.status(500).json({ success: false, error: err?.message || "Arya otomasyon çalıştırılamadı" });
  }
});

router.post("/arya/cleanup-search-urls", async (_req: Request, res: Response): Promise<void> => {
  const products = await db.select().from(productsTable);

  let deactivated = 0;

  for (const p of products) {
    if (!isRealProductUrl(p.supplierProductUrl)) {
      await db
        .update(productsTable)
        .set({ isActive: false, productStatus: "draft" })
        .where(eq(productsTable.id, p.id));

      deactivated++;
    }
  }

  res.json({
    success: true,
    deactivatedCount: deactivated,
    message: `${deactivated} geçersiz linkli ürün pasife alındı.`,
  });
});

router.post("/arya/cleanup-fake", async (_req: Request, res: Response): Promise<void> => {
  const products = await db.select().from(productsTable);

  let deactivated = 0;

  for (const p of products) {
    const bad =
      !p.name ||
      !isRealProductUrl(p.supplierProductUrl) ||
      !isRealImageUrl(p.imageUrl) ||
      priceNumber(p.price) <= 0 ||
      clean(p.name).toLowerCase().includes("demo") ||
      clean(p.name).toLowerCase().includes("test");

    if (bad) {
      await db
        .update(productsTable)
        .set({ isActive: false, productStatus: "draft" })
        .where(eq(productsTable.id, p.id));

      deactivated++;
    }
  }

  res.json({
    success: true,
    deactivatedCount: deactivated,
    message: `${deactivated} sahte/eksik ürün pasife alındı.`,
  });
});

router.post("/arya/find-real-suppliers", async (_req: Request, res: Response): Promise<void> => {
  try {
    const products = await db.select().from(productsTable);
    const suppliers = await db.select().from(supplierProductsTable);

    let valid = 0;
    let rejected = 0;
    const logs: any[] = [];

    for (const p of products) {
      if (isRealProductUrl(p.supplierProductUrl) && isRealImageUrl(p.imageUrl)) {
        logs.push({ id: p.id, name: p.name, status: "accepted", reason: "Zaten geçerli" });
        valid++;
      } else {
        await db
          .update(productsTable)
          .set({ isActive: false, productStatus: "draft" })
          .where(eq(productsTable.id, p.id));

        logs.push({ id: p.id, name: p.name, status: "rejected", reason: "Gerçek link/görsel yok" });
        rejected++;
      }
    }

    res.json({
      success: true,
      found: valid,
      notFound: rejected,
      supplierCount: suppliers.length,
      logs,
      message: `${valid} ürün geçerli, ${rejected} ürün taslağa alındı.`,
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err?.message || "Tedarikçi kontrolü başarısız" });
  }
});

router.post("/arya/suggestions/:id/approve", async (req: Request, res: Response): Promise<void> => {
  const id = Number(req.params.id);

  if (!Number.isFinite(id)) {
    res.status(400).json({ error: "Geçersiz ID" });
    return;
  }

  const [suggestion] = await db
    .select()
    .from(pendingSuggestionsTable)
    .where(eq(pendingSuggestionsTable.id, id));

  if (!suggestion) {
    res.status(404).json({ error: "Öneri bulunamadı" });
    return;
  }

  const [existing] = await db
    .select({ id: productsTable.id })
    .from(productsTable)
    .where(
      or(
        eq(productsTable.name, suggestion.name),
        eq(productsTable.supplierProductUrl, suggestion.supplierProductUrl ?? ""),
      ),
    )
    .limit(1);

  if (existing) {
    await db
      .update(pendingSuggestionsTable)
      .set({ status: "approved", updatedAt: new Date() })
      .where(eq(pendingSuggestionsTable.id, id));

    res.json({
      success: true,
      duplicate: true,
      productId: existing.id,
      message: `"${suggestion.name}" zaten ürün listesinde var.`,
    });
    return;
  }

  const [product] = await db
    .insert(productsTable)
    .values({
      name: suggestion.name,
      brand: suggestion.brand ?? null,
      barcode: suggestion.barcode ?? null,
      categoryId: suggestion.categoryId ?? undefined,
      description: suggestion.description ?? null,
      imageUrl: suggestion.imageUrl ?? null,
      price: suggestion.estimatedSellPrice ?? "0",
      costPrice: suggestion.estimatedCostPrice ?? null,
      stock: suggestion.stock ?? 10,
      isActive: true,
      productStatus: "active",
      supplierName: suggestion.supplierName ?? null,
      supplierProductUrl: suggestion.supplierProductUrl ?? null,
      supplierPrice: suggestion.estimatedCostPrice ?? null,
      estimatedShippingDays: suggestion.supplierShippingDays ?? 3,
      demandScore: suggestion.demandScore ?? 0,
      riskScore: suggestion.riskScore ?? 0,
      opportunityScore: suggestion.opportunityScore ?? 0,
    })
    .returning();

  await db
    .update(pendingSuggestionsTable)
    .set({ status: "approved", updatedAt: new Date() })
    .where(eq(pendingSuggestionsTable.id, id));

  res.json({
    success: true,
    duplicate: false,
    productId: product.id,
    message: `"${suggestion.name}" ürünlere eklendi.`,
  });
});

router.post("/arya/suggestions/:id/reject", async (req: Request, res: Response): Promise<void> => {
  const id = Number(req.params.id);

  if (!Number.isFinite(id)) {
    res.status(400).json({ error: "Geçersiz ID" });
    return;
  }

  await db
    .update(pendingSuggestionsTable)
    .set({ status: "rejected", rejectedReason: "Kullanıcı reddetti", updatedAt: new Date() })
    .where(eq(pendingSuggestionsTable.id, id));

  res.json({ success: true, message: "Öneri reddedildi." });
});

export default router;