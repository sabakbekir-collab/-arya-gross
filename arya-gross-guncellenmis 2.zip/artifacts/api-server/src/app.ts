import cors from "cors";
import express, { type Express, type NextFunction, type Request, type Response } from "express";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import pinoHttp from "pino-http";
import { logger } from "./lib/logger";
import router from "./routes";

const app: Express = express();
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const buildId = "arya-20260801-140706";

app.disable("x-powered-by");
app.use((req, res, next) => {
  res.setHeader("X-Arya-Build", buildId);
  next();
});
app.use(pinoHttp({ logger }));

const origins = (process.env.CORS_ORIGIN ?? process.env.FRONTEND_URL ?? "")
  .split(",").map((item) => item.trim()).filter(Boolean);
app.use(cors({ origin: origins.length ? origins : true, credentials: true }));
app.use(express.json({ limit: "2mb" }));
app.use(express.urlencoded({ extended: true, limit: "2mb" }));

app.get("/health", (_req, res) => res.json({ status: "ok", buildId }));
app.get("/api/arya-runtime", (_req, res) => {
  res.setHeader("Cache-Control", "no-store");
  res.json({ success: true, buildId, port: process.env.PORT || "3001", domain: process.env.REPLIT_DEV_DOMAIN || null });
});

app.post("/api/arya/automation/run", (req, res, next) => {
  req.url = "/supplier-automation/run";
  router(req, res, next);
});
app.get("/api/arya/automation/suggestions", (req, res, next) => {
  req.url = "/supplier-automation/suggestions";
  router(req, res, next);
});
app.get("/api/arya/automation/health", (req, res, next) => {
  req.url = "/supplier-automation/health";
  router(req, res, next);
});

app.use("/api", router);
app.use("/api", (req: Request, res: Response) => {
  res.status(404).json({ success: false, error: "API endpointi bulunamadı", path: req.originalUrl });
});

const possibleFrontendDists = [
  path.resolve(process.cwd(), "../firat-gida/dist/public"),
  path.resolve(process.cwd(), "artifacts/firat-gida/dist/public"),
  path.resolve(__dirname, "../../firat-gida/dist/public"),
  path.resolve(__dirname, "../../../firat-gida/dist/public"),
  path.resolve(process.env.HOME || "", "workspace/artifacts/firat-gida/dist/public"),
];
const frontendDist = possibleFrontendDists.find((candidate) =>
  fs.existsSync(path.join(candidate, "index.html")),
);

if (frontendDist) {
  const indexHtml = path.join(frontendDist, "index.html");
  logger.info({ frontendDist, buildId }, "ARYA frontend build selected");
  app.use(express.static(frontendDist, {
    index: false,
    etag: true,
    setHeaders(res, filePath) {
      if (filePath.includes(`${path.sep}assets${path.sep}`)) {
        res.setHeader("Cache-Control", "public, max-age=31536000, immutable");
      } else {
        res.setHeader("Cache-Control", "no-cache");
      }
    },
  }));
  app.use("/assets", (_req, res) => res.status(404).type("text/plain").send("Asset bulunamadı"));
  app.use((req, res, next) => {
    if (req.method !== "GET" && req.method !== "HEAD") return next();
    if (req.path.startsWith("/api") || req.path.startsWith("/assets") || path.extname(req.path)) return next();
    res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
    res.setHeader("Pragma", "no-cache");
    res.setHeader("Expires", "0");
    res.setHeader("Content-Type", "text/html; charset=utf-8");
    // ARYA_PROXY_HTML_FIX_V1
    try {
      const html = fs.readFileSync(indexHtml, "utf8");

      res.status(200);
      res.setHeader("Content-Type", "text/html; charset=utf-8");
      res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
      res.setHeader("Pragma", "no-cache");
      res.setHeader("Expires", "0");
      res.setHeader("X-Content-Type-Options", "nosniff");
      res.removeHeader("Accept-Ranges");
      res.send(html);
    } catch (error) {
      logger.error(
        {
          error:
            error instanceof Error
              ? error.message
              : String(error),
          indexHtml,
        },
        "Frontend index okunamadı",
      );

      res
        .status(500)
        .type("text/plain")
        .send("Arya Gross frontend dosyası okunamadı.");
    }
  });
} else {
  logger.error({ possibleFrontendDists, buildId }, "Frontend build not found");
  app.use((_req, res) => res.status(503).type("html").send(`<!doctype html><html><body style="font-family:system-ui;padding:30px"><h1>Arya Gross frontend build bulunamadı</h1><p>Build: ${buildId}</p></body></html>`));
}

app.use((error: unknown, req: Request, res: Response, _next: NextFunction) => {
  logger.error({ err: error, method: req.method, path: req.originalUrl }, "Unhandled request error");
  if (res.headersSent) return;
  res.status(500).json({ success: false, error: "Beklenmeyen sunucu hatası" });
});

export default app;
