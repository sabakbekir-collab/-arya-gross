import app from "./app";
import { logger } from "./lib/logger";
import { seedProductImages } from "./seed-images";

const rawPort = process.env.PORT ?? "3001";
const port = Number(rawPort);

if (!Number.isInteger(port) || port <= 0 || port > 65535) {
  throw new Error(`Geçersiz PORT değeri: ${rawPort}`);
}

const server = app.listen(port, "0.0.0.0", () => {
  logger.info({ port }, "Arya Gross sunucusu çalışıyor");
  seedProductImages().catch((error) =>
    logger.warn({ err: error }, "seedProductImages başarısız oldu"),
  );
});

function shutdown(signal: string) {
  logger.info({ signal }, "Sunucu kapatılıyor");
  server.close((error) => {
    if (error) {
      logger.error({ err: error }, "Sunucu düzgün kapatılamadı");
      process.exit(1);
    }
    process.exit(0);
  });
  setTimeout(() => process.exit(1), 10_000).unref();
}

process.once("SIGINT", () => shutdown("SIGINT"));
process.once("SIGTERM", () => shutdown("SIGTERM"));
