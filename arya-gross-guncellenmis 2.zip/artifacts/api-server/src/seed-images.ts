import { db, productsTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { logger } from "./lib/logger";

const IMGS = {
  pistachio: "https://food2live.com/cdn/shop/products/b0ce3ba6-4e3b-510f-87b5-48dc5219bd6c_1445x.jpg?v=1673622398",
  walnut:    "https://icdn.tradew.com/file/201904/1573591/jpg/7724782.jpg?x-oss-process=image/resize,m_pad,l_600/quality,Q_90",
  honey:     "https://m.media-amazon.com/images/I/41HQoKWUZEL.jpg",
  lentils:   "https://m.media-amazon.com/images/I/516bDpXaMRL.jpg",
  pepper:    "https://m.media-amazon.com/images/I/51J2gH28rvL.jpg",
  mixedNuts: "https://www.browneyedbaker.com/wp-content/uploads/2020/12/nuts-bolts-4-1300.jpg",
  oliveOil:  "https://m.media-amazon.com/images/I/61SEHvFai3L.jpg",
  tomato:    "https://floralapron.com/wp-content/uploads/2023/03/P3131224-scaled.jpg",
  hazelnut:  "https://m.media-amazon.com/images/I/41g-qPbzBNL.jpg",
  salt:      "https://i.etsystatic.com/17828597/r/il/3a9748/4376247031/il_300x300.4376247031_e3c9.jpg",
  raisins:   "https://agoramarket.shop/wp-content/uploads/2021/06/8-8.jpg",
  tahini:    "https://www.alphafoodie.com/wp-content/uploads/2022/09/Tahini-Sesame-Paste-A-jar-with-homemade-tahini.jpeg",
};

const IMAGE_RULES: Array<{ pattern: RegExp; url: string }> = [
  { pattern: /fıstık|fistik|pistachio/i,                   url: IMGS.pistachio },
  { pattern: /ceviz|walnut/i,                              url: IMGS.walnut    },
  { pattern: /fındık|findik|hazelnut/i,                    url: IMGS.hazelnut  },
  { pattern: /bal|honey/i,                                 url: IMGS.honey     },
  { pattern: /mercimek|lentil/i,                           url: IMGS.lentils   },
  { pattern: /isot|biber|pepper|baharat|spice/i,           url: IMGS.pepper    },
  { pattern: /kuruyemiş|kuruyemis|karışık.*nut|mixed/i,    url: IMGS.mixedNuts },
  { pattern: /zeytinyağ|zeytinyag|olive/i,                 url: IMGS.oliveOil  },
  { pattern: /salça|salca|domates|tomato/i,                url: IMGS.tomato    },
  { pattern: /tuz|salt/i,                                  url: IMGS.salt      },
  { pattern: /üzüm|uzum|raisin|kuru.*üzüm|sultana/i,      url: IMGS.raisins   },
  { pattern: /tahini|susam|sesame/i,                       url: IMGS.tahini    },
  { pattern: /badem|almond/i,                              url: IMGS.mixedNuts },
  { pattern: /kaju|cashew/i,                               url: IMGS.mixedNuts },
  { pattern: /peynir|cheese/i,                             url: IMGS.honey     },
];

export function pickImageForProduct(productName: string): string | null {
  for (const rule of IMAGE_RULES) {
    if (rule.pattern.test(productName)) return rule.url;
  }
  return null;
}

/**
 * seedProductImages — DEVRE DIŞI
 * Stok fotoğraf CDN URL'leriyle ürün görseli yaması kaldırıldı.
 * Gerçek ürün görseli sadece CSV yükleme veya admin panelden manuel giriş ile eklenebilir.
 */
export async function seedProductImages(_force = false): Promise<number> {
  logger.info("seedProductImages: devre dışı — sahte stok fotoğraf yaması kaldırıldı");
  return 0;
}
