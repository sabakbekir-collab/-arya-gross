// ─────────────────────────────────────────────────────────────────────────────
// Real Supplier Brain — Gerçek ürün bulucu beyin
// Tüm tedarikçileri gerçek HTTP istekleriyle tarar, ürün URL'lerini doğrular,
// en ucuz sağlam tedarikçiyi seçer. Demo veri üretmez.
// ─────────────────────────────────────────────────────────────────────────────

export interface BrainOffer {
  supplier: string;
  title: string;
  price: number;
  url: string;
  imageUrl: string;
  linkBroken: boolean;
  httpStatus: number | string;
  verified: boolean;
  similarityScore: number;
}

export interface RejectedCandidate {
  url: string;
  supplier: string;
  reason: string;
}

export interface BrainResult {
  ok: boolean;
  query: string;
  bestOffer: BrainOffer | null;
  offers: BrainOffer[];
  rejected: RejectedCandidate[];
  message: string;
}

interface SupplierConfig {
  name: string;
  domain: string;
  searchUrl: (q: string) => string;
  priority: number;
  productPatterns: string[];
}

// ─────────────────────────────────────────────────────────────────────────────
// Supplier Registry — öncelik sırasına göre sıralı
// ─────────────────────────────────────────────────────────────────────────────

export const SUPPLIERS: SupplierConfig[] = [
  {
    name: "Migros",
    domain: "migros.com.tr",
    searchUrl: (q) => `https://www.migros.com.tr/arama?q=${encodeURIComponent(q)}`,
    priority: 1,
    productPatterns: ["-p-", "-pm-"],
  },
  {
    name: "CarrefourSA",
    domain: "carrefoursa.com",
    searchUrl: (q) => `https://www.carrefoursa.com/arama?q=${encodeURIComponent(q)}`,
    priority: 2,
    productPatterns: ["-p-", "/pd/"],
  },
  {
    name: "Metro",
    domain: "metro-cc.com.tr",
    searchUrl: (q) => `https://www.metro-cc.com.tr/ara?text=${encodeURIComponent(q)}`,
    priority: 3,
    productPatterns: ["/urun/"],
  },
  {
    name: "ŞOK",
    domain: "sokmarket.com.tr",
    searchUrl: (q) => `https://www.sokmarket.com.tr/search?query=${encodeURIComponent(q)}`,
    priority: 4,
    productPatterns: ["/urun/", "-p-", "/pd/"],
  },
  {
    name: "Bizim Toptan",
    domain: "bizimtoptan.com.tr",
    searchUrl: (q) => `https://www.bizimtoptan.com.tr/arama?q=${encodeURIComponent(q)}`,
    priority: 5,
    productPatterns: ["/urun/", "/p/"],
  },
  {
    name: "A101",
    domain: "a101.com.tr",
    searchUrl: (q) => `https://www.a101.com.tr/arama?q=${encodeURIComponent(q)}`,
    priority: 6,
    productPatterns: ["/p/", "/urun/", "-p-"],
  },
  {
    name: "Pazarama",
    domain: "pazarama.com",
    searchUrl: (q) => `https://www.pazarama.com/search?text=${encodeURIComponent(q)}`,
    priority: 7,
    productPatterns: ["/product/", "/urun/", "-p-"],
  },
  {
    name: "Getir",
    domain: "getir.com",
    searchUrl: (q) => `https://www.getir.com/market/arama/?q=${encodeURIComponent(q)}`,
    priority: 8,
    productPatterns: ["/grocery/", "/market/"],
  },
  {
    name: "n11",
    domain: "n11.com",
    searchUrl: (q) => `https://www.n11.com/arama?q=${encodeURIComponent(q)}`,
    priority: 9,
    productPatterns: ["/urun/", ".html"],
  },
  {
    name: "Hepsiburada",
    domain: "hepsiburada.com",
    searchUrl: (q) => `https://www.hepsiburada.com/ara?q=${encodeURIComponent(q)}`,
    priority: 10,
    productPatterns: ["-pm-", "-p-", "/pd/"],
  },
  {
    name: "Amazon TR",
    domain: "amazon.com.tr",
    searchUrl: (q) => `https://www.amazon.com.tr/s?k=${encodeURIComponent(q)}`,
    priority: 11,
    productPatterns: ["/dp/"],
  },
  {
    name: "Trendyol",
    domain: "trendyol.com",
    searchUrl: (q) => `https://www.trendyol.com/sr?q=${encodeURIComponent(q)}`,
    priority: 99,
    productPatterns: ["-p-"],
  },
];

// ─────────────────────────────────────────────────────────────────────────────
// URL Pattern constants
// ─────────────────────────────────────────────────────────────────────────────

const SEARCH_URL_PATTERNS = [
  "?q=", "&q=", "?query=", "?k=", "?srch=",
  "/sr?", "/search?", "/arama?", "/ara?", "?text=",
  "searchQuery=", "keyword=", "?search=", "/arama/",
];

const LISTING_URL_PATTERNS = [
  "/liste/", "/kategori/", "/catalog/",
  "/c/", "/category/", "/dept/", "/collections/",
];

const TRENDYOL_APP_PATTERNS = [
  "ty.gl/", "app.trendyol.com", "trendyol://", "m.trendyol.com/sr?",
];

// ─────────────────────────────────────────────────────────────────────────────
// 1. normalizeProductName
// ─────────────────────────────────────────────────────────────────────────────

export function normalizeProductName(name: string): string {
  return name
    .toLowerCase()
    .trim()
    .replace(/\s+/g, " ")
    .replace(/[*%#@!?]/g, "")
    .trim();
}

// ─────────────────────────────────────────────────────────────────────────────
// 2. buildSupplierSearchUrls
// ─────────────────────────────────────────────────────────────────────────────

export function buildSupplierSearchUrls(
  productName: string
): Array<{ supplier: SupplierConfig; searchUrl: string }> {
  const normalized = normalizeProductName(productName);
  return SUPPLIERS.sort((a, b) => a.priority - b.priority).map((s) => ({
    supplier: s,
    searchUrl: s.searchUrl(normalized),
  }));
}

// ─────────────────────────────────────────────────────────────────────────────
// 3. fetchSupplierPage — gerçek HTTP fetch
// ─────────────────────────────────────────────────────────────────────────────

interface FetchResult {
  html: string | null;
  status: number | string;
  ok: boolean;
  finalUrl: string;
}

export async function fetchSupplierPage(url: string, timeoutMs = 9000): Promise<FetchResult> {
  const ctrl = new AbortController();
  const tid = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const res = await fetch(url, {
      method: "GET",
      signal: ctrl.signal,
      redirect: "follow",
      headers: {
        "User-Agent":
          "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 " +
          "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
        Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
        "Accept-Language": "tr-TR,tr;q=0.9,en-US;q=0.8,en;q=0.5",
        "Accept-Encoding": "gzip, deflate, br",
        "Cache-Control": "no-cache",
        "Upgrade-Insecure-Requests": "1",
        "Sec-Fetch-Dest": "document",
        "Sec-Fetch-Mode": "navigate",
        "Sec-Fetch-Site": "none",
      },
    });
    clearTimeout(tid);
    const s = res.status;
    const finalUrl = res.url || url;

    if (s === 404 || s === 410 || s === 451) {
      return { html: null, status: s, ok: false, finalUrl };
    }
    if (s === 403 || s === 401 || s === 429) {
      return { html: null, status: s, ok: false, finalUrl };
    }
    if (s >= 500) {
      return { html: null, status: s, ok: false, finalUrl };
    }
    if (s >= 200 && s < 400) {
      const contentType = res.headers.get("content-type") ?? "";
      if (!contentType.includes("text/html") && !contentType.includes("application/xhtml")) {
        return { html: null, status: s, ok: true, finalUrl };
      }
      const html = await res.text();
      return { html, status: s, ok: true, finalUrl };
    }
    return { html: null, status: s, ok: false, finalUrl };
  } catch {
    clearTimeout(tid);
    return { html: null, status: "TIMEOUT", ok: false, finalUrl: url };
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// 4. extractProductCandidates — HTML'den ürün linki çıkar
// ─────────────────────────────────────────────────────────────────────────────

export function extractProductCandidates(
  html: string,
  supplier: SupplierConfig,
  maxCandidates = 5
): string[] {
  const hrefRegex = /href=["']([^"']+)["']/gi;
  const seen = new Set<string>();
  const candidates: string[] = [];

  let match: RegExpExecArray | null;
  while ((match = hrefRegex.exec(html)) !== null && candidates.length < maxCandidates) {
    let url = match[1];
    if (!url) continue;

    // Relative URL → absolute
    if (url.startsWith("/") && !url.startsWith("//")) {
      url = `https://www.${supplier.domain}${url}`;
    } else if (url.startsWith("//")) {
      url = `https:${url}`;
    } else if (!url.startsWith("http")) {
      continue;
    }

    // Must be on this supplier's domain
    if (!url.toLowerCase().includes(supplier.domain)) continue;

    // Must match product patterns
    const hasProductPattern = supplier.productPatterns.some((p) =>
      url.toLowerCase().includes(p.toLowerCase())
    );
    if (!hasProductPattern) continue;

    // Must not be search/listing page
    const urlLower = url.toLowerCase();
    const isSearch = SEARCH_URL_PATTERNS.some((p) => urlLower.includes(p));
    const isListing = LISTING_URL_PATTERNS.some((p) => urlLower.includes(p));
    if (isSearch || isListing) continue;

    // Trendyol-specific app redirect patterns
    if (supplier.domain === "trendyol.com") {
      const isTrendyolApp = TRENDYOL_APP_PATTERNS.some((p) => urlLower.includes(p));
      if (isTrendyolApp) continue;
    }

    // Deduplicate
    const clean = url.split("?")[0].split("#")[0];
    if (seen.has(clean)) continue;
    seen.add(clean);
    candidates.push(url);
  }

  return candidates;
}

// ─────────────────────────────────────────────────────────────────────────────
// Content analysis helpers
// ─────────────────────────────────────────────────────────────────────────────

function stripHtml(html: string): string {
  return html.replace(/<script[\s\S]*?<\/script>/gi, " ")
    .replace(/<style[\s\S]*?<\/style>/gi, " ")
    .replace(/<[^>]+>/g, " ")
    .replace(/\s+/g, " ")
    .toLowerCase();
}

function extractTitle(html: string): string {
  const og = html.match(/property=["']og:title["'][^>]*content=["']([^"']+)["']/i)
    ?? html.match(/content=["']([^"']+)["'][^>]*property=["']og:title["']/i);
  if (og) return og[1].trim();
  const title = html.match(/<title[^>]*>([^<]+)<\/title>/i);
  if (title) return title[1].replace(/\s*[-|]\s*.*$/, "").trim();
  const h1 = html.match(/<h1[^>]*>([^<]+)<\/h1>/i);
  if (h1) return h1[1].trim();
  return "";
}

function extractPrice(html: string): number | null {
  const pricePatterns = [
    /itemprop=["']price["'][^>]*content=["'](\d+(?:[.,]\d{1,2})?)["']/i,
    /data-price=["'](\d+(?:[.,]\d{1,2})?)["']/i,
    /"price"\s*:\s*"?(\d+(?:[.,]\d{1,2})?)["']?/,
    /"Price"\s*:\s*"?(\d+(?:[.,]\d{1,2})?)["']?/,
    /class=["'][^"']*price[^"']*["'][^>]*>\s*[^<₺0-9]*(\d{1,5}(?:[.,]\d{1,2})?)\s*(?:TL|₺)/i,
    /(\d{1,5}[.,]\d{2})\s*(?:TL|₺)/,
    /(?:TL|₺)\s*(\d{1,5}[.,]\d{2})/,
    /(\d{1,5}[.,]\d{2})/,
  ];
  for (const p of pricePatterns) {
    const m = html.match(p);
    if (m) {
      const val = parseFloat(m[1].replace(",", "."));
      if (val > 0 && val < 100_000) return val;
    }
  }
  return null;
}

function extractImage(html: string): string {
  const og = html.match(/property=["']og:image["'][^>]*content=["']([^"']+)["']/i)
    ?? html.match(/content=["']([^"']+)["'][^>]*property=["']og:image["']/i);
  if (og && og[1].startsWith("http")) return og[1];
  const img = html.match(/<img[^>]+src=["'](https?:\/\/[^"']+\.(?:jpg|jpeg|png|webp)[^"']*)["']/i);
  if (img) return img[1];
  return "";
}

function calculateSimilarity(productName: string, html: string): number {
  const words = normalizeProductName(productName)
    .split(/\s+/)
    .filter((w) => w.length > 2);
  if (words.length === 0) return 1;

  const title = extractTitle(html).toLowerCase();
  const text = title + " " + stripHtml(html).substring(0, 6000);
  const matched = words.filter((w) => text.includes(w));
  return matched.length / words.length;
}

function hasCTA(html: string): boolean {
  const lower = html.toLowerCase();
  const ctas = ["sepete ekle", "satın al", "stoka ekle", "sepetim", "sipariş ver",
    "add to cart", "buy now", "stok var", "mevcut", "in stock"];
  return ctas.some((k) => lower.includes(k));
}

function getSupplierNameFromUrl(url: string): string {
  for (const s of SUPPLIERS) {
    if (url.includes(s.domain)) return s.name;
  }
  return "Bilinmeyen";
}

// ─────────────────────────────────────────────────────────────────────────────
// 5. validateProductUrl — URL doğrulama (yapı + HTTP + içerik)
// ─────────────────────────────────────────────────────────────────────────────

interface ValidationResult {
  ok: boolean;
  offer?: BrainOffer;
  reason?: string;
}

export async function validateProductUrl(
  url: string,
  productName: string
): Promise<ValidationResult> {
  // Structure check
  if (!url.startsWith("http")) return { ok: false, reason: "Geçersiz URL" };
  let parsed: URL;
  try {
    parsed = new URL(url);
  } catch {
    return { ok: false, reason: "URL ayrıştırılamadı" };
  }
  if (!parsed.pathname || parsed.pathname === "/") {
    return { ok: false, reason: "Ana sayfa bağlantısı" };
  }
  const urlLower = url.toLowerCase();
  if (SEARCH_URL_PATTERNS.some((p) => urlLower.includes(p))) {
    return { ok: false, reason: "Arama sayfası linki" };
  }
  if (LISTING_URL_PATTERNS.some((p) => urlLower.includes(p))) {
    return { ok: false, reason: "Kategori/liste sayfası linki" };
  }
  if (url.includes("trendyol.com") && TRENDYOL_APP_PATTERNS.some((p) => urlLower.includes(p))) {
    return { ok: false, reason: "Trendyol uygulama yönlendirme linki" };
  }

  // HTTP fetch
  const { html, status, ok, finalUrl } = await fetchSupplierPage(url);
  const supplierName = getSupplierNameFromUrl(url);

  if (!ok) {
    const linkBroken = url.includes("trendyol.com") && status === 403;
    return {
      ok: false,
      reason: `HTTP ${status} — ${
        status === 404 || status === 410
          ? "Ürün bulunamadı"
          : status === 403
          ? "Bot koruması (403)"
          : status === "TIMEOUT"
          ? "Zaman aşımı"
          : "Erişilemiyor"
      }`,
      // If it's Trendyol 403, we surface it as a broken offer anyway
      ...(linkBroken && {
        offer: {
          supplier: supplierName,
          title: productName,
          price: 0,
          url: finalUrl || url,
          imageUrl: "",
          linkBroken: true,
          httpStatus: status,
          verified: false,
          similarityScore: 0,
        },
      }),
    };
  }

  if (!html) {
    // Got a 200 but no HTML (SPA or binary content)
    // We accept it as "valid but unverified"
    const offer: BrainOffer = {
      supplier: supplierName,
      title: productName,
      price: 0,
      url: finalUrl || url,
      imageUrl: "",
      linkBroken: false,
      httpStatus: status,
      verified: false,
      similarityScore: 0.5,
    };
    return { ok: true, offer };
  }

  // Content validation
  const similarity = calculateSimilarity(productName, html);
  if (similarity < 0.45) {
    return {
      ok: false,
      reason: `Düşük benzerlik (${Math.round(similarity * 100)}%) — farklı ürün sayfası`,
    };
  }

  const price = extractPrice(html);
  if (!price) {
    return { ok: false, reason: "Sayfada fiyat bulunamadı" };
  }

  const imageUrl = extractImage(html);
  const cta = hasCTA(html);
  if (!cta) {
    return { ok: false, reason: "Sepete ekle / stok göstergesi yok" };
  }

  const title = extractTitle(html) || productName;
  const offer: BrainOffer = {
    supplier: supplierName,
    title,
    price,
    url: finalUrl || url,
    imageUrl,
    linkBroken: false,
    httpStatus: status,
    verified: (status as number) >= 200 && (status as number) < 300,
    similarityScore: similarity,
  };
  return { ok: true, offer };
}

// ─────────────────────────────────────────────────────────────────────────────
// 6. calculateBestOffer — en ucuz sağlam tedarikçi
// ─────────────────────────────────────────────────────────────────────────────

export function calculateBestOffer(offers: BrainOffer[]): BrainOffer | null {
  if (offers.length === 0) return null;

  // Prefer non-Trendyol, non-broken, highest price confidence
  const prioritized = [...offers].sort((a, b) => {
    const aTrendyol = a.supplier === "Trendyol" ? 1 : 0;
    const bTrendyol = b.supplier === "Trendyol" ? 1 : 0;
    if (aTrendyol !== bTrendyol) return aTrendyol - bTrendyol;
    if (a.linkBroken !== b.linkBroken) return a.linkBroken ? 1 : -1;
    if (a.verified !== b.verified) return a.verified ? -1 : 1;
    if (a.price !== b.price) {
      if (a.price === 0) return 1;
      if (b.price === 0) return -1;
      return a.price - b.price;
    }
    return 0;
  });

  return prioritized[0] ?? null;
}

// ─────────────────────────────────────────────────────────────────────────────
// 7. findRealProduct — tam orkestrasyon
// ─────────────────────────────────────────────────────────────────────────────

export async function findRealProduct(productName: string): Promise<BrainResult> {
  const normalized = normalizeProductName(productName);
  const rejected: RejectedCandidate[] = [];
  const validOffers: BrainOffer[] = [];
  const supplierSearchUrls = buildSupplierSearchUrls(normalized);

  for (const { supplier, searchUrl } of supplierSearchUrls) {
    if (validOffers.length >= 5) break;

    // Fetch search results page
    const { html, status, ok } = await fetchSupplierPage(searchUrl);

    if (!ok || !html) {
      rejected.push({
        url: searchUrl,
        supplier: supplier.name,
        reason: `Arama sayfası erişilemiyor (${status}) — ${
          status === 403 || status === 429
            ? "bot koruması"
            : status === "TIMEOUT"
            ? "zaman aşımı"
            : `HTTP ${status}`
        }`,
      });
      continue;
    }

    // Extract product link candidates from search results
    const candidates = extractProductCandidates(html, supplier, 4);

    if (candidates.length === 0) {
      rejected.push({
        url: searchUrl,
        supplier: supplier.name,
        reason: "Arama sonuçlarında ürün linki bulunamadı (SPA veya JS ile yükleniyor olabilir)",
      });
      continue;
    }

    // Validate each candidate
    let foundFromSupplier = false;
    for (const candidateUrl of candidates) {
      if (validOffers.length >= 5) break;
      const validation = await validateProductUrl(candidateUrl, normalized);
      if (validation.ok && validation.offer) {
        if (!validOffers.some((o) => o.url === validation.offer!.url)) {
          validOffers.push(validation.offer);
          foundFromSupplier = true;
        }
      } else {
        rejected.push({
          url: candidateUrl,
          supplier: supplier.name,
          reason: validation.reason ?? "Doğrulama başarısız",
        });
      }
    }

    if (!foundFromSupplier && candidates.length > 0) {
      // Already tracked individual rejections above
    }
  }

  const bestOffer = calculateBestOffer(validOffers);
  const nonTrendyol = validOffers.filter((o) => o.supplier !== "Trendyol").length;

  let message: string;
  if (validOffers.length === 0) {
    message =
      "Gerçek ürün bulunamadı — tedarikçi siteleri bot koruması uyguluyor veya ürün mevcut değil.";
  } else {
    message = `${validOffers.length} tedarikçide bulundu, ${nonTrendyol} Trendyol dışı. En ucuz: ${bestOffer?.supplier ?? "—"} (₺${bestOffer?.price ?? 0})`;
  }

  return {
    ok: validOffers.length > 0,
    query: productName,
    bestOffer,
    offers: validOffers,
    rejected,
    message,
  };
}
